# Évolution de Tao

Lire README.md et docs/theory.json. Préserver le modèle seed + héritage ; ne pas imposer cinq centres.

Une modification part d’un résidu reproductible lié à une histoire. Expliquer le résultat souhaité, les contraintes, la preuve attendue et le coût de complexité. Chercher la plus petite expérience utile. Préserver les cas non intégrés ; ne pas confondre répétition, traitement et résolution.

Avant de retenir une modification : exécuter `bash scripts/verify.sh`, conserver les résultats et un contre-exemple pertinent. Une mutation de schéma exige une migration et un retour arrière. Les sources, la mémoire privée et le runtime installé sont distincts.

Ne pas lire des secrets, pousser vers un remote, publier, installer des dépendances ou modifier la politique d’autorité sans instruction du propriétaire. Ne pas remplacer une erreur réelle par un indicateur positif. Aucun appel IA automatique ne doit apparaître dans la boucle basale.
