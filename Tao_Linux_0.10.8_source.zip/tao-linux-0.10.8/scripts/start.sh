#!/usr/bin/env bash
# One explicit local setup, then continue in Tao's browser interface.
set -euo pipefail
TAO_SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$TAO_SOURCE_DIR"
if [[ $# -ne 0 ]]; then
  echo 'Usage : bash scripts/start.sh' >&2
  exit 2
fi
if ! command -v python3 >/dev/null || ! command -v git >/dev/null; then
  echo 'Python 3.9+ et Git sont nécessaires. Installe les moyens manquants, puis relance cette commande.' >&2
  exit 1
fi
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else "Python 3.9 ou plus récent est nécessaire.")'
echo 'Vérification des sources de Tao…'
bash scripts/verify.sh
echo 'Installation et démarrage de Tao…'
bash bootstrap/install.sh
"${HOME}/.local/bin/tao" doctor --require-running
echo 'Tao est démarré. Ouvre l’adresse locale affichée ci-dessus : le centre principal C₀ t’accueillera.'
echo 'La connexion et un premier échange confirmeront les moyens du fournisseur ; aucun appel IA n’a été lancé par cette commande.'
