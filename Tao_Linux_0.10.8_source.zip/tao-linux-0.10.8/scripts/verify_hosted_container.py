#!/usr/bin/env python3
"""Real container smoke test with synthetic owner data; no AI account or call.

Run after docker build -f deployment/Dockerfile.hosted -t tao-hosted:test .
The volume belongs only to this test and is removed after its two containers.
"""
import hashlib
import http.client
import json
import re
import secrets
import subprocess
import time


def docker(*args):
    return subprocess.run(['docker', *args], check=True, capture_output=True, text=True,
                          timeout=120).stdout.strip()


def main():
    volume = 'tao-smoke-' + secrets.token_hex(8)
    code = secrets.token_urlsafe(32)
    password = secrets.token_urlsafe(32)
    origin = 'https://tao-hosted.test'
    cookie = None
    token = 'setup'
    container = None
    docker('volume', 'create', volume)

    def request(path, body=None, authenticated=True, host='tao-hosted.test'):
        headers = {'Host': host}
        if authenticated and cookie: headers['Cookie'] = cookie
        raw = None
        if body is not None:
            raw = json.dumps(body).encode()
            headers.update({'Origin': origin, 'Content-Type': 'application/json',
                            'X-Tao-Token': token})
        conn = http.client.HTTPConnection('127.0.0.1', port, timeout=5)
        try:
            conn.request('POST' if body is not None else 'GET', path, raw, headers)
            response = conn.getresponse()
            return response.status, response.read(), dict(response.getheaders())
        finally: conn.close()

    def boot():
        nonlocal container, port
        container = docker('run', '-d', '--rm', '-p', '127.0.0.1::8080',
                           '-v', volume + ':/data',
                           '-e', 'TAO_HOST_ORIGIN=' + origin,
                           '-e', 'TAO_HOST_SETUP_SHA256=' + hashlib.sha256(code.encode()).hexdigest(),
                           'tao-hosted:test')
        port = int(docker('port', container, '8080/tcp').rsplit(':', 1)[1])
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            try:
                status, raw, _ = request('/health', authenticated=False,
                                         host='healthcheck.railway.app')
                if status == 200 and json.loads(raw) == {'ok': True}: return
            except (OSError, http.client.HTTPException, ValueError): pass
            time.sleep(.3)
        # Synthetic installation only; omit raw container logs to avoid ever
        # teaching this check to expose a credential when reused elsewhere.
        raise AssertionError('Hosted container did not become healthy')

    try:
        port = 0
        boot()
        assert request('/state', authenticated=False)[0] == 401
        assert request('/state', authenticated=False, host='healthcheck.railway.app')[0] == 403
        status, _, headers = request('/host/setup', {'code': code, 'password': password}, authenticated=False)
        assert status == 200, 'Owner activation failed'
        cookie = headers['Set-Cookie'].split(';', 1)[0]
        assert all(item in headers['Set-Cookie'] for item in ['Secure', 'HttpOnly', 'SameSite=Strict'])
        status, page, _ = request('/')
        assert status == 200
        # The primary hosted entry point is the center cockpit.  Keep the
        # legacy house available below, but do not make its old navigation
        # link part of the hosted deployment contract.
        assert b'tao.center.interface.v1' in page
        assert b'src="/assets/tao-center.js"' in page
        status, house, _ = request('/explore?world=main&lang=fr')
        assert status == 200
        assert b'href="/host/ai"' in house and b'href="/host/account"' in house
        bootstrap = re.search(
            rb'<script id="tao-bootstrap" type="application/json">(.*?)</script>',
            page, re.DOTALL)
        assert bootstrap is not None, 'Center cockpit bootstrap is missing'
        token = json.loads(bootstrap.group(1))['token']
        assert request('/api/dialogue/memory', {'text': 'Mémoire fictive conservée après redéploiement.', 'revision': 0})[0] == 200
        assert request('/host/ai')[0] == 200
        # Tini is PID1; the Python supervisor and node run as the owner account.
        check = """import json,os
from pathlib import Path
children=Path('/proc/1/task/1/children').read_text().split()
supervisors=[p for p in children if b'/app/deployment/hosted.py' in Path('/proc/'+p+'/cmdline').read_bytes()]
assert len(supervisors)==1
assert os.stat('/proc/'+supervisors[0]).st_uid == 1000
pid=json.loads(Path('/data/node/pid.json').read_text())['pid']
assert os.stat('/proc/'+str(pid)).st_uid == 1000
assert Path('/data/source/.git').is_dir()
Path('/data/source/smoke-preserve.txt').write_text('A local edit must survive image replacement.')
"""
        docker('exec', '--user', '1000', container, 'python', '-c', check)
        version = docker('exec', '--user', '1000', container, 'codex', '--version')
        assert version.startswith('codex-cli '), 'Pinned CLI not available'
        docker('stop', container); container = None
        boot()
        status, state, _ = request('/state')
        assert status == 200, 'Owner session did not survive container replacement'
        assert json.loads(state)['dialogue']['memory'] == 'Mémoire fictive conservée après redéploiement.'
        docker('exec', '--user', '1000', container, 'python', '-c',
               "from pathlib import Path; assert Path('/data/source/smoke-preserve.txt').read_text() == 'A local edit must survive image replacement.'")
        assert request('/host/setup', {'code': code, 'password': password}, authenticated=False)[0] == 409
        assert request('/host/logout', {})[0] == 200
        assert request('/state')[0] == 401
        print('Hosted container: private access, non-root services, persistent memory/session/source, one-time activation and logout verified. No AI call.')
    finally:
        if container:
            subprocess.run(['docker', 'rm', '-f', container], capture_output=True, timeout=20)
        subprocess.run(['docker', 'volume', 'rm', volume], capture_output=True, timeout=20)


if __name__ == '__main__': main()
