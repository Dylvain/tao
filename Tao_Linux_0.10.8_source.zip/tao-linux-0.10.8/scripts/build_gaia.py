#!/usr/bin/env python3
"""Build an inert, portable public portal from explicitly selected inputs.

No private Tao state, account, environment secret or network service is read.
An installer is only published after verification against an explicitly named
trust key. Preview source archives remain clearly labelled review material.
"""
import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from gaia import catalogue
from scripts.release_signing import (DESKTOP_MANIFEST_NAME, DESKTOP_METADATA_NAME,
                                     DESKTOP_SIGNATURE_NAME, inspect_release,
                                     parse_desktop_manifest, parse_manifest, verify,
                                     verify_desktop)

LEGACY_STATIC_FILES = ('index.html', 'style.css', 'app.js')
STATIC_FILES = (*LEGACY_STATIC_FILES, 'birth.json')
SITE_SCHEMA = 'gaia.static-site.v1'
MAX_FILE_BYTES = 128 * 1024 * 1024
MAX_SITE_BYTES = 256 * 1024 * 1024
SECURITY_HEADERS = {
    'Content-Security-Policy': "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'; object-src 'none'",
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    'X-Frame-Options': 'DENY',
}

BIRTH_LOOP = ['persist', 'observe', 'compare', 'residual', 'vary', 'test', 'retain_or_rollback']
BIRTH_INCLUDED = ['runtime', 'default_genome', 'reflexes', 'development_kit',
                  'builtin_heritage', 'canonical_theory']
BIRTH_EXCLUDED = ['identity', 'private_memory', 'conversations', 'credentials',
                  'permissions', 'provider_configuration']


def read_regular(path, limit=MAX_FILE_BYTES):
    path = Path(path)
    if '..' in path.parts:
        raise ValueError('Traversée de dossier refusée.')
    path = path.absolute()
    with ExitStack() as stack:
        directory = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        stack.callback(os.close, directory)
        for part in path.parts[1:-1]:
            directory = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
            stack.callback(os.close, directory)
        descriptor = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
        stack.callback(os.close, descriptor)
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > limit:
            raise ValueError('Fichier public non régulier, lié ou trop volumineux.')
        with os.fdopen(descriptor, 'rb', closefd=False) as stream:
            data = stream.read(limit + 1)
        after = os.fstat(descriptor)
        fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        if len(data) > limit or len(data) != before.st_size or any(getattr(before, f) != getattr(after, f) for f in fields):
            raise ValueError('Fichier public modifié pendant sa lecture.')
        return data


def parse_json(data):
    return json.loads(data, object_pairs_hook=catalogue.unique_object)


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()


def validate_birth_contract(value):
    """Accept only Gaïa's inert public seed contract, never private authority."""
    if (not isinstance(value, dict) or
            set(value) != {'schema', 'status', 'subject', 'seed', 'inheritance',
                           'birth', 'adaptation', 'permissions', 'executable'} or
            value['schema'] != 'tao.gaia.birth.v1' or
            value['status'] != 'public_inert_contract' or
            value['subject'] != 'new_sovereign_tao' or value['executable'] is not False):
        raise ValueError('Contrat public de naissance invalide.')
    seed = value['seed']
    if (not isinstance(seed, dict) or set(seed) != {'observer_model', 'specialized_centers', 'basal_loop'} or
            seed['observer_model'] != 'C0' or seed['specialized_centers'] != [] or
            seed['basal_loop'] != BIRTH_LOOP):
        raise ValueError('Graine publique invalide.')
    inheritance = value['inheritance']
    if (not isinstance(inheritance, dict) or set(inheritance) != {'included', 'optional', 'excluded'} or
            inheritance['included'] != BIRTH_INCLUDED or
            inheritance['optional'] != ['explicitly_selected_inert_methods'] or
            inheritance['excluded'] != BIRTH_EXCLUDED):
        raise ValueError('Héritage public invalide.')
    birth = value['birth']
    if (not isinstance(birth, dict) or set(birth) != {'location', 'identity', 'story_authority', 'activation'} or
            birth != {'location': 'owner_selected_machine', 'identity': 'fresh_local',
                      'story_authority': 'human', 'activation': 'manual'}):
        raise ValueError('Conditions de naissance invalides.')
    adaptation = value['adaptation']
    if (not isinstance(adaptation, dict) or
            set(adaptation) != {'machine_observation', 'reasoner', 'reasoner_required',
                                'automatic_ai_calls', 'first_center'} or
            adaptation != {'machine_observation': 'local_explicit', 'reasoner': 'owner_selected',
                           'reasoner_required': False, 'automatic_ai_calls': False,
                           'first_center': 'only_after_reproducible_residual_and_explicit_owner_decision'}):
        raise ValueError('Contrat d’adaptation invalide.')
    if value['permissions'] != {'read': 'none', 'execution': 'not_granted'}:
        raise ValueError('Un contrat public ne transmet aucune permission.')
    return value


def allowed_names(version, mode, legacy=False, desktop=False):
    names = {*(LEGACY_STATIC_FILES if legacy else STATIC_FILES),
             'catalogue.json', 'portal.json', 'release.json', 'SHA256SUMS',
             '_headers', 'Tao_Linux_' + version + '_source.zip'}
    if mode == 'signed':
        names.update({'TAO_LINUX_' + version + '.run', 'release.sig', 'signing.json', 'release-public.pem'})
        if desktop:
            names.update({f'Tao_Linux_{version}_all.deb', DESKTOP_MANIFEST_NAME,
                          DESKTOP_SIGNATURE_NAME, DESKTOP_METADATA_NAME})
    return names


def load_site(folder, allow_legacy=False):
    """Read and verify one complete immutable-in-memory site snapshot."""
    folder = Path(folder).absolute()
    manifest = parse_json(read_regular(folder / 'site-manifest.json', 32768))
    if not isinstance(manifest, dict) or set(manifest) != {'schema', 'version', 'mode', 'files'}:
        raise ValueError('Manifeste de site invalide.')
    version, mode = manifest['version'], manifest['mode']
    if (manifest['schema'] != SITE_SCHEMA or not isinstance(version, str) or
            not re.fullmatch(r'(?:0|[1-9][0-9]{0,4})\.(?:0|[1-9][0-9]{0,4})\.(?:0|[1-9][0-9]{0,4})', version) or mode not in ('preview', 'signed')):
        raise ValueError('Version ou mode de site invalide.')
    files = manifest['files']
    file_names = set(files) if isinstance(files, dict) else set()
    desktop = mode == 'signed' and file_names == allowed_names(version, mode, desktop=True)
    legacy = (allow_legacy and isinstance(files, dict) and
              file_names == allowed_names(version, mode, legacy=True))
    if (not isinstance(files, dict) or
            (file_names != allowed_names(version, mode) and not desktop and not legacy)):
        raise ValueError('Liste de fichiers publics invalide.')
    result, total = {}, 0
    for name, metadata in files.items():
        if (not isinstance(metadata, dict) or set(metadata) != {'sha256', 'size'} or
                type(metadata['size']) is not int or not 0 <= metadata['size'] <= MAX_FILE_BYTES or
                not isinstance(metadata['sha256'], str) or not re.fullmatch(r'[a-f0-9]{64}', metadata['sha256'])):
            raise ValueError('Empreinte de fichier public invalide.')
        total += metadata['size']
        if total > MAX_SITE_BYTES:
            raise ValueError('Site public trop volumineux.')
        data = read_regular(folder / name, metadata['size'])
        if len(data) != metadata['size'] or hashlib.sha256(data).hexdigest() != metadata['sha256']:
            raise ValueError('Un fichier public diffère de la version construite.')
        result[name] = data
    portal = parse_json(result['portal.json'])
    installer = 'TAO_LINUX_' + version + '.run'
    source = 'Tao_Linux_' + version + '_source.zip'
    desktop_installer = f'Tao_Linux_{version}_all.deb'
    portal_keys = {'version', 'download_status', 'reason', 'installer',
                   'source_archive', 'signature'}
    if desktop:
        portal_keys.update({'desktop_installer', 'desktop_signature'})
    if (not isinstance(portal, dict) or set(portal) != portal_keys or
            portal['version'] != version or portal['download_status'] != mode or
            not isinstance(portal['reason'], str) or not 1 <= len(portal['reason']) <= 1000 or
            portal['source_archive'] != {'name': source, 'url': source}):
        raise ValueError('Le portail ne correspond pas à la version construite.')
    release = parse_manifest(result['release.json'], version=version)
    for name, record in release['files'].items():
        if name in result and (len(result[name]) != record['size'] or hashlib.sha256(result[name]).hexdigest() != record['sha256']):
            raise ValueError('Le téléchargement ne correspond pas à sa distribution.')
    desktop_release = None
    if desktop:
        desktop_release = parse_desktop_manifest(result[DESKTOP_MANIFEST_NAME], version=version)
        desktop_record = desktop_release['package']
        if (desktop_release['release_manifest_sha256'] != hashlib.sha256(result['release.json']).hexdigest() or
                desktop_record['name'] != desktop_installer or
                len(result[desktop_installer]) != desktop_record['size'] or
                hashlib.sha256(result[desktop_installer]).hexdigest() != desktop_record['sha256']):
            raise ValueError('Le paquet graphique ne correspond pas à sa release source.')
    checksum_rows = [(name, release['files'][name])
                     for name in release['files'] if name in result]
    if desktop_release is not None:
        checksum_rows.append((desktop_installer, desktop_release['package']))
    expected_checksums = ''.join(record['sha256'] + '  ' + name + '\n'
                                 for name, record in checksum_rows).encode()
    if result['SHA256SUMS'] != expected_checksums:
        raise ValueError('Empreintes publiques incohérentes.')
    if mode == 'preview':
        if portal['installer'] is not None or portal['signature'] is not None:
            raise ValueError('Un aperçu ne peut pas annoncer un installateur signé.')
    else:
        if portal['installer'] != {'name': installer, 'url': installer}:
            raise ValueError('Lien de téléchargement invalide.')
        if desktop and portal['desktop_installer'] != {
                'name': desktop_installer, 'url': desktop_installer}:
            raise ValueError('Lien du paquet graphique invalide.')
        # Recheck cryptographic consistency under the bundled key. This does NOT
        # independently trust that key: authority comes from the explicit key
        # at build time and the trusted deployment, not this descriptive copy.
        with tempfile.TemporaryDirectory(prefix='gaia-consistency-') as temp:
            base = Path(temp); snapshot = base / 'release'; snapshot.mkdir()
            for name in (*release['files'], 'release.json', 'release.sig', 'signing.json'):
                (snapshot / name).write_bytes(result[name])
            if desktop:
                for name in (desktop_installer, DESKTOP_MANIFEST_NAME,
                             DESKTOP_SIGNATURE_NAME, DESKTOP_METADATA_NAME):
                    (snapshot / name).write_bytes(result[name])
            key = base / 'public.pem'; key.write_bytes(result['release-public.pem'])
            checked = verify(snapshot, key, version=version)
            desktop_checked = verify_desktop(snapshot, key, version=version) if desktop else None
        expected_signature = {'manifest': 'release.json', 'signature': 'release.sig',
                              'metadata': 'signing.json', 'public_key': 'release-public.pem',
                              'public_key_sha256': checked['public_key_sha256']}
        if portal['signature'] != expected_signature:
            raise ValueError('Description de signature invalide.')
        if desktop:
            expected_desktop_signature = {
                'manifest': DESKTOP_MANIFEST_NAME,
                'signature': DESKTOP_SIGNATURE_NAME,
                'metadata': DESKTOP_METADATA_NAME,
                'public_key': 'release-public.pem',
                'public_key_sha256': desktop_checked['public_key_sha256'],
            }
            if portal['desktop_signature'] != expected_desktop_signature:
                raise ValueError('Description de signature du paquet graphique invalide.')
    catalogue.validate(parse_json(result['catalogue.json']))
    if not legacy:
        validate_birth_contract(parse_json(result['birth.json']))
    return manifest, result


def build(release_dir=None, output=None, trusted_key=None):
    release_dir = Path(release_dir or ROOT / 'dist')
    output = Path(output or release_dir / 'gaia')
    if '..' in release_dir.parts or '..' in output.parts:
        raise ValueError('Traversée de dossier refusée.')
    release_dir, output = release_dir.absolute(), output.absolute()
    if output == release_dir or output == ROOT or output in ROOT.parents:
        raise ValueError('Choisir un dossier de sortie distinct des sources et de la distribution.')
    if any(p.is_symlink() for p in (output, *output.parents)):
        raise ValueError('Destination symbolique refusée.')
    # Inspect declared files only. Copy the bytes, then validate the snapshot
    # again so a changed input cannot be silently published during a build.
    release = inspect_release(release_dir)
    version = release['version']
    payloads = {name: read_regular(release_dir / name) for name in release['files']}
    manifest_bytes = read_regular(release_dir / 'release.json', 16384)
    public_key = None
    desktop_installer = f'Tao_Linux_{version}_all.deb'
    desktop_files = (desktop_installer, DESKTOP_MANIFEST_NAME,
                     DESKTOP_SIGNATURE_NAME, DESKTOP_METADATA_NAME)
    desktop_release = None
    desktop_signature = None
    with tempfile.TemporaryDirectory(prefix='gaia-verify-') as temp:
        snapshot = Path(temp)
        for name, data in payloads.items():
            (snapshot / name).write_bytes(data)
        (snapshot / 'release.json').write_bytes(manifest_bytes)
        snapshot_manifest = inspect_release(snapshot, version=version)
        if snapshot_manifest != release:
            raise ValueError('La distribution a changé pendant sa préparation.')
        signature = None
        if trusted_key is not None:
            original_key = Path(trusted_key)
            if '..' in original_key.parts:
                raise ValueError('Traversée de dossier refusée dans la clé.')
            original_key = original_key.absolute()
            if any(original_key == base or base in original_key.parents for base in (release_dir, output)):
                raise ValueError('La clé de confiance doit être extérieure à la distribution et au site.')
            public_key = read_regular(original_key, 16384)
            for name in ('release.sig', 'signing.json'):
                (snapshot / name).write_bytes(read_regular(release_dir / name, 16384))
            # The trusted key is outside the release snapshot by construction.
            key_path = snapshot.parent / (snapshot.name + '-trusted.pem')
            try:
                with key_path.open('xb') as stream:
                    stream.write(public_key)
                checked = verify(snapshot, key_path, version=version)
                presence = [os.path.lexists(release_dir / name) for name in desktop_files]
                if any(presence) and not all(presence):
                    raise ValueError('Le paquet graphique et toutes ses preuves signées sont requis ensemble.')
                if all(presence):
                    for name in desktop_files:
                        limit = MAX_FILE_BYTES if name == desktop_installer else 16384
                        (snapshot / name).write_bytes(read_regular(release_dir / name, limit))
                    desktop_release = verify_desktop(snapshot, key_path, version=version)
                    desktop_signature = {
                        'manifest': DESKTOP_MANIFEST_NAME,
                        'signature': DESKTOP_SIGNATURE_NAME,
                        'metadata': DESKTOP_METADATA_NAME,
                        'public_key': 'release-public.pem',
                        'public_key_sha256': desktop_release['public_key_sha256'],
                    }
            finally:
                key_path.unlink(missing_ok=True)
            signature = {'manifest': 'release.json', 'signature': 'release.sig',
                         'metadata': 'signing.json', 'public_key': 'release-public.pem',
                         'public_key_sha256': checked['public_key_sha256']}
            payloads.update({name: read_regular(snapshot / name, 16384)
                             for name in ('release.sig', 'signing.json')})
            if desktop_release is not None:
                payloads.update({name: read_regular(
                    snapshot / name, MAX_FILE_BYTES if name == desktop_installer else 16384)
                    for name in desktop_files})
    mode = 'signed' if signature else 'preview'
    installer = 'TAO_LINUX_' + version + '.run'
    source = 'Tao_Linux_' + version + '_source.zip'
    if mode == 'preview':
        payloads.pop(installer)
    else:
        payloads['release-public.pem'] = public_key
    portal = {'version': version, 'download_status': mode,
              'reason': ('Version signée vérifiée lors de la construction du site. Vérifier la clé de confiance avant installation.'
                         if signature else 'Sources expérimentales disponibles pour revue. L’installateur public attend une signature vérifiée.'),
              'installer': {'name': installer, 'url': installer} if signature else None,
              'source_archive': {'name': source, 'url': source}, 'signature': signature}
    if desktop_release is not None:
        portal.update({
            'desktop_installer': {'name': desktop_installer, 'url': desktop_installer},
            'desktop_signature': desktop_signature,
        })
    payloads.update({name: read_regular(ROOT / 'gaia' / name, 2 * 1024 * 1024) for name in STATIC_FILES})
    payloads['catalogue.json'] = json_bytes(catalogue.load())
    payloads['portal.json'] = json_bytes(portal)
    payloads['release.json'] = manifest_bytes
    visible_release = [name for name in release['files'] if name in payloads]
    checksum_rows = [(name, release['files'][name]) for name in visible_release]
    if desktop_release is not None:
        checksum_rows.append((desktop_installer, desktop_release['package']))
    payloads['SHA256SUMS'] = ''.join(record['sha256'] + '  ' + name + '\n'
                                    for name, record in checksum_rows).encode()
    payloads['_headers'] = ('/*\n' + ''.join('  ' + k + ': ' + v + '\n' for k, v in SECURITY_HEADERS.items())).encode()
    if (set(payloads) != allowed_names(version, mode, desktop=desktop_release is not None) or
            sum(map(len, payloads.values())) > MAX_SITE_BYTES):
        raise ValueError('Ensemble public invalide ou trop volumineux.')
    site_manifest = {'schema': SITE_SCHEMA, 'version': version, 'mode': mode,
                     'files': {name: {'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data)}
                               for name, data in sorted(payloads.items())}}
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        old, _ = load_site(output, allow_legacy=True)
        if {p.name for p in output.iterdir()} != set(old['files']) | {'site-manifest.json'}:
            raise ValueError('La destination contient des fichiers non gérés ; aucun remplacement.')
    staging = Path(tempfile.mkdtemp(prefix='.gaia-build-', dir=output.parent))
    backup = None
    try:
        for name, data in payloads.items():
            (staging / name).write_bytes(data)
        (staging / 'site-manifest.json').write_bytes(json_bytes(site_manifest))
        # This bundle contains public bytes only; the serving process is non-root.
        for published in staging.iterdir():
            published.chmod(0o644)
        staging.chmod(0o755)
        load_site(staging)
        if output.exists():
            backup = Path(tempfile.mkdtemp(prefix='.gaia-previous-', dir=output.parent))
            backup.rmdir()
            os.replace(output, backup)
        try:
            os.replace(staging, output)
        except BaseException:
            if backup is not None:
                os.replace(backup, output)
                backup = None
            raise
        if backup is not None:
            shutil.rmtree(backup)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return {'version': version, 'mode': mode, 'output': str(output),
            'files': len(payloads), 'installer_published': signature is not None,
            'desktop_installer_published': desktop_release is not None}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Construire Gaïa, portail statique de Tao')
    parser.add_argument('--release-dir', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--trusted-key', type=Path)
    args = parser.parse_args()
    try:
        print(json.dumps(build(args.release_dir, args.output, args.trusted_key), ensure_ascii=False))
    except (ValueError, OSError) as exc:
        parser.exit(1, str(exc) + '\n')
