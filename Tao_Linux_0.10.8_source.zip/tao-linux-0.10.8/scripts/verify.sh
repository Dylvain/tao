#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
import py_compile
import sys
from pathlib import Path

sys.path.insert(0, 'bootstrap')
from tao_runtime import RUNTIME_FILES

paths = [Path('bootstrap') / name for name in RUNTIME_FILES]
paths += [Path(name) for name in (
    'bootstrap/install.py', 'deployment/hosted.py', 'genesis_service.py',
    'gaia/catalogue.py',
)]
paths += sorted(Path('scripts').glob('*.py'))
for path in paths:
    py_compile.compile(str(path), doraise=True)
PY
python3 -m unittest discover -s tests -v
