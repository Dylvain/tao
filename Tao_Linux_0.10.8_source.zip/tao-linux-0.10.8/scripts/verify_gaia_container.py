#!/usr/bin/env python3
"""Qualify the real public preview container without accounts or AI calls.

Run after: docker build --file Dockerfile --tag tao-gaia:test .
A named, read-only container uses --network none. HTTP probes run through docker
exec against its own loopback interface; no host ports or volumes are needed.
"""
import base64
import json
import secrets
import subprocess
import sys
import time

VERSION = '0.10.8'
MAX_RESPONSE_BYTES = 128 * 1024 * 1024

# Return bounded structured metadata. In particular, the source archive never
# travels through docker exec stdout: only its digest, size and prefix do.
HTTP_PROBE = r'''
import base64, hashlib, http.client, json, sys
request = json.loads(sys.argv[1])
limit = 128 * 1024 * 1024 if request['summary'] else 2 * 1024 * 1024
conn = http.client.HTTPConnection('127.0.0.1', 8080, timeout=5)
try:
    body = base64.b64decode(request['body_b64'], validate=True) if request['body_b64'] is not None else None
    conn.request(request['method'], request['path'], body=body,
                 headers={'Content-Type': 'application/json'} if body is not None else {})
    response = conn.getresponse()
    digest = hashlib.sha256()
    size, prefix, chunks = 0, b'', []
    while True:
        chunk = response.read(min(65536, limit - size + 1))
        if not chunk:
            break
        size += len(chunk)
        if size > limit:
            raise ValueError('Response exceeded the smoke-test bound')
        digest.update(chunk)
        prefix = (prefix + chunk)[:4]
        if not request['summary']:
            chunks.append(chunk)
    result = {'status': response.status,
              'headers': {key.lower(): value for key, value in response.getheaders()},
              'size': size, 'sha256': digest.hexdigest(),
              'prefix_b64': base64.b64encode(prefix).decode('ascii')}
    if not request['summary']:
        result['body_b64'] = base64.b64encode(b''.join(chunks)).decode('ascii')
    print(json.dumps(result))
except (OSError, http.client.HTTPException, ValueError) as exc:
    print(json.dumps({'error': type(exc).__name__, 'message': str(exc)}))
finally:
    conn.close()
'''


def docker(*args):
    return subprocess.run(['docker', *args], check=True, capture_output=True,
                          text=True, timeout=30).stdout.strip()


def diagnostics(container_name, error):
    """Keep the failed container until bounded public-preview logs are read."""
    detail = getattr(error, 'stderr', None)
    if detail:
        print('Docker command error: ' + str(detail)[-4096:], file=sys.stderr)
    try:
        result = subprocess.run(['docker', 'logs', '--tail', '50', container_name],
                                capture_output=True, text=True, timeout=15)
        print('Gaia container diagnostics (last 50 log lines, at most 16 KiB):', file=sys.stderr)
        print((result.stdout + result.stderr)[-16384:], file=sys.stderr)
    except (OSError, subprocess.TimeoutExpired) as exc:
        print('Container diagnostics unavailable: ' + str(exc), file=sys.stderr)


def main():
    container_name = 'gaia-smoke-' + secrets.token_hex(8)
    expected_health = {'ok': True, 'version': VERSION, 'integrity_verified': True,
                       'download_status': 'preview', 'signature_verified_at_build': False,
                       'private_host': False}

    def probe(path, method='GET', body=None, summary=False):
        args = {'path': path, 'method': method, 'summary': summary,
                'body_b64': base64.b64encode(body).decode('ascii') if body is not None else None}
        result = json.loads(docker('exec', container_name, 'python', '-c', HTTP_PROBE,
                                   json.dumps(args)))
        if 'error' in result:
            raise OSError(result['error'] + ': ' + result['message'])
        assert 0 <= result['size'] <= MAX_RESPONSE_BYTES, 'Response exceeded the smoke-test bound'
        return result

    def request(path, method='GET', body=None):
        result = probe(path, method, body)
        return result['status'], base64.b64decode(result['body_b64'], validate=True), result['headers']

    try:
        # Deliberately omit --rm: early process exits must retain their logs for
        # diagnostics. The preassigned name also permits cleanup after a timeout.
        docker('run', '--name', container_name, '--detach', '--read-only',
               '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges=true',
               '--network', 'none', 'tao-gaia:test')
        assert docker('inspect', '--format', '{{.HostConfig.NetworkMode}}', container_name) == 'none'
        assert docker('inspect', '--format', '{{.HostConfig.ReadonlyRootfs}}', container_name) == 'true'
        assert docker('inspect', '--format', '{{.Config.User}}', container_name).split(':')[0] == '10001'
        deadline = time.monotonic() + 60
        last_error = 'No health response'
        while time.monotonic() < deadline:
            if docker('inspect', '--format', '{{.State.Running}}', container_name) != 'true':
                raise AssertionError('Gaia container exited before readiness')
            try:
                status, raw, _ = request('/health')
                health = json.loads(raw)
                if status == 200 and isinstance(health, dict) and health == expected_health:
                    break
                last_error = 'Unexpected preview health response (HTTP ' + str(status) + ')'
            except (OSError, ValueError, subprocess.CalledProcessError) as exc:
                last_error = str(exc)[:500]
            time.sleep(.25)
        else:
            raise AssertionError('Gaia container did not become healthy: ' + last_error)

        # Check both the configured account and the actual running service UID.
        docker('exec', container_name, 'python', '-c',
               "import os; from pathlib import Path; assert os.getuid() == 10001; "
               "assert os.stat('/proc/1').st_uid == 10001; "
               "assert not Path('/app/dist/gaia/TAO_LINUX_" + VERSION + ".run').exists(); "
               "assert not Path('/app/dist/gaia/Tao_Linux_" + VERSION + "_all.deb').exists()")
        status, page, headers = request('/')
        assert status == 200 and 'Gaïa'.encode('utf-8') in page, 'Gaia landing page missing'
        assert headers.get('x-content-type-options') == 'nosniff'
        assert 'set-cookie' not in headers, 'Public Gaia must not create an owner session'
        status, raw, _ = request('/catalogue.json')
        catalogue = json.loads(raw)
        assert status == 200 and catalogue['schema_version'] == 1 and catalogue['entries']
        assert all(entry.get('executable') is False for entry in catalogue['entries'])
        status, raw, _ = request('/portal.json')
        portal = json.loads(raw)
        assert status == 200 and portal['download_status'] == 'preview' and portal['installer'] is None
        status, raw, _ = request('/release.json')
        release = json.loads(raw)
        assert status == 200 and release['version'] == VERSION
        source_name = 'Tao_Linux_' + VERSION + '_source.zip'
        source = probe('/' + source_name, summary=True)
        assert source['status'] == 200 and base64.b64decode(source['prefix_b64']).startswith(b'PK'), 'Preview source archive missing'
        assert source['size'] == release['files'][source_name]['size']
        assert source['sha256'] == release['files'][source_name]['sha256']
        assert 'body_b64' not in source, 'Archive bytes must not be returned by the probe'
        assert request('/TAO_LINUX_' + VERSION + '.run')[0] == 404, 'Unsigned installer exposed'
        assert request('/Tao_Linux_' + VERSION + '_all.deb')[0] == 404, 'Unsigned desktop package exposed'
        assert request('/bootstrap.sh')[0] == 410, 'Bootstrap execution route must be withdrawn'
        for path in ('/.env', '/.git/config', '/state', '/api/dialogue', '/host/ai',
                     '/bootstrap/tao_node.py', '/genesis_service.py', '/release-private.pem',
                     '/../VERSION.json', '/%2e%2e/VERSION.json'):
            assert request(path)[0] == 404, 'Private or undeclared route exposed: ' + path
        for path in ('/', '/catalogue.json', '/upload', '/api/upload'):
            assert request(path, method='POST', body=b'{"fixture":"inert"}')[0] == 405, 'Public write accepted: ' + path
        assert docker('diff', container_name) == '', 'Public service wrote to the container filesystem'
        print('Gaia container: non-root, read-only, network none, public catalogue and verified source bytes; unsigned installer, private routes and writes refused. No AI call.')
    except BaseException as exc:
        diagnostics(container_name, exc)
        raise
    finally:
        subprocess.run(['docker', 'rm', '-f', container_name], capture_output=True, timeout=20)


if __name__ == '__main__':
    main()
