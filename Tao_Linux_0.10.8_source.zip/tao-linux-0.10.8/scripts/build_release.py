#!/usr/bin/env python3
"""Reproducible releases from an exact, reviewed source allowlist.

Unlisted files are never opened or searched. Extracted sources build without Git;
--strict-git additionally requires tracked HEAD bytes for publishing. Hashes prove
integrity, not the identity of a publisher.
"""
import argparse
import base64
from contextlib import ExitStack
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import uuid
import zipfile

ROOT = Path(__file__).absolute().parents[1]
VERSION = '0.10.8'
UPDATE_CONTRACT = {
    'minimum_runtime': '0.10.7',
    'install_mode': 'explicit',
    'changes': [{
        'fr': 'Empêche le lanceur graphique de remplacer un runtime Tao sain et plus récent.',
        'en': 'Prevents the graphical launcher from replacing a healthy newer Tao runtime.',
    }, {
        'fr': 'Compare strictement les versions numériques et refuse les versions anciennes ou ambiguës.',
        'en': 'Strictly compares numeric versions and rejects older or ambiguous versions.',
    }, {
        'fr': 'Conserve le paquet Debian/Ubuntu signé et le .run comme chemin de mise à jour explicite.',
        'en': 'Keeps the signed Debian/Ubuntu package and the .run explicit update path.',
    }, {
        'fr': 'Ne migre aucun état privé et ne prétend pas prendre en charge les autres systèmes.',
        'en': 'Migrates no private state and makes no support claim for other operating systems.',
    }],
    # Ordinary updates must remain readable without rewriting private state.
    # A future non-empty list is visible to the owner but intentionally blocks
    # this first automatic installer path.
    'state_migrations': [],
}
ALLOWLIST = 'RELEASE_FILES.json'
MAX_FILES = 512
MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024
MAX_ALLOWLIST_BYTES = 128 * 1024
REQUIRED_FILES = {ALLOWLIST, 'VERSION.json', 'docs/theory.json',
                  'bootstrap/tao_theory.py', 'scripts/build_release.py'}


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Clé JSON dupliquée : ' + key)
        result[key] = value
    return result


def _directory_flags():
    # Fail closed when safe, descriptor-based Linux traversal is unavailable.
    if not hasattr(os, 'O_NOFOLLOW') or not hasattr(os, 'O_DIRECTORY'):
        raise ValueError('Construction requise sur un système avec O_NOFOLLOW')
    return os.O_RDONLY | os.O_NOFOLLOW | os.O_DIRECTORY


def _open_root(stack):
    root = Path(ROOT).absolute()
    fd = os.open(root.anchor, _directory_flags())
    stack.callback(os.close, fd)
    for part in root.parts[1:]:
        if part in {'.', '..'}:
            raise ValueError('Racine de distribution non canonique')
        fd = os.open(part, _directory_flags(), dir_fd=fd)
        stack.callback(os.close, fd)
    return fd


def _open_source(root_fd, name, stack):
    parent = root_fd
    for part in name.split('/')[:-1]:
        parent = os.open(part, _directory_flags(), dir_fd=parent)
        stack.callback(os.close, parent)
    fd = os.open(name.split('/')[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                 dir_fd=parent)
    stack.callback(os.close, fd)
    metadata = os.fstat(fd)
    if not stat.S_ISREG(metadata.st_mode):
        raise ValueError('Fichier régulier requis : ' + name)
    return fd, metadata


def _read_source(fd, metadata, name, limit):
    if metadata.st_size > limit:
        raise ValueError('Fichier trop volumineux : ' + name)
    chunks = []
    remaining = metadata.st_size + 1
    while remaining:
        chunk = os.read(fd, min(remaining, 65536))
        if not chunk:
            break
        chunks.append(chunk)
        remaining -= len(chunk)
    data = b''.join(chunks)
    after = os.fstat(fd)
    fields = ('st_size', 'st_mtime_ns', 'st_ctime_ns')
    if len(data) != metadata.st_size or any(getattr(metadata, k) != getattr(after, k) for k in fields):
        raise ValueError('Fichier modifié pendant la construction : ' + name)
    return data


def _validate_names(value):
    if (not isinstance(value, dict) or set(value) != {'schema_version', 'files'}
            or type(value['schema_version']) is not int or value['schema_version'] != 1):
        raise ValueError('Schéma de RELEASE_FILES.json invalide')
    names = value['files']
    if not isinstance(names, list) or not 1 <= len(names) <= MAX_FILES:
        raise ValueError('Liste de fichiers absente ou trop longue')
    seen = set()
    for name in names:
        if (not isinstance(name, str) or not name or len(name) > 240
                or any(character in name for character in '\\:*?[]')
                or any(ord(character) < 32 or ord(character) == 127 for character in name)
                or any(part in {'', '.', '..'} for part in name.split('/'))):
            raise ValueError('Chemin explicite relatif et canonique requis')
        if name in seen:
            raise ValueError('Chemin dupliqué : ' + name)
        seen.add(name)
    if not REQUIRED_FILES <= seen:
        raise ValueError('Fichiers de reconstruction requis absents de la liste')
    return sorted(names)


def source_snapshot():
    """Read only selected regular files; validate every path before contents."""
    try:
        with ExitStack() as stack:
            root_fd = _open_root(stack)
            allow_fd, allow_stat = _open_source(root_fd, ALLOWLIST, stack)
            allow_data = _read_source(allow_fd, allow_stat, ALLOWLIST, MAX_ALLOWLIST_BYTES)
            names = _validate_names(json.loads(allow_data, object_pairs_hook=unique_object))
            records = {}
            total = 0
            for name in names:
                fd, metadata = ((allow_fd, allow_stat) if name == ALLOWLIST
                                else _open_source(root_fd, name, stack))
                if metadata.st_size > MAX_FILE_BYTES:
                    raise ValueError('Fichier trop volumineux : ' + name)
                total += metadata.st_size
                if total > MAX_TOTAL_BYTES:
                    raise ValueError('Sources de distribution trop volumineuses')
                records[name] = (fd, metadata)
            return {name: (allow_data if name == ALLOWLIST
                           else _read_source(fd, metadata, name, MAX_FILE_BYTES))
                    for name, (fd, metadata) in records.items()}
    except OSError as exc:
        raise ValueError('Source absente, inaccessible ou lien symbolique refusé') from exc


def _validate_sources(sources):
    # Compile exactly the Python bytes being archived, without writing bytecode.
    compiled = {name: compile(data, name, 'exec') for name, data in sources.items()
                if name.endswith('.py')}
    versions = json.loads(sources['VERSION.json'], object_pairs_hook=unique_object)
    if versions['node_version'] != VERSION or versions['genesis_version'] != VERSION:
        raise ValueError('Versions de distribution incohérentes')
    expected = versions['theory']
    raw = sources['docs/theory.json']
    if hashlib.sha256(raw).hexdigest() != expected['sha256']:
        raise ValueError('Empreinte du canon différente de VERSION.json')
    namespace = {'__name__': 'release_theory_validation',
                 '__file__': str(Path(ROOT) / 'bootstrap/tao_theory.py')}
    exec(compiled['bootstrap/tao_theory.py'], namespace)
    theory = namespace['validate'](json.loads(raw, object_pairs_hook=unique_object))
    if any(theory['meta'].get(key) != expected[key] for key in ('id', 'version')):
        raise ValueError('Identité ou version du canon incompatible')


def _strict_git(sources):
    """Require the selected snapshot and index to equal the committed HEAD."""
    env = {key: value for key, value in os.environ.items() if not key.startswith('GIT_')}
    command = ['git', '--literal-pathspecs', '-C', str(Path(ROOT).absolute())]

    def git(*args):
        try:
            return subprocess.run(command + list(args), env=env, check=True,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout
        except (OSError, subprocess.CalledProcessError) as exc:
            raise ValueError('Vérification Git stricte indisponible ou dépôt absent') from exc

    top = Path(os.fsdecode(git('rev-parse', '--show-toplevel').strip())).absolute()
    if top != Path(ROOT).absolute():
        raise ValueError('La racine de distribution doit être la racine Git')
    algorithm = git('rev-parse', '--show-object-format').decode('ascii').strip()
    if algorithm not in {'sha1', 'sha256'}:
        raise ValueError('Format des objets Git inconnu')
    head = {}
    for record in git('ls-tree', '-z', 'HEAD', '--', *sources).split(b'\0'):
        if record:
            metadata, name = record.split(b'\t', 1)
            mode, kind, digest = metadata.split()
            if mode not in {b'100644', b'100755'} or kind != b'blob':
                raise ValueError('Objet Git non régulier refusé')
            head[os.fsdecode(name)] = (mode, digest)
    index = {}
    for record in git('ls-files', '--stage', '-z', '--', *sources).split(b'\0'):
        if record:
            metadata, name = record.split(b'\t', 1)
            mode, digest, stage = metadata.split()
            if stage != b'0':
                raise ValueError('Conflit Git non résolu')
            index[os.fsdecode(name)] = (mode, digest)
    for name, data in sources.items():
        digest = hashlib.new(algorithm, b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest().encode('ascii')
        if name not in head or index.get(name) != head[name] or digest != head[name][1]:
            raise ValueError('Source non suivie ou différente de HEAD : ' + name)


def _installer(data, digest):
    script = '''#!/usr/bin/env python3
# Tao local installer. Source archive is embedded, verified, and kept under ~/tao-linux-@VERSION@.
import base64,hashlib,io,os,subprocess,sys,zipfile
from pathlib import Path
DATA=base64.b64decode(PAYLOAD)
if hashlib.sha256(DATA).hexdigest()!=DIGEST: raise SystemExit("Archive corrompue")
root=Path.home()/"tao-linux-@VERSION@"
os.environ["TAO_INIT_SOURCE_GIT"]="1" if not root.exists() else "0"
with zipfile.ZipFile(io.BytesIO(DATA)) as z:
    # Validate the entire archive and existing source before writing any file.
    records=[]
    for item in z.infolist():
        parts=Path(item.filename).parts
        if not parts or parts[0]!="tao-linux-@VERSION@" or ".." in parts: raise SystemExit("Chemin d'archive invalide")
        rel=Path(*parts[1:]); out=root/rel
        if root.is_symlink() or not out.resolve().is_relative_to(root.resolve()): raise SystemExit("Lien de destination refusé")
        data=z.read(item)
        if out.exists() and (out.is_symlink() or not out.is_file() or out.read_bytes()!=data):
            raise SystemExit("Source déjà modifiée, préservée : "+str(out)+". Extraire le ZIP ailleurs pour une mise à jour.")
        records.append((out,data))
    for out,data in records:
        out.parent.mkdir(parents=True,exist_ok=True)
        if not out.exists(): out.write_bytes(data)
print("Sources :",root,flush=True)
raise SystemExit(subprocess.call([sys.executable,str(root/"bootstrap/install.py"),*sys.argv[1:]]))
'''
    script = script.replace('@VERSION@', VERSION)
    return script.replace('DATA=base64.b64decode(PAYLOAD)',
                          'PAYLOAD=' + repr(base64.b64encode(data).decode('ascii')) + '\nDIGEST=' + repr(digest)
                          + '\nDATA=base64.b64decode(PAYLOAD)').encode('utf-8')


def _write_outputs(outputs):
    """Stage every byte first; replace files atomically, with release.json last."""
    with ExitStack() as stack:
        root_fd = _open_root(stack)
        try:
            os.mkdir('dist', dir_fd=root_fd)
        except FileExistsError:
            pass
        dist_fd = os.open('dist', _directory_flags(), dir_fd=root_fd)
        stack.callback(os.close, dist_fd)
        for name in outputs:
            try:
                mode = os.stat(name, dir_fd=dist_fd, follow_symlinks=False).st_mode
            except FileNotFoundError:
                continue
            if not stat.S_ISREG(mode):
                raise ValueError('Destination non régulière refusée : ' + name)
        pending = []
        try:
            for name, data in outputs.items():
                temporary = '.release-' + uuid.uuid4().hex + '.tmp'
                fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                             0o700 if name.endswith('.run') else 0o644, dir_fd=dist_fd)
                pending.append((temporary, name))
                with os.fdopen(fd, 'wb') as handle:
                    handle.write(data)
                    handle.flush()
                    os.fsync(handle.fileno())
            for temporary, name in pending:
                os.replace(temporary, name, src_dir_fd=dist_fd, dst_dir_fd=dist_fd)
            os.fsync(dist_fd)
        finally:
            for temporary, _ in pending:
                try:
                    os.unlink(temporary, dir_fd=dist_fd)
                except FileNotFoundError:
                    pass


def build(strict_git=False):
    sources = source_snapshot()
    if strict_git:
        _strict_git(sources)
    _validate_sources(sources)
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, content in sources.items():
            info = zipfile.ZipInfo('tao-linux-' + VERSION + '/' + name, date_time=(2026, 9, 28, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, content)
    data = stream.getvalue()
    digest = hashlib.sha256(data).hexdigest()
    runname = f'TAO_LINUX_{VERSION}.run'
    zipname = f'Tao_Linux_{VERSION}_source.zip'
    outputs = {runname: _installer(data, digest), zipname: data}
    update_contract = json.loads(json.dumps(UPDATE_CONTRACT, ensure_ascii=False))
    manifest = {'schema': 'tao.release.v2', 'version': VERSION,
                'update': update_contract, 'files': {
        name: {'sha256': hashlib.sha256(content).hexdigest(), 'size': len(content)}
        for name, content in outputs.items()}}
    outputs['SHA256SUMS'] = ''.join(f"{row['sha256']}  {name}\n" for name, row in manifest['files'].items()).encode('ascii')
    outputs['release.json'] = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
    _write_outputs(outputs)
    print(json.dumps(manifest))
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--strict-git', action='store_true',
                        help='require every release file to be tracked and equal to HEAD')
    build(strict_git=parser.parse_args().strict_git)
