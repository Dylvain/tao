#!/usr/bin/env python3
"""One private, persistent Tao node behind the hosted HTTPS gateway.

The container image supplies the gateway and the initial source seed. Subsequent
boots preserve both the source Git history and the separately installed runtime.
No credentials, provider calls or source upgrades are performed during boot.
"""
from __future__ import annotations

import contextlib
import fcntl
import importlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import threading
import time
from urllib.parse import urlsplit

IMAGE = Path(__file__).resolve().parents[1]
VOLUME_SCHEMA = 'tao.host.volume.v1'
DIRECTORIES = ('node', 'home', 'codex', 'host-auth')


class MountRequiredError(ValueError):
    pass


def origin_from_env(env):
    origin = env.get('TAO_HOST_ORIGIN', '')
    if not origin:
        domain = env.get('RAILWAY_PUBLIC_DOMAIN', '')
        if not re.fullmatch(r'[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.up\.railway\.app', domain):
            raise ValueError('Configurer TAO_HOST_ORIGIN avec l’origine HTTPS publique exacte.')
        origin = 'https://' + domain
    try:
        parsed = urlsplit(origin)
        valid = (parsed.scheme == 'https' and parsed.hostname and not parsed.username
                 and not parsed.password and not parsed.path and not parsed.query
                 and not parsed.fragment and parsed.netloc == parsed.hostname
                 + (':' + str(parsed.port) if parsed.port else ''))
        valid = valid and re.fullmatch(r'[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?', parsed.hostname)
        valid = valid and (parsed.port is None or 1 <= parsed.port <= 65535)
    except ValueError:
        valid = False
    if not valid:
        raise ValueError('TAO_HOST_ORIGIN doit être une origine HTTPS sans chemin ni identifiants.')
    return origin


def directory(path, owners):
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid not in owners:
        raise ValueError('Répertoire hébergé non sûr ; vérifier ses liens et son propriétaire.')
    return info


def require_mount(data):
    # A directory in the image's writable layer would disappear on redeploy.
    # The operator must attach and back up a real persistent Railway/Docker volume.
    if not os.path.ismount(data):
        raise MountRequiredError('Monter un volume persistant dédié sur TAO_HOST_DATA avant de démarrer Tao.')


def private_directory(path, uid, gid):
    """Change only the opened directory, never a link swapped into its place."""
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        if os.fstat(fd).st_uid not in {0, uid}:
            raise ValueError('Propriétaire du volume inattendu.')
        if os.fstat(fd).st_uid != uid:
            os.fchown(fd, uid, gid)
        os.fchmod(fd, 0o700)
    finally:
        os.close(fd)


def prepare_volume(data, uid, gid):
    """Bounded root bootstrap; never follow links or recursively change owners."""
    if not data.is_absolute() or '..' in data.parts or data == Path('/'):
        raise ValueError('TAO_HOST_DATA doit désigner un volume dédié absolu.')
    for parent in reversed(data.parents):
        directory(parent, {0, uid})
    data.mkdir(mode=0o700, exist_ok=True)
    directory(data, {0, uid})
    marker = data / 'host-runtime-owner.json'
    expected = {'schema': VOLUME_SCHEMA, 'uid': uid, 'gid': gid}
    if marker.exists() or marker.is_symlink():
        info = marker.lstat()
        if (not stat.S_ISREG(info.st_mode) or info.st_uid not in {0, uid}
                or info.st_size > 1024 or json.loads(marker.read_text()) != expected):
            raise ValueError('Marqueur du volume non reconnu ; aucune reprise de propriété.')
    else:
        if any(p.name != 'lost+found' for p in data.iterdir()):
            raise ValueError('Le premier démarrage exige un volume dédié vide ; données préservées.')
        fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'w') as stream:
            json.dump(expected, stream)
            stream.flush()
            os.fsync(stream.fileno())
    for path in (data, *(data / name for name in DIRECTORIES)):
        new = not path.exists() and not path.is_symlink()
        if new:
            path.mkdir(mode=0o700)
        info = directory(path, {0, uid})
        if info.st_uid != uid:
            # An interrupted bootstrap may leave only an empty fixed directory.
            if path != data and not new and any(path.iterdir()):
                raise ValueError('Répertoire existant appartenant à root ; reprise manuelle requise.')
            if os.geteuid() != 0:
                raise ValueError('Le volume doit appartenir au compte Tao.')
        private_directory(path, uid, gid)
    fd = os.open(marker, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid not in {0, uid}:
            raise ValueError('Marqueur du volume non sûr.')
        if info.st_uid != uid:
            os.fchown(fd, uid, gid)
        os.fchmod(fd, 0o600)
    finally:
        os.close(fd)


def drop_privileges(uid=1000, gid=1000):
    if os.geteuid() == 0:
        os.setgroups([])
        os.setgid(gid)
        os.setuid(uid)
    if os.geteuid() != uid or os.getegid() != gid or uid == 0:
        raise ValueError('Tao hébergé doit fonctionner sous son compte non privilégié.')


def process_env(data):
    env = dict(os.environ)
    env.update(TAO_HOSTED='1', TAO_HOST_DATA=str(data), TAO_ROOT=str(data / 'node'),
               CODEX_HOME=str(data / 'codex'), TAO_WORLD='main',
               XDG_CONFIG_HOME=str(data / 'home' / '.config'),
               PATH=str(data / 'home' / '.local' / 'bin') + ':' + env.get('PATH', '/usr/local/bin:/usr/bin:/bin'))
    # These are actual account paths, not shell scratch variables. Path.home()
    # and child tools must agree with the dedicated Unix account's home.
    env['HOME'] = str(data / 'home')
    for name in ('TAO_NO_START', 'TAO_INIT_SOURCE_GIT', 'PYTHONPATH', 'PYTHONHOME'):
        env.pop(name, None)
    return env


def git(source, *args, env=None):
    return subprocess.run(['git', '-c', 'core.hooksPath=/dev/null', '-C', str(source), *args],
                          env=env, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          text=True, timeout=30).stdout.strip()


def ensure_source(data, image=IMAGE, env=None):
    source = data / 'source'
    if source.exists() or source.is_symlink():
        directory(source, {os.geteuid()})
        directory(source / '.git', {os.geteuid()})
        if Path(git(source, 'rev-parse', '--show-toplevel', env=env)).resolve() != source:
            raise ValueError('Les sources persistantes ne sont pas un dépôt Git autonome.')
        git(source, 'rev-parse', '--verify', 'HEAD', env=env)
        return source
    staging = Path(tempfile.mkdtemp(prefix='source-seed-', dir=data))
    try:
        def ignore(_path, names):
            return [name for name in names if name in {'.git', '__pycache__', '.pytest_cache', 'node_modules', 'dist'}
                    or name == '.env' or name.startswith('.env.') or name.endswith('.pyc')]
        shutil.copytree(image, staging, dirs_exist_ok=True, ignore=ignore, symlinks=True)
        # A seed must not bring in links to files outside its public source tree.
        if any(path.is_symlink() for path in staging.rglob('*')):
            raise ValueError('La copie initiale contient un lien symbolique ; installation refusée.')
        git(staging, 'init', '-b', 'main', env=env)
        git(staging, 'config', 'user.name', 'Tao Hosted', env=env)
        git(staging, 'config', 'user.email', 'tao@localhost', env=env)
        git(staging, 'add', '--all', env=env)
        git(staging, 'commit', '-m', 'Initial hosted Tao source', env=env)
        staging.rename(source)
        return source
    finally:
        if staging.exists():
            shutil.rmtree(staging)


def runtime_path(root):
    link = root / 'runtime'
    if not link.is_symlink():
        raise ValueError('Le runtime installé est absent ou invalide.')
    directory(root / 'releases', {os.geteuid()})
    runtime = link.resolve(strict=True)
    if runtime.parent != (root / 'releases').resolve() or not (runtime / 'tao_node.py').is_file():
        raise ValueError('Le runtime installé doit rester dans les versions privées du nœud.')
    return runtime


def ensure_runtime(root, source, env):
    if (root / 'runtime').exists() or (root / 'runtime').is_symlink():
        runtime_path(root)
        record = json.loads((root / 'source.json').read_text())
        if record.get('path') != str(source):
            raise ValueError('Ce runtime appartient à d’autres sources ; aucune réinstallation automatique.')
        return
    # Only initial installation executes the persistent seed. Existing dirty or
    # accepted source changes never trigger an implicit runtime upgrade at boot.
    subprocess.run([sys.executable, str(source / 'bootstrap' / 'install.py'), '--no-start'],
                   env=env, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
    runtime_path(root)


@contextlib.contextmanager
def lock_file(path, blocking=False):
    fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid():
            raise ValueError('Verrou du runtime non sûr.')
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        except BlockingIOError:
            yield False
        else:
            try:
                yield True
            finally:
                fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)


class Supervisor:
    """Adopt installer-created daemons by singleton lock, without spawning twice."""
    def __init__(self, root, env):
        self.root, self.env = root, env
        self.child = None
        self.next_start = 0.0

    def tick(self):
        if self.child is not None:
            if self.child.poll() is None:
                return 'running'
            self.child.wait()
            self.child = None
        if time.monotonic() < self.next_start:
            return 'backoff'
        with lock_file(self.root / 'install.lock') as installing:
            if not installing:
                return 'installing'
            with lock_file(self.root / 'daemon.lock') as available:
                if not available:
                    return 'adopted'
                runtime_path(self.root)
            # install.lock closes the stop/start race with the atelier installer.
            # daemon.lock is released so the child can acquire its own singleton.
            log = self.root / 'daemon.log'
            if log.is_symlink():
                raise ValueError('Journal du daemon non sûr.')
            if log.exists() and log.stat().st_size > 2 * 1024 * 1024:
                log.replace(self.root / 'daemon.log.previous')
            with log.open('ab') as stream:
                self.child = subprocess.Popen([sys.executable, str(self.root / 'runtime' / 'tao_node.py'), 'daemon'],
                                              env=self.env, stdin=subprocess.DEVNULL, stdout=stream, stderr=stream,
                                              start_new_session=True)
            log.chmod(0o600)
            self.next_start = time.monotonic() + 3
            return 'started'

    def close(self, n):
        # The node checks its session before sending the local stop request; this
        # also reaches a replacement daemon launched by an accepted installation.
        try:
            n.stop_daemon()
        except (OSError, ValueError, RuntimeError):
            pass
        if self.child is not None:
            if self.child.poll() is None:
                self.child.terminate()
                try:
                    self.child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.child.kill()
                    self.child.wait(timeout=5)
            else:
                self.child.wait()


def main():
    os.umask(0o077)
    origin = origin_from_env(os.environ)
    port = int(os.environ.get('PORT', '8080'))
    if not 1024 <= port <= 65535:
        raise ValueError('PORT doit être compris entre 1024 et 65535.')
    data = Path(os.environ.get('TAO_HOST_DATA', '/data'))
    require_mount(data)
    prepare_volume(data, 1000, 1000)
    drop_privileges()
    env = process_env(data)
    os.environ.clear()
    os.environ.update(env)
    os.chdir(data / 'home')
    with lock_file(data / 'hosted.lock') as own:
        if not own:
            raise ValueError('Un superviseur utilise déjà ce volume.')
        source = ensure_source(data, env=env)
        root = data / 'node'
        ensure_runtime(root, source, env)
        # Gateway/auth code stays in the immutable image. An atelier may evolve
        # the node runtime, but cannot implicitly replace its public auth layer.
        sys.path.insert(0, str(IMAGE / 'bootstrap'))
        n = importlib.import_module('tao_node')
        if n.policy()['http_port'] == port:
            raise ValueError('PORT doit être distinct du port HTTP privé du nœud.')
        host = importlib.import_module('tao_host')
        ai = importlib.import_module('tao_host_ai').HostAI(n)
        server = None
        serving = False
        supervisor = Supervisor(root, env)
        stopped = threading.Event()
        for signum in (signal.SIGTERM, signal.SIGINT):
            signal.signal(signum, lambda _signal, _frame: stopped.set())
        try:
            # Constructor validates persistent authentication before any listener
            # can serve application state or a daemon is started.
            server = host.HostServer(('0.0.0.0', port), n, origin, data / 'host-auth', ai)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            serving = True
            while not stopped.is_set():
                supervisor.tick()
                stopped.wait(.5)
        finally:
            if server is not None:
                if serving:
                    server.shutdown()
                server.server_close()
            ai.close()
            supervisor.close(n)


if __name__ == '__main__':
    try:
        main()
    except MountRequiredError:
        print('TAO_HOST_READY=0 — volume persistant absent : monter un volume sur TAO_HOST_DATA.', file=sys.stderr)
        raise SystemExit(1)
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError):
        # Never send provider output, environment or credentials to public logs.
        print('TAO_HOST_READY=0 — démarrage refusé ; vérifier origine, volume, authentification et runtime.', file=sys.stderr)
        raise SystemExit(1)
