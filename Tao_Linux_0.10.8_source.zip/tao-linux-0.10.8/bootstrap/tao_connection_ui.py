"""Local owner device login and history import are separate, explicit steps.

Uses the already bounded hosted login implementation. Page reads do not launch
the CLI: only the owner's check/start/cancel requests operate on it. Tao never
reads a credential file or imports a provider account's history through login.
"""
import html
import json
import os
import threading
from urllib.parse import quote

from tao_host_ai import HostAI, DEVICE_URL

_LOCK = threading.Lock()


def manager(n, server):
    with _LOCK:
        if not hasattr(server, 'tao_connection'):
            class LocalAI(HostAI):
                def _exe(self):
                    return n.adaptation.executable(n, 'codex')
                def _environment(self):
                    env = super()._environment()
                    # A user service may not inherit the terminal's interpreter
                    # path (for example Node installed with nvm). Use the same
                    # saved PATH as dialogue/code workers, keeping the login
                    # environment allowlist and never copying other variables.
                    saved_path = n.adaptation.source(n).get('path_env')
                    if isinstance(saved_path, str) and saved_path:
                        env['PATH'] = saved_path
                    return env
            server.tao_connection = LocalAI(n)
        return server.tao_connection


def status(n, server):
    result = manager(n, server)._snapshot()
    result['schema'] = 'tao.connection.v1'
    result['history_imported'] = False
    result['history_access'] = 'separate_explicit_import'
    return result


def post(n, server, path, obj):
    if obj != {}:
        raise ValueError('Cette action de connexion n’accepte aucun paramètre.')
    if os.environ.get('TAO_HOSTED') == '1':
        raise ValueError('Utiliser la connexion propriétaire dans /host/ai sur ce Tao hébergé.')
    action = {'/api/connection/check': 'status', '/api/connection/start': 'start',
              '/api/connection/cancel': 'cancel'}.get(path)
    if action is None:
        raise ValueError('Action de connexion inconnue.')
    getattr(manager(n, server), action)()
    return status(n, server)


WORDS = {
 'fr': {'title':'Modèle pour discuter', 'back':'Mes pièces',
  'intro':'Une IA pour discuter et organiser ce que tu choisis de lui confier.',
  'one':'Connecter le moteur de discussion',
  'explain':'Tao utilise Codex sur la machine qui héberge cette installation. La connexion ne lance aucune conversation et ne récupère pas ton historique ChatGPT.',
  'check':'Vérifier ma connexion', 'start':'Connecter Codex', 'cancel':'Annuler la demande',
  'open':'Ouvrir OpenAI et saisir ce code',
  'code':'Code personnel temporaire :',
  'two':'Faire entrer mes conversations',
  'import_text':'Choisis un export de conversations ChatGPT ou Claude, ou un paquet Tao. Relis les espaces proposés et leur destination avant d’importer. Les textes restent des sources à vérifier.',
  'import':'Importer mes conversations',
  'three':'Visiter une pièce', 'next':'Pour continuer',
  'continue_text':'Ouvre un espace et demande à Tao de le compléter à partir de tes récits. Les repères proposés gardent leurs citations ; tu peux les corriger, les retenir ou les écarter.',
  'continue':'Commencer une discussion',
  'missing':'Si Codex manque, son installation et sa première configuration restent à faire sur la machine qui héberge Tao.',
  'install':'Guide officiel de connexion et d’installation',
  'host':'Ouvrir la connexion de ce Tao hébergé',
  'hint':'Si la connexion par code n’est pas disponible, utilise la connexion Codex dans le terminal de cet hôte. Tao respecte les méthodes autorisées par ton compte.',
  'scope':'Le statut confirme uniquement la connexion du programme. La disponibilité du modèle et ses quotas se vérifieront lors de ton premier échange.',
  'means':'Moyens repérés sur cette installation',
  'discuss':'Discuter', 'improve':'Améliorer Tao',
  'codex_found':'Codex est repéré.', 'codex_missing':'Codex n’est pas repéré.',
  'git_found':'Git est repéré.', 'git_missing':'Git n’est pas repéré.',
  'source_found':'Le dossier des sources est repéré.',
  'source_missing':'Le dossier des sources n’est pas repéré.',
  'source_path':'Dossier des sources',
  'source_limits':'Le commit et la propreté du dépôt seront vérifiés avant la préparation. Ces moyens ne confirment ni la connexion du compte, ni les quotas, ni un résultat.',
  'discussion_independent':'Tu peux discuter sans que l’atelier de code soit prêt.',
  'idle':'Connexion non vérifiée. Choisis « Vérifier ma connexion ».',
  'connected':'Codex confirme sa connexion sur cette installation.',
  'unavailable':'Codex n’est pas détecté sur cette installation.',
  'disconnected':'Codex ne confirme pas de compte connecté.',
  'unconfirmed':'La connexion n’a pas pu être vérifiée.',
  'starting':'Préparation du code de connexion…',
  'awaiting_authorization':'Ouvre OpenAI et saisis le code personnel affiché ci-dessous.',
  'checking':'Vérification de la connexion…',
  'cancelled':'Demande annulée. Un compte déjà connecté reste connecté.',
  'cancelling':'Annulation en cours…', 'expired':'Ce code a expiré. Tu peux demander un nouveau code.',
  'failed':'Connexion non confirmée. Vérifie la disponibilité de la connexion par code dans ton compte.',
  'error':'Résultat non confirmé. Vérifie la connexion avant de relancer une action.'},
 'en': {'title':'Conversation model', 'back':'My rooms',
  'intro':'An AI to discuss and organise what you choose to share.',
  'one':'Connect a conversation engine',
  'explain':'Tao uses Codex on the machine hosting this installation. Signing in neither starts a conversation nor retrieves your ChatGPT history.',
  'check':'Check my connection', 'start':'Connect Codex', 'cancel':'Cancel request',
  'open':'Open OpenAI and enter this code', 'code':'Personal temporary code:',
  'two':'Bring my conversations in',
  'import_text':'Choose a ChatGPT or Claude conversation export, or a Tao package. Review the suggested spaces and destinations before importing. Imported text remains attributed source material.',
  'import':'Import my conversations',
  'three':'Visit a room', 'next':'Continue',
  'continue_text':'Open a room and ask Tao to work from stories you have shared. Suggested landmarks retain their quotations; you can edit, keep or set them aside.',
  'continue':'Start a conversation',
  'missing':'If Codex is missing, install and configure it on the machine hosting Tao.',
  'install':'Official connection and installation guide',
  'host':'Open this hosted Tao’s sign-in page',
  'hint':'If device code sign-in is unavailable, use Codex login in this host’s terminal. Tao respects the authentication methods allowed by your account.',
  'scope':'This status only confirms the program’s login. Model availability and quotas will be checked when you send your first message.',
  'means':'Tools found on this installation',
  'discuss':'Talk', 'improve':'Improve Tao',
  'codex_found':'Codex was found.', 'codex_missing':'Codex was not found.',
  'git_found':'Git was found.', 'git_missing':'Git was not found.',
  'source_found':'The source folder was found.',
  'source_missing':'The source folder was not found.',
  'source_path':'Source folder',
  'source_limits':'The commit and working tree will be checked before preparation. These tools do not confirm account login, quotas or an outcome.',
  'discussion_independent':'You can talk without the code workshop being ready.',
  'idle':'Connection not checked. Choose “Check my connection”.',
  'connected':'Codex confirms it is connected on this installation.',
  'unavailable':'Codex was not found on this installation.',
  'disconnected':'Codex does not confirm a signed-in account.',
  'unconfirmed':'The connection could not be verified.', 'starting':'Preparing a connection code…',
  'awaiting_authorization':'Open OpenAI and enter the personal code below.',
  'checking':'Checking the connection…',
  'cancelled':'Request cancelled. An account already signed in remains signed in.',
  'cancelling':'Cancelling…', 'expired':'This code has expired. You can request a new one.',
  'failed':'Sign-in was not confirmed. Check whether device code sign-in is available for your account.',
  'error':'Result not confirmed. Check the connection before retrying an action.'}
}

JS = r'''
const $=id=>document.getElementById(id);let timer,requestId=0,busy=false;
function show(s){
 clearTimeout(timer);$('status').textContent=config.words[s.state]||config.words.unconfirmed;
 const code=typeof s.user_code==='string'&&/^[A-Z0-9-]{6,32}$/.test(s.user_code)&&s.verification_url==='https://auth.openai.com/codex/device';
 $('pairing').hidden=!code;$('code').textContent=code?s.user_code:'';
 $('start').disabled=!!s.login_in_progress||s.connected===true||!s.cli_available;
 $('cancel').hidden=!s.login_in_progress;$('cancel').disabled=false;$('check').disabled=false;
 if(s.login_in_progress)timer=setTimeout(()=>request('status',false),1500);
}
async function request(action,post=true){
 if(busy)return;busy=true;const id=++requestId;clearTimeout(timer);
 for(const name of ['start','check','cancel'])$(name).disabled=true;
 try{const url=new URL('/api/connection/'+action,location.origin);url.searchParams.set('world',config.world);
 const response=await fetch(url.pathname+url.search,{method:post?'POST':'GET',credentials:'same-origin',cache:'no-store',headers:post?{'Content-Type':'application/json','X-Tao-Token':config.token}:{},body:post?'{}':undefined});
 const value=await response.json();if(!response.ok)throw Error(value.error||config.words.error);if(id===requestId)show(value);
 }catch(error){if(id===requestId){$('pairing').hidden=true;$('code').textContent='';$('status').textContent=config.words.error;$('check').disabled=false;}}
 finally{busy=false;}
}
if(!config.hosted){$('start').onclick=()=>request('start');$('check').onclick=()=>request('check');$('cancel').onclick=()=>request('cancel');request('status',false);}
'''


def render(n, locale='fr'):
    if locale not in WORDS:
        raise ValueError('Langue disponible : fr ou en.')
    w = WORDS[locale]
    esc = lambda value: html.escape(str(value), quote=True)
    world = n.worlds.current()
    suffix = '?world=' + quote(world, safe='')
    hosted = os.environ.get('TAO_HOSTED') == '1'
    diagnostic = n.adaptation.diagnose(n)
    missing = {item['code'] for item in diagnostic['blockers']}
    source_detail = ('<details><summary>'+esc(w['source_path'])+'</summary><code>'+
                     esc(diagnostic['source'])+'</code></details>') if diagnostic.get('source') else ''
    readiness = ('<div class="readiness"><h3>'+esc(w['means'])+'</h3><p><b>'+
                 esc(w['discuss'])+'</b> · '+esc(w['codex_found'] if diagnostic['codex_detected'] else w['codex_missing'])+
                 '</p><p><b>'+esc(w['improve'])+'</b> · '+
                 esc(w['git_missing'] if 'git_missing' in missing else w['git_found'])+' '+
                 esc(w['source_missing'] if 'source_missing' in missing else w['source_found'])+
                 '</p>'+source_detail+'<p class="muted">'+esc(w['source_limits'])+'</p><p class="muted">'+
                 esc(w['discussion_independent'])+'</p></div>')
    token = json.dumps(n.TOKEN).replace('<', '\\u003c')
    config = json.dumps({'words': w, 'world': world,
                         'hosted': hosted}, ensure_ascii=False).replace('<', '\\u003c')
    controls = ('<p><a class="button" href="/host/ai">'+esc(w['host'])+'</a></p>') if hosted else (
        '<p id="status" role="status" aria-live="polite">'+esc(w['idle'])+'</p>'
        '<div id="pairing" hidden><p>'+esc(w['code'])+'</p><code id="code"></code>'
        '<a href="'+DEVICE_URL+'" target="_blank" rel="noopener noreferrer">'+esc(w['open'])+'</a></div>'
        '<button id="check">'+esc(w['check'])+'</button><button id="start" disabled>'+esc(w['start'])+'</button>'
        '<button id="cancel" hidden>'+esc(w['cancel'])+'</button>')
    return '''<!doctype html><html lang="'''+locale+'''"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tao · '''+esc(w['title'])+'''</title><style>
:root{color-scheme:light}*{box-sizing:border-box}body{margin:0;background:#f5f3ed;color:#27372f;font:16px/1.65 system-ui}main{max-width:760px;margin:auto;padding:28px 20px 60px}h1{font-size:clamp(30px,6vw,46px);line-height:1.15}h2{font-size:22px}section{margin:24px 0;padding:24px;border:1px solid #d9ded5;border-radius:16px;background:var(--panel)}a{color:#315a47}button,.button{display:inline-block;min-height:44px;font:inherit;padding:10px 16px;border:0;border-radius:9px;background:#315a47;color:#fff;margin:6px 6px 6px 0;cursor:pointer}.button{text-decoration:none}button:disabled{opacity:.5;cursor:default}.muted{color:#596860;font-size:14px}code{display:block;font-size:25px;overflow-wrap:anywhere;padding:14px 0}#pairing{padding:16px;border:1px solid #b9c7bc;border-radius:10px}[hidden]{display:none!important}:focus-visible{outline:3px solid var(--accent);outline-offset:4px}@media(max-width:500px){main{padding:20px 14px}section{padding:18px}button{width:100%}}
.readiness{border-top:1px solid #d9ded5;margin-top:24px;padding-top:10px}.readiness h3{font-size:17px}.readiness code{font-size:14px;padding:0}.readiness p{margin:8px 0}

/* Tao · maison : surfaces, typography and interaction */
:root{--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47;--soft:#edf1ea;--gold:#c79d67;color-scheme:light}
body{min-height:100vh;background:radial-gradient(circle at 88% -10%,#eee3d2,transparent 38%),var(--bg)}
nav{min-height:60px}.page-nav{display:flex;align-items:center;justify-content:space-between;gap:20px;padding-bottom:18px;border-bottom:1px solid var(--line)}.eyebrow{color:var(--accent);font:700 11px/1.5 system-ui,sans-serif;letter-spacing:.15em;text-transform:uppercase}nav .brand{font:600 29px/1 ui-serif,Georgia,serif;letter-spacing:-.045em;color:var(--text);text-decoration:none}
a{color:var(--accent);text-underline-offset:3px}a:hover,summary:hover{text-decoration-color:var(--gold)}
header{margin:26px 0 28px;padding:clamp(24px,4vw,42px);border:1px solid var(--line);border-top:3px solid var(--gold);border-radius:20px;background:linear-gradient(135deg,#fffdfa,#f6f1e8);box-shadow:0 12px 30px rgba(39,55,47,.045)}
header p:last-child{max-width:68ch}h1,h2,h3{font-family:ui-serif,Georgia,serif;letter-spacing:-.025em}h1{font-weight:500}h2,h3{font-weight:600}
section,.panel{box-shadow:0 6px 22px rgba(39,55,47,.035)}
button,.button{background:var(--accent);color:#fff}button.secondary,.button.secondary{background:var(--soft);color:var(--accent);border:1px solid var(--line)}
input:not([type=checkbox]):not([type=file]),textarea,select{background:var(--panel);color:var(--text);border-color:#b9c7bc}pre{background:#f3f1eb;color:var(--text);border:1px solid var(--line)}
button:focus-visible,a:focus-visible,summary:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid var(--accent);outline-offset:3px}
#message{background:#ecf1ea;color:var(--text);border:1px solid #b7cab8;box-shadow:0 8px 25px rgba(39,55,47,.12)}#message.error{background:#fff1e6;color:#613f2d;border-color:#dfb997}
.next-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.next-grid>div{min-width:0;padding:17px 19px;border:1px solid var(--line);border-left:3px solid var(--gold);border-radius:12px;background:#f8f6f0}.next-grid h3{margin-top:0}.next-grid .button{margin-top:8px}.readiness{border-color:var(--line)}#pairing{background:var(--soft);border-color:var(--line)}details summary{cursor:pointer;min-height:44px;color:var(--accent)}@media(max-width:620px){.next-grid{grid-template-columns:1fr}}
@media(max-width:540px){header{margin:18px 0 20px;padding:23px 19px;border-radius:16px}}
</style></head><body><main><nav class="page-nav"><a class="brand" href="/explore'''+esc(suffix+'&lang='+locale)+'''">tao.</a><a href="/explore'''+esc(suffix+'&lang='+locale)+'''">← '''+esc(w['back'])+'''</a></nav><header><p class="eyebrow">Tao · '''+('Seuil des IA' if locale=='fr' else 'AI doorway')+'''</p><h1>'''+esc(w['title'])+'''</h1><p>'''+esc(w['intro'])+'''</p></header><section><h2>'''+esc(w['one'])+'''</h2><p>'''+esc(w['explain'])+'''</p>'''+controls+'''<p class="muted">'''+esc(w['scope'])+'''</p><details><summary>'''+esc(w['install'])+'''</summary><p>'''+esc(w['missing'])+'''</p><p>'''+esc(w['hint'])+'''</p><a href="https://developers.openai.com/codex/auth/" target="_blank" rel="noopener noreferrer">OpenAI · Codex</a></details>'''+readiness+'''</section><section class="next-steps"><h2>'''+esc(w['next'])+'''</h2><div class="next-grid"><div><h3>'''+esc(w['two'])+'''</h3><p>'''+esc(w['import_text'])+'''</p><a class="button secondary" href="/onboarding?world=main">'''+esc(w['import'])+'''</a></div><div><h3>'''+esc(w['three'])+'''</h3><p>'''+esc(w['continue_text'])+'''</p><a class="button secondary" href="/'''+esc(suffix+'&view=dialogue')+'''#dialogue">'''+esc(w['continue'])+'''</a></div></div></section></main><script>const token='''+token+';const config='+config+';config.token=token;\n'+JS+'</script></body></html>'
