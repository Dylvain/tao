"""Portable core-state snapshots with explicit, reversible restoration.

Encryption deliberately lives in the browser: this module never receives the
passphrase and never claims to back up credentials, source code, runtimes or
external archive files.  Version one is intentionally a single-state
transaction so a rejected or interrupted validation cannot partially replace
the current phenotype.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import re

import tao_centers as centers
import tao_worlds as worlds


SCHEMA = 'tao.portable.core.v1'
PREVIEW_SCHEMA = 'tao.portable.core.preview.v1'
MAX_STATE_BYTES = 16 * 1024 * 1024
MAX_BODY = 18 * 1024 * 1024
MAX_JSON_DEPTH = 80
MAX_JSON_VALUES = 1_000_000
INCLUDED = ('state.json',)
EXCLUDED = (
    'credentials and device sessions',
    'source code and installed runtime',
    'running and temporary jobs',
    'dialogue and imported-history archive files',
    'audit journals and adaptation workspaces',
)


def _canonical(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(',', ':'), allow_nan=False).encode('utf-8')
    except (TypeError, ValueError, UnicodeError, RecursionError) as exc:
        raise ValueError('Sauvegarde : données JSON non représentables.') from exc


def _digest(value):
    return hashlib.sha256(_canonical(value)).hexdigest()


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('Sauvegarde : champ JSON répété.')
        value[key] = item
    return value


def _invalid_constant(value):
    raise ValueError('Sauvegarde : nombre JSON non fini.')


def request_json(raw):
    """Strict request parser used only by the bounded backup routes."""
    if not isinstance(raw, bytes) or not raw or len(raw) > MAX_BODY:
        raise ValueError('Sauvegarde : requête vide ou trop grande.')
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=_unique_object,
                           parse_constant=_invalid_constant)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise ValueError('Sauvegarde : requête JSON illisible.') from exc
    _json_tree(value)
    if not isinstance(value, dict):
        raise ValueError('Sauvegarde : objet JSON requis.')
    return value


def _json_tree(value):
    count = 0
    stack = [(value, 0)]
    while stack:
        item, depth = stack.pop(); count += 1
        if count > MAX_JSON_VALUES or depth > MAX_JSON_DEPTH:
            raise ValueError('Sauvegarde : document trop complexe.')
        if item is None or isinstance(item, (str, bool, int)):
            continue
        if isinstance(item, float):
            if not math.isfinite(item):
                raise ValueError('Sauvegarde : nombre non fini.')
            continue
        if isinstance(item, list):
            stack.extend((child, depth + 1) for child in item)
            continue
        if isinstance(item, dict):
            if any(not isinstance(key, str) for key in item):
                raise ValueError('Sauvegarde : clé JSON non textuelle.')
            stack.extend((child, depth + 1) for child in item.values())
            continue
        raise ValueError('Sauvegarde : type JSON inconnu.')


def _main_only():
    if worlds.current() != worlds.MAIN:
        raise ValueError('La sauvegarde complète du nœud se fait depuis le centre principal.')


def _clean_state(n, value):
    state = copy.deepcopy(value)
    if not isinstance(state, dict):
        raise ValueError('Sauvegarde : état Tao invalide.')
    if '_world_view' in state:
        raise ValueError('Sauvegarde : une projection d’espace ne peut pas remplacer le nœud.')
    state.pop('_integrity', None)
    _json_tree(state)
    raw = _canonical(state)
    if len(raw) > MAX_STATE_BYTES:
        raise ValueError('Sauvegarde : le cœur de Tao dépasse la limite de 16 Mio ; rien n’a été remplacé.')
    if state.get('schema') != 'tao.node.state.v4':
        raise ValueError('Sauvegarde : schéma d’état incompatible.')
    if not isinstance(state.get('id'), str) or not re.fullmatch(r'node:[a-f0-9]{24}', state['id']):
        raise ValueError('Sauvegarde : identité de nœud invalide.')
    if not isinstance(state.get('buffers'), dict):
        raise ValueError('Sauvegarde : registre de résidus invalide.')
    if state.get('theory') != n.THEORY:
        raise ValueError('Sauvegarde : canon Tao incompatible avec ce runtime.')

    # Validate every world projection and every center registry on detached
    # copies.  These readers may add harmless defaults to their local copy but
    # can neither persist nor call an external provider.
    registry = worlds._registry(state)
    for ident in registry['spaces']:
        with worlds.using(ident):
            projected = worlds.project(state)
            centers._registry(projected)
    return state, raw, registry


def _bundle(n, value):
    if not isinstance(value, dict) or set(value) != {
            'schema', 'created_at', 'source', 'scope', 'state', 'state_sha256'}:
        raise ValueError('Sauvegarde : enveloppe incomplète ou ambiguë.')
    if value.get('schema') != SCHEMA:
        raise ValueError('Sauvegarde : format non pris en charge.')
    if not isinstance(value.get('created_at'), str) or not re.fullmatch(
            r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z', value['created_at']):
        raise ValueError('Sauvegarde : date invalide.')
    source = value.get('source')
    if not isinstance(source, dict) or set(source) != {'node_version', 'theory'}:
        raise ValueError('Sauvegarde : origine invalide.')
    if source.get('node_version') != n.NODE_VERSION or source.get('theory') != n.THEORY:
        raise ValueError('Sauvegarde : cette première version exige le même runtime Tao.')
    scope = value.get('scope')
    if scope != {'included': list(INCLUDED), 'excluded': list(EXCLUDED)}:
        raise ValueError('Sauvegarde : périmètre absent ou modifié.')
    state, raw, registry = _clean_state(n, value.get('state'))
    if value.get('state_sha256') != hashlib.sha256(raw).hexdigest():
        raise ValueError('Sauvegarde : empreinte du cœur invalide.')
    normalized = copy.deepcopy(value); normalized['state'] = state
    return normalized, registry, len(raw)


def _state_digest(n):
    state, _, _ = _clean_state(n, n.load_raw_state())
    return _digest(state)


def _counts(state, registry):
    center_count = 0; message_count = 0
    for ident, metadata in registry['spaces'].items():
        owner = state if ident == worlds.MAIN else metadata
        center_registry = owner.get('centers', {}) if isinstance(owner, dict) else {}
        if isinstance(center_registry, dict) and isinstance(center_registry.get('centers'), dict):
            center_count += len(center_registry['centers'])
        dialogue = owner.get('dialogue', {}) if isinstance(owner, dict) else {}
        if isinstance(dialogue, dict) and isinstance(dialogue.get('messages'), list):
            message_count += len(dialogue['messages'])
    return {'spaces': len(registry['spaces']), 'centers': center_count,
            'active_messages': message_count}


def export(n):
    _main_only()
    with n.LOCK:
        state, _, registry = _clean_state(n, n.load_raw_state())
        bundle = {
            'schema': SCHEMA,
            'created_at': n.now(),
            'source': {'node_version': n.NODE_VERSION, 'theory': dict(n.THEORY)},
            'scope': {'included': list(INCLUDED), 'excluded': list(EXCLUDED)},
            'state': state,
            'state_sha256': _digest(state),
        }
        # Exercise the same validator as restoration before exposing the copy.
        _bundle(n, bundle)
        stamp = re.sub(r'[-:TZ]', '', bundle['created_at'])
        return {'bundle': bundle, 'filename': 'tao-core-' + stamp + '.tao-backup',
                'summary': _counts(state, registry)}


def inspect(n, bundle):
    _main_only()
    normalized, registry, state_bytes = _bundle(n, bundle)
    with n.LOCK:
        current = _state_digest(n)
    return {'schema': PREVIEW_SCHEMA, 'review_digest': _digest(normalized),
            'expected_current_digest': current,
            'created_at': normalized['created_at'], 'state_bytes': state_bytes,
            'summary': _counts(normalized['state'], registry),
            'included': list(INCLUDED), 'excluded': list(EXCLUDED)}


def _assert_idle(n):
    import tao_adaptation as adaptation
    import tao_dialogue as dialogue
    if dialogue.active(n):
        raise ValueError('Arrêter ou attendre la réponse IA en cours avant de restaurer.')
    for path in (n.ROOT / 'adaptations').glob('*/job.json'):
        row = n.load_json(path)
        if row and adaptation.status(n, row).get('status') in adaptation.BUSY:
            raise ValueError('Attendre la fin du travail de code avant de restaurer.')


def _verified_state_bytes(n, state):
    value = copy.deepcopy(state)
    value.pop('_integrity', None)
    value['_integrity'] = n.digest_bytes(n.json_bytes(value))
    return json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')


def restore(n, bundle, review_digest, expected_current_digest, confirmed=False):
    _main_only()
    if confirmed is not True:
        raise ValueError('Confirmer explicitement le remplacement du cœur local.')
    normalized, registry, _ = _bundle(n, bundle)
    digest = _digest(normalized)
    if not isinstance(review_digest, str) or not re.fullmatch(r'[a-f0-9]{64}', review_digest):
        raise ValueError('Sauvegarde : empreinte de relecture invalide.')
    if not isinstance(expected_current_digest, str) or not re.fullmatch(
            r'[a-f0-9]{64}', expected_current_digest):
        raise ValueError('Sauvegarde : état courant non identifié.')
    if review_digest != digest:
        raise ValueError('La sauvegarde a changé depuis sa relecture ; rien n’a été remplacé.')
    with n.LOCK:
        _assert_idle(n)
        current_state, _, _ = _clean_state(n, n.load_raw_state())
        current_digest = _digest(current_state)
        if current_digest != expected_current_digest:
            raise ValueError('Tao a changé depuis l’aperçu. Relire la sauvegarde avant de restaurer.')
        previous = n.ROOT / 'portable-restore.prev.json'
        n.durable_bytes(previous, _verified_state_bytes(n, current_state))
        n.atomic_json(n.STATE, normalized['state'], backup=True)
        return {'restored': True, 'after_digest': _digest(normalized['state']),
                'rollback_available': True,
                'summary': _counts(normalized['state'], registry)}


def rollback(n, after_digest, confirmed=False):
    _main_only()
    if confirmed is not True:
        raise ValueError('Confirmer explicitement le retour à l’état précédent.')
    if not isinstance(after_digest, str) or not re.fullmatch(r'[a-f0-9]{64}', after_digest):
        raise ValueError('Restauration à annuler non identifiée.')
    with n.LOCK:
        _assert_idle(n)
        if _state_digest(n) != after_digest:
            raise ValueError('Tao a changé depuis la restauration ; retour automatique refusé.')
        previous = n.ROOT / 'portable-restore.prev.json'
        if not previous.is_file() or previous.is_symlink() or previous.stat().st_size > MAX_STATE_BYTES + 4096:
            raise ValueError('État précédent vérifié introuvable ; rien n’a été remplacé.')
        try:
            state = n.checked_state(previous)
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            raise ValueError('État précédent invalide ; rien n’a été remplacé.') from exc
        state, _, registry = _clean_state(n, state)
        n.atomic_json(n.STATE, state, backup=True)
        return {'rolled_back': True, 'summary': _counts(state, registry)}
