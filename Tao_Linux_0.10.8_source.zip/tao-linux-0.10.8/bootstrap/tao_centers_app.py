"""Modern center interface over the existing local, human-governed contracts.

The client is deliberately a projection: it receives bounded presentation data
and calls owner-only routes. It adds no center, provider, billing rule,
permission, or automatic model call on page load.
"""
from __future__ import annotations

import copy
import html
import json

import tao_centers as centers
import tao_connectors as connectors
import tao_dialogue as dialogue
import tao_landmarks as landmarks
import tao_update as update
import tao_worlds as worlds


SCHEMA = 'tao.center.interface.v1'


def _messages(n, state, focus):
    """Keep only the selected center thread and the fields rendered by the UI."""
    chosen_jobs = set()
    result = []

    def same_target(reference):
        return (isinstance(reference, dict)
                and reference.get('kind') == focus.get('kind')
                and reference.get('id') == focus.get('id'))

    for message in state.get('dialogue', {}).get('messages', []):
        keep = False
        if message.get('role') == 'user' and same_target(message.get('focus')):
            chosen_jobs.add(message.get('job_id')); keep = True
        elif message.get('role') == 'assistant' and message.get('job_id') in chosen_jobs:
            keep = True
        if not keep:
            continue
        public = {key: copy.deepcopy(message.get(key)) for key in (
            'id', 'role', 'text', 'job_id', 'model', 'input_context',
            'center_capture') if key in message}
        result.append(public)
    action_rows = [message['center_capture']['action'] for message in result
                   if isinstance(message.get('center_capture'), dict)
                   and isinstance(message['center_capture'].get('action'), dict)
                   and message['center_capture']['action'].get('kind') == 'action']
    if action_rows:
        catalog = connectors.catalog(n)
        for message in result:
            captures = message.get('center_capture')
            if (isinstance(captures, dict) and isinstance(captures.get('action'), dict)
                    and captures['action'].get('kind') == 'action'):
                captures['action'] = centers.project_action_capture(
                    n, captures['action'], catalog)
    return result[-24:]


def _inputs(n, state, locale, selected):
    if selected is None:
        return []
    view = landmarks.view(n, state, locale)
    labels = {slot['concept_id']: slot['label'] for slot in view['slots']}
    result = []
    for item in view['items']:
        if item['status'] == 'archived':
            continue
        text = item['text']
        result.append({
            'id': item['id'], 'revision': item['revision'],
            'kind': 'landmark',
            'reference': {'kind': 'landmark', 'id': item['id'],
                          'revision': item['revision']},
            'concept_id': item['concept_id'],
            'concept_label': labels.get(item['concept_id'], item['concept_id']),
            'title': item['title'], 'text': text[:800],
            'text_truncated': len(text) > 800, 'status': item['status'],
        })
    result.extend(centers.action_input_choices(n, state, selected['id'], locale))
    return result


def presentation(n, state, locale='fr', selected_id=None):
    """Build a read-only interface projection without mutating private state."""
    if locale not in ('fr', 'en'):
        raise ValueError('Langue disponible : fr ou en.')
    registry = centers.view(n, state)
    rows = registry['centers']
    selected = next((row for row in rows if row['id'] == selected_id), None)
    if selected_id is not None and selected is None:
        raise ValueError('Ce centre n’existe pas dans cet espace.')
    focus = ({'kind': 'center', 'id': selected['id'], 'revision': selected['revision']}
             if selected else
             {'kind': 'center_factory', 'id': 'new', 'revision': registry['revision']})
    messages = _messages(n, state, focus)
    initial_job = None
    if messages and messages[-1].get('role') == 'user' and messages[-1].get('job_id'):
        try:
            candidate = dialogue.view(n, messages[-1]['job_id'])
            if candidate.get('status') in dialogue.BUSY | {'blocked', 'interrupted'}:
                initial_job = candidate
        except (ValueError, OSError):
            pass
    return {
        'schema': SCHEMA,
        'world': worlds.current(),
        'worldTitle': worlds.describe(n, state)['current']['title'],
        'locale': locale,
        'token': n.TOKEN,
        'registryRevision': registry['revision'],
        'dialogueRevision': state.get('dialogue', {}).get('revision', 0),
        'selectedCenterId': selected['id'] if selected else None,
        'focus': focus,
        'centers': rows,
        'links': registry['links'],
        'messages': messages,
        'centerInputs': _inputs(n, state, locale, selected),
        'initialJob': initial_job,
        # Local status only: rendering C0 never contacts a release host.
        'update': update.status(n),
        # Product policy is explicit but inert.  There is no paywall, center
        # count limit, billing provider, or donation endpoint in this runtime.
        'product': {'billingEnabled': False, 'centerLimit': None},
    }


def render(n, state=None, locale='fr', selected_id=None):
    state = n.load_state() if state is None else state
    value = presentation(n, state, locale, selected_id)
    title = next((row['definition']['title'] for row in value['centers']
                  if row['id'] == value['selectedCenterId']),
                 'Centre principal' if locale == 'fr' else 'Main center')
    encoded = json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    encoded = encoded.replace('<', '\\u003c').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')
    loading = 'Tao se prépare…' if locale == 'fr' else 'Tao is getting ready…'
    return f'''<!doctype html>
<html lang="{locale}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="color-scheme" content="light">
  <meta name="theme-color" content="#f6f5f1">
  <title>Tao · {html.escape(title)}</title>
  <link rel="manifest" href="/app.webmanifest" crossorigin="use-credentials">
  <link rel="icon" href="/assets/tao-icon.svg" type="image/svg+xml">
  <link rel="apple-touch-icon" href="/assets/tao-icon-192.png">
  <link rel="stylesheet" href="/assets/tao-center.css">
</head>
<body>
  <div id="tao-root"><p style="padding:2rem;font-family:system-ui;color:#6f7975">{html.escape(loading)}</p></div>
  <script id="tao-bootstrap" type="application/json">{encoded}</script>
  <script type="module" src="/assets/tao-center.js"></script>
</body>
</html>'''
