"""Private, typed landmarks: attributed descriptions, never execution mandates.

An AI may classify a supplied quotation, but may not invent its contents. Human
review records a choice, not independent verification. Optional additive state
keeps earlier runtimes able to preserve these records without interpreting them.
"""
import copy
import hashlib
import json
import re
import uuid

import tao_worlds as worlds
import tao_continuity as continuity
from tao_work import text_field, check_revision

SCHEMA = 'tao.landmarks.v1'
MAX_ITEMS = 500
MAX_HISTORY = 60
MAX_BYTES = 4 * 1024 * 1024
MAX_PROPOSALS = 5
CONCEPT_KEYS = ('story', 'objective', 'problem', 'question', 'person', 'role',
                'mission', 'task', 'contract', 'income', 'expense', 'commitment',
                'resource', 'method', 'evidence')
CONCEPT_IDS = tuple('tao.concept.' + key for key in CONCEPT_KEYS)
PROPOSAL_SCHEMA = {'type': 'array', 'maxItems': MAX_PROPOSALS, 'items': {
    'type': 'object', 'properties': {
        'concept_id': {'type': 'string', 'enum': list(CONCEPT_IDS)},
        'source_id': {'type': 'string', 'maxLength': 240},
        'quote': {'type': 'string', 'minLength': 8, 'maxLength': 2000}},
    'required': ['concept_id', 'source_id', 'quote'], 'additionalProperties': False}}


def _concept(value, locale='fr'):
    import tao_foundations as foundation
    row = foundation.get_concept(value, locale=locale)
    if row['id'] not in CONCEPT_IDS:
        raise ValueError('Ce type ne fait pas partie des repères disponibles.')
    return row


def _registry(s):
    if s.get('_world_view', worlds.current()) != worlds.current():
        raise ValueError('Ces repères appartiennent à un autre espace.')
    memory = s.get('continuity', {})
    if not isinstance(memory, dict):
        raise ValueError('Registre de continuité invalide ; aucune correction implicite.')
    value = copy.deepcopy(memory.get('landmarks', {'schema': SCHEMA, 'revision': 0, 'items': []}))
    if (not isinstance(value, dict) or value.get('schema') != SCHEMA or
            type(value.get('revision')) is not int or value['revision'] < 0 or
            not isinstance(value.get('items'), list) or len(value['items']) > MAX_ITEMS):
        raise ValueError('Registre de repères invalide ; les données sont conservées.')
    seen = set()
    for row in value['items']:
        if (not isinstance(row, dict) or not isinstance(row.get('id'), str) or
                not re.fullmatch('[a-f0-9]{12}', row['id']) or row['id'] in seen or
                row.get('world_id') != worlds.current() or
                not isinstance(row.get('concept_id'), str) or row['concept_id'] not in CONCEPT_IDS or
                not isinstance(row.get('status'), str) or row['status'] not in ('proposed', 'active', 'archived') or
                type(row.get('revision')) is not int or row['revision'] < 1 or
                not isinstance(row.get('history'), list) or len(row['history']) > MAX_HISTORY or
                not isinstance(row.get('provenance'), list) or row.get('execution_enabled') is not False):
            raise ValueError('Repère invalide ou extérieur à cet espace ; aucune correction implicite.')
        text_field(row.get('title'), 'Le titre', 160, True)
        text_field(row.get('text'), 'Le contenu', 4000, True)
        seen.add(row['id'])
    return value


def view(n, s=None, locale='fr'):
    value = _registry(n.load_state() if s is None else s)
    slots = []
    for ident in CONCEPT_IDS:
        concept = _concept(ident, locale)
        rows = [row for row in value['items'] if row['concept_id'] == ident]
        slots.append(dict(concept_id=ident, key=concept['key'], label=concept['label'],
                          definition=concept['definition'], count=len(rows),
                          **{status + '_count': sum(row['status'] == status for row in rows)
                             for status in ('active', 'proposed', 'archived')}))
    return dict(value, world_id=worlds.current(), slots=slots, execution_enabled=False,
                limits={'items': MAX_ITEMS, 'revisions_per_item': MAX_HISTORY, 'bytes': MAX_BYTES},
                authority='description_only', verification='attributed_not_independently_verified')


def _writable(s):
    import tao_foundations as foundation
    if foundation._archived(worlds._registry(s)['spaces'], worlds.current()):
        raise ValueError('Cet espace est archivé ; le restaurer avant de modifier ses repères.')


def _save(n, s, registry):
    _writable(s)
    if len(n.json_bytes(registry)) > MAX_BYTES:
        raise ValueError('Registre de repères plein ; aucune trace ni révision supprimée.')
    continuity.ensure(s)['landmarks'] = registry
    n.atomic_json(n.STATE, s, backup=True)
    n.WAKE.set()


def _capacity(registry):
    if len(registry['items']) >= MAX_ITEMS:
        raise ValueError('500 repères conservés ; exporter et revoir la rétention. Aucun repère supprimé.')


def _find(registry, ident, revision):
    row = next((item for item in registry['items'] if item['id'] == ident), None)
    if row is None:
        raise ValueError('Ce repère ne figure pas dans cet espace.')
    check_revision(revision, row['revision'])
    return row


def _remember(n, row, action):
    if len(row['history']) >= MAX_HISTORY:
        raise ValueError('60 révisions conservées pour ce repère ; aucune version effacée.')
    row['history'].append({key: copy.deepcopy(row[key]) for key in
        ('revision', 'concept_id', 'title', 'text', 'status', 'verification', 'updated_at')})
    row.update(revision=row['revision'] + 1, updated_at=n.now(), last_action=action)


def _new(n, concept_id, title, text, origin, provenance, status='active'):
    return {'id': uuid.uuid4().hex[:12], 'world_id': worlds.current(),
            'concept_id': concept_id, 'title': title, 'text': text, 'status': status,
            'revision': 1, 'origin': origin, 'verification':
                'ai_classification_unverified' if origin == 'ai' else 'human_report_unverified',
            'provenance': copy.deepcopy(provenance), 'history': [],
            'created_at': n.now(), 'updated_at': n.now(), 'execution_enabled': False}


def create(n, concept_id, title, text, revision=0):
    concept = _concept(concept_id)
    title = text_field(title, 'Le titre', 160, True)
    text = text_field(text, 'Le contenu', 4000, True)
    with n.LOCK:
        s = n.load_state(); registry = _registry(s)
        check_revision(revision, registry['revision']); _capacity(registry)
        row = _new(n, concept['id'], title, text, 'human', [{
            'source_id': 'entry:' + uuid.uuid4().hex, 'quote': text, 'role': 'user',
            'world_id': worlds.current(), 'authority': 'human_report_unverified'}])
        registry['items'].append(row); registry['revision'] += 1
        _save(n, s, registry)
        return copy.deepcopy(row)


def update(n, ident, title, text, revision, concept_id=None):
    title = text_field(title, 'Le titre', 160, True)
    text = text_field(text, 'Le contenu', 4000, True)
    concept = _concept(concept_id) if concept_id is not None else None
    with n.LOCK:
        s = n.load_state(); registry = _registry(s); row = _find(registry, ident, revision)
        if row['status'] == 'archived':
            raise ValueError('Restaurer ce repère avant de le modifier.')
        _remember(n, row, 'human_edit')
        row.update(title=title, text=text, verification='human_edit_unverified')
        if concept: row['concept_id'] = concept['id']
        registry['revision'] += 1; _save(n, s, registry)
        return copy.deepcopy(row)


def _action(n, ident, revision, action):
    with n.LOCK:
        s = n.load_state(); registry = _registry(s); row = _find(registry, ident, revision)
        if action == 'review' and row['status'] != 'proposed':
            raise ValueError('Seul un repère proposé peut être retenu après revue.')
        if action == 'archive' and row['status'] == 'archived':
            raise ValueError('Ce repère est déjà archivé.')
        if action == 'restore' and row['status'] != 'archived':
            raise ValueError('Ce repère n’est pas archivé.')
        _remember(n, row, 'human_' + action)
        if action == 'review':
            row.update(status='active', verification='human_reviewed_not_independently_verified')
        elif action == 'archive':
            row.update(before_archive_status=row['status'], status='archived')
        else:
            row['status'] = row.pop('before_archive_status', 'proposed')
        registry['revision'] += 1; _save(n, s, registry)
        return copy.deepcopy(row)


def review(n, ident, revision):
    return _action(n, ident, revision, 'review')


def archive(n, ident, revision):
    return _action(n, ident, revision, 'archive')


def restore(n, ident, revision):
    return _action(n, ident, revision, 'restore')


def merge(n, ids, title, text, revision):
    """Explicit human composition; original cards and quotations stay intact."""
    if (not isinstance(ids, list) or not 2 <= len(ids) <= 8 or
            any(not isinstance(ident, str) for ident in ids) or len(set(ids)) != len(ids)):
        raise ValueError('Choisir de deux à huit repères distincts de cet espace.')
    title = text_field(title, 'Le titre commun', 160, True)
    text = text_field(text, 'Le contenu commun', 4000, True)
    with n.LOCK:
        s = n.load_state(); registry = _registry(s)
        check_revision(revision, registry['revision']); _capacity(registry)
        by_id = {row['id']: row for row in registry['items']}
        if any(ident not in by_id for ident in ids):
            raise ValueError('Tous les repères doivent appartenir à cet espace.')
        rows = [by_id[ident] for ident in ids]
        if len({row['concept_id'] for row in rows}) != 1:
            raise ValueError('Fusionner seulement des repères du même type ; un rôle n’est pas un contrat.')
        if any(row['status'] == 'archived' for row in rows):
            raise ValueError('Restaurer les repères archivés avant de les fusionner.')
        provenance = []
        for row in rows:
            for source in row['provenance']:
                item = copy.deepcopy(source)
                item['via_landmark_ids'] = list(dict.fromkeys(item.get('via_landmark_ids', []) + [row['id']]))
                if item not in provenance: provenance.append(item)
        result = _new(n, rows[0]['concept_id'], title, text, 'merge', provenance)
        result.update(merged_from=ids[:], verification='human_composition_unverified')
        for row in rows:
            _remember(n, row, 'human_merge')
            row.update(before_archive_status=row['status'], status='archived', merged_into=result['id'])
        registry['items'].append(result); registry['revision'] += 1
        _save(n, s, registry)
        return copy.deepcopy(result)


def sources(payload):
    """Only exact human messages and explicitly supplied imported excerpts.

IDs are local stable references to their actual location in this context. No
source is fetched here. Imported assistant words keep that role and uncertainty.
"""
    world_id = payload.get('world', {}).get('id', worlds.current())
    if world_id != worlds.current():
        raise ValueError('Le contexte source appartient à un autre espace.')
    result = []
    for ident, message in continuity._human_messages(payload.get('messages', [])).items():
        source = {'source_id': 'message:' + ident, 'text': message['text'], 'role': 'user',
                  'kind': 'message', 'message_id': ident, 'world_id': world_id,
                  'authority': 'human_report_unverified'}
        if message.get('source') == 'human_selected_transfer':
            source['text'] = message['origin']['quote']
            source['origin'] = copy.deepcopy(message['origin'])
            source['authority'] = 'transferred_human_report_unverified'
        result.append(source)
    for excerpt in payload.get('imported_history', {}).get('excerpts', []):
        if not isinstance(excerpt, dict) or excerpt.get('role') not in ('user', 'assistant'):
            continue
        metadata = {key: copy.deepcopy(excerpt[key]) for key in
                    ('archive_id', 'conversation_id', 'message_id', 'offset', 'role', 'source_role', 'active_branch')
                    if key in excerpt}
        if not all(isinstance(metadata.get(key), str) for key in ('archive_id', 'conversation_id', 'message_id')):
            raise ValueError('Référence d’archive incomplète.')
        if not isinstance(excerpt.get('text'), str): raise ValueError('Extrait source invalide.')
        digest = hashlib.sha256(json.dumps(metadata, sort_keys=True).encode()).hexdigest()
        result.append(dict(metadata, source_id='import:' + digest, text=excerpt['text'],
                           world_id=world_id, kind='imported_excerpt', authority='unverified_import'))
    return result


def source_inventory(payload):
    return [{key: value for key, value in row.items() if key not in ('text', 'origin')}
            for row in sources(payload)]


def validate_proposals(value, provided_sources):
    if not isinstance(value, list) or len(value) > MAX_PROPOSALS:
        raise ValueError('Cinq repères proposés maximum par réponse.')
    allowed = {}
    for source in provided_sources:
        if not isinstance(source, dict) or source.get('world_id') != worlds.current():
            raise ValueError('Source de repère extérieure à cet espace.')
        ident = source.get('source_id')
        if not isinstance(ident, str) or not isinstance(source.get('text'), str):
            raise ValueError('Source de repère invalide.')
        if ident in allowed and allowed[ident] != source:
            raise ValueError('Référence source ambiguë.')
        allowed[ident] = source
    clean = []
    for row in value:
        if not isinstance(row, dict) or set(row) != {'concept_id', 'source_id', 'quote'}:
            raise ValueError('Un repère IA contient uniquement un type, une source et sa citation exacte.')
        if not isinstance(row['concept_id'], str) or row['concept_id'] not in CONCEPT_IDS:
            raise ValueError('Type de repère inconnu.')
        if not isinstance(row['source_id'], str) or row['source_id'] not in allowed:
            raise ValueError('La source proposée ne figure pas dans le contexte transmis.')
        quote = row['quote']; source = allowed[row['source_id']]
        if not isinstance(quote, str) or not 8 <= len(quote) <= 2000 or not quote.strip() or quote not in source['text']:
            raise ValueError('Une citation exacte de 8 à 2000 caractères est requise ; aucun montant ou récit inventé.')
        clean.append(copy.deepcopy(row))
    return clean


def assimilate(n, s, proposals, provided_sources, reply_id):
    """Mutate the caller-owned state atomically with the saved dialogue reply."""
    result = {'ids': [], 'warnings': [], 'execution_enabled': False}
    if not s.get('continuity', {}).get('enabled', True): return result
    try: _writable(s)
    except ValueError as exc:
        result['warnings'].append(str(exc)); return result
    clean = validate_proposals(proposals, provided_sources)
    if not clean: return result
    registry = _registry(s); allowed = {row['source_id']: row for row in provided_sources}
    for proposal in clean:
        original = allowed[proposal['source_id']]
        identity = ([original.get(key) for key in ('archive_id', 'conversation_id', 'message_id')]
                    if original.get('kind') == 'imported_excerpt' else proposal['source_id'])
        fingerprint = n.digest_bytes(n.json_bytes([proposal['concept_id'], identity, proposal['quote']]))
        prior = next((row for row in registry['items'] if row.get('fingerprint') == fingerprint), None)
        if prior:
            result['ids'].append(prior['id']); continue
        if len(registry['items']) >= MAX_ITEMS:
            result['warnings'].append('Registre de repères plein ; proposition conservée dans la réponse brute.')
            continue
        source = {key: copy.deepcopy(value) for key, value in allowed[proposal['source_id']].items() if key != 'text'}
        source.update(quote=proposal['quote'], reply_id=reply_id)
        concept = _concept(proposal['concept_id'])
        row = _new(n, concept['id'], concept['label'], proposal['quote'], 'ai', [source], status='proposed')
        row['fingerprint'] = fingerprint
        registry['items'].append(row)
        if len(n.json_bytes(registry)) > MAX_BYTES:
            registry['items'].pop()
            result['warnings'].append('Capacité des repères atteinte ; aucune trace antérieure supprimée.')
            continue
        registry['revision'] += 1; result['ids'].append(row['id'])
    continuity.ensure(s)['landmarks'] = registry
    return result


def context(n, s, query=''):
    registry = _registry(s)
    enabled = s.get('continuity', {}).get('enabled', True)
    eligible = [row for row in registry['items'] if row['status'] != 'archived' and
                (enabled or row['origin'] != 'ai' or row['status'] == 'active')]
    terms = set(re.findall(r'\w{3,}', query.casefold()))
    def score(row):
        text = (row['title'] + ' ' + row['text']).casefold()
        return (sum(term in text for term in terms), row['status'] == 'active', row['updated_at'])
    eligible.sort(key=score, reverse=True)
    selected = [{key: copy.deepcopy(row[key]) for key in
                ('id', 'concept_id', 'title', 'text', 'status', 'revision', 'verification', 'origin', 'execution_enabled')}
                for row in eligible[:8]]
    for row in selected:
        row['text_truncated'] = len(row['text']) > 800; row['text'] = row['text'][:800]
        original = next(item for item in eligible if item['id'] == row['id'])
        row['sources'] = [{key: source[key] for key in ('source_id', 'role', 'authority') if key in source}
                          for source in original['provenance'][:4]]
        row['omitted_sources'] = max(0, len(original['provenance']) - 4)
    return {'world_id': worlds.current(), 'revision': registry['revision'], 'items': selected,
            'omitted_items': len(eligible) - len(selected), 'extraction_enabled': enabled,
            'concepts': [{key: value for key, value in _concept(ident).items()
                          if key in ('id', 'key', 'label', 'definition')} for ident in CONCEPT_IDS],
            'authority': 'attributed_descriptions_only', 'execution_enabled': False,
            'notice': 'Les repères et leur classement sont corrigeables. Un contrat ou une tâche décrit ne donne aucun droit d’agir ; une preuve citée reste à vérifier.'}
