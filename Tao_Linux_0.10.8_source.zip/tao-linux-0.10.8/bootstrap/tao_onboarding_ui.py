"""Private, reviewable history import with measured host capabilities kept apart."""
import html
import json
import os
from urllib.parse import quote


PAGE_JS = r'''
const $=id=>document.getElementById(id);
let selectedDocument=null,selectedKind='prepared',assignments=null,targets=null,review=null,generation=0,applying=false,previewing=false,pendingFiles=[],filePosition=0,fileTotal=0,currentFinished=false;
const kinds={context:'Contexte',preference:'Préférence',constraint:'Contrainte',question:'Question',goal:'Objectif',hypothesis:'Hypothèse',fact:'Élément rapporté'};
function el(tag,text,cls){const item=document.createElement(tag);if(text!==undefined)item.textContent=String(text);if(cls)item.className=cls;return item}
function notice(text,error=false){$('message').replaceChildren();$('message').textContent=text;$('message').classList.toggle('error',error);$('message').hidden=false}
function scoped(path){const url=new URL(path,location.origin);url.searchParams.set('world','main');return url.pathname+url.search}
async function request(path,data){
 const options={credentials:'same-origin',cache:'no-store'};
 if(data!==undefined){options.method='POST';options.headers={'Content-Type':'application/json','X-Tao-Token':token};options.body=JSON.stringify(data)}
 let response;try{response=await fetch(scoped(path),options)}catch(error){throw Error('Connexion interrompue : le résultat n’est pas confirmé. Relis un nouvel aperçu pour vérifier ce qui a été conservé avant de reprendre.')}
 let result;try{result=await response.json()}catch(error){throw Error('Réponse illisible : le résultat n’est pas confirmé. Relis un nouvel aperçu avant de reprendre.')}
 if(response.status===401){const error=Error('Ta session a expiré. Reconnecte-toi puis prépare un nouvel aperçu.');error.login=true;throw error}
 if(!response.ok)throw Error(result.error||'Cette demande n’a pas été acceptée. Prépare un nouvel aperçu avant de reprendre.');return result;
}
function route(action){return selectedKind==='prepared'?'/api/onboarding/'+action:'/api/history/'+action}
function payload(document){
 if(selectedKind==='prepared')return {document};
 const value=selectedKind==='archive_zip'?{archive_zip:document}:{archive:document};
 if(assignments)value.assignments=assignments.map(item=>({...item}));
 return value;
}
function encodeZip(buffer){
 const bytes=new Uint8Array(buffer),chunks=[];
 for(let offset=0;offset<bytes.length;offset+=32768)chunks.push(String.fromCharCode(...bytes.subarray(offset,offset+32768)));
 return btoa(chunks.join(''));
}
function showError(error){notice(error.message,true);if(error.login){const link=el('a',' Se reconnecter');link.href=config.login;$('message').appendChild(link)}}
function controls(){
 $('history-file').disabled=applying;$('preview-again').disabled=!selectedDocument||previewing||applying;$('reclassify').disabled=!selectedDocument||previewing||applying;
 for(const item of $('conversation-assignments').querySelectorAll('select'))item.disabled=previewing||applying;
 for(const item of $('target-assignments').querySelectorAll('select'))item.disabled=previewing||applying||Boolean(review&&review.already_imported);
 $('retarget-preview').disabled=!selectedDocument||previewing||applying;
 $('confirm-import').disabled=!review||review.already_imported||applying;
 $('apply-import').disabled=!review||review.already_imported||!$('confirm-import').checked||applying;
 $('apply-import').textContent=applying?'Reprise en cours…':'Reprendre mon histoire dans ces espaces';
 $('next-file').hidden=!pendingFiles.length;$('next-file').disabled=previewing||applying;
 $('next-file').textContent=(currentFinished?'Relire':'Passer à')+' l’export suivant ('+(filePosition+1)+'/'+fileTotal+')'+(currentFinished?'':' sans importer celui-ci');
 document.body.setAttribute('aria-busy',applying||previewing?'true':'false');
}
function invalidate(){review=null;$('confirm-import').checked=false;$('review').hidden=true;$('space-preview').replaceChildren();$('done').hidden=true;$('space-links').replaceChildren();controls()}
function renderAssignments(data){
 const section=$('classification'),box=$('conversation-assignments');box.replaceChildren();section.hidden=!Array.isArray(data.assignments);
 if(section.hidden)return;assignments=data.assignments.map(item=>({conversation_id:item.conversation_id,space_key:item.space_key}));
 $('classification-notice').textContent='Le classement proposé utilise les mots des conversations. Corrige-le si nécessaire, puis prépare un nouvel aperçu. Aucun modèle IA n’a été appelé.';
 for(const item of data.assignments){const label=el('label',undefined,'assignment');label.appendChild(el('span',item.title+' · '+item.message_count+' message(s)'));const select=el('select');
 for(const category of data.categories||[]){const option=el('option',category.title);option.value=category.key;select.appendChild(option)}select.value=item.space_key;
 select.onchange=()=>{if(applying||previewing)return;const row=assignments.find(entry=>entry.conversation_id===item.conversation_id);row.space_key=select.value;targets=null;$('target-placement').hidden=true;$('target-assignments').replaceChildren();generation++;invalidate();$('classification-notice').textContent='Classement modifié. Prépare un nouvel aperçu pour relire les espaces et les textes correspondants.'};label.appendChild(select);box.appendChild(label)}
}
function targetChoice(card,space,data){
 if(!Array.isArray(data.target_options)||space.key==='main')return;
 const label=el('label',undefined,'assignment');label.appendChild(el('span',(space.proposed_title||space.title)+' → conserver dans'));const select=el('select');
 const fresh=el('option','Créer un nouvel espace · '+(space.proposed_title||space.title));fresh.value='';select.appendChild(fresh);
 for(const candidate of data.target_options){if(candidate.id==='main'&&(data.spaces||[]).some(row=>row.key==='main'))continue;const option=el('option',candidate.title+' · espace existant');option.value=candidate.id;select.appendChild(option)}
 select.value=targets&&targets[space.key]||'';select.disabled=data.already_imported;
 select.onchange=()=>{if(applying||previewing||data.already_imported)return;targets={...(targets||{})};if(select.value)targets[space.key]=select.value;else delete targets[space.key];generation++;invalidate();notice('Destination modifiée. Prépare un nouvel aperçu pour vérifier les espaces, les textes et leur confidentialité avant de confirmer.')};
 label.appendChild(select);card.appendChild(label);
}
function renderTargets(data){
 const section=$('target-placement'),box=$('target-assignments');box.replaceChildren();section.hidden=!Array.isArray(data.target_options);
 if(section.hidden)return;for(const space of data.spaces||[])targetChoice(box,space,data);
}
function paragraph(parent,label,value){if(value===undefined||value===null||value==='')return;parent.append(el('h4',label),el('p',typeof value==='string'?value:JSON.stringify(value,null,2),'preserve'))}
function sourceDetails(parent,sources){
 if(!sources||!sources.length)return;
 const box=el('details');box.appendChild(el('summary','Sources déclarées · '+sources.length));
 box.appendChild(el('p','Ces sources sont fournies avec le fichier. Leur auteur et leur exactitude ne sont pas authentifiés.','muted'));
 for(const source of sources){const item=el('article',undefined,'source');item.append(el('h4',source.label||source.id),el('p','Référence : '+source.id+' · '+(source.kind||'origine déclarée'),'small'));if(source.text)item.appendChild(el('p',source.text,'preserve'));box.appendChild(item)}
 parent.appendChild(box);
}
function references(parent,ids,sources){
 if(!ids||!ids.length)return;
 const labels=ids.map(id=>{const source=(sources||[]).find(item=>item.id===id);return source?source.label+' ['+id+']':id});
 parent.appendChild(el('p','Sources déclarées : '+labels.join(' · '),'small'));
}
function renderPreview(data){
 if(data.targets&&typeof data.targets==='object')targets={...data.targets};
 $('review-title').textContent=data.title||'Ton histoire à reprendre';const counts=data.counts||{};
 $('review-counts').textContent=(counts.new_spaces||0)+' nouvel(s) espace(s) · '+(counts.notes||0)+' note(s) · '+(counts.needs||0)+' besoin(s) à suivre.';
 $('review-notice').textContent=data.already_imported?'Ce fichier a déjà été repris. Tes corrections ultérieures sont conservées ; aucun nouvel import n’est nécessaire.':(data.notice||'Relis les histoires, les notes et les besoins avant de les conserver.');
 const warnings=$('import-warnings');warnings.replaceChildren();for(const warning of data.warnings||[])warnings.appendChild(el('li',typeof warning==='string'?warning:JSON.stringify(warning)));
 if(selectedKind!=='prepared')warnings.appendChild(el('li','Les messages de l’export sont conservés comme archives. Le contexte de discussion reçoit seulement les extraits sélectionnés ci-dessous ; les messages système et outils ne deviennent pas des consignes. Les pièces jointes ne sont pas transférées. Cet import n’est pas une synchronisation de ton compte.'));
 const box=$('space-preview');box.replaceChildren();const spaces=data.spaces||[];
 for(const space of spaces){const card=el('article',undefined,'space');card.append(el('h3',space.title),el('p',space.existing?'Espace existant · contexte ajouté sans remplacer son histoire':'Nouvel espace','tag'));
 if(space.notice)card.appendChild(el('p',space.notice,'muted'));if(space.proposed_title&&space.proposed_title!==space.title)paragraph(card,'Nom proposé dans le fichier',space.proposed_title);if(space.proposed_description&&space.proposed_description!==space.description)paragraph(card,'Description proposée dans le fichier',space.proposed_description);
 const parent=spaces.find(item=>item.id===space.parent_id);card.appendChild(el('p','Rattaché à : '+(parent?parent.title:space.parent_id==='main'?'Principal':space.parent_id||'racine'),'small'));
 paragraph(card,'Description',space.description);paragraph(card,space.story_mode==='append_context'?'Histoire proposée, ajoutée comme contexte':'Histoire proposée',space.story);references(card,space.source_ids,space.sources);
 if((space.notes||[]).length){card.appendChild(el('h4','Ce que Tao pourra retenir'));const list=el('ul');for(const note of space.notes){const item=el('li');item.append(el('strong',(kinds[note.kind]||note.kind)+' — '),el('span',note.text,'preserve'));references(item,note.source_ids,space.sources);list.appendChild(item)}card.appendChild(list)}
 if((space.needs||[]).length){card.appendChild(el('h4','Besoins à suivre'));for(const need of space.needs){const item=el('div',undefined,'need');item.appendChild(el('h5',need.title));paragraph(item,'Situation actuelle',need.current);paragraph(item,'Résultat souhaité',need.desired);paragraph(item,'Comment le vérifier',need.acceptance);paragraph(item,'Prochaine étape proposée',need.next_step);references(item,need.source_ids,space.sources);card.appendChild(item)}}
 sourceDetails(card,space.sources);box.appendChild(card);
 }
 const raw=el('details');raw.append(el('summary','Voir l’aperçu complet'),el('pre',JSON.stringify(data,null,2)));box.appendChild(raw);renderAssignments(data);renderTargets(data);
 $('review').hidden=false;$('confirm-import').checked=false;if(data.already_imported){currentFinished=true;showSpaces(data.spaces,true)}controls();
}
function showSpaces(spaces,already){
 $('done-title').textContent=already?'Ces pièces sont déjà prêtes.':'Les pièces de ta maison sont prêtes.';
 $('done-note').textContent='Tes pièces sont prêtes. Ouvre celle que tu veux visiter : tu pourras y poursuivre la discussion et corriger ce qui mérite de l’être. L’import n’a lancé aucune action ni connecté d’outil.';
 const list=$('space-links');list.replaceChildren();for(const space of spaces||[]){const item=el('li'),link=el('a',space.title);link.href='/explore?world='+encodeURIComponent(space.id);item.appendChild(link);list.appendChild(item)}$('done').hidden=false;
}
async function preparePreview(){
 if(!selectedDocument||applying||previewing)return;const turn=++generation,documentToReview=selectedDocument;invalidate();previewing=true;controls();notice('Préparation de l’aperçu…');
 try{const body=payload(documentToReview);if(targets!==null)body.targets={...targets};const data=await request(route('preview'),body);if(turn!==generation)return;review=data;renderPreview(data);notice(data.already_imported?'Ce fichier a déjà été repris.':'Aperçu prêt. Vérifie la destination de chaque partie. Rien n’a encore été importé.')}
 catch(error){if(turn===generation){
  if(!error.login&&$('target-placement').hidden){try{const choices=await request(route('destinations'),payload(documentToReview));if(turn===generation){if(targets===null)targets={...(choices.targets||{})};renderTargets(choices)}}catch(ignored){}}
  if(turn===generation)showError(error)
 }}finally{if(turn===generation){previewing=false;controls()}}
}
async function loadFile(file){
 const turn=++generation;selectedDocument=null;assignments=null;targets=null;review=null;currentFinished=false;previewing=false;invalidate();$('classification').hidden=true;$('conversation-assignments').replaceChildren();$('target-placement').hidden=true;$('target-assignments').replaceChildren();$('message').hidden=true;const position=fileTotal>1?' · export '+filePosition+'/'+fileTotal:'';$('file-status').textContent=file?file.name+position:'Aucun fichier choisi.';if(!file)return;
 try{if(!file.size)throw Error('Le fichier choisi est vide.');if(file.size>16777216)throw Error('Le fichier dépasse 16 Mio. Prépare un export plus petit.');const zipped=/\.zip$/i.test(file.name)||file.type==='application/zip'||file.type==='application/x-zip-compressed';if(zipped){selectedKind='archive_zip';selectedDocument=encodeZip(await file.arrayBuffer());if(turn!==generation)return;$('file-status').textContent=file.name+position+' · ZIP prêt à relire.'}else{const text=await file.text();if(turn!==generation)return;let data;try{data=JSON.parse(text)}catch(error){throw Error('Le fichier n’est pas un document JSON lisible. Choisis un ZIP pris en charge ou son fichier conversations.json.')}if(!data||typeof data!=='object')throw Error('Le fichier doit contenir un export de conversations ou une histoire Tao.');selectedKind=data.schema==='tao.history_import.v1'?'prepared':'archive';if(selectedKind==='prepared'&&file.size>262144)throw Error('L’histoire Tao préparée dépasse 256 Kio. Prépare un extrait plus petit.');selectedDocument=data;$('file-status').textContent=file.name+position+' · JSON prêt à relire.'}controls();await preparePreview()}
 catch(error){if(turn===generation){showError(error);controls()}}
}
async function selectFile(){
 if(applying)return;const files=Array.from($('history-file').files||[]);pendingFiles=[];fileTotal=files.length;filePosition=files.length?1:0;if(files.length>8){generation++;selectedDocument=null;fileTotal=0;invalidate();$('file-status').textContent=files.length+' fichiers choisis.';notice('Choisis au maximum 8 exports à la fois.',true);return}pendingFiles=files.slice(1);await loadFile(files[0]);
}
async function nextFile(){
 if(applying||previewing||!pendingFiles.length)return;const file=pendingFiles.shift();filePosition++;await loadFile(file);
}
async function applyImport(event){
 event.preventDefault();if(applying||!review||review.already_imported||!$('confirm-import').checked)return;
 const documentToImport=selectedDocument,reviewToApply=review;applying=true;controls();notice('Reprise de ton histoire…');
 try{const body=payload(documentToImport);body.review_digest=reviewToApply.review_digest;body.confirmed=true;if(reviewToApply.targets)body.targets={...reviewToApply.targets};const result=await request(route('apply'),body);currentFinished=true;showSpaces(result.spaces,result.already_imported);review=null;$('review').hidden=true;$('classification').hidden=true;$('target-placement').hidden=true;notice((result.already_imported?'Ce fichier avait déjà été repris.':'Espaces, notes et besoins conservés.')+(pendingFiles.length?' Relis maintenant l’export suivant.':' Tu peux continuer dans Tao.'))}
 catch(error){invalidate();showError(error)}finally{applying=false;$('confirm-import').checked=false;controls()}
}
const environmentLabels={observed_at:'Mesuré le',measured_at:'Mesuré le',scope:'Lieu de mesure',host:'Hôte de Tao',system:'Système',platform:'Système',release:'Version du système',machine:'Architecture',python:'Python',version:'Version',tools:'Outils',name:'Nom',present:'Présent',available:'Disponible',authenticated:'Authentification',adapter:'Prise en charge',resources:'Ressources',memory_total:'Mémoire totale',memory_available:'Mémoire disponible',disk_total:'Disque total',disk_free:'Disque disponible',cpu_count:'Processeurs logiques',limitations:'Limites',notes:'Précisions',codex:'Codex',git:'Git',node_version:'Version de Tao',running:'Tao actif',authority:'Autorité',execution_enabled:'Exécution autorisée'};
function environmentFields(parent,value,depth=0){
 if(depth>5){parent.appendChild(el('p',JSON.stringify(value)));return}
 if(Array.isArray(value)){const list=el('ul');for(const item of value){const row=el('li');environmentFields(row,item,depth+1);list.appendChild(row)}parent.appendChild(list);return}
 if(value&&typeof value==='object'){const list=el('dl');for(const [key,item] of Object.entries(value)){list.appendChild(el('dt',environmentLabels[key]||key));const detail=el('dd');if(['memory_total','memory_available','disk_total','disk_free'].includes(key)&&typeof item==='number')detail.appendChild(el('span',(item/1073741824).toLocaleString('fr-FR',{maximumFractionDigits:1})+' Gio'));else environmentFields(detail,item,depth+1);list.appendChild(detail)}parent.appendChild(list);return}
 parent.appendChild(el('span',value===true?'Oui':value===false?'Non':value===null?'Non vérifié':value==='observation_only'?'Observation seulement':String(value)));
}
async function loadEnvironment(){
 const button=$('refresh-environment');if(button.disabled)return;button.disabled=true;$('environment-status').textContent='Lecture des moyens de cette installation…';
 try{const data=await request('/api/onboarding/environment');$('environment-data').replaceChildren();environmentFields($('environment-data'),data);$('environment-status').textContent='État mesuré sur l’hôte qui exécute Tao. Ces observations sont distinctes des déclarations du fichier.'}
 catch(error){$('environment-status').textContent=error.message;showError(error)}finally{button.disabled=false}
}
$('history-file').onchange=selectFile;$('next-file').onclick=nextFile;$('preview-again').onclick=preparePreview;$('reclassify').onclick=preparePreview;$('retarget-preview').onclick=preparePreview;$('confirm-import').onchange=controls;$('import-form').onsubmit=applyImport;$('refresh-environment').onclick=loadEnvironment;
controls();loadEnvironment();
'''


def render(n, s):
    """Return a main-space review page; child pages never receive the importer."""
    world = n.worlds.current()
    home = html.escape('/?world=' + quote(world, safe=''), quote=True)
    head = '''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tao · Reprendre mes conversations</title><style>
:root{color-scheme:light;--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.6 system-ui,sans-serif}main{max-width:860px;margin:auto;padding:28px 24px 64px}nav{display:flex;align-items:center;justify-content:space-between;gap:20px;padding-bottom:18px;border-bottom:1px solid var(--line)}.brand{font-size:25px;letter-spacing:.13em}header{padding:30px 0 22px}h1{font-size:clamp(30px,5vw,44px);line-height:1.15;margin:10px 0}h2{font-size:23px;line-height:1.3;margin:0 0 15px}h3{font-size:21px;line-height:1.4;margin:0 0 10px}h4{font-size:16px;margin:18px 0 4px}h5{font-size:18px;margin:4px 0}p{margin:8px 0}a{color:var(--accent)}section{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:24px;margin-bottom:22px;overflow-wrap:anywhere}button,input,select{font:inherit;max-width:100%}select{width:100%;padding:10px;background:var(--bg);color:var(--text);border:1px solid #b9c7bc;border-radius:8px}.assignment{display:block;margin:18px 0}.assignment span{display:block;margin-bottom:7px}button{min-height:44px;padding:11px 17px;margin:12px 0 4px;border:0;border-radius:9px;background:var(--accent);color:#fff;font-weight:600;cursor:pointer}button.secondary{background:transparent;color:var(--text);border:1px solid #b9c7bc}button:disabled{opacity:.5;cursor:not-allowed}input[type=file]{width:100%;padding:12px 0}input[type=file]::file-selector-button{font:inherit;padding:10px 14px;margin-right:14px;background:#f1f3ec;color:var(--text);border:1px solid #b9c7bc;border-radius:8px;cursor:pointer}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid var(--accent);outline-offset:4px}.muted,.small,summary{color:var(--muted)}.small{font-size:13px}.tag{color:var(--accent);font-size:14px}.preserve{white-space:pre-wrap}.space{border-top:1px solid var(--line);padding:22px 0}.space:first-child{margin-top:22px}.need,.source{border-left:2px solid var(--line);padding:8px 0 8px 16px;margin:14px 0}li{margin:12px 0}ul{padding-left:22px}details{margin-top:16px}summary{cursor:pointer;min-height:44px;padding:8px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;max-height:55vh;overflow:auto;font-size:13px;background:var(--bg);padding:16px;border-radius:8px}.consent{display:flex;gap:12px;align-items:flex-start;margin:20px 0 10px}.consent input{width:20px;height:20px;flex:0 0 20px;margin-top:4px}dt{font-size:14px;color:var(--muted);margin-top:12px}dd{margin:0 0 10px}dd dl{padding-left:16px}#message{background:var(--accent);color:#fff;padding:15px 18px;border-radius:10px;margin-bottom:22px;overflow-wrap:anywhere}#message.error{background:#fff1e6}#message a{color:inherit}#space-links a{display:inline-block;min-height:44px;padding:8px 0}[hidden]{display:none!important}@media(max-width:540px){main{padding:16px 14px 40px}section{padding:18px}header{padding-top:24px}button{width:100%}nav>a{font-size:14px}input[type=file]::file-selector-button{display:block;margin-bottom:10px}}

/* Tao · maison : surfaces, typography and interaction */
:root{--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47;--soft:#edf1ea;--gold:#c79d67;color-scheme:light}
body{min-height:100vh;background:radial-gradient(circle at 88% -10%,#eee3d2,transparent 38%),var(--bg)}
nav{min-height:60px}.page-nav{display:flex;align-items:center;justify-content:space-between;gap:20px;padding-bottom:18px;border-bottom:1px solid var(--line)}.eyebrow{color:var(--accent);font:700 11px/1.5 system-ui,sans-serif;letter-spacing:.15em;text-transform:uppercase}nav .brand{font:600 29px/1 ui-serif,Georgia,serif;letter-spacing:-.045em;color:var(--text);text-decoration:none}
a{color:var(--accent);text-underline-offset:3px}a:hover,summary:hover{text-decoration-color:var(--gold)}
header{margin:26px 0 28px;padding:clamp(24px,4vw,42px);border:1px solid var(--line);border-top:3px solid var(--gold);border-radius:20px;background:linear-gradient(135deg,#fffdfa,#f6f1e8);box-shadow:0 12px 30px rgba(39,55,47,.045)}
header p:last-child{max-width:68ch}h1,h2,h3{font-family:ui-serif,Georgia,serif;letter-spacing:-.025em}h1{font-weight:500}h2,h3{font-weight:600}
section,.panel{box-shadow:0 6px 22px rgba(39,55,47,.035)}
button,.button{background:var(--accent);color:#fff}button.secondary,.button.secondary{background:var(--soft);color:var(--accent);border:1px solid var(--line)}
input:not([type=checkbox]):not([type=file]),textarea,select{background:var(--panel);color:var(--text);border-color:#b9c7bc}pre{background:#f3f1eb;color:var(--text);border:1px solid var(--line)}
button:focus-visible,a:focus-visible,summary:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid var(--accent);outline-offset:3px}
#message{background:#ecf1ea;color:var(--text);border:1px solid #b7cab8;box-shadow:0 8px 25px rgba(39,55,47,.12)}#message.error{background:#fff1e6;color:#613f2d;border-color:#dfb997}
#space-links{list-style:none;display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,210px),1fr));gap:10px;padding:0;margin:22px 0}#space-links li{margin:0}#space-links a{display:flex;align-items:center;min-height:70px;padding:14px 18px;background:var(--soft);border:1px solid var(--line);border-radius:12px;font-weight:600;text-decoration:none}.home-link{display:inline-flex;align-items:center;min-height:44px;padding:10px 16px;background:var(--accent);color:#fff;border-radius:9px;text-decoration:none;font-weight:600}.home-link:hover{color:#fff}
@media(max-width:540px){header{margin:18px 0 20px;padding:23px 19px;border-radius:16px}}
</style></head><body><main><nav><a class="brand" href="/?world=main">tao.</a><a href="''' + home + '''">Retour à Tao</a></nav><header><p class="eyebrow">Import · préparer les pièces</p><h1>Faire entrer mes connaissances.</h1><p>Choisis un export de conversations. Tao propose les pièces où ranger tes projets et tes questions ; tu relis chaque suggestion avant de la conserver.</p></header>'''
    if world != 'main':
        return head + '''<section><h2>Depuis ton espace principal</h2><p>La reprise peut créer plusieurs espaces. Ouvre ce parcours depuis le principal pour choisir et relire le fichier.</p><a href="/onboarding?world=main">Reprendre mon histoire dans le principal</a></section></main></body></html>'''
    config = {'world': 'main',
              'login': '/host/login' if os.environ.get('TAO_HOSTED') == '1' else '/mobile/login'}
    encoded = json.dumps(config, ensure_ascii=True).replace('<', '\\u003c')
    token = json.dumps(n.TOKEN, ensure_ascii=True).replace('<', '\\u003c')
    return head + '''<section aria-labelledby="file-title"><h2 id="file-title">1. Choisir mes conversations</h2><p>Sélectionne directement un ou plusieurs ZIP d’export ChatGPT ou Claude, des exports JSON pris en charge, ou un fichier d’histoire préparé avec ton IA. Tao traite chaque source séparément et demande une nouvelle confirmation avant chaque import.</p><p class="small"><strong>Récupérer mon export :</strong> <a href="https://chatgpt.com/settings/data-controls" target="_blank" rel="noreferrer">ChatGPT · Contrôles des données</a> · <a href="https://claude.ai/settings/data-privacy-controls" target="_blank" rel="noreferrer">Claude · Confidentialité</a>. Choisis ensuite <strong>Exporter les données</strong> et télécharge le ZIP reçu par e-mail.</p><p class="small"><strong>Gemini :</strong> Google propose un export via <a href="https://takeout.google.com/" target="_blank" rel="noreferrer">Google Takeout</a>, mais Tao ne reconnaît pas encore son format d’activité. Il ne sera pas présenté comme importé sans adaptateur vérifié.</p><label for="history-file">Mes exports de conversations ou mon histoire Tao</label><input id="history-file" type="file" multiple accept=".zip,application/zip,application/x-zip-compressed,.json,application/json" aria-describedby="file-help file-status"><p id="file-status" class="small">Aucun fichier choisi.</p><p id="file-help" class="small">Jusqu’à 8 fichiers à la fois. Chaque ZIP ou JSON est limité à 16 Mio ; une histoire Tao préparée à 256 Kio. Dans un ZIP, Tao lit uniquement l’unique fichier conversations.json en mémoire et ne copie aucune pièce jointe. Les fichiers sont transmis uniquement à cette installation de Tao. Aucun accès à tes comptes IA n’est créé. Un autre service reste compatible s’il fournit un format JSON reconnu.</p><button id="preview-again" class="secondary" type="button" disabled>Préparer un nouvel aperçu</button><button id="next-file" class="secondary" type="button" hidden>Passer à l’export suivant</button></section><div id="message" role="status" aria-live="polite" hidden></div>
<section aria-labelledby="waiting-title"><h2 id="waiting-title">En attendant mon export</h2><p>Tu peux déjà raconter au centre principal ce que tu veux comprendre : il gardera la demande ici, proposera un centre adapté ou préparera un lien à relire. Les anciennes pièces restent consultables librement ; rien n’est envoyé ni conservé automatiquement par un simple clic.</p><p class="small">Ce que tu ajoutes et corriges maintenant sera préservé si tu importes tes conversations plus tard.</p><p><a class="home-link" href="/?world=main">Parler dans le centre principal</a> · <a href="/explore?world=main#spaces-title">Parcourir les repères</a></p></section>
<section id="classification" aria-labelledby="classification-title" hidden><h2 id="classification-title">2. Choisir les espaces</h2><p id="classification-notice"></p><div id="conversation-assignments"></div><button id="reclassify" type="button" class="secondary">Relire avec ce classement</button></section>
<section id="target-placement" aria-labelledby="target-title" hidden><h2 id="target-title">Remplir mes espaces</h2><p>Choisis où conserver chaque partie. Les suggestions utilisent uniquement l’identité des espaces de départ. Le nom, l’histoire et les données des espaces existants sont préservés ; chaque changement demande un nouvel aperçu.</p><div id="target-assignments"></div><button id="retarget-preview" type="button" class="secondary">Relire ces destinations</button></section>
<section id="review" aria-labelledby="review-title" hidden><h2 id="review-title">Relire ce qui sera conservé</h2><p id="review-counts" class="tag"></p><p id="review-notice"></p><ul id="import-warnings"></ul><p class="muted">Les textes importés sont des déclarations à vérifier et à corriger. Une ancienne intention peut avoir changé. Ils ne prouvent ni l’état actuel de ta machine ni la disponibilité de tes comptes.</p><div id="space-preview"></div><form id="import-form"><label class="consent"><input id="confirm-import" type="checkbox" required><span>J’ai relu ces espaces et ces textes. Je souhaite les conserver dans mon Tao privé.</span></label><p class="small">Les extraits pertinents des archives pourront accompagner tes prochains messages à l’IA configurée. Tu peux désactiver cette recherche dans Ma mémoire et la continuité. Cette reprise ne lance aucune IA ou tâche et ne connecte aucun compte. Les besoins restent ouverts.</p><button id="apply-import" disabled>Créer mes espaces et reprendre mon histoire</button></form></section>
<section id="done" aria-labelledby="done-title" hidden><h2 id="done-title"></h2><p id="done-note"></p><ul id="space-links"></ul><a class="home-link" href="/?world=main">Voir ma maison</a></section>
<section aria-labelledby="environment-title"><h2 id="environment-title">Ce que Tao observe ici</h2><p>Le système et les outils de l’hôte qui exécute Tao. Sur un téléphone, cet hôte peut être ton PC ou un serveur.</p><p id="environment-status" class="small" role="status">Lecture des moyens disponibles…</p><div id="environment-data"></div><p class="small">La présence d’un programme ne prouve pas qu’un compte est connecté ni qu’il peut agir. Cette lecture ne parcourt pas tes documents et n’appelle aucune IA.</p><button id="refresh-environment" type="button" class="secondary">Actualiser les observations</button></section><footer class="small">Tao ''' + html.escape(n.NODE_VERSION, quote=True) + ''' · Tes histoires restent dans les espaces choisis.</footer></main><script>
const token=''' + token + ''';
const config=''' + encoded + ''';
''' + PAGE_JS + '\n</script></body></html>'


page = render


ARCHIVES_JS = r'''
const $=id=>document.getElementById(id);
let searchGeneration=0;
function el(tag,text,cls){const node=document.createElement(tag);if(text!==undefined)node.textContent=String(text);if(cls)node.className=cls;return node}
function scoped(path){const url=new URL(path,location.origin);url.searchParams.set('world',config.world);return url.pathname+url.search}
async function request(path){let response;try{response=await fetch(scoped(path),{cache:'no-store',credentials:'same-origin'})}catch(error){throw Error('La connexion a été interrompue. Réessaie la lecture.')}let result;try{result=await response.json()}catch(error){throw Error('La réponse est illisible. Réessaie la lecture.')}
 if(response.status===401){const error=Error('Ta session a expiré. Reconnecte-toi pour consulter tes archives.');error.login=true;throw error}
 if(!response.ok)throw Error(result.error||'Cette lecture n’a pas abouti. Réessaie.');return result;
}
function showError(target,error){target.replaceChildren();target.appendChild(el('p',error.message||'La connexion a été interrompue. Réessaie la lecture.'));if(error.login){const link=el('a','Se reconnecter');link.href=config.login;target.appendChild(link)}}
async function loadArchives(){
 const box=$('archive-list');try{const data=await request('/api/history/archives');box.replaceChildren();const archives=data.archives||[];
 if(!archives.length){box.appendChild(el('p','Aucune conversation importée dans cet espace.'));return}
 for(const archive of archives){const card=el('article');card.appendChild(el('h3',archive.title||'Archive de conversations'));card.appendChild(el('p',archive.conversations+' conversation(s) · '+archive.messages+' message(s).','muted'));const details=el('details');details.appendChild(el('summary','Origine et téléchargement'));details.appendChild(el('pre',JSON.stringify(archive.source||{},null,2)));details.appendChild(el('p','Le téléchargement contient uniquement les conversations de cette archive attribuées à cet espace. Garde ce fichier privé.','muted'));const link=el('a','Télécharger l’archive normalisée de cet espace');link.href=scoped('/api/history/archive?id='+encodeURIComponent(archive.id));details.appendChild(link);card.appendChild(details);box.appendChild(card)}
 }catch(error){showError(box,error)}
}
async function search(event){
 event.preventDefault();const query=$('archive-query').value.trim(),turn=++searchGeneration,box=$('search-results');box.replaceChildren();if(!query)return;box.appendChild(el('p','Recherche dans cet espace…'));
 try{const result=await request('/api/history/search?q='+encodeURIComponent(query));if(turn!==searchGeneration)return;box.replaceChildren();const excerpts=result.excerpts||[];
 if(!excerpts.length)box.appendChild(el('p','Aucun extrait trouvé dans les conversations importées de cet espace.'));
 for(const excerpt of excerpts){const card=el('article');card.append(el('h3',excerpt.title||'Conversation'),el('p','Rôle déclaré : '+(excerpt.source_role||excerpt.role||'inconnu'),'muted'),el('p',excerpt.text,'preserve'));if(excerpt.truncated)card.appendChild(el('p','Extrait abrégé. Le message complet reste dans l’archive.','muted'));card.appendChild(el('p','Conversation : '+excerpt.conversation_id+' · message : '+excerpt.message_id,'small'));box.appendChild(card)}
 }catch(error){if(turn===searchGeneration)showError(box,error)}
}
$('archive-search').onsubmit=search;loadArchives();
'''


def render_archives(n, s):
    """Read archives only in the current space; search is an explicit request."""
    world = n.worlds.current()
    config = {'world': world,
              'login': '/host/login' if os.environ.get('TAO_HOSTED') == '1' else '/mobile/login'}
    encoded = json.dumps(config, ensure_ascii=True).replace('<', '\\u003c')
    home = html.escape('/?world=' + quote(world, safe=''), quote=True)
    return '''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tao · Mes conversations importées</title><style>
:root{color-scheme:light;--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.6 system-ui,sans-serif}main{max-width:860px;margin:auto;padding:28px 24px 64px}nav{display:flex;justify-content:space-between;gap:18px;border-bottom:1px solid var(--line);padding-bottom:18px}.brand{font-size:25px;letter-spacing:.13em}header{padding:30px 0 22px}h1{font-size:clamp(30px,5vw,44px);line-height:1.15}h2{font-size:23px}h3{font-size:18px}a{color:var(--accent)}section{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:24px;margin-bottom:22px;overflow-wrap:anywhere}label{display:block}input{font:inherit;width:100%;padding:12px;background:var(--bg);color:var(--text);border:1px solid #b9c7bc;border-radius:8px;margin-top:8px}button{font:inherit;min-height:44px;padding:11px 17px;margin-top:12px;border:0;border-radius:9px;background:var(--accent);color:#fff;cursor:pointer;font-weight:600}button:focus-visible,a:focus-visible,input:focus-visible,summary:focus-visible{outline:3px solid var(--accent);outline-offset:4px}.muted,.small,summary{color:var(--muted)}.small{font-size:13px}.preserve{white-space:pre-wrap}article{padding:18px 0;border-top:1px solid var(--line)}article:first-child{border:0}pre{font-size:13px;white-space:pre-wrap;overflow-wrap:anywhere;max-height:40vh;overflow:auto}summary{min-height:44px;cursor:pointer;padding:8px 0}@media(max-width:540px){main{padding:16px 14px 40px}section{padding:18px}button{width:100%}}

/* Tao · maison : surfaces, typography and interaction */
:root{--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47;--soft:#edf1ea;--gold:#c79d67;color-scheme:light}
body{min-height:100vh;background:radial-gradient(circle at 88% -10%,#eee3d2,transparent 38%),var(--bg)}
nav{min-height:60px}.page-nav{display:flex;align-items:center;justify-content:space-between;gap:20px;padding-bottom:18px;border-bottom:1px solid var(--line)}.eyebrow{color:var(--accent);font:700 11px/1.5 system-ui,sans-serif;letter-spacing:.15em;text-transform:uppercase}nav .brand{font:600 29px/1 ui-serif,Georgia,serif;letter-spacing:-.045em;color:var(--text);text-decoration:none}
a{color:var(--accent);text-underline-offset:3px}a:hover,summary:hover{text-decoration-color:var(--gold)}
header{margin:26px 0 28px;padding:clamp(24px,4vw,42px);border:1px solid var(--line);border-top:3px solid var(--gold);border-radius:20px;background:linear-gradient(135deg,#fffdfa,#f6f1e8);box-shadow:0 12px 30px rgba(39,55,47,.045)}
header p:last-child{max-width:68ch}h1,h2,h3{font-family:ui-serif,Georgia,serif;letter-spacing:-.025em}h1{font-weight:500}h2,h3{font-weight:600}
section,.panel{box-shadow:0 6px 22px rgba(39,55,47,.035)}
button,.button{background:var(--accent);color:#fff}button.secondary,.button.secondary{background:var(--soft);color:var(--accent);border:1px solid var(--line)}
input:not([type=checkbox]):not([type=file]),textarea,select{background:var(--panel);color:var(--text);border-color:#b9c7bc}pre{background:#f3f1eb;color:var(--text);border:1px solid var(--line)}
button:focus-visible,a:focus-visible,summary:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid var(--accent);outline-offset:3px}
#message{background:#ecf1ea;color:var(--text);border:1px solid #b7cab8;box-shadow:0 8px 25px rgba(39,55,47,.12)}#message.error{background:#fff1e6;color:#613f2d;border-color:#dfb997}
#space-links{list-style:none;display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,210px),1fr));gap:10px;padding:0;margin:22px 0}#space-links li{margin:0}#space-links a{display:flex;align-items:center;min-height:70px;padding:14px 18px;background:var(--soft);border:1px solid var(--line);border-radius:12px;font-weight:600;text-decoration:none}.home-link{display:inline-flex;align-items:center;min-height:44px;padding:10px 16px;background:var(--accent);color:#fff;border-radius:9px;text-decoration:none;font-weight:600}.home-link:hover{color:#fff}
@media(max-width:540px){header{margin:18px 0 20px;padding:23px 19px;border-radius:16px}}
</style></head><body><main><nav><a class="brand" href="''' + home + '''">tao.</a><a href="''' + home + '''">Retour à ma pièce</a></nav><header><p class="eyebrow">La bibliothèque · sources</p><h1>Mes conversations importées.</h1><p>Retrouve un passage dans cette pièce et consulte sa source. Tu choisis ensuite ce que Tao doit retenir.</p><a href="/onboarding?world=main">Reprendre d’autres conversations</a></header><section><h2>Retrouver un passage</h2><form id="archive-search"><label for="archive-query">Mots à rechercher dans cet espace</label><input id="archive-query" type="search" maxlength="160" required><button>Chercher dans les archives</button></form><div id="search-results" role="status" aria-live="polite"></div></section><section><h2>Archives de cet espace</h2><p class="muted">Ces textes viennent d’un export déclaré. Ils ne prouvent ni l’identité de leur auteur ni l’exactitude d’une réponse IA. Les pièces jointes ne sont pas transférées.</p><div id="archive-list" role="status" aria-live="polite">Lecture des archives…</div></section></main><script>
const config=''' + encoded + ''';
''' + ARCHIVES_JS + '\n</script></body></html>'
