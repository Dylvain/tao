"""Compare provided discrete measurements with declared model bounds.

This pure calculator does not estimate a person's integration capacity. Bounds
are hypotheses supplied by the caller, not scientific or financial assurances.
It neither persists data nor changes an action, permission, buffer or policy.
"""
import copy
import math
from fractions import Fraction


REQUEST_SCHEMA = 'tao.integrability.request.v1'
RESULT_SCHEMA = 'tao.integrability.evaluation.v1'
MAX_SAMPLES = 200
ORDER_KEYS = ('state', 'trend', 'trend_change')


def _text(value, label, maximum):
    if (not isinstance(value, str) or not value.strip() or len(value) > maximum
            or any(ord(character) < 32 or ord(character) == 127 for character in value)):
        raise ValueError(label + ' : texte non vide requis, ' + str(maximum) + ' caractères maximum.')
    return value.strip()


def _number(value, label):
    # bool is an int in Python, but is not a measurement or a time.
    if type(value) not in (int, float):
        raise ValueError(label + ' : nombre fini requis.')
    try:
        finite = math.isfinite(value)
    except (OverflowError, ValueError):
        finite = False
    if not finite:
        raise ValueError(label + ' : nombre fini représentable requis.')
    return value


def _fraction(value):
    # Treat the supplied decimal spelling as the model value. In particular,
    # 0.3 - 0.2 is compared to 0.1 without a binary rounding artefact. This
    # does not recover precision already lost before the input was supplied.
    return Fraction(str(value))


def _display(value):
    try:
        result = float(value)
    except (OverflowError, ValueError):
        raise ValueError('Échelle numérique non représentable ; changer les unités ou les mesures.') from None
    if not math.isfinite(result) or (value and result == 0):
        raise ValueError('Échelle numérique non représentable ; changer les unités ou les mesures.')
    return result


def _bounds(raw, key):
    if not isinstance(raw, dict) or not raw:
        raise ValueError('Limites de ' + key + ' : min/max ou max_abs requis.')
    if set(raw) == {'max_abs'}:
        maximum = _number(raw['max_abs'], 'max_abs')
        if maximum < 0:
            raise ValueError('max_abs doit être positif ou nul.')
        return {'max_abs': maximum}
    if not set(raw) <= {'min', 'max'}:
        raise ValueError('Limites de ' + key + ' : min/max ou max_abs, sans autre champ.')
    result = {name: _number(value, name) for name, value in raw.items()}
    if 'min' in result and 'max' in result and result['min'] > result['max']:
        raise ValueError('La limite min ne peut pas dépasser max.')
    return result


def _validate(payload):
    required = {'schema', 'quantity', 'unit', 'time_unit', 'samples', 'bounds'}
    if (not isinstance(payload, dict) or not required <= set(payload)
            or not set(payload) <= required | {'reference'}):
        raise ValueError('Série invalide : schéma, quantité, unité, temps, mesures et limites requis.')
    if payload['schema'] != REQUEST_SCHEMA or payload['time_unit'] not in ('s', 'day'):
        raise ValueError('Schéma tao.integrability.request.v1 et time_unit s ou day requis.')
    result = {'schema': REQUEST_SCHEMA,
              'quantity': _text(payload['quantity'], 'La quantité', 120),
              'unit': _text(payload['unit'], 'L’unité', 40), 'time_unit': payload['time_unit']}
    if 'reference' in payload:
        result['reference'] = _text(payload['reference'], 'La référence déclarée', 1000)
    samples = payload['samples']
    if not isinstance(samples, list) or len(samples) > MAX_SAMPLES:
        raise ValueError('Une liste de zéro à ' + str(MAX_SAMPLES) + ' mesures est requise.')
    result['samples'] = []
    for raw in samples:
        if (not isinstance(raw, dict) or not {'t', 'value'} <= set(raw)
                or not set(raw) <= {'t', 'value', 'source_id', 'unit'}):
            raise ValueError('Chaque mesure exige t et value ; seuls source_id et unit sont facultatifs.')
        sample = {'t': _number(raw['t'], 'Le temps dans l’unité déclarée'),
                  'value': _number(raw['value'], 'La mesure')}
        if result['samples'] and _fraction(sample['t']) <= _fraction(result['samples'][-1]['t']):
            raise ValueError('Les temps doivent être strictement croissants ; aucun tri implicite.')
        if 'source_id' in raw:
            sample['source_id'] = _text(raw['source_id'], 'La source déclarée', 120)
        if 'unit' in raw:
            sample['unit'] = _text(raw['unit'], 'L’unité de la mesure', 40)
            if sample['unit'] != result['unit']:
                raise ValueError('Toutes les mesures doivent avoir la même unité ; aucune conversion implicite.')
        result['samples'].append(sample)
    if not isinstance(payload['bounds'], dict) or not set(payload['bounds']) <= set(ORDER_KEYS):
        raise ValueError('Les limites concernent seulement state, trend et trend_change.')
    result['bounds'] = {key: _bounds(value, key) for key, value in payload['bounds'].items()}
    return result


def _comparison(value, bounds):
    if bounds is None:
        return 'unknown', None
    lower = -_fraction(bounds['max_abs']) if 'max_abs' in bounds else (
        _fraction(bounds['min']) if 'min' in bounds else None)
    upper = _fraction(bounds['max_abs']) if 'max_abs' in bounds else (
        _fraction(bounds['max']) if 'max' in bounds else None)
    if lower is not None and value < lower:
        return 'exceeds', 'below_min'
    if upper is not None and value > upper:
        return 'exceeds', 'above_max'
    return 'within_model_bounds', None


def evaluate(payload):
    """Return a traceable, inert report; reject invalid or unrepresentable input.

    For each interval v = (x_next-x)/(t_next-t). Trend change compares two
    adjacent interval rates over the distance between their temporal midpoints.
    These are finite differences, not a reconstruction of an unobserved curve.
    Missing limits never become zero, and missing observations never pass.
    """
    data = _validate(payload)
    samples = data['samples']
    # (representative time, value, original sample indices, interval start/end)
    states = [(_fraction(row['t']), _fraction(row['value']), [i], None, None)
              for i, row in enumerate(samples)]
    trends = []
    for left, right in zip(states, states[1:]):
        elapsed = right[0] - left[0]
        trends.append(((left[0] + right[0]) / 2, (right[1] - left[1]) / elapsed,
                       left[2] + right[2], left[0], right[0]))
    levels = [states, trends]
    changes = []
    for left, right in zip(trends, trends[1:]):
        changes.append(((left[0] + right[0]) / 2,
                        (right[1] - left[1]) / (right[0] - left[0]),
                        sorted(set(left[2] + right[2])), left[0], right[0]))
    levels.append(changes)

    orders, observations = [], {}
    for order, key in enumerate(ORDER_KEYS):
        bound = data['bounds'].get(key)
        points = []
        violations = []
        for index, (time, value, sample_indices, start, end) in enumerate(levels[order]):
            status, side = _comparison(value, bound)
            point = {'index': index, 't': _display(time), 'value': _display(value),
                     'sample_indices': list(sample_indices),
                     'source_ids': list(dict.fromkeys(samples[i]['source_id']
                                                     for i in sample_indices if 'source_id' in samples[i])),
                     'status': status}
            if start is not None:
                point.update(from_t=_display(start), to_t=_display(end))
            if side is not None:
                point['violation'] = side
                violations.append(index)
            points.append(point)
        if bound is None:
            status, reason = 'unknown', 'no_declared_bounds'
        elif not points:
            status, reason = 'insufficient_data', 'not_enough_samples'
        elif violations:
            status, reason = 'exceeds', 'observed_values_exceed_declared_bounds'
        else:
            status, reason = 'within_model_bounds', 'observed_values_within_declared_bounds'
        unit = data['unit'] if order == 0 else '(' + data['unit'] + ')/' + data['time_unit'] + ('²' if order == 2 else '')
        orders.append({'order': order, 'key': key, 'unit': unit,
                       'status': status, 'reason': reason, 'count': len(points),
                       'required_samples': order + 1, 'bounds': copy.deepcopy(bound),
                       'violations': violations,
                       'observed_range': {'min': min(point['value'] for point in points),
                                          'max': max(point['value'] for point in points)} if points else None})
        observations[key] = points
    statuses = {row['status'] for row in orders}
    overall = ('exceeds' if 'exceeds' in statuses else
               'within_model_bounds' if statuses == {'within_model_bounds'} else
               'insufficient_data' if 'insufficient_data' in statuses else 'unknown')
    return {'schema': RESULT_SCHEMA, 'quantity': data['quantity'], 'status': overall,
            'scope': 'provided_discrete_samples_and_declared_bounds',
            'execution_enabled': False, 'orders': orders, 'observations': observations,
            'input': copy.deepcopy(data),
            'provenance': {'input': 'provided_by_caller',
                           'bounds': 'user_declared_hypotheses', 'verified': False,
                           'reference': data.get('reference')},
            'limits': [
                'Les limites déclarées ne prouvent pas une capacité réelle d’intégration.',
                'Les mesures sont déclarées, sans authentification indépendante de leur source.',
                'Les écarts entre mesures, les incertitudes et le futur ne sont pas évalués.',
                'Les différences finies ne sont pas des dérivées exactes d’une trajectoire inconnue.',
                'Une unité commune est déclarée ; aucune monnaie ou unité n’est convertie.',
                'Comparaisons sur les nombres décimaux fournis ; affichage numérique arrondi si nécessaire.',
                'Aucun résultat ne ferme un besoin, ne déclenche une action ou n’accorde un droit.',
            ]}
