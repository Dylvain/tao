"""Local work intake. A description is neither a learned skill nor an execution mandate."""

def text_field(value, label, limit, required=False):
    if not isinstance(value, str) or len(value) > limit or (required and not value.strip()):
        raise ValueError(f'{label} : texte requis, {limit} caractères maximum' if required else f'{label} : texte de {limit} caractères maximum')
    return value.strip()


def check_revision(expected, current):
    if type(expected) is not int or expected != current:
        raise ValueError('Cette fiche a changé dans un autre onglet. Recharge la page avant de modifier.')


def save_context(n, description, keep_learning='', boundaries='', revision=0):
    import tao_worlds as worlds
    values = {
        'description': text_field(description, 'Ton travail', 8000, True),
        'keep_learning': text_field(keep_learning, 'Ce que tu souhaites pratiquer', 2000),
        'boundaries': text_field(boundaries, 'Les limites à respecter', 2000),
    }
    with n.LOCK:
        s = n.load_state(); previous = s.get('work_context', {})
        check_revision(revision, previous.get('revision', 0))
        history = list(previous.get('history', []))
        if previous:
            history.append({k: v for k, v in previous.items() if k != 'history'})
        context_id = 'work:' + s['id'] + (':' + worlds.current() if worlds.current() != 'main' else '')
        row = dict(values, schema='tao.work.context.v1', id=context_id,
                   revision=revision + 1, updated_at=n.now(), source='human_report',
                   authority='description_only', history=history[-10:])
        s['work_context'] = row
        n.atomic_json(n.STATE, s, backup=True)
        n.event('work_context_saved', {'revision': row['revision']})
        n.WAKE.set()
        return row


def add_task(n, title):
    title = text_field(title, 'La tâche à confier', 2000, True)
    with n.LOCK:
        s = n.load_state(); context = s.get('work_context')
        if not context:
            raise ValueError('Décris d’abord ton travail.')
        bid = 'user:work:' + n.digest_bytes(n.json_bytes([context['id'], title]))[:12]
        if bid in s['buffers']:
            return s['buffers'][bid]
        if len(n.open_buffers(s)) >= 200:
            raise ValueError('200 besoins ouverts ; en terminer ou regrouper avant d’en ajouter.')
        b = n.make_buffer(bid, 'work', 'Aide à préparer pour : ' + title, authority='human')
        b.update(desired=title, acceptance='Décrire un exemple et son résultat attendu, puis vérifier une aide sur des cas réels.',
                 story_id=context['id'], work_task={'schema': 'tao.work.task.v1', 'title': title,
                 'phase': 'needs_example', 'revision': 1, 'context_revision': context['revision'],
                 'source': 'human_report', 'authority': 'description_only', 'execution_enabled': False})
        s['buffers'][bid] = b
        n.atomic_json(n.STATE, s, backup=True)
        n.event('work_task_saved', {'id': bid}); n.WAKE.set()
        return b


def save_example(n, bid, situation, expected, boundaries='', revision=1):
    if not isinstance(bid, str):
        raise ValueError('Tâche inconnue')
    example = {'situation': text_field(situation, 'La situation de départ', 2000, True),
               'expected': text_field(expected, 'Le résultat attendu', 2000, True),
               'boundaries': text_field(boundaries, 'Les limites de cet exemple', 1500),
               'source': 'human_report', 'status': 'unverified', 'at': n.now()}
    with n.LOCK:
        s = n.load_state(); b = s['buffers'].get(bid)
        if not b or b.get('status') != 'open' or not b.get('work_task'):
            raise ValueError('Une tâche de travail ouverte est requise.')
        task = b['work_task']; check_revision(revision, task['revision'])
        history = list(task.get('example_history', []))
        if task.get('example'): history.append(task['example'])
        task.update(example=example, example_history=history[-10:], phase='example_recorded', revision=revision + 1)
        b['acceptance'] = expected.strip()
        n.atomic_json(n.STATE, s, backup=True)
        n.event('work_example_saved', {'id': bid, 'revision': task['revision']}); n.WAKE.set()
        return b


def brief(s):
    context = s.get('work_context', {})
    lines = ['# Mon travail avec Tao', '', '## Mon quotidien', context.get('description', 'À décrire'),
             '', '## Ce que je souhaite continuer à faire ou apprendre', context.get('keep_learning') or 'À préciser',
             '', '## Limites et personnes concernées', context.get('boundaries') or 'À préciser', '',
             'Ces récits restent à vérifier. Cette fiche ne donne aucune permission d’exécution.']
    for b in s.get('buffers', {}).values():
        task = b.get('work_task')
        if not task: continue
        lines += ['', '## ' + task['title'], 'État du besoin : ' + b['status']]
        example = task.get('example', {})
        lines += ['Situation : ' + (example.get('situation') or 'À décrire'),
                  'Résultat attendu : ' + (example.get('expected') or 'À préciser'),
                  'Limites de l’exemple : ' + (example.get('boundaries') or 'À préciser'),
                  'Automatisation : non implémentée pour cette fiche.']
    return '\n'.join(lines) + '\n'
