"""Owner HTTPS gateway with two narrowly scoped outbound-worker ingress routes.

The deployment supplies TLS and a canonical HTTPS origin. This module never
configures hosting, invokes an AI, retries a write, or exposes the local token.
"""
from __future__ import annotations

from collections import deque
from contextlib import contextmanager
import fcntl
import hashlib
import hmac
import html
import http.client
from http.cookies import SimpleCookie, CookieError
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import socket
import stat
import tempfile
import threading
import time
import urllib.parse

SCHEMA = 'tao.host.auth.v1'
COOKIE = '__Host-tao-host'
SESSION_TTL = 30 * 24 * 3600
MAX_SESSIONS = 8
MAX_BODY = 32768
MAX_HANDOFF = 262144
MAX_DEVICE_BODY = 1024 * 1024
MAX_RESPONSE = 8 * 1024 * 1024
MAX_HISTORY_BODY = 24 * 1024 * 1024
MAX_BACKUP_BODY = 18 * 1024 * 1024
DEVICE_ROUTES = ('/api/devices/enrol', '/api/devices/worker')
PASSWORD_ROUNDS = 600000
AUTH_ATTEMPTS = 10
AUTH_WINDOW = 60
REQUEST_TIMEOUT = 20


class AccessError(ValueError):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def _hash(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def _browser_html(data, local_token, browser_token):
    """Replace the exact local credential in legacy and modern HTML shells."""
    pairs = (
        ('const token=' + json.dumps(local_token) + ';',
         'const token=' + json.dumps(browser_token) + ';'),
        ('"token":' + json.dumps(local_token),
         '"token":' + json.dumps(browser_token)),
    )
    for original, replacement in pairs:
        data = data.replace(original.encode('utf-8'), replacement.encode('utf-8'))
    return data


def _origin(value):
    if not isinstance(value, str) or not 1 <= len(value) <= 300 or any(ord(c) < 33 or ord(c) > 126 for c in value) or '\\' in value:
        raise ValueError('Une origine HTTPS exacte est requise.')
    try:
        parsed = urllib.parse.urlsplit(value)
        host = parsed.hostname or ''
        port = parsed.port
        if (parsed.scheme != 'https' or parsed.username or parsed.password or
                parsed.path not in ('', '/') or parsed.query or parsed.fragment or
                not host or len(host) > 253 or '.' not in host or
                any(not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', label) for label in host.split('.')) or
                port is not None and not 1 <= port <= 65535):
            raise ValueError
        return 'https://' + host + (':' + str(port) if port not in (None, 443) else '')
    except (ValueError, TypeError):
        raise ValueError('Une origine HTTPS exacte, sans chemin ni identifiants, est requise.') from None


def _password(value):
    if not isinstance(value, str) or not 12 <= len(value) <= 256 or '\x00' in value:
        raise AccessError(400, 'Choisir un mot de passe de 12 à 256 caractères.')
    return value


def _label(value):
    if not isinstance(value, str) or not value.strip() or len(value) > 80 or any(ord(c) < 32 for c in value):
        raise AccessError(400, 'Le nom de cet appareil doit contenir de 1 à 80 caractères.')
    return value.strip()


def _derive(password, salt):
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt), PASSWORD_ROUNDS).hex()


class HostAuth:
    """A persistent owner record, protected across threads and processes."""
    def __init__(self, root):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.root.chmod(0o700)
        self.file = self.root / 'host-auth.json'
        self.lockfile = self.root / 'host-auth.lock'
        self.mutex = threading.RLock()
        self.attempts = deque()
        first = not self.lockfile.exists()
        # A missing deployment variable must not leave an initialization lock
        # that looks like the loss of an already-created owner record.
        if first and not self.file.exists():self.setup_digest()
        with self.lock():
            if not self.file.exists():
                if not first:
                    raise ValueError('Configuration d’accès absente ; restauration par le propriétaire requise.')
                self.setup_digest()
                self.write({'schema': SCHEMA, 'configured': False, 'sessions': []})
            self.load()

    @contextmanager
    def lock(self):
        with self.mutex:
            fd = os.open(self.lockfile, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
            try:
                os.fchmod(fd, 0o600)
                fcntl.flock(fd, fcntl.LOCK_EX)
                yield
            finally:
                fcntl.flock(fd, fcntl.LOCK_UN)
                os.close(fd)

    @staticmethod
    def setup_digest():
        value = os.environ.get('TAO_HOST_SETUP_SHA256', '')
        if not re.fullmatch(r'[a-f0-9]{64}', value):
            raise ValueError('Configuration de première activation absente ou invalide.')
        return value

    def load(self):
        try:
            info = self.file.lstat()
            if not stat.S_ISREG(info.st_mode) or info.st_size > 65536 or info.st_mode & 0o077:
                raise ValueError
            row = json.loads(self.file.read_bytes())
            if not isinstance(row, dict) or row.get('schema') != SCHEMA or type(row.get('configured')) is not bool:
                raise ValueError
            sessions = row.get('sessions')
            if not isinstance(sessions, list) or len(sessions) > MAX_SESSIONS:
                raise ValueError
            if not row['configured']:
                if sessions or 'password' in row:
                    raise ValueError
                self.setup_digest()
            else:
                password = row.get('password', {})
                if (not isinstance(password, dict) or password.get('algorithm') != 'pbkdf2-sha256' or
                        password.get('rounds') != PASSWORD_ROUNDS or
                        not isinstance(password.get('salt'), str) or not re.fullmatch('[a-f0-9]{32}', password['salt']) or
                        not isinstance(password.get('hash'), str) or not re.fullmatch('[a-f0-9]{64}', password['hash'])):
                    raise ValueError
            ids = set()
            for session in sessions:
                if (not isinstance(session, dict) or not isinstance(session.get('id'), str) or
                        not re.fullmatch('[a-f0-9]{32}', session['id']) or session['id'] in ids or
                        not isinstance(session.get('hash'), str) or not re.fullmatch('[a-f0-9]{64}', session['hash']) or
                        type(session.get('created_at')) is not int or type(session.get('expires_at')) is not int or
                        session['created_at'] < 0 or session['expires_at'] - session['created_at'] != SESSION_TTL):
                    raise ValueError
                _label(session.get('label'))
                ids.add(session['id'])
            return row
        except (ValueError, TypeError, OSError, KeyError, UnicodeError):
            raise ValueError('Configuration d’accès illisible ; accès fermé. Restaurer sa sauvegarde depuis l’hébergement.') from None

    def write(self, row):
        data = json.dumps(row, ensure_ascii=False, sort_keys=True, indent=2).encode('utf-8')
        fd, name = tempfile.mkstemp(prefix='.host-auth-', dir=self.root)
        try:
            with os.fdopen(fd, 'wb') as stream:
                os.fchmod(stream.fileno(), 0o600)
                stream.write(data);stream.flush();os.fsync(stream.fileno())
            os.replace(name, self.file)
            directory = os.open(self.root, os.O_RDONLY | os.O_DIRECTORY)
            try:os.fsync(directory)
            finally:os.close(directory)
        finally:
            try:os.unlink(name)
            except FileNotFoundError:pass

    def configured(self):
        with self.lock():return self.load()['configured']

    def rate(self):
        now = time.monotonic()
        while self.attempts and now - self.attempts[0] >= AUTH_WINDOW:
            self.attempts.popleft()
        if len(self.attempts) >= AUTH_ATTEMPTS:
            raise AccessError(429, 'Trop de tentatives de connexion. Attendre une minute avant de réessayer.')
        self.attempts.append(now)

    @staticmethod
    def live(row):
        return [session for session in row['sessions'] if session['expires_at'] > time.time()]

    def issue(self, row, label):
        row['sessions'] = self.live(row)
        if len(row['sessions']) >= MAX_SESSIONS:
            raise AccessError(409, 'Huit appareils sont déjà connectés. Révoquer un accès depuis un appareil connecté.')
        token = secrets.token_urlsafe(32)
        now = int(time.time())
        session = {'id': secrets.token_hex(16), 'hash': _hash(token), 'label': label,
                   'created_at': now, 'expires_at': now + SESSION_TTL}
        row['sessions'].append(session)
        self.write(row)
        return token

    def setup(self, code, password, label):
        password = _password(password);label = _label(label)
        with self.lock():
            row = self.load();self.rate()
            if row['configured']:
                raise AccessError(409, 'Cet accès est déjà activé. Utiliser le mot de passe choisi.')
            if not isinstance(code, str) or not 32 <= len(code) <= 200 or not secrets.compare_digest(_hash(code), self.setup_digest()):
                raise AccessError(403, 'Code de première activation invalide.')
            salt = secrets.token_hex(16)
            row.update(configured=True, activated_at=int(time.time()),
                       password={'algorithm': 'pbkdf2-sha256', 'rounds': PASSWORD_ROUNDS,
                                 'salt': salt, 'hash': _derive(password, salt)})
            return self.issue(row, label)

    def login(self, password, label, old_token=None):
        password = _password(password);label = _label(label)
        with self.lock():
            row = self.load();self.rate()
            if not row['configured']:
                raise AccessError(403, 'Activer cet accès avec le code initial avant de se connecter.')
            stored = row['password']
            if not secrets.compare_digest(_derive(password, stored['salt']), stored['hash']):
                raise AccessError(403, 'Connexion refusée. Vérifier le mot de passe.')
            # Reauthentication replaces this browser's previous bearer token.
            if old_token:
                old_hash = _hash(old_token)
                row['sessions'] = [session for session in row['sessions'] if not secrets.compare_digest(session['hash'], old_hash)]
            return self.issue(row, label)

    def session(self, token):
        with self.lock():
            row = self.load()
            if not token:return None
            hashed = _hash(token)
            return next((session for session in self.live(row) if secrets.compare_digest(session['hash'], hashed)), None)

    def sessions(self, token):
        with self.lock():
            row = self.load();hashed = _hash(token)
            if not any(secrets.compare_digest(session['hash'], hashed) for session in self.live(row)):
                raise AccessError(401, 'Session expirée ou révoquée.')
            return [{key: session[key] for key in ('id', 'label', 'created_at', 'expires_at')} for session in self.live(row)]

    def revoke(self, token, ident):
        with self.lock():
            row = self.load();hashed = _hash(token)
            current = next((session for session in self.live(row) if secrets.compare_digest(session['hash'], hashed)), None)
            if current is None:raise AccessError(401, 'Session expirée ou révoquée.')
            if ident == 'current':ident = current['id']
            if ident != 'all' and not any(session['id'] == ident for session in row['sessions']):
                raise AccessError(404, 'Appareil connecté introuvable.')
            row['sessions'] = [] if ident == 'all' else [session for session in self.live(row) if session['id'] != ident]
            self.write(row)
            return ident in ('all', current['id'])


STYLE = '''<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>
:root{color-scheme:light;--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47;--gold:#c79d67}
*{box-sizing:border-box}body{font:16px/1.6 system-ui,sans-serif;background:radial-gradient(circle at 88% -10%,#eee3d2,transparent 38%),var(--bg);color:var(--text);margin:0;padding:24px;min-height:100vh}
main{max-width:560px;margin:5vh auto;padding:clamp(24px,5vw,42px);background:linear-gradient(145deg,var(--panel),#f8f5ee);border:1px solid var(--line);border-top:3px solid var(--gold);border-radius:20px;box-shadow:0 16px 42px rgba(39,55,47,.07)}
.brand{font:600 29px/1 ui-serif,Georgia,serif;letter-spacing:-.045em;color:var(--text);text-decoration:none}.brand span{color:var(--gold)}.eyebrow{font-size:11px;letter-spacing:.15em;text-transform:uppercase;font-weight:700;color:var(--accent);margin-top:32px}
h1{font:500 clamp(30px,5vw,43px)/1.16 ui-serif,Georgia,serif;letter-spacing:-.03em;margin:8px 0 15px}p{overflow-wrap:anywhere;color:var(--muted)}label{display:block;font-weight:600;margin-top:18px}
input,button{font:inherit;width:100%;padding:12px 14px;margin:8px 0 12px;border-radius:9px;min-height:44px}input{border:1px solid #b9c7bc;background:var(--panel);color:var(--text)}button{background:var(--accent);color:#fff;border:1px solid var(--accent);font-weight:600;cursor:pointer}button:disabled{opacity:.55;cursor:not-allowed}a{color:var(--accent);text-underline-offset:3px}
article{border-top:1px solid var(--line);padding:16px 0}article strong{font:600 20px/1.3 ui-serif,Georgia,serif}article button,#logout{background:#edf1ea;color:var(--accent);border-color:var(--line)}button[data-id="all"]{background:#f8ece5;color:#713d2d;border-color:#d9b6a2}#message:not(:empty){padding:12px 14px;background:#edf1ea;border:1px solid var(--line);border-radius:9px;color:var(--text)}
:focus-visible{outline:3px solid var(--accent);outline-offset:3px}@media(max-width:560px){body{padding:14px}main{margin:2vh auto;padding:24px 18px;border-radius:16px}}
</style>'''


def login_page(configured):
    setup = '' if configured else '<label for="code">Code de première activation</label><input id="code" autocomplete="off" autocapitalize="none" spellcheck="false" maxlength="200" required>'
    title = 'Retrouver mon Tao' if configured else 'Activer mon Tao privé'
    intro = 'Connecte-toi avec le mot de passe choisi.' if configured else 'Saisis le code reçu séparément puis choisis ton mot de passe. Le code initial ne pourra plus être réutilisé.'
    return '<!doctype html><html lang="fr"><head>'+STYLE+'<title>'+title+'</title></head><body><main><div class="brand">tao<span>.</span></div><p class="eyebrow">La porte de mon Tao</p><h1>'+title+'</h1><p>'+intro+'</p><form>'+setup+'''<label for="password">Mot de passe (12 caractères minimum)</label><input id="password" type="password" minlength="12" maxlength="256" autocomplete="'''+('current-password' if configured else 'new-password')+'''" required><label for="label">Nom de cet appareil</label><input id="label" maxlength="80" value="Mon appareil" required><button>'''+('Me connecter' if configured else 'Activer et me connecter')+'''</button></form><p id="message" role="status"></p><p><a href="/host/login">Revenir à la connexion</a></p><p>Cet accès donne les mêmes possibilités que ton interface Tao. Une action extérieure reste soumise à ses propres autorisations.</p></main><script>document.querySelector('form').onsubmit=async e=>{e.preventDefault();const button=document.querySelector('button');button.disabled=true;try{const body={password:document.querySelector('#password').value,label:document.querySelector('#label').value};const code=document.querySelector('#code');if(code)body.code=code.value.trim();const r=await fetch(code?'/host/setup':'/host/login',{method:'POST',headers:{'Content-Type':'application/json','X-Tao-Token':'host-auth'},body:JSON.stringify(body)});const result=await r.json();if(!r.ok){const error=Error(result.error||'Connexion refusée');error.confirmed=true;throw error}location.href='/'}catch(err){document.querySelector('#message').textContent=err.confirmed?err.message:'Le résultat de la connexion n’est pas confirmé. Reviens à la page de connexion pour vérifier ton accès avant tout nouvel envoi ; si l’activation a réussi, utilise le mot de passe que tu viens de choisir.';button.disabled=false}};</script></body></html>'''


class HostServer(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 16

    def __init__(self, address, n, origin, auth_root=None, ai=None):
        self.node = n
        self.origin = _origin(origin)
        self.authority = self.origin.removeprefix('https://')
        self.auth = HostAuth(auth_root if auth_root is not None else n.ROOT / 'host')
        self.ai = ai
        self.upstream_port = n.policy()['http_port']
        self.slots = threading.BoundedSemaphore(16)
        super().__init__(address, HostHandler)

    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request);return
        try:super().process_request(request, client_address)
        except BaseException:
            self.slots.release();raise

    def process_request_thread(self, request, client_address):
        try:super().process_request_thread(request, client_address)
        finally:self.slots.release()

    def handle_error(self, request, client_address):
        pass


class HostHandler(BaseHTTPRequestHandler):
    server_version = 'Tao'
    sys_version = ''

    def setup(self):
        super().setup();self.connection.settimeout(5)
        self.auth_session = None
        self.session_token = None
        self.body_raw = None
        self.body_value = None
        self.deadline_expired = threading.Event()
        self.deadline = threading.Timer(REQUEST_TIMEOUT, self.expire_connection)
        self.deadline.daemon = True;self.deadline.start()

    def expire_connection(self):
        self.deadline_expired.set()
        try:self.connection.shutdown(socket.SHUT_RDWR)
        except OSError:pass

    def finish(self):
        self.deadline.cancel()
        try:super().finish()
        except OSError:pass

    @property
    def node(self):return self.server.node

    def log_message(self, *args):pass

    def send_error(self, code, message=None, explain=None):
        self.json(code, {'error': 'Requête non autorisée.'})

    def send_body(self, status, body, content_type='application/json; charset=utf-8', cookie=None):
        self.send_response(status)
        for key, value in [('Content-Type', content_type), ('Content-Length', str(len(body))),
                           ('Cache-Control', 'no-store'), ('X-Content-Type-Options', 'nosniff'),
                           ('Referrer-Policy', 'no-referrer'), ('X-Frame-Options', 'DENY'),
                           ('Strict-Transport-Security', 'max-age=31536000'),
                           ('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")]:
            self.send_header(key, value)
        if status == 429:self.send_header('Retry-After', str(AUTH_WINDOW))
        if cookie:self.send_header('Set-Cookie', cookie)
        self.end_headers()
        if self.command != 'HEAD':self.wfile.write(body)

    def json(self, status, obj, cookie=None):
        self.send_body(status, json.dumps(obj, ensure_ascii=False).encode('utf-8'), cookie=cookie)

    def error(self, status, message):
        self.json(status, dict(error=message, **({'login_url': '/host/login'} if status == 401 else {})))

    def one_header(self, name):
        values = self.headers.get_all(name, [])
        return values[0] if len(values) == 1 else None

    def boundary(self):
        if self.deadline_expired.is_set():raise AccessError(408, 'Délai de requête dépassé.')
        host = self.one_header('Host')
        health_host = self.command == 'GET' and self.path == '/health' and host == 'healthcheck.railway.app'
        if host != self.server.authority and not health_host:
            raise AccessError(403, 'Hôte refusé.')
        if (not self.path.startswith('/') or self.path.startswith('//') or '\\' in self.path or
                len(self.path) > 4096 or '#' in self.path):
            raise AccessError(400, 'Chemin invalide.')
        return self.server.auth.configured()

    def cookie_token(self):
        raw = self.one_header('Cookie')
        if not raw or len(raw) > 4096:return None
        if sum(part.strip().startswith(COOKIE+'=') for part in raw.split(';')) != 1:return None
        try:
            cookies = SimpleCookie();cookies.load(raw)
            token = cookies[COOKIE].value if COOKIE in cookies else ''
            return token if re.fullmatch('[A-Za-z0-9_-]{43}', token) else None
        except CookieError:return None

    def authenticate(self):
        if self.deadline_expired.is_set():raise AccessError(408, 'Délai de requête dépassé.')
        token = self.cookie_token()
        session = self.server.auth.session(token)
        if session is None:raise AccessError(401, 'Session expirée ou appareil non connecté.')
        self.session_token = token;self.auth_session = session
        return session

    def browser_token(self):
        if self.auth_session is None or not self.session_token:raise AccessError(401, 'Connexion requise.')
        return hmac.new(self.session_token.encode('ascii'), b'tao.host.csrf.v1', hashlib.sha256).hexdigest()

    @staticmethod
    def cookie(token='', expires=False):
        return f'{COOKIE}={token}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age={0 if expires else SESSION_TTL}'

    def read_body(self, limit=None):
        length = self.one_header('Content-Length')
        if self.headers.get_all('Transfer-Encoding') or length is None or not re.fullmatch('[0-9]{1,8}', length):
            raise AccessError(400, 'Longueur de requête invalide.')
        if limit is None:
            path = urllib.parse.urlsplit(self.path).path
            limit = (MAX_BACKUP_BODY if path.startswith('/api/backup/') else
                     MAX_HISTORY_BODY if path.startswith(('/api/onboarding/', '/api/history/')) else
                     (MAX_HANDOFF if path == '/api/dialogue/handoff' or path.startswith(('/api/reuse/', '/api/bridge/', '/api/connectors/')) else MAX_BODY))
        length = int(length)
        if not 1 <= length <= limit:raise AccessError(413, 'Requête trop grande ou vide.')
        if (self.one_header('Content-Type') or '').split(';', 1)[0].strip().lower() != 'application/json':
            raise AccessError(415, 'Objet JSON requis.')
        body = self.rfile.read(length)
        if self.deadline_expired.is_set():raise AccessError(408, 'Délai de requête dépassé.')
        if len(body) != length:raise AccessError(400, 'Requête incomplète.')
        try:value = json.loads(body)
        except (ValueError, UnicodeError):raise AccessError(400, 'Objet JSON illisible.') from None
        if not isinstance(value, dict):raise AccessError(400, 'Objet JSON requis.')
        self.body_raw = body;self.body_value = value
        return value

    def do_HEAD(self):self.error(405, 'Méthode non autorisée.')

    def do_GET(self):
        try:
            configured = self.boundary()
            if self.path == '/health':return self.health()
            path = urllib.parse.urlsplit(self.path).path
            if path in ('/host/login', '/host/setup'):
                return self.send_body(200, login_page(configured).encode('utf-8'), 'text/html; charset=utf-8')
            try:self.authenticate()
            except AccessError:
                if path == '/':return self.send_body(200, login_page(configured).encode('utf-8'), 'text/html; charset=utf-8')
                raise
            if path == '/host/account':return self.account()
            if path == '/host/ai' or path.startswith('/host/ai/'):
                if self.server.ai is not None and self.server.ai.route(self):return
                raise AccessError(404, 'Connexion du modèle indisponible.')
            if path.startswith('/host'):raise AccessError(404, 'Page introuvable.')
            self.forward()
        except AccessError as exc:self.error(exc.status, str(exc))
        except (ValueError, TypeError, RuntimeError, OSError):self.error(503, 'Tao est indisponible. Vérifier le service et sa configuration d’accès.')

    def do_POST(self):
        try:
            configured = self.boundary()
            path = urllib.parse.urlsplit(self.path).path
            if path in DEVICE_ROUTES:
                # A worker never receives the owner's browser or node authority.
                # Its pairing code / bearer is checked by the node broker.
                if self.path != path or self.headers.get_all('Origin'):
                    raise AccessError(403, 'Route réservée au moteur connecté, sans origine ni paramètres.')
                if not configured:raise AccessError(403, 'Activer l’accès propriétaire avant de connecter un moteur.')
                authorization = self.one_header('Authorization')
                if path == '/api/devices/worker':
                    if not authorization or not re.fullmatch(r'Bearer [A-Za-z0-9_-]{32,256}', authorization):
                        raise AccessError(401, 'Identifiant du moteur requis.')
                elif self.headers.get_all('Authorization'):
                    raise AccessError(403, 'L’appairage utilise uniquement son code à usage unique.')
                self.read_body(MAX_DEVICE_BODY if path == '/api/devices/worker' else MAX_BODY)
                return self.forward_device(authorization)
            header = self.one_header('X-Tao-Token')
            if self.one_header('Origin') != self.server.origin or not header or len(header) > 256:
                raise AccessError(403, 'Origine ou protection de session refusée.')
            public_auth = self.path in ('/host/setup', '/host/login')
            if not public_auth:
                self.authenticate()
                if not secrets.compare_digest(header, self.browser_token()):raise AccessError(403, 'Protection de session invalide ; recharger la page.')
            value = self.read_body()
            if public_auth:
                allowed = {'password', 'label', 'code'} if path == '/host/setup' else {'password', 'label'}
                if set(value) - allowed:raise AccessError(400, 'Champs de connexion inconnus.')
                label = value.get('label', 'Mon appareil')
                token = (self.server.auth.setup(value.get('code'), value.get('password'), label) if path == '/host/setup' else
                         self.server.auth.login(value.get('password'), label, self.cookie_token()))
                return self.json(200, {'ok': True}, cookie=self.cookie(token))
            self.authenticate()  # A session revoked while the body arrived cannot dispatch an action.
            if path == '/host/logout':
                if value:raise AccessError(400, 'Aucun champ requis pour la déconnexion.')
                self.server.auth.revoke(self.session_token, 'current')
                return self.json(200, {'ok': True}, cookie=self.cookie(expires=True))
            if path == '/host/revoke':
                if set(value) != {'id'} or not isinstance(value['id'], str):raise AccessError(400, 'Choisir un appareil à révoquer.')
                expired = self.server.auth.revoke(self.session_token, value['id'])
                return self.json(200, {'ok': True, 'disconnected': expired}, cookie=self.cookie(expires=True) if expired else None)
            if path == '/host/ai' or path.startswith('/host/ai/'):
                if self.server.ai is not None and self.server.ai.route(self):return
                raise AccessError(404, 'Connexion du modèle indisponible.')
            if path == '/api/stop' or path.startswith('/host'):
                raise AccessError(403, 'Cette action se gère depuis l’hébergement.')
            self.forward(self.body_raw)
        except AccessError as exc:self.error(exc.status, str(exc))
        except (ValueError, TypeError, RuntimeError, OSError):self.error(503, 'Requête non confirmée. Vérifier son résultat avant de la relancer.')

    def account(self):
        sessions = self.server.auth.sessions(self.session_token)
        rows = ''.join('<article><strong>'+html.escape(session['label'])+'</strong><p>'+('Cet appareil' if session['id'] == self.auth_session['id'] else 'Autre appareil connecté')+'</p><button data-id="'+session['id']+'">Révoquer cet accès</button></article>' for session in sessions)
        page = '<!doctype html><html lang="fr"><head>'+STYLE+'<title>Mon accès Tao</title></head><body><main><a class="brand" href="/">tao<span>.</span></a><p class="eyebrow">Les clés de la maison</p><h1>Mon accès</h1><p><a href="/">← Revenir à Tao</a></p><p>Les accès expirent après 30 jours. Révoquer un appareil bloque ses prochaines requêtes ; une action déjà engagée peut continuer.</p>'+rows+'<button data-id="all">Déconnecter tous les appareils</button><button id="logout">Me déconnecter ici</button><p id="message" role="status"></p><p><a href="/host/login">Revenir à la connexion</a></p></main><script>const csrf='+json.dumps(self.browser_token())+''';async function action(path,body){try{const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Tao-Token':csrf},body:JSON.stringify(body)});const result=await r.json();if(!r.ok){const error=Error(result.error||'Action refusée');error.confirmed=true;throw error}location.href=result.disconnected||path==='/host/logout'?'/host/login':'/host/account'}catch(err){document.querySelector('#message').textContent=err.confirmed?err.message:'Le résultat n’est pas confirmé. Actualise puis vérifie les accès avant de relancer cette action.'}}for(const b of document.querySelectorAll('[data-id]'))b.onclick=()=>action('/host/revoke',{id:b.dataset.id});document.querySelector('#logout').onclick=()=>action('/host/logout',{});</script></body></html>'''
        self.send_body(200, page.encode('utf-8'), 'text/html; charset=utf-8')

    def health(self):
        connection = http.client.HTTPConnection('127.0.0.1', self.server.upstream_port, timeout=2)
        ok = False
        try:
            connection.request('GET', '/health', headers={'Host': '127.0.0.1:'+str(self.server.upstream_port)})
            response = connection.getresponse();body = response.read(65537)
            ok = response.status == 200 and len(body) <= 65536 and json.loads(body).get('ok') is True
        except (http.client.HTTPException, OSError, ValueError, TypeError, AttributeError):pass
        finally:connection.close()
        self.json(200 if ok else 503, {'ok': ok})

    def forward_device(self, authorization):
        """Forward only a worker contract, without translating its authority."""
        with self.node.LOCK:local = self.node.load_json(self.node.ROOT/'session.json', {})
        if (not isinstance(local, dict) or local.get('port') != self.server.upstream_port or
                not isinstance(local.get('token'), str) or not 1 <= len(local['token']) <= 256):
            raise AccessError(503, 'Tao attend son démarrage ou son redémarrage.')
        headers = {'Host': '127.0.0.1:'+str(self.server.upstream_port), 'Content-Type': 'application/json'}
        if authorization:headers['Authorization'] = authorization
        connection = http.client.HTTPConnection('127.0.0.1', self.server.upstream_port, timeout=10)
        try:
            connection.request('POST', self.path, body=self.body_raw, headers=headers)
            response = connection.getresponse();data = response.read(MAX_RESPONSE+1)
            if len(data) > MAX_RESPONSE:raise AccessError(502, 'Réponse trop grande pour cet accès.')
            if 300 <= response.status < 400:raise AccessError(502, 'Redirection locale refusée.')
            content_type = response.getheader('Content-Type', '').split(';', 1)[0].strip().lower()
            if content_type != 'application/json':raise AccessError(502, 'Réponse du moteur invalide.')
            try:value = json.loads(data)
            except (ValueError, UnicodeError):raise AccessError(502, 'Réponse du moteur illisible.') from None
            if not isinstance(value, dict):raise AccessError(502, 'Réponse du moteur invalide.')
            # Refuse secret echoes even when an upstream error or JSON escaping
            # would otherwise make them visible. Do not forward any headers.
            visible = json.dumps(value, ensure_ascii=False)
            secrets_to_hide = [local['token']]
            if authorization:secrets_to_hide.append(authorization.removeprefix('Bearer '))
            for key in ('code', 'token'):
                candidate = self.body_value.get(key)
                if isinstance(candidate, str) and 16 <= len(candidate) <= 1024:secrets_to_hide.append(candidate)
            if any(secret in visible for secret in secrets_to_hide):
                raise AccessError(502, 'La réponse du moteur contient un identifiant privé.')
            self.json(response.status, value)
        except (http.client.HTTPException, OSError):
            self.error(503, 'Résultat du moteur inconnu. Conserver son identifiant de requête avant de réessayer.')
        finally:connection.close()

    def forward(self, body=None):
        self.authenticate()
        with self.node.LOCK:local = self.node.load_json(self.node.ROOT/'session.json', {})
        if (not isinstance(local, dict) or local.get('port') != self.server.upstream_port or
                not isinstance(local.get('token'), str) or not 1 <= len(local['token']) <= 256):
            raise AccessError(503, 'Tao attend son démarrage ou son redémarrage.')
        host = '127.0.0.1:'+str(self.server.upstream_port)
        headers = {'Host': host}
        if body is not None:headers.update({'Content-Type': 'application/json', 'Origin': 'http://'+host, 'X-Tao-Token': local['token']})
        long_tool = body is not None and urllib.parse.urlsplit(self.path).path in {'/api/connectors/inspect', '/api/connectors/execute'}
        if long_tool:
            # Only after authentication and the complete bounded body. The MCP
            # client has a 30 s deadline plus process cleanup; never retry here.
            self.deadline.cancel()
            if self.deadline_expired.is_set():raise AccessError(408, 'Délai de requête dépassé.')
            self.deadline = threading.Timer(40, self.expire_connection)
            self.deadline.daemon = True;self.deadline.start()
        connection = http.client.HTTPConnection('127.0.0.1', self.server.upstream_port, timeout=40 if long_tool else 10)
        try:
            connection.request('POST' if body is not None else 'GET', self.path, body=body, headers=headers)
            path = urllib.parse.urlsplit(self.path).path
            maximum = (MAX_BACKUP_BODY if path.startswith('/api/backup/') else
                       34 * 1024 * 1024 if path == '/api/history/archive' else MAX_RESPONSE)
            response = connection.getresponse();data = response.read(maximum+1)
            if len(data) > maximum:raise AccessError(502, 'Réponse trop grande pour cet accès.')
            if 300 <= response.status < 400:raise AccessError(502, 'Redirection locale refusée.')
            content_type = response.getheader('Content-Type', 'application/octet-stream')
            if content_type.split(';', 1)[0].strip().lower() == 'text/html':
                data = _browser_html(data, local['token'], self.browser_token())
            if local['token'].encode('utf-8') in data:raise AccessError(502, 'La réponse locale nécessite une adaptation avant de pouvoir être exposée.')
            self.send_body(response.status, data, content_type)
        except (http.client.HTTPException, OSError):
            self.error(503, 'Le résultat de cette action est inconnu. Actualiser et vérifier son état avant de la relancer.' if body is not None else 'Tao redémarre ou est momentanément indisponible. Actualiser dans quelques secondes.')
        finally:connection.close()
