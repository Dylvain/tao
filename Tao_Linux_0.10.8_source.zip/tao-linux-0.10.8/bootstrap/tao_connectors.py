"""Owner-installed stdio MCP tools, with exact human-reviewed single attempts.

Registering executable commands is an owner CLI operation, never a model or web
configuration tool. Discovery itself launches the trusted program. This is NOT
an OS sandbox: a registered server has the Linux owner's rights and may already
have side effects at startup. Application worlds scope the records, not Unix.
Nothing runs from catalog(), request(), a timer, a server hint or a model reply.
Responses remain attributed external data, never instructions or local proof.
"""
import copy
import hashlib
import hmac
import json
import math
import os
import re
import secrets
import selectors
import shutil
import signal
import subprocess
import time
from pathlib import Path

import tao_worlds as worlds
from tao_work import check_revision, text_field

SCHEMA = 'tao.connectors.v1'
PROTOCOL = '2025-11-25'
MAX_CONNECTORS = 16
MAX_REQUESTS = 100
MAX_TOOLS = 64
MAX_ARGUMENT_BYTES = 16 * 1024
MAX_DESCRIPTOR_BYTES = 32 * 1024
MAX_TOOL_BYTES = 256 * 1024
MAX_RESULT_BYTES = 64 * 1024
MAX_REGISTRY_BYTES = 24 * 1024 * 1024
MAX_LINE_BYTES = 512 * 1024
MAX_STDOUT_BYTES = 1024 * 1024
MAX_STDERR_BYTES = 64 * 1024
TIMEOUT_SECONDS = 30
ID_RE = r'[a-f0-9]{32}'
SHA_RE = r'[a-f0-9]{64}'
TOOL_RE = r'[A-Za-z0-9_.:-]{1,128}'
ACTIVE = {'checking', 'executing'}
TERMINAL = {'succeeded', 'tool_error', 'failed', 'blocked', 'unknown', 'dismissed'}


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def _digest(value):
    return hashlib.sha256(_json(value)).hexdigest()


def _match(value, pattern, label):
    if not isinstance(value, str) or not re.fullmatch(pattern, value):
        raise ValueError(label + ' invalide.')
    return value


def _plain_json(value, depth=0):
    if depth > 20:
        raise ValueError('JSON trop imbriqué.')
    if value is None or type(value) in (str, bool, int):
        return
    if type(value) is float and math.isfinite(value):
        return
    if isinstance(value, list):
        for item in value:
            _plain_json(item, depth + 1)
        return
    if isinstance(value, dict) and all(isinstance(k, str) for k in value):
        for item in value.values():
            _plain_json(item, depth + 1)
        return
    raise ValueError('Donnée JSON invalide ou non finie.')


def _bounded(value, limit, label):
    try:
        _plain_json(value)
        encoded = _json(value)
    except (TypeError, RecursionError, UnicodeError) as exc:
        raise ValueError(label + ' invalide.') from exc
    if len(encoded) > limit:
        raise ValueError(label + ' trop volumineux.')
    return copy.deepcopy(value)


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError('Clé JSON dupliquée.')
        result[key] = value
    return result


def _decode(data):
    def reject(_):
        raise ValueError('Nombre JSON non fini.')
    result = json.loads(data, object_pairs_hook=_pairs, parse_constant=reject)
    _plain_json(result)
    return result


def proposal_arguments(value):
    """Decode one model-proposed argument object without executing anything.

    Provider schemas carry arbitrary tool arguments as JSON text because their
    strict object shapes cannot safely describe unknown connector fields.  The
    connector boundary remains authoritative: duplicate keys, non-finite
    numbers, excessive depth and oversized payloads are rejected here before a
    review request can be retained.
    """
    if not isinstance(value, str) or not value or len(value.encode('utf-8')) > MAX_ARGUMENT_BYTES:
        raise ValueError('Arguments d’outil absents ou trop volumineux.')
    try:
        result = _decode(value)
    except (ValueError, UnicodeError, RecursionError, json.JSONDecodeError) as exc:
        raise ValueError('Arguments d’outil JSON invalides.') from exc
    if not isinstance(result, dict):
        raise ValueError('Les arguments d’outil doivent former un objet JSON.')
    return _bounded(result, MAX_ARGUMENT_BYTES, 'Arguments')


def _world(n):
    n.load_state()  # Reject a syntactically valid but nonexistent selected world.
    return worlds.current()


def _path(n, world):
    folder = n.ROOT / 'connectors'
    path = folder / (world + '.json')
    if folder.is_symlink() or path.is_symlink():
        raise ValueError('Le registre des outils ne peut pas être un lien symbolique.')
    return path


def _config(row):
    return {key: copy.deepcopy(row[key]) for key in ('argv', 'cwd', 'env_names')}


def _review(row):
    return _digest({key: row[key] for key in (
        'id', 'world_id', 'connector_id', 'tool', 'arguments', 'descriptor_digest',
        'config_digest', 'server_digest', 'origin')})


def _load(n, world):
    path = _path(n, world)
    node_id = n.load_raw_state()['id']
    if not path.exists():
        return {'schema': SCHEMA, 'node_id': node_id, 'world_id': world,
                'revision': 0, 'connectors': {}, 'requests': {}}
    if path.stat().st_size > MAX_REGISTRY_BYTES:
        raise ValueError('Registre des outils trop volumineux ; conservé sans modification.')
    try:
        data = _decode(path.read_text(encoding='utf-8'))
        if (not isinstance(data, dict) or data.get('schema') != SCHEMA or
                data.get('node_id') != node_id or data.get('world_id') != world or
                type(data.get('revision')) is not int or data['revision'] < 0):
            raise ValueError('Registre incompatible avec ce Tao ou cet espace.')
        for kind, limit in (('connectors', MAX_CONNECTORS), ('requests', MAX_REQUESTS)):
            if not isinstance(data.get(kind), dict) or len(data[kind]) > limit:
                raise ValueError('Registre au-delà des limites.')
            for ident, row in data[kind].items():
                _match(ident, ID_RE, 'Identifiant')
                if not isinstance(row, dict) or row.get('id') != ident or row.get('world_id') != world:
                    raise ValueError('Entrée du registre invalide.')
                if kind == 'connectors':
                    if row.get('status') not in {'registered', 'ready', 'revoked'}:
                        raise ValueError('Statut du connecteur invalide.')
                    if row.get('config_digest') != _digest(_config(row)):
                        raise ValueError('Configuration du connecteur altérée.')
                    tools = row.get('tools')
                    if not isinstance(tools, list) or len(tools) > MAX_TOOLS:
                        raise ValueError('Catalogue du connecteur invalide.')
                    expected = {tool['name']: _digest(tool) for tool in tools}
                    if row.get('tool_digests') != expected:
                        raise ValueError('Catalogue du connecteur altéré.')
                else:
                    if row.get('status') not in ACTIVE | TERMINAL | {'review'}:
                        raise ValueError('Statut de demande invalide.')
                    if row.get('connector_id') not in data['connectors']:
                        raise ValueError('Connecteur de la demande inconnu.')
                    if row.get('descriptor_digest') != _digest(row.get('descriptor')) or row.get('review_digest') != _review(row):
                        raise ValueError('Revue de la demande altérée.')
        return data
    except (ValueError, KeyError, TypeError, RecursionError, UnicodeError, OSError) as exc:
        raise ValueError('Registre des outils illisible ou incompatible ; aucune réinitialisation.') from exc


def _save(n, data):
    path = _path(n, data['world_id'])
    if len(_json(data)) > MAX_REGISTRY_BYTES:
        raise ValueError('Capacité des outils atteinte ; aucune trace supprimée.')
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    data['revision'] += 1
    n.atomic_json(path, data)
    os.chmod(path, 0o600)


def _owned(data, kind, ident):
    _match(ident, ID_RE, 'Identifiant')
    row = data[kind].get(ident)
    if row is None:
        raise ValueError('Élément absent de cet espace.')
    return row


def _process_identity(pid):
    try:
        # Linux proc comm may contain spaces or parentheses; fields start after it.
        return Path('/proc/%d/stat' % pid).read_text().rsplit(')', 1)[1].split()[19]
    except (OSError, IndexError):
        return None


def _recover(n, data):
    changed = False
    for row in data['requests'].values():
        if row['status'] not in ACTIVE:
            continue
        identity = _process_identity(row.get('owner_pid', 0))
        owner = row.get('owner_process')
        # Some Linux sandboxes do not expose their own PID under /proc. When
        # no identity could be recorded, the durable claim still prevents a
        # second dispatch; wait for its deadline instead of cancelling a live
        # request as soon as another tab reads the catalog.
        if time.time() > row.get('deadline', 0) or (owner is not None and identity != owner):
            row.update(status='unknown', finished_at=n.now(),
                       reason='Exécution interrompue : résultat inconnu, aucune nouvelle tentative automatique.')
            changed = True
    if changed:
        _save(n, data)


def _public(row, revision):
    hidden = {'owner_pid', 'owner_process', 'deadline', 'attempt_id', 'dedup_digest'}
    result = {key: copy.deepcopy(value) for key, value in row.items() if key not in hidden}
    result['revision'] = revision
    return result


def catalog(n):
    """Owner view of the selected world's stored catalog; never starts a server."""
    with n.LOCK:
        world = _world(n)
        data = _load(n, world)
        _recover(n, data)
        return {'schema': SCHEMA, 'world_id': world, 'revision': data['revision'],
                'connectors': [_public(row, data['revision']) for row in data['connectors'].values()],
                'requests': [_public(row, data['revision']) for row in data['requests'].values()],
                'limits': {'connectors': MAX_CONNECTORS, 'requests': MAX_REQUESTS,
                           'tools_per_connector': MAX_TOOLS, 'argument_bytes': MAX_ARGUMENT_BYTES,
                           'result_bytes': MAX_RESULT_BYTES, 'timeout_seconds': TIMEOUT_SECONDS},
                'automatic_execution': False, 'os_sandbox': False,
                'result_authority': 'external_untrusted_data', 'protocol': PROTOCOL}


def register(n, payload):
    """Owner CLI ONLY. Config has env variable names, never environment values."""
    required = {'label', 'argv', 'cwd', 'env_names', 'revision', 'owner_confirmed'}
    if not isinstance(payload, dict) or set(payload) != required:
        raise ValueError('Champs de configuration invalides ou manquants.')
    if payload['owner_confirmed'] is not True:
        raise PermissionError('Le propriétaire doit confirmer la commande locale de confiance.')
    label = text_field(payload['label'], 'Le nom du connecteur', 120, True)
    argv = payload['argv']
    if (not isinstance(argv, list) or not 1 <= len(argv) <= 64 or
            any(not isinstance(arg, str) or not arg or '\x00' in arg or len(arg) > 4096 for arg in argv) or
            len(_json(argv)) > MAX_ARGUMENT_BYTES):
        raise ValueError('Commande requise sous forme de liste d’arguments bornée, sans shell.')
    executable = argv[0] if os.path.isabs(argv[0]) else shutil.which(argv[0])
    if not executable or not Path(executable).is_file() or not os.access(executable, os.X_OK):
        raise ValueError('Exécutable absent : installer et vérifier le serveur séparément.')
    argv = [str(Path(executable).resolve())] + argv[1:]
    cwd = payload['cwd']
    if not isinstance(cwd, str) or not os.path.isabs(cwd) or not Path(cwd).is_dir():
        raise ValueError('Un répertoire de travail absolu existant est requis.')
    env_names = payload['env_names']
    if (not isinstance(env_names, list) or len(env_names) > 32 or
            any(not isinstance(name, str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,127}', name) for name in env_names) or
            len(env_names) != len(set(env_names))):
        raise ValueError('Déclarer uniquement les noms des variables d’environnement nécessaires.')
    with n.LOCK:
        world = _world(n)
        data = _load(n, world)
        check_revision(payload['revision'], data['revision'])
        if len(data['connectors']) >= MAX_CONNECTORS:
            raise ValueError('Limite de connecteurs atteinte ; les révocations restent tracées.')
        ident = secrets.token_hex(16)
        row = {'id': ident, 'world_id': world, 'label': label, 'argv': argv,
               'cwd': str(Path(cwd).resolve()), 'env_names': sorted(env_names),
               'created_at': n.now(), 'status': 'registered', 'tools': [], 'tool_digests': {},
               'authority': 'owner_installed_trusted_command', 'os_sandbox': False}
        row['config_digest'] = _digest(_config(row))
        data['connectors'][ident] = row
        _save(n, data)
        return _public(row, data['revision'])


class ProtocolFailure(ValueError):
    """Static diagnostic only: never include server stderr or environment values."""


class RemoteError(ProtocolFailure):
    def __init__(self, error):
        super().__init__('Le serveur MCP a renvoyé une erreur de protocole.')
        self.error = error


class _Stdio:
    def __init__(self, config):
        self.deadline = time.monotonic() + TIMEOUT_SECONDS
        self.selector = selectors.DefaultSelector()
        self.buffer = bytearray()
        self.stdout_bytes = self.stderr_bytes = self.message_count = 0
        self.sequence = 0
        self.changed = False
        self.process = None
        env = {'PATH': os.defpath, 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8'}
        self.redactions = []
        for name in config['env_names']:
            if name not in os.environ:
                raise ProtocolFailure('Une variable d’environnement déclarée manque dans le processus Tao.')
            env[name] = os.environ[name]
            if env[name]:
                self.redactions.append(env[name])
        try:
            self.process = subprocess.Popen(config['argv'], cwd=config['cwd'], env=env,
                                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                            stderr=subprocess.PIPE, shell=False,
                                            close_fds=True, start_new_session=True)
            for stream in (self.process.stdin, self.process.stdout, self.process.stderr):
                os.set_blocking(stream.fileno(), False)
            self.selector.register(self.process.stdout, selectors.EVENT_READ, 'stdout')
            self.selector.register(self.process.stderr, selectors.EVENT_READ, 'stderr')
        except OSError as exc:
            self.close()
            raise ProtocolFailure('Le serveur MCP local ne peut pas démarrer.') from exc

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def close(self):
        process = self.process
        if process is not None:
            # Kill the whole session's process group even when its leader exited.
            # Trusted programs that deliberately daemonize outside it are not sandboxed.
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=0.15)
            except subprocess.TimeoutExpired:
                pass
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=2)
            for stream in (process.stdin, process.stdout, process.stderr):
                if stream:
                    stream.close()
        self.selector.close()

    def redact(self, value):
        if isinstance(value, str):
            for secret in sorted(self.redactions, key=len, reverse=True):
                value = value.replace(secret, '[redacted environment]')
            return value
        if isinstance(value, list):
            return [self.redact(v) for v in value]
        if isinstance(value, dict):
            return {self.redact(k): self.redact(v) for k, v in value.items()}
        return value

    def _pump(self, wait=True):
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise ProtocolFailure('Délai MCP dépassé ; processus arrêté.')
        ready = self.selector.select(min(remaining, 0.25) if wait else 0)
        writable = False
        for key, mask in ready:
            if key.data == 'stdin':
                writable = bool(mask & selectors.EVENT_WRITE)
                continue
            try:
                chunk = os.read(key.fd, 65536)
            except BlockingIOError:
                continue
            if not chunk:
                self.selector.unregister(key.fileobj)
                continue
            if key.data == 'stderr':
                self.stderr_bytes += len(chunk)
                if self.stderr_bytes > MAX_STDERR_BYTES:
                    raise ProtocolFailure('Sortie de diagnostic MCP trop volumineuse ; processus arrêté.')
            else:
                self.stdout_bytes += len(chunk)
                self.buffer.extend(chunk)
                if self.stdout_bytes > MAX_STDOUT_BYTES or len(self.buffer) > MAX_LINE_BYTES:
                    raise ProtocolFailure('Sortie MCP trop volumineuse ; processus arrêté.')
        return writable

    def _send(self, value):
        message = memoryview(_json(value) + b'\n')
        self.selector.register(self.process.stdin, selectors.EVENT_WRITE, 'stdin')
        try:
            while message:
                if self._pump():
                    try:
                        written = os.write(self.process.stdin.fileno(), message)
                    except (BrokenPipeError, OSError) as exc:
                        raise ProtocolFailure('Le serveur MCP a fermé son entrée.') from exc
                    if written <= 0:
                        raise ProtocolFailure('Le serveur MCP a fermé son entrée.')
                    message = message[written:]
        finally:
            self.selector.unregister(self.process.stdin)

    def _message(self, wait=True):
        while b'\n' not in self.buffer:
            self._pump(wait)
            if not wait and b'\n' not in self.buffer:
                return None
            if self.process.poll() is not None and b'\n' not in self.buffer:
                raise ProtocolFailure('Le serveur MCP s’est arrêté avant une réponse complète.')
        line, _, rest = self.buffer.partition(b'\n')
        self.buffer = bytearray(rest)
        self.message_count += 1
        if self.message_count > 512:
            raise ProtocolFailure('Trop de messages MCP ; processus arrêté.')
        try:
            message = _decode(line.decode('utf-8'))
        except (ValueError, UnicodeError, RecursionError) as exc:
            raise ProtocolFailure('Réponse MCP malformée ou JSON dupliqué.') from exc
        if not isinstance(message, dict) or message.get('jsonrpc') != '2.0':
            raise ProtocolFailure('Réponse JSON-RPC invalide.')
        return message

    def _notice(self, message):
        if 'method' not in message:
            return False
        if not isinstance(message['method'], str) or 'result' in message or 'error' in message:
            raise ProtocolFailure('Message MCP invalide.')
        if 'id' in message:
            ident = message['id']
            if type(ident) not in (str, int):
                raise ProtocolFailure('Identifiant MCP invalide.')
            if message['method'] == 'ping':
                self._send({'jsonrpc': '2.0', 'id': ident, 'result': {}})
            else:
                # We advertise no sampling, elicitation, roots or task authority.
                self._send({'jsonrpc': '2.0', 'id': ident,
                            'error': {'code': -32601, 'message': 'Client capability not available'}})
        elif message['method'] == 'notifications/tools/list_changed':
            self.changed = True
        return True

    def rpc(self, method, params, dispatch=None):
        self.sequence += 1
        ident = self.sequence
        message = {'jsonrpc': '2.0', 'id': ident, 'method': method, 'params': params}
        if dispatch:
            dispatch(lambda: self._send(message))
        else:
            self._send(message)
        while True:
            response = self._message()
            if self._notice(response):
                continue
            if type(response.get('id')) is not int or response['id'] != ident or ('result' in response) == ('error' in response):
                raise ProtocolFailure('Réponse MCP inattendue, dupliquée ou sans résultat.')
            if 'error' in response:
                error = response['error']
                if not isinstance(error, dict) or type(error.get('code')) is not int or not isinstance(error.get('message'), str):
                    raise ProtocolFailure('Erreur MCP malformée.')
                raise RemoteError(self.redact(_bounded(error, MAX_RESULT_BYTES, 'Erreur MCP')))
            return response['result']

    def discover(self):
        result = self.rpc('initialize', {'protocolVersion': PROTOCOL, 'capabilities': {},
                                        'clientInfo': {'name': 'tao-tools', 'version': '1'}})
        if (not isinstance(result, dict) or result.get('protocolVersion') != PROTOCOL or
                not isinstance(result.get('capabilities'), dict) or
                not isinstance(result['capabilities'].get('tools'), dict) or
                not isinstance(result.get('serverInfo'), dict)):
            raise ProtocolFailure('Serveur MCP incompatible : protocole et capacité tools requis.')
        server_info = _bounded(result['serverInfo'], 4096, 'Identité MCP')
        self._send({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
        tools, names, cursors = [], set(), set()
        cursor = None
        for _ in range(8):
            page = self.rpc('tools/list', {} if cursor is None else {'cursor': cursor})
            if not isinstance(page, dict) or not isinstance(page.get('tools'), list):
                raise ProtocolFailure('Catalogue MCP invalide.')
            for descriptor in page['tools']:
                if (not isinstance(descriptor, dict) or
                        not isinstance(descriptor.get('inputSchema'), dict) or
                        descriptor['inputSchema'].get('type') != 'object'):
                    raise ProtocolFailure('Descripteur d’outil MCP invalide.')
                name = _match(descriptor.get('name'), TOOL_RE, 'Nom de l’outil')
                if name in names:
                    raise ProtocolFailure('Nom d’outil MCP dupliqué.')
                for key, limit in (('description', 12000), ('title', 256)):
                    if key in descriptor and (not isinstance(descriptor[key], str) or len(descriptor[key]) > limit):
                        raise ProtocolFailure('Description d’outil MCP invalide.')
                tools.append(_bounded(descriptor, MAX_DESCRIPTOR_BYTES, 'Descripteur MCP'))
                names.add(name)
                if len(tools) > MAX_TOOLS:
                    raise ProtocolFailure('Trop d’outils MCP.')
            cursor = page.get('nextCursor')
            if cursor is None:
                break
            if not isinstance(cursor, str) or not cursor or len(cursor) > 1024 or cursor in cursors:
                raise ProtocolFailure('Pagination MCP invalide ou cyclique.')
            cursors.add(cursor)
        else:
            raise ProtocolFailure('Trop de pages dans le catalogue MCP.')
        self.drain()
        if self.changed:
            raise ProtocolFailure('Le catalogue MCP a changé pendant sa lecture ; réinspecter.')
        tools.sort(key=lambda item: item['name'])
        _bounded(tools, MAX_TOOL_BYTES, 'Catalogue MCP')
        # Descriptors containing declared environment values cannot be safely
        # displayed/pinned: fail instead of subtly changing their identity.
        if self.redact(tools) != tools or self.redact(server_info) != server_info:
            raise ProtocolFailure('Le catalogue MCP expose une variable d’environnement ; inspection refusée.')
        return tools, server_info

    def drain(self):
        while True:
            message = self._message(wait=False)
            if message is None:
                return
            if not self._notice(message):
                raise ProtocolFailure('Réponse MCP supplémentaire ou dupliquée.')


def inspect(n, ident, revision):
    """Explicit owner discovery. Starts an installed command, never tools/call."""
    with n.LOCK:
        world = _world(n)
        data = _load(n, world)
        check_revision(revision, data['revision'])
        row = _owned(data, 'connectors', ident)
        if row['status'] == 'revoked':
            raise ValueError('Ce connecteur est révoqué ; le réenregistrer explicitement si nécessaire.')
        if any(item['connector_id'] == ident and item['status'] in ACTIVE for item in data['requests'].values()):
            raise ValueError('Une demande est déjà en cours pour ce connecteur.')
        config = _config(row)
        digest = row['config_digest']
    try:
        with _Stdio(config) as client:
            tools, server_info = client.discover()
    except (ProtocolFailure, ValueError) as exc:
        with n.LOCK:
            data = _load(n, world)
            row = _owned(data, 'connectors', ident)
            if row['status'] != 'revoked' and row['config_digest'] == digest:
                row['last_error'] = str(exc) if not isinstance(exc, RemoteError) else 'Le serveur MCP a refusé l’inspection.'
                _save(n, data)
        raise
    with n.LOCK:
        _world(n)
        if worlds.current() != world:
            raise ValueError('L’espace a changé pendant l’inspection.')
        data = _load(n, world)
        check_revision(revision, data['revision'])
        row = _owned(data, 'connectors', ident)
        if row['status'] == 'revoked' or row['config_digest'] != digest:
            raise ValueError('Le connecteur a changé pendant l’inspection.')
        row.update(status='ready', tools=tools, tool_digests={t['name']: _digest(t) for t in tools},
                   server_info=server_info, server_digest=_digest(server_info),
                   last_inspected_at=n.now(), last_error=None)
        _save(n, data)
        return _public(row, data['revision'])


def request(n, connector_id, tool, arguments, origin='human', request_id=None):
    """Store a proposal only. Safe for an explicitly scoped external bridge."""
    _match(tool, TOOL_RE, 'Nom de l’outil')
    if not isinstance(arguments, dict):
        raise ValueError('Les arguments doivent être un objet JSON.')
    arguments = _bounded(arguments, MAX_ARGUMENT_BYTES, 'Arguments')
    if origin not in {'human', 'dialogue', 'external'}:
        raise ValueError('Origine de demande invalide.')
    if request_id is not None:
        _match(request_id, ID_RE, 'Identifiant de demande')
    dedup = _digest({'connector_id': connector_id, 'tool': tool, 'arguments': arguments, 'origin': origin})
    with n.LOCK:
        world = _world(n)
        data = _load(n, world)
        _recover(n, data)
        if request_id and request_id in data['requests']:
            previous = data['requests'][request_id]
            if previous['dedup_digest'] != dedup:
                raise ValueError('Identifiant de demande déjà utilisé pour d’autres arguments.')
            return _public(previous, data['revision'])
        connector = _owned(data, 'connectors', connector_id)
        if connector['status'] != 'ready':
            raise ValueError('Inspecter un connecteur actif avant de proposer un appel.')
        descriptor = next((item for item in connector['tools'] if item['name'] == tool), None)
        if descriptor is None:
            raise ValueError('Outil absent du catalogue inspecté.')
        if len(data['requests']) >= MAX_REQUESTS:
            raise ValueError('Limite de reçus atteinte ; aucun résultat ni demande supprimé.')
        ident = request_id or secrets.token_hex(16)
        row = {'id': ident, 'world_id': world, 'connector_id': connector_id,
               'connector_label': connector['label'], 'tool': tool, 'arguments': arguments,
               'descriptor': copy.deepcopy(descriptor), 'descriptor_digest': _digest(descriptor),
               'config_digest': connector['config_digest'], 'server_digest': connector['server_digest'],
               'origin': origin, 'status': 'review', 'created_at': n.now(), 'dedup_digest': dedup,
               'authority': 'proposal_only', 'result_authority': 'external_untrusted_data',
               'automatic_retry': False}
        row['review_digest'] = _review(row)
        data['requests'][ident] = row
        _save(n, data)
        return _public(row, data['revision'])


def _still_current(data, row):
    connector = _owned(data, 'connectors', row['connector_id'])
    if (connector['status'] != 'ready' or connector['config_digest'] != row['config_digest'] or
            connector.get('server_digest') != row['server_digest'] or
            connector['tool_digests'].get(row['tool']) != row['descriptor_digest']):
        raise ValueError('Le connecteur ou le catalogue a changé ; préparer une nouvelle demande.')
    return connector


def execute(n, request_id, revision, review_digest):
    """Owner-only exact human review; not exported in any model tool registry."""
    _match(review_digest, SHA_RE, 'Empreinte de revue')
    with n.LOCK:
        world = _world(n)
        data = _load(n, world)
        _recover(n, data)
        check_revision(revision, data['revision'])
        row = _owned(data, 'requests', request_id)
        if row['status'] != 'review':
            raise ValueError('Cette demande ne peut pas être rejouée. Examiner son reçu.')
        if not hmac.compare_digest(review_digest, row['review_digest']):
            raise ValueError('La revue ne correspond pas aux arguments de cette demande.')
        connector = _still_current(data, row)
        config = _config(connector)
        if any(other['connector_id'] == connector['id'] and other['status'] in ACTIVE for other in data['requests'].values()):
            raise ValueError('Un appel est déjà en cours pour ce connecteur.')
        attempt = secrets.token_hex(16)
        row.update(status='checking', authority='human_reviewed_exact_request',
                   reviewed_at=n.now(), attempt_id=attempt, owner_pid=os.getpid(),
                   owner_process=_process_identity(os.getpid()), deadline=time.time() + TIMEOUT_SECONDS + 10)
        _save(n, data)
        claimed_revision = data['revision']
        snapshot = copy.deepcopy(row)
    dispatched = False
    result = None
    reason = None
    remote_error = None
    status = 'failed'
    elapsed_start = time.monotonic()

    def dispatch(send):
        nonlocal dispatched
        with n.LOCK:
            if _world(n) != world:
                raise ValueError('L’espace sélectionné a changé.')
            current = _load(n, world)
            check_revision(claimed_revision, current['revision'])
            active = _owned(current, 'requests', request_id)
            if active['status'] != 'checking' or active.get('attempt_id') != attempt:
                raise ValueError('La demande a été retirée pendant la vérification.')
            _still_current(current, active)
            active.update(status='executing', dispatched_at=n.now())
            _save(n, current)  # Persist BEFORE possibly sending any bytes.
            dispatched = True
            send()

    try:
        with _Stdio(config) as client:
            tools, server_info = client.discover()
            descriptor = next((item for item in tools if item['name'] == snapshot['tool']), None)
            if descriptor is None or _digest(descriptor) != snapshot['descriptor_digest'] or _digest(server_info) != snapshot['server_digest']:
                status = 'blocked'
                reason = 'Le serveur a changé sa description ou son schéma ; aucun argument envoyé. Réinspecter et relire une nouvelle demande.'
            else:
                client.drain()
                if client.changed:
                    raise ValueError('Le serveur signale un nouveau catalogue ; aucun argument envoyé.')
                response = client.rpc('tools/call', {'name': snapshot['tool'], 'arguments': snapshot['arguments']}, dispatch=dispatch)
                if (not isinstance(response, dict) or not isinstance(response.get('content'), list) or
                        ('isError' in response and type(response['isError']) is not bool)):
                    raise ProtocolFailure('Résultat d’outil MCP invalide.')
                result = _bounded(client.redact(response), MAX_RESULT_BYTES, 'Résultat MCP')
                client.drain()
                status = 'tool_error' if result.get('isError', False) else 'succeeded'
    except RemoteError as exc:
        remote_error = exc.error
        status = 'tool_error' if dispatched else 'failed'
        reason = 'Le serveur MCP a renvoyé une erreur ; aucune nouvelle tentative automatique.'
    except (ValueError, OSError) as exc:
        status = 'unknown' if dispatched else 'blocked'
        reason = str(exc) if isinstance(exc, ValueError) else 'Échec du processus MCP local.'
    except BaseException:
        # KeyboardInterrupt/SystemExit also retain uncertainty instead of leaving
        # an approval that could silently be used again on the next startup.
        with n.LOCK:
            current = _load(n, world)
            active = _owned(current, 'requests', request_id)
            if active.get('attempt_id') == attempt:
                active.update(status='unknown', finished_at=n.now(),
                              reason='Exécution interrompue ; aucune nouvelle tentative automatique.')
                _save(n, current)
        raise
    with n.LOCK:
        current = _load(n, world)
        active = _owned(current, 'requests', request_id)
        if active.get('attempt_id') != attempt:
            raise ValueError('Le reçu de la tentative a changé ; aucune réexécution.')
        active.update(status=status, finished_at=n.now(), elapsed_seconds=round(time.monotonic() - elapsed_start, 6),
                      call_dispatched=dispatched, reason=reason, result=result)
        if remote_error is not None:
            active['protocol_error'] = remote_error
        _save(n, current)
        return _public(active, current['revision'])


def dismiss(n, ident, revision):
    with n.LOCK:
        world = _world(n)
        data = _load(n, world)
        check_revision(revision, data['revision'])
        row = _owned(data, 'requests', ident)
        if row['status'] != 'review':
            raise ValueError('Seule une demande en attente peut être écartée ; son reçu reste conservé.')
        row.update(status='dismissed', finished_at=n.now())
        _save(n, data)
        return _public(row, data['revision'])


def revoke(n, ident, revision):
    with n.LOCK:
        world = _world(n)
        data = _load(n, world)
        check_revision(revision, data['revision'])
        row = _owned(data, 'connectors', ident)
        row.update(status='revoked', revoked_at=n.now())
        for item in data['requests'].values():
            if item['connector_id'] == ident and item['status'] in {'review', 'checking'}:
                item.update(status='blocked', finished_at=n.now(), reason='Connecteur révoqué avant l’envoi de l’appel.')
        _save(n, data)
        return _public(row, data['revision'])


remove = revoke  # Never erase review or execution receipts.
