"""Explicit, bounded remote code experiments, without automatic application.

The broker retains leases before returning them. An interrupted lease is never
redispatched: the machine journal must also persist each lease before execution.
Remote reports remain claims from a paired machine, not local execution proofs.
This private sidecar is deliberately outside state/heritage and survives rollback.
"""
import copy
import hashlib
import hmac
import json
import math
import os
import re
import secrets
import time
from datetime import datetime, timezone

import tao_worlds as worlds
from tao_work import check_revision, text_field

SCHEMA = 'tao.devices.v1'
MAX_DEVICES = 16
MAX_JOBS = 100
MAX_PAIRINGS = 16
MAX_PATCH_BYTES = 128 * 1024
MAX_REGISTRY_BYTES = 32 * 1024 * 1024
PAIR_SECONDS = 600
LEASE_SECONDS = 900
GENERATE_SECONDS = 600
VERIFY_SECONDS = 300
TERMINAL = {'verified', 'failed', 'interrupted', 'cancelled', 'stale'}
ACTIVE = {'running', 'verifying'}
JOB_STATUSES = TERMINAL | ACTIVE | {'queued', 'review', 'verify_queued'}
ID_RE = r'[a-f0-9]{32}'
HEAD_RE = r'[a-f0-9]{40}'
SHA_RE = r'[a-f0-9]{64}'
PRESENCE_FIELDS = {'machine_id', 'repo_head', 'clean', 'git', 'codex', 'python',
                   'allow_tests', 'platform', 'request_id'}
RESULT_REQUIRED = {'ok', 'status', 'patch', 'patch_sha256', 'summary', 'elapsed_seconds'}
RESULT_OPTIONAL = {'candidate_commit', 'tests_summary', 'worker_version'}


def _hash(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def _digest(value):
    return _hash(json.dumps(value, ensure_ascii=False, sort_keys=True,
                            separators=(',', ':'), allow_nan=False))


def _match(value, pattern, label):
    if not isinstance(value, str) or not re.fullmatch(pattern, value):
        raise ValueError(label + ' invalide.')
    return value


def _shape(value, fields, optional=()):
    if not isinstance(value, dict) or set(value) - set(fields) - set(optional) or set(fields) - set(value):
        raise ValueError('Champs de la requête invalides ou manquants.')
    return value


def _stamp(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat().replace('+00:00', 'Z')


def _day(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).strftime('%Y-%m-%d')


def _path(n):
    folder = n.ROOT / 'devices'
    path = folder / 'registry.json'
    if folder.is_symlink() or path.is_symlink():
        raise ValueError('Le registre des machines ne peut pas être un lien symbolique.')
    return path


def _load(n):
    path = _path(n)
    node_id = n.load_raw_state()['id']
    if not path.exists():
        return {'schema': SCHEMA, 'node_id': node_id, 'revision': 0,
                'devices': {}, 'pairings': {}, 'jobs': {}}
    if path.stat().st_size > MAX_REGISTRY_BYTES:
        raise ValueError('Registre des machines trop volumineux ; conservation sans modification.')
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
    except (ValueError, OSError) as exc:
        raise ValueError('Registre des machines illisible ; aucune réinitialisation.') from exc
    if (not isinstance(value, dict) or value.get('schema') != SCHEMA or
            value.get('node_id') != node_id or type(value.get('revision')) is not int or value['revision'] < 0):
        raise ValueError('Registre des machines incompatible avec ce Tao.')
    for key, limit in (('devices', MAX_DEVICES), ('pairings', MAX_PAIRINGS), ('jobs', MAX_JOBS)):
        if not isinstance(value.get(key), dict) or len(value[key]) > limit:
            raise ValueError('Registre des machines invalide ou au-delà des limites.')
        for ident, row in value[key].items():
            _match(ident, ID_RE, 'Identifiant')
            if not isinstance(row, dict) or row.get('id') != ident:
                raise ValueError('Entrée du registre invalide.')
            _match(row.get('world_id'), r'main|[a-f0-9]{12}', 'Espace')
            if key == 'devices':
                _match(row.get('token_hash'), SHA_RE, 'Empreinte du jeton')
                _match(row.get('machine_id'), ID_RE, 'Machine')
                if row.get('status') not in {'pending', 'approved', 'revoked'}:
                    raise ValueError('Statut de machine invalide.')
            elif key == 'jobs':
                if row.get('status') not in JOB_STATUSES or row.get('device_id') not in value['devices']:
                    raise ValueError('Expérience invalide.')
                if value['devices'][row['device_id']]['world_id'] != row['world_id']:
                    raise ValueError('Une expérience ne peut pas changer d’espace.')
                if row.get('status') in ACTIVE:
                    _match(row.get('lease_id'), ID_RE, 'Bail')
                    if type(row.get('lease_deadline')) not in (int, float):
                        raise ValueError('Bail incomplet.')
            else:
                _match(row.get('code_hash'), SHA_RE, 'Empreinte du code')
                if type(row.get('expires_epoch')) not in (int, float):
                    raise ValueError('Appairage incomplet.')
    return value


def _save(n, registry, revision=True):
    path = _path(n)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    if revision:
        registry['revision'] += 1
    if len(json.dumps(registry, ensure_ascii=False).encode()) > MAX_REGISTRY_BYTES:
        raise ValueError('Capacité du registre atteinte ; aucune donnée supprimée.')
    n.atomic_json(path, registry)
    os.chmod(path, 0o600)


def _current(n):
    # Validate that the selected world really exists, even on an empty sidecar.
    n.load_state()
    return worlds.current()


def _owned(registry, kind, ident, world):
    _match(ident, ID_RE, 'Identifiant')
    row = registry[kind].get(ident)
    if not row or row['world_id'] != world:
        raise ValueError('Élément absent de cet espace.')
    return row


def _expire(registry, epoch):
    changed = False
    for row in registry['jobs'].values():
        if row['status'] in ACTIVE and row['lease_deadline'] <= epoch:
            row.update(status='interrupted', finished_at=_stamp(epoch),
                       reason='Bail expiré : aucune réexécution automatique.')
            changed = True
    return changed


def _public_device(row):
    return {key: copy.deepcopy(value) for key, value in row.items() if key != 'token_hash'}


def _public_job(row, full=False):
    hidden = {'request_id', 'lease_id', 'claim_request_ids', 'report_digests', 'snapshot', 'buffer_fingerprint'}
    result = {key: copy.deepcopy(value) for key, value in row.items() if key not in hidden}
    result['report_authority'] = 'paired_machine_report_not_local_execution_proof'
    result['automatic_apply'] = False
    result['automatic_deploy'] = False
    if full:
        result.update(copy.deepcopy(row['snapshot']))
        result['patch'] = row.get('generation_result', {}).get('patch', '')
    else:
        for key in ('generation_result', 'verification_result'):
            result.pop(key, None)
    return result


def _budget(n, registry, epoch):
    p = n.policy()
    runs = min(3, p['adaptation_runs_per_day'])
    seconds = min(1800, p['adaptation_seconds_per_day'])
    reservations = [row for row in registry['jobs'].values() if row.get('budget_day') == _day(epoch)]
    return {'name': 'distributed_code_generation', 'scope': 'all_worlds_this_node',
            'day_utc': _day(epoch), 'runs_reserved': len(reservations), 'runs_limit': runs,
            'seconds_reserved': sum(row['reserved_seconds'] for row in reservations),
            'seconds_limit': seconds, 'incomplete_reservations_remain_charged': True,
            'money_measured': False, 'provider_tokens_measured': False,
            'separate_from_local_adaptation_budget': True}


def owner_view(n):
    with n.LOCK:
        world = _current(n)
        registry = _load(n)
        epoch = time.time()
        if _expire(registry, epoch):
            _save(n, registry)
        return {'schema': SCHEMA, 'revision': registry['revision'], 'world_id': world,
                'devices': [_public_device(row) for row in registry['devices'].values() if row['world_id'] == world],
                'jobs': [_public_job(row) for row in registry['jobs'].values() if row['world_id'] == world],
                'pairings': [{key: row.get(key) for key in ('id', 'label', 'world_id', 'created_at', 'expires_at', 'device_id')}
                             for row in registry['pairings'].values() if row['world_id'] == world and row['expires_epoch'] > epoch],
                'limits': {'devices': MAX_DEVICES, 'jobs': MAX_JOBS, 'pairings': MAX_PAIRINGS,
                           'patch_bytes': MAX_PATCH_BYTES},
                'budget': _budget(n, registry, epoch), 'automatic_paid_fallback': False}


def create_pairing(n, label, revision=0):
    label = text_field(label, 'Le nom de cette machine', 100, True)
    with n.LOCK:
        world = _current(n)
        registry = _load(n)
        check_revision(revision, registry['revision'])
        epoch = time.time()
        # Consumed pairings remain as bounded enrollment receipts. Their code
        # can recover the same bearer/machine after a lost response, never add
        # a device or restore authority. Only unused expired codes are removed.
        registry['pairings'] = {key: row for key, row in registry['pairings'].items()
                                if row['expires_epoch'] > epoch or row.get('device_id')}
        if len(registry['pairings']) >= MAX_PAIRINGS or len(registry['devices']) >= MAX_DEVICES:
            raise ValueError('Limite d’appairages ou de machines atteinte ; aucune trace supprimée.')
        ident, code = secrets.token_hex(16), secrets.token_urlsafe(32)
        row = {'id': ident, 'label': label, 'world_id': world, 'code_hash': _hash(code),
               'created_at': _stamp(epoch), 'expires_at': _stamp(epoch + PAIR_SECONDS),
               'expires_epoch': epoch + PAIR_SECONDS, 'device_id': None}
        registry['pairings'][ident] = row
        _save(n, registry)
        return {'id': ident, 'code': code, 'expires_at': row['expires_at'],
                'world_id': world, 'revision': registry['revision']}


def owner_device(n, ident, action, revision=0):
    if action not in ('approve', 'revoke'):
        raise ValueError('Action de machine inconnue.')
    with n.LOCK:
        world = _current(n)
        registry = _load(n)
        check_revision(revision, registry['revision'])
        row = _owned(registry, 'devices', ident, world)
        if action == 'approve':
            if row['status'] == 'revoked':
                raise ValueError('Une machine révoquée ne peut pas être réautorisée ; nouvel appairage requis.')
            row.update(status='approved', approved_at=n.now())
        else:
            row.update(status='revoked', revoked_at=n.now())
            for job in registry['jobs'].values():
                if job['device_id'] == ident and job['status'] not in TERMINAL:
                    job.update(status='cancelled', finished_at=n.now(),
                               reason='Autorisation de cette machine révoquée.')
        _save(n, registry)
        return dict(_public_device(row), revision=registry['revision'])


def _need_projection(s, need_id, world):
    if not isinstance(need_id, str) or not 1 <= len(need_id) <= 200:
        raise ValueError('Besoin de dialogue invalide.')
    source = s.get('buffers', {}).get(need_id)
    if (not isinstance(source, dict) or source.get('kind') != 'dialogue'
            or source.get('status') != 'open' or not isinstance(source.get('dialogue_need'), dict)
            or source['dialogue_need'].get('phase') == 'paused'):
        raise ValueError('Choisir un besoin de dialogue ouvert et repris dans cet espace.')
    need = source['dialogue_need']
    if need.get('id') != need_id or type(need.get('revision')) is not int or need['revision'] < 1:
        raise ValueError('Révision du besoin de dialogue invalide.')
    title = text_field(need.get('title'), 'Le titre du besoin', 160, True)
    current = text_field(need.get('current'), 'La situation', 1200)
    snapshot = {'residual': text_field(current or title, 'L’écart', 4000, True),
                'goal': text_field(need.get('desired'), 'Le résultat souhaité', 2000, True),
                'acceptance': text_field(need.get('acceptance'), 'La preuve attendue', 2000, True)}
    fingerprint = _digest({'id': need_id, 'world_id': world, 'status': source['status'],
                           'revision': need['revision'], 'title': title, 'current': current,
                           'desired': snapshot['goal'], 'acceptance': snapshot['acceptance'],
                           'next_step': need.get('next_step'), 'phase': need.get('phase')})
    return source, snapshot, fingerprint


def project_need(n, need_id, need_revision, expected_snapshot):
    """Project one reviewed dialogue need into inert, separately selectable code work."""
    _shape(expected_snapshot, {'residual', 'goal', 'acceptance'})
    for key, limit in (('residual', 4000), ('goal', 2000), ('acceptance', 2000)):
        text_field(expected_snapshot[key], key, limit, True)
    expected = expected_snapshot
    if type(need_revision) is not int or need_revision < 1:
        raise ValueError('Révision du besoin de dialogue invalide.')
    if not isinstance(need_id, str) or not 1 <= len(need_id) <= 200:
        raise ValueError('Besoin de dialogue invalide.')
    with n.LOCK:
        world = _current(n)
        s = n.load_state()
        link = {'id': need_id, 'revision': need_revision, 'world_id': world}
        bid = 'user:code:dialogue:' + _digest(link)[:20]
        existing = s['buffers'].get(bid)
        if existing is not None:
            if (existing.get('kind') != 'code_projection' or existing.get('authority') != 'human' or
                    existing.get('execution_enabled') is not False or
                    'work_task' in existing or 'dialogue_need' in existing or
                    existing.get('source_need') != link or
                    {key: existing.get(field) for key, field in
                     (('residual', 'residual'), ('goal', 'desired'), ('acceptance', 'acceptance'))} != expected):
                raise ValueError('Le tampon projeté a changé ; aucun ancien résultat écrasé.')
            if existing.get('status') != 'open':
                raise ValueError('Le tampon projeté ' + bid + ' est terminé ; son histoire est conservée.')
            try:
                source, snapshot, fingerprint = _need_projection(s, need_id, world)
            except ValueError:
                raise ValueError('Le besoin d’origine du tampon ' + bid + ' a changé ; relire avant une nouvelle projection.') from None
            if (source['dialogue_need']['revision'] != need_revision or snapshot != expected or
                    existing.get('source_need_fingerprint') != fingerprint):
                raise ValueError('Le besoin d’origine du tampon ' + bid + ' a changé ; relire avant une nouvelle projection.')
            return dict(copy.deepcopy(existing), already_projected=True)
        source, snapshot, fingerprint = _need_projection(s, need_id, world)
        if source['dialogue_need']['revision'] != need_revision or snapshot != expected:
            raise ValueError('Le besoin a changé depuis la revue ; relire avant de préparer le tampon de code.')
        if len(n.open_buffers(s)) >= 200:
            raise ValueError('200 besoins ouverts ; aucun nouveau tampon de code créé.')
        b = n.make_buffer(bid, 'code_projection', snapshot['residual'], authority='human')
        b.update(desired=snapshot['goal'], acceptance=snapshot['acceptance'],
                 story_id=source.get('story_id'), source_need=link,
                 source_need_fingerprint=fingerprint, execution_enabled=False)
        s['buffers'][bid] = b
        n.atomic_json(n.STATE, s, backup=True)
        n.WAKE.set()
        return dict(copy.deepcopy(b), already_projected=False)


def _source_fresh(s, row, world):
    link = row.get('source_need')
    if link is None:
        return row.get('kind') == 'user'
    if (row.get('kind') != 'code_projection' or not isinstance(link, dict)
            or set(link) != {'id', 'revision', 'world_id'}
            or link['world_id'] != world or type(link['revision']) is not int or link['revision'] < 1
            or row.get('id') != 'user:code:dialogue:' + _digest(link)[:20]
            or row.get('authority') != 'human' or row.get('execution_enabled') is not False):
        return False
    try:
        source, snapshot, fingerprint = _need_projection(s, link['id'], world)
    except ValueError:
        return False
    return (source['dialogue_need']['revision'] == link['revision'] and
            row.get('source_need_fingerprint') == fingerprint and
            row.get('residual') == snapshot['residual'] and
            row.get('desired') == snapshot['goal'] and
            row.get('acceptance') == snapshot['acceptance'])


def _snapshot(n, buffer_id, world):
    if not isinstance(buffer_id, str) or len(buffer_id) > 200:
        raise ValueError('Tampon invalide.')
    with worlds.using(world):
        s = n.load_state()
        row = s.get('buffers', {}).get(buffer_id)
    if (not isinstance(row, dict) or row.get('status') != 'open'
            or row.get('kind') not in ('user', 'code_projection')
            or 'work_task' in row or 'dialogue_need' in row):
        raise ValueError('Sélectionner un tampon de code ouvert, distinct d’une tâche métier ou d’un besoin de dialogue.')
    if not _source_fresh(s, row, world):
        raise ValueError('Le besoin d’origine a changé ; préparer un nouveau tampon de code après revue.')
    snapshot = {'residual': text_field(row.get('residual'), 'L’écart', 4000, True),
                'goal': text_field(row.get('desired'), 'Le résultat souhaité', 2000, True),
                'acceptance': text_field(row.get('acceptance'), 'La preuve attendue', 2000, True)}
    return snapshot, _digest({'id': buffer_id, 'world_id': world, 'status': 'open',
                              'kind': row['kind'], **snapshot})


def _fresh(n, row):
    try:
        _, fingerprint = _snapshot(n, row['buffer_id'], row['world_id'])
        return hmac.compare_digest(fingerprint, row['buffer_fingerprint'])
    except ValueError:
        return False


def enqueue(n, device_id, buffer_id, revision=0, expected_snapshot=None):
    if expected_snapshot is not None:
        _shape(expected_snapshot, {'residual', 'goal', 'acceptance'})
        for field, limit in (('residual', 4000), ('goal', 2000), ('acceptance', 2000)):
            text_field(expected_snapshot[field], field, limit, True)
    with n.LOCK:
        world = _current(n)
        registry = _load(n)
        check_revision(revision, registry['revision'])
        device = _owned(registry, 'devices', device_id, world)
        if device['status'] != 'approved':
            raise ValueError('Approuver cette machine avant de lui confier une expérience.')
        presence = device.get('presence', {})
        head = _match(presence.get('repo_head'), HEAD_RE, 'Dernier commit annoncé par la machine')
        if not all(presence.get(field) is True for field in ('git', 'python', 'codex')):
            raise ValueError('Cette machine doit annoncer Git, Python et Codex avant une expérience de code.')
        if len(registry['jobs']) >= MAX_JOBS:
            raise ValueError('Cent expériences conservées ; aucune suppression automatique.')
        snapshot, fingerprint = _snapshot(n, buffer_id, world)
        if expected_snapshot is not None and snapshot != expected_snapshot:
            raise ValueError('Le tampon a changé depuis son affichage ; recharger et relire avant de le transmettre.')
        if any(row['buffer_id'] == buffer_id and row['world_id'] == world and row['status'] not in TERMINAL
               for row in registry['jobs'].values()):
            raise ValueError('Ce tampon possède déjà une expérience en attente ou à examiner.')
        ident = secrets.token_hex(16)
        row = {'id': ident, 'world_id': world, 'device_id': device_id,
               'buffer_id': buffer_id, 'snapshot': snapshot, 'buffer_fingerprint': fingerprint,
               'base_commit': head, 'status': 'queued', 'created_at': n.now(), 'report_digests': {}}
        registry['jobs'][ident] = row
        _save(n, registry)
        return dict(_public_job(row, True), revision=registry['revision'])


def owner_job(n, ident, action, revision=0, review_digest=None, confirmed=False):
    if action not in ('cancel', 'verify') or type(confirmed) is not bool:
        raise ValueError('Action d’expérience invalide.')
    with n.LOCK:
        world = _current(n)
        registry = _load(n)
        check_revision(revision, registry['revision'])
        row = _owned(registry, 'jobs', ident, world)
        if action == 'cancel':
            if row['status'] in TERMINAL:
                raise ValueError('Cette expérience est déjà terminée ; ses preuves sont conservées.')
            row.update(status='cancelled', finished_at=n.now(), reason='Annulation par le propriétaire.')
        else:
            if row['status'] != 'review' or not confirmed:
                raise ValueError('Relire les changements et confirmer explicitement leur exécution pour les tester.')
            _match(review_digest, SHA_RE, 'Empreinte du candidat relu')
            if not hmac.compare_digest(review_digest, row['review_digest']):
                raise ValueError('Le candidat ne correspond pas à la revue ; recharger les changements.')
            if not _fresh(n, row):
                row.update(status='stale', finished_at=n.now(), reason='Le tampon a changé depuis la préparation.')
                _save(n, registry)
                raise ValueError('Le tampon a changé ; cette expérience est périmée.')
            device = registry['devices'][row['device_id']]
            if device['status'] != 'approved':
                raise ValueError('Cette machine n’est plus autorisée.')
            row.update(status='verify_queued', authorized_review_digest=review_digest, verified_requested_at=n.now())
        _save(n, registry)
        return dict(_public_job(row, True), revision=registry['revision'])


def job_view(n, ident):
    with n.LOCK:
        world = _current(n)
        registry = _load(n)
        if _expire(registry, time.time()):
            _save(n, registry)
        return dict(_public_job(_owned(registry, 'jobs', ident, world), True), revision=registry['revision'])


def _enrol(n, registry, payload, epoch):
    _shape(payload, {'code', 'token', 'label', 'machine_id'})
    code = _match(payload['code'], r'[A-Za-z0-9_-]{43}', 'Code d’appairage')
    token = _match(payload['token'], r'[A-Za-z0-9_-]{32,256}', 'Jeton de machine')
    machine_id = _match(payload['machine_id'], ID_RE, 'Machine')
    label = text_field(payload['label'], 'Le nom de cette machine', 100, True)
    code_hash, token_hash = _hash(code), _hash(token)
    pairing = next((row for row in registry['pairings'].values()
                    if hmac.compare_digest(row['code_hash'], code_hash)), None)
    if not pairing:
        raise PermissionError('Code d’appairage invalide ou expiré.')
    if pairing.get('device_id'):
        row = registry['devices'][pairing['device_id']]
        if (not hmac.compare_digest(row['token_hash'], token_hash) or row['machine_id'] != machine_id
                or row['status'] == 'revoked'):
            raise PermissionError('Ce code a déjà été utilisé.')
        return {'device_id': row['id'], 'status': row['status'], 'world_id': row['world_id']}
    if pairing['expires_epoch'] <= epoch:
        raise PermissionError('Code d’appairage invalide ou expiré.')
    if len(registry['devices']) >= MAX_DEVICES:
        raise ValueError('Seize machines conservées ; aucun accès supprimé automatiquement.')
    if any(hmac.compare_digest(row['token_hash'], token_hash) for row in registry['devices'].values()):
        raise PermissionError('Ce jeton est déjà associé à une machine.')
    # The pairing chooses the world. Payloads cannot request another world.
    with worlds.using(pairing['world_id']):
        _current(n)
    ident = secrets.token_hex(16)
    row = {'id': ident, 'world_id': pairing['world_id'], 'label': label,
           'pairing_label': pairing['label'], 'machine_id': machine_id, 'token_hash': token_hash,
           'status': 'pending', 'created_at': _stamp(epoch)}
    registry['devices'][ident] = row
    pairing['device_id'] = ident
    _save(n, registry)
    return {'device_id': ident, 'status': 'pending', 'world_id': row['world_id']}


def _authenticate(registry, token):
    if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{32,256}', token):
        raise PermissionError('Jeton de machine invalide.')
    token_hash = _hash(token)
    row = next((row for row in registry['devices'].values()
                if hmac.compare_digest(row['token_hash'], token_hash)), None)
    if not row or row['status'] == 'revoked':
        raise PermissionError('Cette machine n’est pas autorisée.')
    return row


def _work(row):
    phase = 'verify' if row['status'] == 'verifying' else 'generate'
    result = {'id': row['id'], 'phase': phase, 'lease_id': row['lease_id'],
              'base_commit': row['base_commit'], 'world_id': row['world_id'],
              'timeout_seconds': VERIFY_SECONDS if phase == 'verify' else GENERATE_SECONDS,
              **copy.deepcopy(row['snapshot'])}
    if phase == 'verify':
        result['review_digest'] = row['authorized_review_digest']
        result['patch'] = row['generation_result']['patch']
    return result


def _presence(payload):
    _shape(payload, PRESENCE_FIELDS)
    _match(payload['machine_id'], ID_RE, 'Machine')
    _match(payload['request_id'], ID_RE, 'Identifiant de demande')
    if payload['repo_head'] is not None:
        _match(payload['repo_head'], HEAD_RE, 'Commit')
    for field in ('clean', 'git', 'codex', 'python', 'allow_tests'):
        if type(payload[field]) is not bool:
            raise ValueError('Capacité booléenne invalide.')
    text_field(payload['platform'], 'La plateforme', 100, True)


def _poll(n, registry, device, payload, epoch):
    _presence(payload)
    if device['machine_id'] != payload['machine_id']:
        raise PermissionError('Le jeton appartient à une autre machine.')
    semantic_change = _expire(registry, epoch)
    device['last_seen_at'] = _stamp(epoch)
    device['presence'] = {key: value for key, value in payload.items() if key not in ('request_id', 'machine_id')}
    response = {'device_id': device['id'], 'status': device['status'], 'work': None}
    if device['status'] != 'approved':
        _save(n, registry, revision=semantic_change)
        return response
    jobs = [row for row in registry['jobs'].values() if row['device_id'] == device['id']]
    current = next((row for row in jobs if row['status'] in ACTIVE), None)
    if current:
        if not _fresh(n, current):
            current.update(status='stale', finished_at=_stamp(epoch), reason='Le tampon a changé pendant l’expérience.')
            semantic_change = True
        elif current['request_id'] == payload['request_id']:
            response['work'] = _work(current)
        _save(n, registry, revision=semantic_change)
        return response
    if any(payload['request_id'] in row.get('claim_request_ids', []) for row in jobs):
        # A lost poll/report response must not turn a previous request into a
        # second experiment after the original lease reached a terminal state.
        _save(n, registry, revision=semantic_change)
        return response
    row = next((row for row in jobs if row['status'] in ('queued', 'verify_queued')), None)
    if not row:
        _save(n, registry, revision=semantic_change)
        return response
    if not _fresh(n, row):
        row.update(status='stale', finished_at=_stamp(epoch), reason='Le tampon a changé avant l’exécution.')
        _save(n, registry)
        return response
    if not all(payload[field] for field in ('git', 'python', 'clean')) or payload['repo_head'] is None:
        response['waiting_reason'] = 'La machine attend un dépôt Git propre et Python.'
    elif payload['repo_head'] != row['base_commit']:
        row.update(status='stale', finished_at=_stamp(epoch), reason='Le commit annoncé par la machine a changé.')
        semantic_change = True
    elif row['status'] == 'queued' and not payload['codex']:
        response['waiting_reason'] = 'Codex doit être disponible sur cette machine.'
    elif row['status'] == 'verify_queued' and not payload['allow_tests']:
        response['waiting_reason'] = 'L’exécution des tests attend aussi l’autorisation locale de cette machine.'
    else:
        phase = 'generate' if row['status'] == 'queued' else 'verify'
        budget = _budget(n, registry, epoch)
        if phase == 'generate' and (budget['runs_reserved'] >= budget['runs_limit'] or
                                   budget['seconds_reserved'] + GENERATE_SECONDS > budget['seconds_limit']):
            response['waiting_reason'] = 'Budget distribué du jour épuisé ; aucune exécution de remplacement.'
        else:
            row.update(status='running' if phase == 'generate' else 'verifying',
                       lease_id=secrets.token_hex(16), request_id=payload['request_id'],
                       lease_deadline=epoch + LEASE_SECONDS, started_at=_stamp(epoch))
            row.setdefault('claim_request_ids', []).append(payload['request_id'])
            if phase == 'generate':
                row.update(budget_day=_day(epoch), reserved_seconds=GENERATE_SECONDS)
            response['work'] = _work(row)
            semantic_change = True
    _save(n, registry, revision=semantic_change)
    return response


def _result(value, phase):
    _shape(value, RESULT_REQUIRED, RESULT_OPTIONAL)
    if type(value['ok']) is not bool or value['status'] not in {'review', 'failed', 'verified', 'interrupted'}:
        raise ValueError('Résultat d’expérience invalide.')
    if value['status'] == 'review' and phase != 'generate' or value['status'] == 'verified' and phase != 'verify':
        raise ValueError('Le résultat appartient à une autre étape.')
    if value['ok'] != (value['status'] in {'review', 'verified'}):
        raise ValueError('La réussite annoncée ne correspond pas au statut.')
    if not isinstance(value['patch'], str) or len(value['patch'].encode('utf-8')) > MAX_PATCH_BYTES:
        raise ValueError('Diff trop volumineux ou invalide ; il ne sera pas tronqué.')
    _match(value['patch_sha256'], SHA_RE, 'Empreinte du diff')
    if not hmac.compare_digest(_hash(value['patch']), value['patch_sha256']):
        raise ValueError('L’empreinte du diff ne correspond pas au candidat.')
    text_field(value['summary'], 'Le résumé', 4000)
    seconds = value['elapsed_seconds']
    if type(seconds) not in (int, float) or not math.isfinite(seconds) or seconds < 0 or seconds > LEASE_SECONDS:
        raise ValueError('Durée d’exécution invalide.')
    if 'candidate_commit' in value and value['candidate_commit'] is not None:
        _match(value['candidate_commit'], HEAD_RE, 'Commit du candidat')
    for key, limit in (('tests_summary', 4000), ('worker_version', 50)):
        if key in value:
            text_field(value[key], key, limit)
    return copy.deepcopy(value)


def _report(n, registry, device, payload, epoch):
    _shape(payload, {'id', 'phase', 'lease_id', 'result'})
    _match(payload['id'], ID_RE, 'Expérience')
    _match(payload['lease_id'], ID_RE, 'Bail')
    if payload['phase'] not in ('generate', 'verify'):
        raise ValueError('Étape d’expérience inconnue.')
    if device['status'] != 'approved':
        raise PermissionError('Approbation du propriétaire requise.')
    row = registry['jobs'].get(payload['id'])
    if not row or row['device_id'] != device['id'] or row['world_id'] != device['world_id']:
        raise PermissionError('Cette expérience n’appartient pas à la machine.')
    result = _result(payload['result'], payload['phase'])
    digest = _digest(payload)
    receipt = row['report_digests'].get(payload['phase'])
    if receipt:
        if not hmac.compare_digest(receipt, digest):
            raise ValueError('Un résultat différent a déjà été reçu ; aucune preuve écrasée.')
        return {'id': row['id'], 'status': row['status'], 'received': True, 'duplicate': True}
    if _expire(registry, epoch):
        _save(n, registry)
    expected = 'running' if payload['phase'] == 'generate' else 'verifying'
    if row['status'] != expected or row.get('lease_id') != payload['lease_id']:
        raise ValueError('Ce bail est terminé, annulé ou inconnu ; résultat non retenu.')
    if not _fresh(n, row):
        row.update(status='stale', finished_at=_stamp(epoch), reason='Le tampon a changé avant la réception du résultat.')
        _save(n, registry)
        raise ValueError('Le tampon a changé ; résultat périmé.')
    if (payload['phase'] == 'verify' and result['ok'] and
            not hmac.compare_digest(result['patch_sha256'], row['authorized_review_digest'])):
        raise ValueError('Les tests ne portent pas sur le candidat explicitement relu.')
    row['report_digests'][payload['phase']] = digest
    row['generation_result' if payload['phase'] == 'generate' else 'verification_result'] = result
    row.update(status=result['status'], reported_at=_stamp(epoch))
    if payload['phase'] == 'generate' and result['status'] == 'review':
        row['review_digest'] = result['patch_sha256']
    if result['status'] in TERMINAL:
        row['finished_at'] = _stamp(epoch)
    _save(n, registry)
    return {'id': row['id'], 'status': row['status'], 'received': True, 'duplicate': False}


def worker(n, action, payload, token=None):
    if action not in ('enrol', 'poll', 'report'):
        raise ValueError('Action de machine inconnue.')
    with n.LOCK:
        registry = _load(n)
        epoch = time.time()
        if action == 'enrol':
            return _enrol(n, registry, payload, epoch)
        device = _authenticate(registry, token)
        if action == 'poll':
            return _poll(n, registry, device, payload, epoch)
        return _report(n, registry, device, payload, epoch)
