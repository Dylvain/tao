"""Opt-in owner gateway behind private Tailscale Serve; no public listener.

Transport and pairing are separate from the local node's authority checks. This
module never configures Tailscale, opens a LAN port, retries a write, or calls AI.
"""
from __future__ import annotations

import hashlib
import http.client
import json
import os
import re
import secrets
import threading
import time
import urllib.parse
from http.cookies import SimpleCookie, CookieError
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SCHEMA = 'tao.mobile.v1'
COOKIE = '__Host-tao-mobile'
PAIR_TTL = 600
SESSION_TTL = 30 * 24 * 3600
MAX_SESSIONS = 8
MAX_BODY = 32768
MAX_RESPONSE = 8 * 1024 * 1024
MAX_HISTORY_BODY = 24 * 1024 * 1024
MAX_BACKUP_BODY = 18 * 1024 * 1024
_ACTIVE = {}


def _hash(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def _browser_html(data, local_token, browser_token):
    """Replace the exact local credential in legacy and modern HTML shells."""
    pairs = (
        ('const token=' + json.dumps(local_token) + ';',
         'const token=' + json.dumps(browser_token) + ';'),
        ('"token":' + json.dumps(local_token),
         '"token":' + json.dumps(browser_token)),
    )
    for original, replacement in pairs:
        data = data.replace(original.encode('utf-8'), replacement.encode('utf-8'))
    return data


def _valid_login(value):
    return isinstance(value, str) and 1 <= len(value) <= 320 and all(33 <= ord(c) <= 126 for c in value)


def _valid_label(value):
    return isinstance(value, str) and bool(value.strip()) and len(value) <= 80 and all(ord(c) >= 32 for c in value)


def _hex(value, length):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{' + str(length) + '}', value) is not None


def _timestamp(value):
    return type(value) is int and value > 0


def _origin(value):
    if not isinstance(value, str) or len(value) > 300:
        raise ValueError('Une origine HTTPS Tailscale est requise.')
    try:
        url = urllib.parse.urlsplit(value)
        hostname = url.hostname or ''
        port = url.port
        labels = hostname.split('.')
        if (url.scheme != 'https' or url.username or url.password or
                url.path not in ('', '/') or url.query or url.fragment or
                not hostname.endswith('.ts.net') or len(labels) < 3 or
                len(hostname) > 253 or port not in (None, 443, 8443) or
                any(not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', label) for label in labels)):
            raise ValueError
        host = hostname + (':8443' if port == 8443 else '')
        if value.strip() != value or '\\' in value:
            raise ValueError
        return 'https://' + host
    except (ValueError, TypeError):
        raise ValueError('Utiliser https://nom.reseau.ts.net, éventuellement sur le port 8443.') from None


def _load(n):
    row = n.load_json(n.ROOT / 'mobile.json')
    if row is None:
        return {'schema': SCHEMA, 'enabled': False, 'sessions': []}
    if not isinstance(row, dict) or row.get('schema') != SCHEMA or type(row.get('enabled')) is not bool:
        raise ValueError('Configuration mobile illisible ; accès refusé.')
    if row.get('enabled') or 'origin' in row:
        if (_origin(row.get('origin')) != row['origin'] or
                not _valid_login(row.get('owner_login')) or
                type(row.get('port')) is not int or not 1024 <= row['port'] <= 65535 or
                not _hex(row.get('generation'), 32)):
            raise ValueError('Configuration mobile invalide ; accès refusé.')
    if not isinstance(row.get('sessions'), list) or len(row['sessions']) > MAX_SESSIONS:
        raise ValueError('Sessions mobiles invalides ; accès refusé.')
    for session in row['sessions']:
        if (not isinstance(session, dict) or not _hex(session.get('id'), 16) or not _hex(session.get('hash'), 64) or
                not _valid_label(session.get('label')) or not _timestamp(session.get('created_at')) or
                not _timestamp(session.get('expires_at')) or session['expires_at'] <= session['created_at']):
            raise ValueError('Session mobile illisible ; accès refusé.')
    if 'pairing' in row:
        invitation = row['pairing']
        if (not isinstance(invitation, dict) or not _hex(invitation.get('hash'), 64) or
                not _valid_label(invitation.get('label')) or not _timestamp(invitation.get('expires_at'))):
            raise ValueError('Association mobile illisible ; accès refusé.')
    return row


def _fingerprint(row):
    return _hash(json.dumps({key: row.get(key) for key in ('origin', 'owner_login', 'port', 'generation')}, sort_keys=True))


def _save(n, row):
    n.atomic_json(n.ROOT / 'mobile.json', row)


def _sessions(row):
    now = time.time()
    return [session for session in row['sessions'] if session.get('expires_at', 0) > now]


def configure(n, origin, owner_login, port=8792):
    origin = _origin(origin)
    if not _valid_login(owner_login):
        raise ValueError('Indiquer le login Tailscale exact du propriétaire.')
    if type(port) is not int or not 1024 <= port <= 65535 or port == n.policy()['http_port']:
        raise ValueError('Choisir un port local distinct de Tao, entre 1024 et 65535.')
    with n.LOCK:
        previous = _load(n)
        unchanged = (previous.get('enabled') and previous.get('origin') == origin and
                     previous.get('owner_login') == owner_login and previous.get('port') == port)
        if not unchanged:
            _save(n, {'schema': SCHEMA, 'enabled': True, 'origin': origin, 'owner_login': owner_login,
                      'port': port, 'generation': secrets.token_hex(16), 'sessions': []})
        return status(n)


def status(n):
    with n.LOCK:
        row = _load(n)
        live = n.load_json(n.ROOT / 'mobile-listener.json', {})
        if not isinstance(live, dict):
            raise ValueError('État de la passerelle mobile illisible.')
        alive = bool(live.get('pid') and live.get('start') and n.proc_start(live['pid']) == live['start'])
        active = _ACTIVE.get(str(n.ROOT))
        in_process = bool(active and active[1].is_alive() and active[0].fingerprint == _fingerprint(row))
        running = in_process if active else (alive and live.get('fingerprint') == _fingerprint(row))
        return {'schema': SCHEMA, 'enabled': row['enabled'], 'running': bool(running and row['enabled']),
                'restart_required': bool(row['enabled'] and not running),
                'origin': row.get('origin'), 'owner_login': row.get('owner_login'), 'port': row.get('port'),
                'sessions': [{key: session[key] for key in ('id', 'label', 'created_at', 'expires_at')}
                             for session in _sessions(row)],
                'pairing_expires_at': row.get('pairing', {}).get('expires_at'),
                'serve_command': ('tailscale serve --bg --https=' + str(urllib.parse.urlsplit(row['origin']).port or 443) +
                                  ' http://127.0.0.1:' + str(row['port'])) if row.get('origin') else None,
                'network_setup': 'manual_private_tailscale_serve', 'offline_sync': False}


def pair(n, label='Mon téléphone'):
    if not _valid_label(label):
        raise ValueError('Donner un nom à cet appareil (80 caractères maximum).')
    with n.LOCK:
        row = _load(n)
        if not row['enabled']:
            raise ValueError('Configurer d’abord l’accès mobile.')
        row['sessions'] = _sessions(row)
        if len(row['sessions']) >= MAX_SESSIONS:
            raise ValueError('Huit appareils sont déjà associés ; révoquer un appareil avant de continuer.')
        code = secrets.token_urlsafe(32)
        expires = int(time.time()) + PAIR_TTL
        row['pairing'] = {'hash': _hash(code), 'label': label.strip(), 'expires_at': expires}
        _save(n, row)
        return {'code': code, 'expires_at': expires, 'origin': row['origin'], 'single_use': True,
                'message': 'Saisir ce code sur le téléphone. Il expire dans dix minutes et ne sera plus affiché.'}


def revoke(n, ident='all'):
    with n.LOCK:
        row = _load(n)
        if ident != 'all' and not any(session.get('id') == ident for session in row['sessions']):
            raise ValueError('Appareil associé introuvable.')
        row['sessions'] = [] if ident == 'all' else [s for s in row['sessions'] if s.get('id') != ident]
        # An unused pairing invitation must not survive revocation.
        row.pop('pairing', None)
        _save(n, row)
        return status(n)


def disable(n):
    with n.LOCK:
        row = _load(n)
        row.update(enabled=False, sessions=[])
        row.pop('pairing', None)
        _save(n, row)
        return status(n)


LOGIN = '''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Relier mon téléphone à Tao</title>
<style>
:root{color-scheme:light;--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47;--gold:#c79d67}
*{box-sizing:border-box}body{font:16px/1.6 system-ui,sans-serif;background:radial-gradient(circle at 88% -10%,#eee3d2,transparent 38%),var(--bg);color:var(--text);margin:0;padding:14px;min-height:100vh}main{max-width:480px;margin:7vh auto;padding:clamp(24px,5vw,42px);background:linear-gradient(145deg,var(--panel),#f8f5ee);border:1px solid var(--line);border-top:3px solid var(--gold);border-radius:20px;box-shadow:0 16px 42px rgba(39,55,47,.07)}
.brand{font:600 29px/1 ui-serif,Georgia,serif;letter-spacing:-.045em}.brand span{color:var(--gold)}.eyebrow{font-size:11px;letter-spacing:.15em;text-transform:uppercase;font-weight:700;color:var(--accent);margin-top:32px}h1{font:500 clamp(30px,6vw,43px)/1.16 ui-serif,Georgia,serif;letter-spacing:-.03em;margin:8px 0 15px}label{display:block;font-weight:600;margin:22px 0 6px}
input,button{font:inherit;width:100%;padding:12px 14px;margin:8px 0 12px;border-radius:9px;min-height:44px}input{background:var(--panel);border:1px solid #b9c7bc;color:var(--text)}button{background:var(--accent);color:#fff;border:1px solid var(--accent);font-weight:600;cursor:pointer}button:disabled{opacity:.55;cursor:not-allowed}p{overflow-wrap:anywhere;color:var(--muted)}#message:not(:empty){padding:12px 14px;background:#fff1e6;border:1px solid #dfb997;border-radius:9px;color:#613f2d}:focus-visible{outline:3px solid var(--accent);outline-offset:3px}@media(max-width:540px){main{margin:3vh auto;padding:24px 18px;border-radius:16px}}
</style>
<main><div class="brand">tao<span>.</span></div><p class="eyebrow">La porte de mon Tao</p><h1>Retrouver mon Tao</h1><p>Les mêmes discussions et les mêmes données que sur ton ordinateur.</p><form><label for="code">Code d’association créé sur ton ordinateur</label><input id="code" autocomplete="off" autocapitalize="none" spellcheck="false" maxlength="100" required><button>Relier cet appareil</button></form><p id="message" role="status"></p><p>Ton ordinateur doit rester allumé et connecté. Cet accès permet les mêmes actions que ton interface locale.</p></main>
<script>document.querySelector('form').onsubmit=async e=>{e.preventDefault();const button=document.querySelector('button');button.disabled=true;try{const r=await fetch('/mobile/pair',{method:'POST',headers:{'Content-Type':'application/json','X-Tao-Token':'pair'},body:JSON.stringify({code:document.querySelector('#code').value.trim()})});const result=await r.json();if(!r.ok)throw Error(result.error||'Association refusée');location.href='/'}catch(err){document.querySelector('#message').textContent=err.message;button.disabled=false}};</script></html>'''


class MobileServer(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 16

    def __init__(self, address, n, config):
        self.node = n
        self.fingerprint = _fingerprint(config)
        self.origin = config['origin']
        self.owner = config['owner_login']
        self.upstream_port = n.policy()['http_port']
        self.slots = threading.BoundedSemaphore(16)
        super().__init__(address, MobileHandler)

    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self.slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()

    def handle_error(self, request, client_address):
        # Do not log headers, request targets, credentials, or private responses.
        pass


class MobileHandler(BaseHTTPRequestHandler):
    server_version = 'Tao'
    sys_version = ''

    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, *args):
        pass

    def send_body(self, status, body, content_type='application/json; charset=utf-8', cookie=None):
        self.send_response(status)
        for name, value in [('Content-Type', content_type), ('Content-Length', str(len(body))),
                            ('Cache-Control', 'no-store'), ('X-Content-Type-Options', 'nosniff'),
                            ('Referrer-Policy', 'no-referrer'), ('X-Frame-Options', 'DENY'),
                            ('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")]:
            self.send_header(name, value)
        if cookie:
            self.send_header('Set-Cookie', cookie)
        self.end_headers()
        self.wfile.write(body)

    def json(self, status, obj, cookie=None):
        self.send_body(status, json.dumps(obj, ensure_ascii=False).encode(), cookie=cookie)

    def error(self, status, text):
        self.json(status, dict(error=text, **({'login_url': '/mobile/login'} if status == 401 else {})))

    def one_header(self, name):
        values = self.headers.get_all(name, [])
        return values[0] if len(values) == 1 else None

    def boundary(self):
        if (self.one_header('Host') != self.server.origin.removeprefix('https://') or
                self.one_header('Tailscale-User-Login') != self.server.owner):
            self.error(403, 'Accès privé refusé.')
            return None
        if (not self.path.startswith('/') or self.path.startswith('//') or '\\' in self.path or
                len(self.path) > 4096 or '#' in self.path):
            self.error(400, 'Chemin invalide.')
            return None
        with self.server.node.LOCK:
            row = _load(self.server.node)
            if not row['enabled'] or _fingerprint(row) != self.server.fingerprint:
                self.error(503, 'Accès mobile désactivé ou configuration à redémarrer.')
                return None
            return row

    def session(self, row):
        raw = self.one_header('Cookie')
        if not raw or len(raw) > 4096:
            return None
        try:
            # Duplicate cookie names are ambiguous; reject them before parsing.
            if sum(piece.strip().startswith(COOKIE + '=') for piece in raw.split(';')) != 1:
                return None
            cookies = SimpleCookie(); cookies.load(raw)
            token = cookies[COOKIE].value if COOKIE in cookies else ''
            if not re.fullmatch(r'[A-Za-z0-9_-]{43}', token):
                return None
            hashed = _hash(token)
            return next((s for s in _sessions(row) if secrets.compare_digest(s.get('hash', ''), hashed)), None)
        except CookieError:
            return None

    def do_GET(self):
        try:
            row = self.boundary()
            if row is None:
                return
            if self.path == '/mobile/login':
                return self.send_body(200, LOGIN.encode(), 'text/html; charset=utf-8')
            if not self.session(row):
                if urllib.parse.urlsplit(self.path).path == '/':
                    return self.send_body(200, LOGIN.encode(), 'text/html; charset=utf-8')
                return self.error(401, 'Associer cet appareil depuis la page d’accueil de Tao.')
            if urllib.parse.urlsplit(self.path).path.startswith('/mobile'):
                return self.error(404, 'Page introuvable.')
            self.forward()
        except (ValueError, TypeError, RuntimeError, OSError):
            self.error(503, 'Accès mobile indisponible ; vérifier le service sur l’ordinateur.')

    def read_body(self):
        length = self.one_header('Content-Length')
        if self.headers.get_all('Transfer-Encoding') or length is None or not re.fullmatch(r'[0-9]{1,8}', length):
            self.error(400, 'Longueur de requête invalide.')
            return None
        length = int(length)
        path = urllib.parse.urlsplit(self.path).path
        maximum = (MAX_BACKUP_BODY if path.startswith('/api/backup/') else
                   MAX_HISTORY_BODY if path.startswith(('/api/onboarding/', '/api/history/')) else
                   (262144 if path == '/api/dialogue/handoff' or path.startswith(('/api/reuse/', '/api/bridge/', '/api/connectors/')) else MAX_BODY))
        if not 1 <= length <= maximum:
            self.error(413, 'Requête trop grande ou vide.')
            return None
        if (self.one_header('Content-Type') or '').split(';', 1)[0].strip().lower() != 'application/json':
            self.error(415, 'Objet JSON requis.')
            return None
        body = self.rfile.read(length)
        if len(body) != length:
            self.error(400, 'Requête incomplète.')
            return None
        try:
            value = json.loads(body)
        except (ValueError, UnicodeError):
            self.error(400, 'Objet JSON illisible.')
            return None
        if not isinstance(value, dict):
            self.error(400, 'Objet JSON requis.')
            return None
        return body, value

    def do_POST(self):
        try:
            row = self.boundary()
            if row is None:
                return
            if (self.one_header('Origin') != self.server.origin or
                    not self.one_header('X-Tao-Token') or len(self.one_header('X-Tao-Token')) > 256):
                return self.error(403, 'Origine ou protection de session refusée.')
            path = urllib.parse.urlsplit(self.path).path
            is_pair = self.path == '/mobile/pair'
            session = self.session(row)
            if not is_pair and not session:
                return self.error(401, 'Session mobile expirée ou révoquée.')
            if path == '/api/stop' or (path.startswith('/mobile') and not is_pair):
                return self.error(403, 'Cette action reste accessible depuis l’ordinateur.')
            content = self.read_body()
            if content is None:
                return
            body, value = content
            if is_pair:
                return self.consume_pair(value)
            self.forward(body)
        except (ValueError, TypeError, RuntimeError, OSError):
            self.error(503, 'Requête refusée ou ordinateur momentanément indisponible.')

    def consume_pair(self, value):
        code = value.get('code')
        if set(value) != {'code'} or not isinstance(code, str) or not re.fullmatch(r'[A-Za-z0-9_-]{43}', code):
            return self.error(403, 'Code invalide ou expiré.')
        n = self.server.node
        with n.LOCK:
            row = _load(n)
            invitation = row.get('pairing', {})
            if (not row['enabled'] or _fingerprint(row) != self.server.fingerprint or
                    invitation.get('expires_at', 0) <= time.time() or
                    not secrets.compare_digest(invitation.get('hash', ''), _hash(code))):
                return self.error(403, 'Code invalide ou expiré.')
            row['sessions'] = _sessions(row)
            if len(row['sessions']) >= MAX_SESSIONS:
                return self.error(409, 'Nombre maximal d’appareils atteint.')
            token = secrets.token_urlsafe(32)
            now = int(time.time())
            row['sessions'].append({'id': secrets.token_hex(8), 'label': invitation['label'],
                                    'hash': _hash(token), 'created_at': now, 'expires_at': now + SESSION_TTL})
            row.pop('pairing', None)
            _save(n, row)
        self.json(200, {'ok': True}, cookie=f'{COOKIE}={token}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}')

    def forward(self, body=None):
        n = self.server.node
        # Recheck revocation immediately before forwarding, without holding the
        # node lock across HTTP (the upstream needs the same lock).
        with n.LOCK:
            row = _load(n)
            if not row['enabled'] or _fingerprint(row) != self.server.fingerprint or not self.session(row):
                return self.error(401, 'Session mobile expirée ou révoquée.')
            local = n.load_json(n.ROOT / 'session.json', {})
        if (local.get('port') != self.server.upstream_port or not isinstance(local.get('token'), str) or
                not local['token'] or len(local['token']) > 256):
            return self.error(503, 'Tao redémarre ou attend son démarrage sur l’ordinateur.')
        host = '127.0.0.1:' + str(self.server.upstream_port)
        headers = {'Host': host}
        if body is not None:
            headers.update({'Content-Type': 'application/json', 'Origin': 'http://' + host,
                            'X-Tao-Token': local['token']})
        long_tool = body is not None and urllib.parse.urlsplit(self.path).path in {'/api/connectors/inspect', '/api/connectors/execute'}
        connection = http.client.HTTPConnection('127.0.0.1', self.server.upstream_port, timeout=40 if long_tool else 10)
        try:
            connection.request('POST' if body is not None else 'GET', self.path, body=body, headers=headers)
            response = connection.getresponse()
            path = urllib.parse.urlsplit(self.path).path
            maximum = (MAX_BACKUP_BODY if path.startswith('/api/backup/') else
                       34 * 1024 * 1024 if path == '/api/history/archive' else MAX_RESPONSE)
            data = response.read(maximum + 1)
            if len(data) > maximum:
                return self.error(502, 'Réponse trop grande ; consulter cette donnée sur l’ordinateur.')
            if 300 <= response.status < 400:
                return self.error(502, 'Redirection locale refusée.')
            content_type = response.getheader('Content-Type', 'application/octet-stream')
            if content_type.split(';', 1)[0].strip().lower() == 'text/html':
                # The phone is authorized by its paired cookie and exact
                # Origin, never by the node credential used only upstream.
                data = _browser_html(data, local['token'], secrets.token_urlsafe(32))
            if local['token'].encode('utf-8') in data:
                return self.error(502, 'La réponse locale nécessite une adaptation avant de pouvoir être exposée.')
            self.send_body(response.status, data, content_type)
        except (http.client.HTTPException, OSError):
            message = ('La connexion a été interrompue. Le résultat de cette action est inconnu ; recharger et vérifier son état avant de la relancer.'
                       if body is not None else 'Tao est momentanément indisponible ou redémarre. Réessayer dans quelques secondes.')
            self.error(503, message)
        finally:
            connection.close()


def start(n):
    with n.LOCK:
        row = _load(n)
        if not row['enabled']:
            return None
        server = MobileServer(('127.0.0.1', row['port']), n, row)
        thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .1}, daemon=True)
        try:
            n.atomic_json(n.ROOT / 'mobile-listener.json', {'pid': os.getpid(), 'start': n.proc_start(os.getpid()),
                          'port': row['port'], 'fingerprint': server.fingerprint})
            thread.start()
        except BaseException:
            server.server_close()
            try:
                live = n.load_json(n.ROOT / 'mobile-listener.json', {})
                if live.get('pid') == os.getpid() and live.get('fingerprint') == server.fingerprint:
                    (n.ROOT / 'mobile-listener.json').unlink(missing_ok=True)
            except (ValueError, RuntimeError, OSError, AttributeError):
                pass
            raise
        handle = (server, thread)
        _ACTIVE[str(n.ROOT)] = handle
        return handle


def stop(handle):
    if handle is None:
        return
    server, thread = handle
    server.shutdown(); thread.join(timeout=3); server.server_close()
    n = server.node
    with n.LOCK:
        live = n.load_json(n.ROOT / 'mobile-listener.json', {})
        if live.get('pid') == os.getpid() and live.get('fingerprint') == server.fingerprint:
            (n.ROOT / 'mobile-listener.json').unlink(missing_ok=True)
        _ACTIVE.pop(str(n.ROOT), None)
