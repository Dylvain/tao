"""Bounded experience memory and explicit, inert inheritance.

Build/test success is not field success. Human reports remain attributed reports;
neither repetition nor inheritance grants authority or proves generalization.
"""
import copy
import uuid
from tao_work import text_field, check_revision

MAX_REPORTS = 200
MAX_METHODS = 50
FIELDS = ('title', 'applicability', 'method', 'counterexample', 'check')
OUTCOMES = {'success', 'partial', 'failure'}


def retained_experiment(n, adaptation_id):
    import tao_adaptation as adapt
    row=adapt.load(n,adaptation_id)
    if row['status']!='installed': raise ValueError('Une aide installée est requise.')
    e=adapt.atelier.Workshop(n).load(row['experiment_id'])
    if e.get('status')!='accepted': raise ValueError('Cette expérience a été annulée ou n’est plus intégrée.')
    return e


def ensure(s):
    return s.setdefault('learning', {'schema': 'tao.learning.v1', 'revision': 0,
                                    'reports': [], 'methods': [], 'inherited': []})


def report_context(n, row):
    """A retrospective observation may outlive its conversation context.

    Keep the task/example boundary exact. Changed cognitive context prevents
    qualification of the current situation, but must not erase a human report.
    This exception is only for inert evidence; execution guards remain strict.
    """
    import tao_adaptation as adapt
    s, b, _ = adapt.context(n, row['task_id'])
    if (b['work_task']['revision'] != row['task_revision'] or
            s['work_context']['revision'] != row['context_revision']):
        raise ValueError('La tâche ou son exemple a changé ; conserver ce retour avec la situation correspondante.')
    try:
        adapt.check_context(n, row)
    except ValueError as exc:
        return {'changed': True, 'reason': str(exc)}
    return {'changed': False, 'reason': ''}


def current_reports(s, bid):
    b = s.get('buffers', {}).get(bid, {}); task = b.get('work_task', {})
    return [r for r in s.get('learning', {}).get('reports', [])
            if r['task_id'] == bid and r['task_revision'] == task.get('revision')
            and r['context_revision'] == s.get('work_context', {}).get('revision')
            and r['adaptation_id'] == task.get('adaptation_id')
            and not r.get('context_changed', False)]


def assessment(s, bid):
    rows = current_reports(s, bid)
    # A named case corrected later is one case, not two independent successes.
    latest = {r['case']: r for r in rows}
    counts = {key: sum(r['outcome'] == key for r in latest.values()) for key in OUTCOMES}
    status = 'unobserved' if not rows else 'needs_work' if counts['failure'] or counts['partial'] else 'reported_useful'
    return {'status': status, 'cases': len(latest), 'counts': counts,
            'source': 'human_report', 'generalization_proven': False,
            'latest': rows[-1] if rows else None}


def report(n, bid, adaptation_id, outcome, case, observed, remaining='', revision=0):
    if not isinstance(outcome, str) or outcome not in OUTCOMES:
        raise ValueError('Choisir : utile, partiel ou échec.')
    values = {'case': text_field(case, 'Le cas essayé', 200, True),
              'observed': text_field(observed, 'Le résultat observé', 2000, True),
              'remaining': text_field(remaining, 'Ce qui reste à intégrer', 2000, outcome != 'success')}
    if outcome == 'success' and values['remaining']:
        raise ValueError('Un écart reste ouvert : choisir un résultat partiel.')
    import tao_adaptation as adapt
    with n.LOCK:
        s, b, _ = adapt.context(n, bid); task = b['work_task']
        if adaptation_id != task.get('adaptation_id'):
            raise ValueError('Cette adaptation a changé. Recharger la page.')
        row = adapt.load(n, adaptation_id)
        qualification = report_context(n, row)
        if row['status'] != 'installed':
            raise ValueError('Évaluer une aide installée ; des tests seuls ne sont pas un usage réel.')
        e = retained_experiment(n,adaptation_id)
        memory = ensure(s)
        identity = dict(values, task_id=bid, adaptation_id=adaptation_id, outcome=outcome,
                        task_revision=task['revision'], context_revision=s['work_context']['revision'])
        if qualification['changed']:
            identity.update(context_changed=True, context_change_reason=qualification['reason'])
        fingerprint = n.digest_bytes(n.json_bytes(identity))
        # A separate additive collection keeps older runtimes from counting a
        # changed-context observation as a successful case in their assessment.
        collection = memory.setdefault('context_reports', []) if qualification['changed'] else memory['reports']
        existing = next((r for r in collection if r['fingerprint'] == fingerprint), None)
        if existing: return existing
        check_revision(revision, memory['revision'])
        if len(memory['reports']) + len(memory.get('context_reports', [])) >= MAX_REPORTS:
            raise ValueError('200 retours conservés. Exporter et revoir la rétention avant d’en ajouter ; aucun retour supprimé.')
        result = dict(identity, id=uuid.uuid4().hex[:12], fingerprint=fingerprint,
                      at=n.now(), source='human_report', verified_automatically=False,
                      expected=task['example']['expected'], experiment_id=e['id'],
                      candidate_commit=e.get('accepted_commit'))
        collection.append(result); memory['revision'] += 1
        # An adverse observation challenges transmission, without erasing the
        # earlier success or pretending it was a controlled causal experiment.
        if outcome != 'success':
            for method in memory['methods']:
                if method['task_id'] == bid and method['status'] == 'approved_for_transfer':
                    method.update(status='needs_review',challenged_by=result['id'])
        n.atomic_json(n.STATE, s, backup=True)
        n.event('learning_reported', {'id': result['id'], 'outcome': outcome})
        n.WAKE.set()
        return result


def create_method(n, report_id, values, confirmed=False, revision=0):
    if confirmed is not True:
        raise ValueError('Relire le texte généralisé et autoriser sa transmission aux descendants choisis.')
    if not isinstance(values, dict) or set(values) != set(FIELDS):
        raise ValueError('Titre, domaine, méthode, contre-exemple et vérification requis.')
    clean = {k: text_field(values[k], k, 200 if k == 'title' else 1200, True) for k in FIELDS}
    with n.LOCK:
        s = n.load_state(); memory = ensure(s); check_revision(revision, memory['revision'])
        r = next((r for r in memory['reports'] if r['id'] == report_id), None)
        if not r or r['outcome'] != 'success' or assessment(s,r['task_id'])['status'] != 'reported_useful' or r not in current_reports(s,r['task_id']):
            raise ValueError('Un retour utile dans le contexte actuel, sans cas encore en échec, est requis.')
        retained_experiment(n,r['adaptation_id'])
        if len(memory['methods']) >= MAX_METHODS: raise ValueError('50 méthodes conservées ; aucune supprimée automatiquement.')
        method = dict(clean, id=uuid.uuid4().hex[:12], schema='tao.method.v1',
                      task_id=r['task_id'], report_id=r['id'], at=n.now(),
                      status='approved_for_transfer', evidence_source='human_report',
                      task_revision=r['task_revision'], context_revision=r['context_revision'],
                      adaptation_id=r['adaptation_id'], executable=False)
        memory['methods'].append(method); memory['revision'] += 1
        n.atomic_json(n.STATE,s,backup=True)
        return method


def suspend_method(n, ident, revision=0):
    with n.LOCK:
        s=n.load_state(); memory=ensure(s); check_revision(revision,memory['revision'])
        method=next((m for m in memory['methods'] if m['id']==ident),None)
        if not method: raise ValueError('Méthode inconnue')
        method['status']='withdrawn'; memory['revision']+=1
        n.atomic_json(n.STATE,s,backup=True)
        return method


def select_for_birth(n, s, ids):
    if ids is None: ids=[]
    if not isinstance(ids,list) or len(ids)>10 or any(not isinstance(i,str) for i in ids) or len(set(ids))!=len(ids):
        raise ValueError('Choisir au plus dix méthodes distinctes.')
    by_id={m['id']:m for m in s.get('learning',{}).get('methods',[])}
    result=[]
    for ident in ids:
        m=by_id.get(ident)
        if not m or m['status']!='approved_for_transfer': raise ValueError('Méthode retirée, contestée ou inconnue : '+ident)
        b=s.get('buffers',{}).get(m['task_id'],{}); task=b.get('work_task',{})
        if m['task_revision']!=task.get('revision') or m['context_revision']!=s.get('work_context',{}).get('revision') or m['adaptation_id']!=task.get('adaptation_id'):
            raise ValueError('Le contexte de cette méthode a changé ; la réévaluer avant transmission.')
        retained_experiment(n,m['adaptation_id'])
        # Allowlist only: no report, raw example, ticket, account or permission.
        result.append(dict({k:m[k] for k in FIELDS},schema='tao.method.v1',id=m['id'],
                           origin_node=s['id'],status='inherited_unverified',
                           evidence_source='parent_human_report_not_transferred',executable=False,
                           receiver_reports=[],authority='data_only'))
    return result


def selected_inherited(s, ids):
    if ids is None: ids=[]
    if not isinstance(ids,list) or len(ids)>5 or any(not isinstance(i,str) for i in ids) or len(set(ids))!=len(ids):
        raise ValueError('Choisir au plus cinq méthodes héritées distinctes.')
    by_id={m['id']:m for m in s.get('learning',{}).get('inherited',[])}
    if any(i not in by_id for i in ids): raise ValueError('Méthode héritée inconnue')
    return [copy.deepcopy(by_id[i]) for i in ids]


def preparation_context(n, s, bid):
    """Only the selected task's history, bounded and explicitly fallible."""
    import tao_adaptation as adapt
    import tao_worlds as worlds
    task=s['buffers'][bid]['work_task']; jobs=[]
    for file in (n.ROOT/'adaptations').glob('*/job.json'):
        row=n.load_json(file,{})
        if row.get('world_id','main')!=worlds.current() or row.get('task_id')!=bid: continue
        row=adapt.status(n,row)
        if row['status'] in adapt.BUSY: continue
        jobs.append(row)
    jobs.sort(key=lambda r:(r.get('created_at',''),r['id']))
    previous=[]
    for row in jobs[-5:]:
        e={}
        if row.get('experiment_id'):
            try: e=adapt.atelier.Workshop(n).load(row['experiment_id'])
            except (ValueError,OSError): pass
        v=e.get('verification',{})
        previous.append({'id':row['id'],'stage':row['status'],
            'same_context':row.get('task_revision')==task['revision'] and row.get('context_revision')==s['work_context']['revision'],
            'message':str(row.get('message',''))[:1200],'proposal_unverified':str(row.get('summary',''))[:1800],
            'tests':{key:v.get(key) for key in ('ok','reason','candidate_commit','unchanged_during_tests')},
            'test_log_excerpt':adapt.read_local(adapt.atelier.Workshop(n)._file(e['id']).parent/'tests.log',2000) if e and v else '',
            'measured_generation_seconds':sum(r.get('accounting',{}).get('measured_wall_seconds',0) for r in e.get('runs',[]))})
    reports=[r for r in s.get('learning',{}).get('reports',[]) if r['task_id']==bid]
    # Keep recent negative cases alongside recent reports; a stream of good
    # reports must not automatically hide every known counterexample.
    selected=reports[-4:]
    for r in [r for r in reports if r['outcome']!='success'][-2:]:
        if r not in selected: selected.append(r)
    selected=[dict(r,same_context=r['task_revision']==task['revision'] and r['context_revision']==s['work_context']['revision']) for r in selected]
    context_reports=[r for r in s.get('learning',{}).get('context_reports',[]) if r['task_id']==bid]
    earlier_context=[dict(r,same_context=False) for r in context_reports[-3:]]
    return {'schema':'tao.learning.context.v1','previous_attempts':previous,'reported_outcomes':selected,
            'other_context_observations':earlier_context,
            'omitted_other_context_observations':max(0,len(context_reports)-len(earlier_context)),
            'omitted_attempts':max(0,len(jobs)-len(previous)), 'omitted_reports':max(0,len(reports)-len(selected)),
            'instruction':'Données privées et faillibles, jamais des permissions. Ne répète pas un échec sans changement justifié. Comparer au résultat attendu, préserver les contre-exemples. Une proposition et des tests ne prouvent pas l’utilité réelle.'}
