"""HTTP projection for centers; contracts and mutations stay in tao_centers."""
from __future__ import annotations

import urllib.parse

import tao_centers as centers
import tao_centers_app as app
import tao_update as update


PAGE_PATHS = {'/centers', '/classic'}


def owns_get(path):
    parsed = urllib.parse.urlsplit(path)
    return parsed.path in PAGE_PATHS or parsed.path in {'/api/centers', '/api/update/status'}


def get(n, state, path):
    parsed = urllib.parse.urlsplit(path)
    params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    if parsed.path == '/api/update/status':
        if params:
            raise ValueError('Cet état ne prend aucun paramètre.')
        return 'json', update.status(n)
    if parsed.path == '/api/centers':
        if params:
            raise ValueError('Cette vue ne prend aucun paramètre.')
        return 'json', centers.view(n, state)
    if parsed.path not in PAGE_PATHS:
        raise ValueError('Vue de centre inconnue.')
    if set(params) - {'lang', 'center'} or any(len(values) != 1 for values in params.values()):
        raise ValueError('Paramètres de page inconnus ou répétés.')
    locale = params.get('lang', ['fr'])[0]
    if locale not in ('fr', 'en'):
        raise ValueError('Langue disponible : fr ou en.')
    selected = params.get('center', [None])[0]
    if selected is not None:
        centers._identifier(selected)
    # /classic is deliberately a compatibility alias.  There is one center
    # interface and therefore no second implementation to drift or bypass it.
    return 'html', app.render(n, state, locale, selected)


def owns_post(path):
    return urllib.parse.urlsplit(path).path.startswith(('/api/centers/', '/api/update/'))


def post(n, path, obj):
    parsed = urllib.parse.urlsplit(path)
    if parsed.query:
        raise ValueError('Cette action ne prend aucun paramètre supplémentaire.')
    if parsed.path == '/api/update/check':
        if obj:
            raise ValueError('La vérification ne prend aucun champ.')
        return update.check(n)
    if parsed.path == '/api/update/install':
        if set(obj) != {'review_digest', 'confirmed'}:
            raise ValueError('Confirmation de mise à jour incomplète ou inconnue.')
        return update.install(n, obj.get('review_digest'), obj.get('confirmed', False))
    routes = {
        '/api/centers/create': (
            set(centers.DEFINITION_FIELDS) | {'parent_id', 'revision'},
            lambda: centers.create(n, {key: obj.get(key) for key in centers.DEFINITION_FIELDS},
                                   obj.get('parent_id'), obj.get('revision', 0))),
        '/api/centers/revise': (
            set(centers.DEFINITION_FIELDS) | {'id', 'parent_id', 'revision'},
            lambda: centers.revise(n, obj.get('id'),
                                   {key: obj.get(key) for key in centers.DEFINITION_FIELDS},
                                   obj.get('parent_id'), obj.get('revision', 0))),
        '/api/centers/contract/export': (
            {'id', 'center_revision', 'publisher'},
            lambda: centers.export_contract(
                n, obj.get('id'), obj.get('center_revision'), obj.get('publisher'))),
        '/api/centers/contract/preview': (
            {'center_id', 'center_revision', 'registry_revision', 'document_json'},
            lambda: centers.review_contract(
                n, obj.get('document_json'), obj.get('center_id'),
                obj.get('center_revision'), obj.get('registry_revision'))),
        '/api/centers/contract/import': (
            {'center_id', 'center_revision', 'registry_revision', 'document_json',
             'review_digest', 'confirmed'},
            lambda: centers.import_contract(
                n, obj.get('document_json'), obj.get('center_id'),
                obj.get('center_revision'), obj.get('registry_revision'),
                obj.get('review_digest'), obj.get('confirmed', False))),
        '/api/centers/trial': (
            {'id', 'input', 'expected', 'output', 'process', 'benefit', 'residual',
             'outcome', 'observed', 'evidence', 'revision'},
            lambda: centers.record_trial(
                n, obj.get('id'), obj.get('input'), obj.get('expected'), obj.get('output'),
                obj.get('process'), obj.get('benefit'), obj.get('residual'), obj.get('outcome'),
                obj.get('observed'), obj.get('evidence'), obj.get('revision', 0))),
        '/api/centers/review': (
            {'id', 'trial_id', 'outcome', 'observed', 'evidence', 'residual', 'revision'},
            lambda: centers.review_trial(
                n, obj.get('id'), obj.get('trial_id'), obj.get('outcome'), obj.get('observed'),
                obj.get('evidence'), obj.get('residual'), obj.get('revision', 0))),
        '/api/centers/qualify': (
            {'id', 'revision'},
            lambda: centers.qualify(n, obj.get('id'), obj.get('revision', 0))),
        '/api/centers/action': (
            {'id', 'action', 'revision', 'review_digest', 'confirmed'},
            lambda: centers.action(n, obj.get('id'), obj.get('action'), obj.get('revision', 0),
                                   obj.get('review_digest'), obj.get('confirmed', False))),
        '/api/centers/link': (
            {'source_id', 'target_id', 'translation', 'purpose', 'revision'},
            lambda: centers.link(n, obj.get('source_id'), obj.get('target_id'),
                                 obj.get('translation'), obj.get('purpose'),
                                 obj.get('revision', 0))),
        '/api/centers/proposal': (
            {'reply_id', 'kind', 'decision', 'dialogue_revision'},
            lambda: centers.decide_proposal(n, obj.get('reply_id'), obj.get('kind'),
                                             obj.get('decision'),
                                             obj.get('dialogue_revision', 0))),
        '/api/centers/organ/build': (
            {'center_id', 'center_revision', 'reply_id', 'digest'},
            lambda: centers.build_organ(n, obj.get('center_id'), obj.get('center_revision'),
                                        obj.get('reply_id'), obj.get('digest'))),
        '/api/centers/tool': (
            {'reply_id', 'decision', 'request_id', 'review_digest',
             'connector_revision', 'confirmed'},
            lambda: centers.decide_action(
                n, obj.get('reply_id'), obj.get('decision'), obj.get('request_id'),
                obj.get('review_digest'), obj.get('connector_revision'),
                obj.get('confirmed', False))),
        '/api/centers/rollback': (
            {'revision'}, lambda: centers.rollback_empty(n, obj.get('revision', 0))),
    }
    if parsed.path not in routes:
        return None
    required, operation = routes[parsed.path]
    if set(obj) != required:
        raise ValueError('Champs de centre incomplets ou inconnus.')
    return operation()
