"""Single inventory of the files composing a Tao runtime.

The groups document responsibilities; they are not independently installable
packages.  A descendant inherits the same ordered inventory and the installer
copies it verbatim.  Keeping this list here prevents installation, birth and
verification from silently describing different Tao bodies.
"""
from __future__ import annotations


KERNEL_FILES = (
    'tao_runtime.py',
    'tao_node.py',
    'tao_theory.py',
    'tao_work.py',
    'tao_continuity.py',
    'tao_worlds.py',
    'tao_centers.py',
    'tao_backup.py',
    'tao_ecology.py',
)

INTELLIGENCE_FILES = (
    'tao_dialogue.py',
    'tao_routing.py',
    'tao_learning.py',
)

EVOLUTION_FILES = (
    'tao_workshop.py',
    'tao_adaptation.py',
    'tao_update.py',
)

CAPABILITY_FILES = (
    'tao_reuse.py',
    'tao_bridge.py',
    'tao_connectors.py',
    'tao_tools.py',
    'tao_devices.py',
    'tao_device_worker.py',
    'tao_mobile.py',
    'tao_handoff.py',
    'tao_host.py',
    'tao_host_ai.py',
)

PROJECTION_FILES = (
    'tao_centers_app.py',
    'tao_centers_routes.py',
    'tao_ui.py',
    'tao_home_ui.py',
    'tao_navigation_ui.py',
    'tao_connection_ui.py',
    'tao_guide_ui.py',
    'tao_trends_ui.py',
    'tao_devices_ui.py',
    'tao_tools_ui.py',
    'tao_onboarding.py',
    'tao_onboarding_ui.py',
    'tao_onboarding_routes.py',
    'tao_history_archive.py',
    'tao_history_store.py',
    'tao_foundations.py',
    'tao_landmarks.py',
    'tao_integrability.py',
    'tao_workspace_routes.py',
    'tao_logic.py',
)

RUNTIME_FILES = KERNEL_FILES + INTELLIGENCE_FILES + EVOLUTION_FILES + CAPABILITY_FILES + PROJECTION_FILES
RUNTIME_ASSETS = (
    'tao-center.js',
    'tao-center.css',
    'tao.webmanifest',
    'tao-icon.svg',
    'tao-icon-192.png',
    'tao-icon-512.png',
)

if len(RUNTIME_FILES) != len(set(RUNTIME_FILES)):
    raise RuntimeError('La composition du runtime Tao contient un doublon.')
