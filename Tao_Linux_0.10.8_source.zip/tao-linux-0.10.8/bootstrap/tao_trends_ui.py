"""An empty, explicit calculator for discrete changes, without forecasts."""
import html
import json
from urllib.parse import quote


WORDS = {
 'fr': {'title':'Comprendre une tendance', 'back':'Mes espaces',
 'intro':'Comparer une situation, son évolution et la variation de cette évolution aux limites que tu déclares.',
 'quantity':'Que mesures-tu ?', 'unit':'Dans quelle unité ?',
 'samples':'Tes mesures : jour écoulé ; valeur, une mesure par ligne',
 'sample_help':'Le premier jour peut être 0. Les jours doivent augmenter. Exemple de format seulement : 0 ; 120. Utilise un point pour les décimales. Une même série garde une seule unité ou devise.',
 'limits':'Quelles limites veux-tu examiner ?', 'min':'Valeur minimale', 'max':'Valeur maximale',
 'rate':'Variation maximale en valeur absolue, par jour',
 'acceleration':'Variation maximale de la tendance, par jour²',
 'reference':'Pourquoi ces limites ? (facultatif)',
 'unknown':'Un champ laissé vide reste inconnu. Ces limites sont tes hypothèses, pas des capacités humaines mesurées.',
 'run':'Examiner mes mesures', 'result':'Ce que montrent les mesures',
 'scope':'Ce calcul examine seulement les points fournis. Il ne prédit pas l’avenir ni ce qui s’est passé entre les mesures. Il ne déclenche aucune action et n’enregistre pas les valeurs.',
 'state':'Situation', 'trend':'Tendance', 'trend_change':'Variation de tendance',
 'within_model_bounds':'Dans les limites déclarées sur les mesures disponibles',
 'exceeds':'Une limite déclarée est dépassée', 'insufficient_data':'Pas assez de mesures',
 'status_unknown':'Limites non définies', 'range':'Valeurs observées',
 'error':'Vérifie la série et les limites.', 'day':'jour', 'from':'de', 'to':'à',
 'notation':'État : unité ; tendance : unité/jour ; variation de tendance : unité/jour².',
 'count':'mesure(s)', 'invalid':'Chaque ligne doit contenir un jour et une valeur numériques séparés par un point-virgule.'},
 'en': {'title':'Understand a trend', 'back':'My spaces',
 'intro':'Compare a situation, its change and the change of that trend with bounds you declare.',
 'quantity':'What are you measuring?', 'unit':'In which unit?',
 'samples':'Your measurements: elapsed day ; value, one per line',
 'sample_help':'The first day may be 0. Days must increase. Format example only: 0 ; 120. Use a decimal point. A series must use one unit or currency.',
 'limits':'Which bounds do you want to examine?', 'min':'Minimum value', 'max':'Maximum value',
 'rate':'Maximum absolute change per day', 'acceleration':'Maximum absolute trend change per day²',
 'reference':'Why these bounds? (optional)',
 'unknown':'An empty field stays unknown. These bounds are your hypotheses, not measured human capacities.',
 'run':'Examine my measurements', 'result':'What the measurements show',
 'scope':'This calculation only examines the supplied points. It predicts neither the future nor what happened between samples. It performs no action and does not store the values.',
 'state':'Situation', 'trend':'Trend', 'trend_change':'Trend change',
 'within_model_bounds':'Within declared bounds on available measurements',
 'exceeds':'A declared bound is exceeded', 'insufficient_data':'Not enough measurements',
 'status_unknown':'Bounds not defined', 'range':'Observed values', 'error':'Check the series and bounds.',
 'day':'day', 'from':'from', 'to':'to', 'notation':'State: unit; trend: unit/day; trend change: unit/day².',
 'count':'sample(s)', 'invalid':'Each line needs a numeric day and value separated by a semicolon.'}
}

JS = r'''
const $=id=>document.getElementById(id),w=config.words;
function payload(){
 const raw=$('samples').value.trim();
 const samples=raw?raw.split(/\r?\n/).map((line,i)=>{
  const cells=line.split(';').map(x=>x.trim());
  if(cells.length!==2||cells.some(x=>!x||!/^[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[-+]?\d+)?$/i.test(x)))throw Error(w.invalid);
  const day=Number(cells[0]),value=Number(cells[1]);if(!Number.isFinite(day)||!Number.isFinite(value))throw Error(w.invalid);
  return {t:day,value,source_id:'line:'+(i+1)};
 }):[];
 const bounds={},state={};
 for(const id of ['min','max'])if($(id).value.trim()!=='')state[id]=Number($(id).value);
 if(Object.keys(state).length)bounds.state=state;
 if($('rate').value.trim()!=='')bounds.trend={max_abs:Number($('rate').value)};
 if($('acceleration').value.trim()!=='')bounds.trend_change={max_abs:Number($('acceleration').value)};
 const data={schema:'tao.integrability.request.v1',quantity:$('quantity').value,unit:$('unit').value,time_unit:'day',samples,bounds};
 if($('reference').value.trim())data.reference=$('reference').value.trim();return data;
}
function display(data){
 const result=$('results');result.replaceChildren();
 for(const order of data.orders){const article=document.createElement('article'),title=document.createElement('h3'),status=document.createElement('p');
 title.textContent=w[order.key];status.textContent=w[order.status==='unknown'?'status_unknown':order.status]||order.status;
 article.append(title,status);const range=order.observed_range;
 if(range){const factor=1,unit=data.input.unit+(order.order?'/'+w.day+(order.order===2?'²':''):'');
 const values=document.createElement('p');values.textContent=w.range+' : '+Number((range.min*factor).toPrecision(8))+' → '+Number((range.max*factor).toPrecision(8))+' '+unit;article.append(values);}
 const count=document.createElement('small');count.textContent=order.count+' '+w.count;article.append(count);result.append(article);}
 $('result-section').hidden=false;
}
$('trend-form').onsubmit=async event=>{event.preventDefault();const button=$('run');if(button.disabled)return;button.disabled=true;$('error').hidden=true;
 try{const body=payload(),url=new URL('/api/integrability/evaluate',location.origin);url.searchParams.set('world',config.world);
 const response=await fetch(url.pathname+url.search,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-Tao-Token':config.token},body:JSON.stringify(body)});
 const data=await response.json();if(!response.ok)throw Error(data.error||w.error);display(data);
 }catch(error){$('error').textContent=error.message||w.error;$('error').hidden=false;$('result-section').hidden=true;}
 finally{button.disabled=false;}};
'''


def render(n, locale='fr'):
    if locale not in WORDS:
        raise ValueError('Langue disponible : fr ou en.')
    w = WORDS[locale]
    esc = lambda text: html.escape(str(text), quote=True)
    fields = ''.join('<label for="'+ident+'">'+esc(w[ident])+'</label><input id="'+ident+
                     '" type="number" step="any"'+(' min="0"' if ident in ('rate', 'acceleration') else '')+'>'
                     for ident in ('min', 'max', 'rate', 'acceleration'))
    token = json.dumps(n.TOKEN).replace('<', '\\u003c')
    config = json.dumps({'words': w, 'world': n.worlds.current()}, ensure_ascii=False).replace('<', '\\u003c')
    return '''<!doctype html><html lang="'''+locale+'''"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tao · '''+esc(w['title'])+'''</title><style>
:root{color-scheme:light}*{box-sizing:border-box}body{margin:0;background:#f5f3ed;color:#27372f;font:16px/1.6 system-ui}main{max-width:760px;margin:auto;padding:28px 20px 60px}a{color:#315a47}h1{font-size:clamp(30px,5vw,42px);line-height:1.2}h2{font-size:22px}section{padding:24px;background:var(--panel);border:1px solid #d9ded5;border-radius:16px;margin:24px 0}label{display:block;margin:16px 0 6px}input,textarea{display:block;width:100%;font:inherit;color:inherit;background:#f5f3ed;padding:10px 12px;border:1px solid #b9c7bc;border-radius:8px}textarea{min-height:130px;resize:vertical}button{font:inherit;border:0;border-radius:9px;padding:12px 18px;background:#315a47;color:#fff;margin-top:20px;cursor:pointer;min-height:44px}button:disabled{opacity:.5}small,.muted{color:#596860}article{padding:12px 0;border-bottom:1px solid #d9ded5}#error{color:#873e27}[hidden]{display:none!important}:focus-visible{outline:3px solid var(--accent);outline-offset:3px}@media(max-width:500px){main{padding:18px 14px}section{padding:18px}}

/* Tao · maison : surfaces, typography and interaction */
:root{--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47;--soft:#edf1ea;--gold:#c79d67;color-scheme:light}
body{min-height:100vh;background:radial-gradient(circle at 88% -10%,#eee3d2,transparent 38%),var(--bg)}
nav{min-height:60px}.page-nav{display:flex;align-items:center;justify-content:space-between;gap:20px;padding-bottom:18px;border-bottom:1px solid var(--line)}.eyebrow{color:var(--accent);font:700 11px/1.5 system-ui,sans-serif;letter-spacing:.15em;text-transform:uppercase}nav .brand{font:600 29px/1 ui-serif,Georgia,serif;letter-spacing:-.045em;color:var(--text);text-decoration:none}
a{color:var(--accent);text-underline-offset:3px}a:hover,summary:hover{text-decoration-color:var(--gold)}
header{margin:26px 0 28px;padding:clamp(24px,4vw,42px);border:1px solid var(--line);border-top:3px solid var(--gold);border-radius:20px;background:linear-gradient(135deg,#fffdfa,#f6f1e8);box-shadow:0 12px 30px rgba(39,55,47,.045)}
header p:last-child{max-width:68ch}h1,h2,h3{font-family:ui-serif,Georgia,serif;letter-spacing:-.025em}h1{font-weight:500}h2,h3{font-weight:600}
section,.panel{box-shadow:0 6px 22px rgba(39,55,47,.035)}
button,.button{background:var(--accent);color:#fff}button.secondary,.button.secondary{background:var(--soft);color:var(--accent);border:1px solid var(--line)}
input:not([type=checkbox]):not([type=file]),textarea,select{background:var(--panel);color:var(--text);border-color:#b9c7bc}pre{background:#f3f1eb;color:var(--text);border:1px solid var(--line)}
button:focus-visible,a:focus-visible,summary:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid var(--accent);outline-offset:3px}
#message{background:#ecf1ea;color:var(--text);border:1px solid #b7cab8;box-shadow:0 8px 25px rgba(39,55,47,.12)}#message.error{background:#fff1e6;color:#613f2d;border-color:#dfb997}
#error{background:#fff1e6;border:1px solid #dfb997;border-radius:9px;padding:12px 14px}#result-section article:last-child{border-bottom:0}#result-section article{padding:16px 0}
@media(max-width:540px){header{margin:18px 0 20px;padding:23px 19px;border-radius:16px}}
</style></head><body><main><nav class="page-nav"><a class="brand" href="/explore?world='''+quote(n.worlds.current(), safe='')+'&amp;lang='+locale+'''">tao.</a><a href="/explore?world='''+quote(n.worlds.current(), safe='')+'&amp;lang='+locale+'''">← '''+esc(w['back'])+'''</a></nav><header><p class="eyebrow">'''+('L’observatoire · mesures' if locale=='fr' else 'Observatory · measures')+'''</p><h1>'''+esc(w['title'])+'''</h1><p>'''+esc(w['intro'])+'''</p></header><form id="trend-form"><section><label for="quantity">'''+esc(w['quantity'])+'''</label><input id="quantity" maxlength="120" required><label for="unit">'''+esc(w['unit'])+'''</label><input id="unit" maxlength="40" required><label for="samples">'''+esc(w['samples'])+'''</label><textarea id="samples" maxlength="16000" aria-describedby="sample-help"></textarea><p id="sample-help" class="muted">'''+esc(w['sample_help'])+'''</p></section><section><h2>'''+esc(w['limits'])+'''</h2>'''+fields+'''<label for="reference">'''+esc(w['reference'])+'''</label><textarea id="reference" maxlength="1000"></textarea><p class="muted">'''+esc(w['unknown'])+'''</p><p class="muted">'''+esc(w['notation'])+'''</p></section><button id="run">'''+esc(w['run'])+'''</button><p id="error" role="alert" hidden></p></form><section id="result-section" hidden><h2>'''+esc(w['result'])+'''</h2><div id="results"></div></section><p class="muted">'''+esc(w['scope'])+'''</p></main><script>const token='''+token+';const config='+config+';config.token=token;\n'+JS+'</script></body></html>'
