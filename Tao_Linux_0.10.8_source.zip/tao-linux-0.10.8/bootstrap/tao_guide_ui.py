"""A read-only, progressive guide built from Tao's shared logic catalogue.

No model is called and no private state, credentials or account status is read.
The selected world is used only for navigation back to the user's workspace.
"""
import html
from urllib.parse import quote, urlencode


WORDS = {
    'fr': {
        'title': 'Comprendre Tao', 'back': 'Mes espaces', 'talk': 'Raconter ma situation',
        'language': 'Langue du guide', 'intro': 'Une discussion pour mettre votre situation au clair, garder ce qui compte et avancer à votre rythme.',
        'lead': 'Tao relie vos histoires, vos questions et vos objectifs. Vous pouvez le corriger à tout moment. Une aide utile peut devenir une méthode réutilisable, ou une amélioration du logiciel.',
        'path': 'La boucle, en cinq gestes',
        'steps': [
            ('Raconter', 'Décrivez ce qui se passe et ce que vous aimeriez rendre possible. Une question suffit pour commencer.', ('story', 'difference')),
            ('Relier', 'Tao propose des repères : situations, objectifs, besoins et personnes concernées. Vous relisez les sources et corrigez les rapprochements.', ('need', 'objective', 'provenance')),
            ('Choisir', 'Retenez une prochaine étape qui respecte vos contraintes, votre rythme et les autres personnes. Vous pouvez aussi garder une question ouverte.', ('resource', 'mandate')),
            ('Agir', 'Discutez, utilisez une aide disponible ou préparez une amélioration. Les actions extérieures dépendent des moyens connectés et des autorisations données.', ('task', 'function', 'workshop')),
            ('Vérifier', 'Regardez le résultat dans votre situation réelle. Gardez ce qui aide ; corrigez ce qui gêne. Un test technique réussi ne résout pas forcément votre besoin.', ('evidence', 'integration', 'buffer')),
        ],
        'start': 'Commencer sans tout apprendre',
        'example': 'Exemple fictif : « J’ai plusieurs demandes à traiter et je ne sais pas par où commencer. »',
        'start_note': 'Ouvrez un espace, racontez ce que vous savez et laissez Tao poser quelques questions utiles. Les premières propositions restent à relire ; rien n’oblige à remplir toutes les cases.',
        'connection': 'Connecter une IA et reprendre une histoire',
        'connection_text': 'Connecter le modèle permet de lui poser des questions dans Tao. Cela ne récupère pas automatiquement vos anciennes conversations, souvenirs de compte ou fichiers.',
        'import_text': 'Pour reprendre votre passé, choisissez un export compatible et relisez son classement avant l’import. Vos sources restent consultables. L’IA peut ensuite proposer des repères à partir du contexte disponible, qui reste limité.',
        'connect': 'Connecter mon IA', 'import': 'Reprendre mes conversations',
        'coordinates': 'Des dimensions différentes, sans multiplier les IA',
        'coordinates_intro': 'Le même moteur peut servir dans plusieurs espaces. Changer de contexte ne crée pas une nouvelle personne et n’accorde pas de nouveaux droits.',
        'coordinates_rows': [
            ('space', 'Où en parle-t-on ? Travail, vie personnelle, un projet… Chaque espace garde sa mémoire et sa discussion.'),
            ('center', 'Quelle spécialisation serait utile ? Un centre est une hypothèse d’organisation des fonctions, de la mémoire et du rythme ; cinq agents indépendants ne sont pas imposés.'),
            ('mode', 'Comment examine-t-on la situation ? Routine, attention attirée ou examen dirigé : ces modes ne sont pas trois modèles IA installés ni une mesure de QI.'),
            ('mandate', 'Que peut-on réellement faire ? Les droits accordés bornent les actions. Un mode dit supérieur ne peut pas les élargir de lui-même.'),
        ],
        'selves': 'Et le « moi » ou l’intendant ?',
        'selves_text': 'Ce sont des propositions pour mieux organiser le point de vue de Tao et la coordination de ses fonctions. Elles ne prouvent pas une conscience et ne constituent pas encore un intendant autonome livré.',
        'inheritance': 'Ce qui se transmet, ce qui vous appartient',
        'inheritance_rows': [
            ('Héritage commun', 'Le langage, les définitions et les premières capacités donnent un départ. Ils peuvent être discutés et révisés avec leurs raisons et leurs limites.'),
            ('Votre histoire privée', 'Vos échanges, sources et corrections appartiennent à votre installation et à leurs espaces. Ils ne deviennent pas automatiquement un patrimoine partagé.'),
            ('Version du logiciel', 'Une modification du code passe par une proposition, une revue, des tests et une décision d’intégration. Installer du code et enrichir votre mémoire sont deux changements différents.'),
            ('Accès et permissions', 'Une méthode transmise ou un descendant ne reçoit pas automatiquement vos comptes, mots de passe ou droits d’action.'),
        ],
        'available': 'Ce que vous pouvez attendre aujourd’hui',
        'available_rows': [
            ('Disponible dans le logiciel', 'Espaces, repères à relire, mémoire sourcée, import textuel compatible et discussion avec le modèle configuré. Certaines aides se réutilisent sans IA ; l’atelier prépare des changements avec revue et tests.'),
            ('Encore partiel', 'Le classement et le rappel peuvent manquer des éléments. La connexion effective du modèle et des outils doit fonctionner sur votre installation. Tao ne connaît pas spontanément toutes vos applications ni toutes vos anciennes conversations.'),
            ('À construire ou à éprouver', 'Un intendant autonome, la spécialisation réelle des centres et la conciliation automatique de deux installations qui évoluent séparément restent des pistes. Les nommer dans le langage ne les rend pas exécutables.'),
        ],
        'phone': 'Sur téléphone et ordinateur',
        'phone_text': 'Deux appareils peuvent ouvrir le même Tao. L’ordinateur qui l’héberge doit rester accessible, ou il faut une installation hébergée réellement mise en service. Ouvrir Tao sur téléphone ne crée pas une copie autonome et ne synchronise pas deux installations séparées.',
        'devices': 'Mes appareils', 'tools': 'Mes aides', 'trends': 'Comprendre une tendance',
        'integrability': 'Intégrer les différences, sans forcer',
        'integrability_text': 'L’objectif est de garder une situation vivable et de rendre les changements intégrables à un rythme adapté. Une tendance peut demander de l’attention avant qu’un blocage apparaisse. Pour calculer une tendance, il faut des observations comparables, une durée et des limites déclarées.',
        'integrability_limit': 'Une question peut rester ouverte, une contrainte peut être incompatible avec une autre, et un refus peut rester un refus. « Tout concilier » ne signifie pas effacer toutes les différences.',
        'dictionary': 'Explorer les mots et leurs liens',
        'dictionary_note': 'Les noms peuvent changer de langue ; les concepts gardent leur identité. Ce catalogue distingue les définitions de travail, les références historiques et les propositions encore à éprouver.',
        'implementation_note': 'Le statut d’un concept décrit sa place dans le logiciel. Il ne certifie ni le fonctionnement de votre compte IA ni la validité scientifique d’une analogie.',
        'aliases': 'Autres noms', 'formalism': 'Un modèle associé', 'assumptions': 'Conditions et limites',
        'relations': 'Comment ces repères se relient', 'invariants': 'Ce qu’il faut préserver en évoluant',
        'catalogue_version': 'Catalogue de logique', 'canon_version': 'Héritage du langage',
        'status': {'implemented': 'Présent', 'partial': 'Partiel', 'proposed': 'Proposé', 'not_applicable': 'Repère descriptif'},
        'epistemic': {'math': 'Définition mathématique', 'operational': 'Définition de travail', 'historical': 'Référence historique', 'proposed': 'Hypothèse'},
        'read_more': 'Comprendre ce mot', 'footer': 'Ce guide explique Tao ; sa lecture ne lance aucune IA ni action.',
    },
    'en': {
        'title': 'Understand Tao', 'back': 'My spaces', 'talk': 'Describe my situation',
        'language': 'Guide language', 'intro': 'A conversation to understand your situation, keep what matters and move at your own pace.',
        'lead': 'Tao connects your stories, questions and objectives. You can correct it at any time. Useful help can become a reusable method or an improvement to the software.',
        'path': 'The loop in five steps',
        'steps': [
            ('Describe', 'Explain what is happening and what you would like to make possible. One question is enough to begin.', ('story', 'difference')),
            ('Connect', 'Tao proposes landmarks: situations, objectives, needs and people involved. Review the sources and correct the connections.', ('need', 'objective', 'provenance')),
            ('Choose', 'Select a next step that respects your constraints, pace and other people. You can also leave a question open.', ('resource', 'mandate')),
            ('Act', 'Discuss, use an available aid or prepare an improvement. External actions depend on connected capabilities and granted permissions.', ('task', 'function', 'workshop')),
            ('Check', 'Look at the result in your real situation. Keep what helps and correct what gets in the way. A successful technical test does not necessarily resolve your need.', ('evidence', 'integration', 'buffer')),
        ],
        'start': 'Start without learning everything first',
        'example': 'Fictional example: “I have several requests to handle and do not know where to start.”',
        'start_note': 'Open a space, describe what you know and let Tao ask a few useful questions. Early proposals need your review; you do not have to fill in every field.',
        'connection': 'Connect an AI and bring your history',
        'connection_text': 'Connecting a model lets you ask questions within Tao. It does not automatically retrieve your old conversations, account memories or files.',
        'import_text': 'To bring your history, choose a supported export and review its classification before importing. Sources remain available to read. The AI can then propose landmarks from the available context, which remains limited.',
        'connect': 'Connect my AI', 'import': 'Bring my conversations',
        'coordinates': 'Different dimensions, without multiplying AIs',
        'coordinates_intro': 'The same model can serve several spaces. Changing context does not create a new person or grant new permissions.',
        'coordinates_rows': [
            ('space', 'Where are we discussing this? Work, personal life, a project… Each space keeps its own memory and conversation.'),
            ('center', 'What specialisation might help? A centre is a proposed organisation of functions, memory and pace; five independent agents are not required.'),
            ('mode', 'How are we examining the situation? Routine, attracted attention or directed examination: these modes are not three installed AI models or an IQ measure.'),
            ('mandate', 'What is actually allowed? Granted permissions bound actions. A supposedly higher mode cannot expand them on its own.'),
        ],
        'selves': 'What about a “self” or a steward?',
        'selves_text': 'These are proposals to organise Tao’s viewpoint and coordination of functions. They do not prove consciousness and do not constitute an autonomous steward delivered today.',
        'inheritance': 'What is inherited, and what belongs to you',
        'inheritance_rows': [
            ('Shared inheritance', 'Language, definitions and initial capabilities provide a starting point. They can be questioned and revised with their reasons and limits.'),
            ('Your private history', 'Your exchanges, sources and corrections belong to your installation and their spaces. They do not automatically become shared inheritance.'),
            ('Software version', 'A code change goes through a proposal, review, tests and an integration decision. Installing code and enriching your memory are different changes.'),
            ('Access and permissions', 'A shared method or descendant does not automatically receive your accounts, passwords or permissions to act.'),
        ],
        'available': 'What to expect today',
        'available_rows': [
            ('Available in the software', 'Spaces, landmarks to review, sourced memory, supported text imports and discussion with the configured model. Some aids run without AI; the workshop prepares changes with review and tests.'),
            ('Still partial', 'Classification and recall may miss information. The model and tools must actually be connected on your installation. Tao does not automatically know all your applications or previous conversations.'),
            ('To build or test', 'An autonomous steward, real specialisation of centres and automatic reconciliation of two separately evolving installations remain directions to explore. Naming them in the language does not make them executable.'),
        ],
        'phone': 'On phone and computer',
        'phone_text': 'Two devices can open the same Tao. The hosting computer must stay accessible, or a hosted installation must actually be deployed. Opening Tao on a phone does not create an independent copy or synchronise two separate installations.',
        'devices': 'My devices', 'tools': 'My aids', 'trends': 'Understand a trend',
        'integrability': 'Integrating differences without forcing them',
        'integrability_text': 'The aim is to keep situations viable and make changes manageable at an appropriate pace. A trend may need attention before a blockage appears. Calculating a trend requires comparable observations, a time interval and stated limits.',
        'integrability_limit': 'A question can remain open, two constraints can be incompatible and a refusal can remain a refusal. Reconciling differences does not mean erasing them.',
        'dictionary': 'Explore the words and their connections',
        'dictionary_note': 'Names can change language while concepts retain their identity. This catalogue distinguishes working definitions, historical references and proposals still to test.',
        'implementation_note': 'A concept’s status describes its place in the software. It does not certify your AI account or the scientific validity of an analogy.',
        'aliases': 'Other names', 'formalism': 'An associated model', 'assumptions': 'Conditions and limits',
        'relations': 'How these concepts connect', 'invariants': 'What to preserve while evolving',
        'catalogue_version': 'Logic catalogue', 'canon_version': 'Language inheritance',
        'status': {'implemented': 'Present', 'partial': 'Partial', 'proposed': 'Proposed', 'not_applicable': 'Descriptive concept'},
        'epistemic': {'math': 'Mathematical definition', 'operational': 'Working definition', 'historical': 'Historical reference', 'proposed': 'Hypothesis'},
        'read_more': 'Understand this word', 'footer': 'Reading this guide does not call an AI or start an action.',
    },
}


CSS = '''
:root{color-scheme:light;--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47;--soft:#edf1ea;--gold:#c79d67}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.65 system-ui,sans-serif}main{max-width:940px;margin:auto;padding:24px 28px 60px}nav{display:flex;align-items:center;gap:20px;flex-wrap:wrap;padding:0 0 20px;border-bottom:1px solid var(--line)}.brand{font-size:25px;font-weight:750;letter-spacing:.1em;text-decoration:none}.languages{margin-left:auto;display:flex;gap:12px}a{color:var(--accent);text-underline-offset:3px}header{padding:38px 0 24px}h1{font-size:clamp(31px,5vw,44px);line-height:1.2;letter-spacing:-.03em;margin:12px 0 18px}h2{font-size:22px;line-height:1.3;margin:0 0 15px}h3{font-size:18px;margin:10px 0}p{margin:8px 0 15px}.lead{font-size:20px;max-width:760px}.muted,.small{color:var(--muted)}.small{font-size:13px}.eyebrow{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:var(--accent)}section,.panel{padding:26px;background:var(--panel);border:1px solid var(--line);border-radius:14px;margin:20px 0}.steps{list-style:none;padding:0;margin:0;counter-reset:step}.steps>li{counter-increment:step;position:relative;padding:0 0 22px 46px;margin:0}.steps>li:last-child{padding-bottom:0}.steps>li:before{content:counter(step);display:grid;place-items:center;width:30px;height:30px;border-radius:50%;background:var(--soft);color:var(--accent);font-size:14px;font-weight:700;position:absolute;left:0;top:4px}.steps h3{margin-top:0}.step-terms{display:flex;gap:12px;flex-wrap:wrap;font-size:13px}.actions{display:flex;flex-wrap:wrap;gap:12px;margin:18px 0}.button{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:9px 16px;background:var(--accent);color:white;border-radius:9px;font-weight:600;text-decoration:none}.secondary{background:var(--soft);color:var(--accent)}details{border-top:1px solid var(--line);padding:6px 0;margin:0}summary{cursor:pointer;min-height:44px;padding:12px 0;color:var(--accent);font-weight:650}details>div{padding:0 0 16px}.terms{margin-top:18px}.term{scroll-margin-top:15px}.badge{display:inline-block;font-size:12px;border-radius:16px;padding:2px 9px;margin:0 6px 8px 0;background:var(--soft);color:var(--accent)}.proposed{background:#fff1d6;color:#805d23}.partial{background:#e9edf3;color:#516073}.explanation{padding-left:16px;border-left:2px solid var(--line);margin:14px 0}dl{margin:0}dt{font-weight:650;margin-top:16px}dd{margin:4px 0 18px}.capabilities>div{border-top:1px solid var(--line);padding:12px 0}.capabilities>div:first-child{border-top:0}.capabilities p{margin-bottom:0}blockquote{margin:16px 0;padding:12px 18px;border-left:3px solid var(--accent);background:var(--bg)}code{font-size:13px;white-space:pre-wrap;overflow-wrap:anywhere}p,dd,li,summary{overflow-wrap:anywhere;min-width:0}footer{margin-top:28px;color:var(--muted);font-size:13px}a:focus-visible,summary:focus-visible{outline:3px solid #8fba92;outline-offset:4px}li+li{margin-top:8px}@media(max-width:620px){main{padding:18px 15px 40px}section,.panel{padding:21px}header{padding-top:25px}.lead{font-size:18px}nav{gap:14px}.languages{margin-left:0}.steps>li{padding-left:39px}.steps>li:before{width:27px;height:27px}}@media(prefers-reduced-motion:no-preference){html{scroll-behavior:smooth}}

/* Tao · maison : surfaces, typography and interaction */
:root{--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47;--soft:#edf1ea;--gold:#c79d67;color-scheme:light}
body{min-height:100vh;background:radial-gradient(circle at 88% -10%,#eee3d2,transparent 38%),var(--bg)}
nav{min-height:60px}.page-nav{display:flex;align-items:center;justify-content:space-between;gap:20px;padding-bottom:18px;border-bottom:1px solid var(--line)}.eyebrow{color:var(--accent);font:700 11px/1.5 system-ui,sans-serif;letter-spacing:.15em;text-transform:uppercase}nav .brand{font:600 29px/1 ui-serif,Georgia,serif;letter-spacing:-.045em;color:var(--text);text-decoration:none}
a{color:var(--accent);text-underline-offset:3px}a:hover,summary:hover{text-decoration-color:var(--gold)}
header{margin:26px 0 28px;padding:clamp(24px,4vw,42px);border:1px solid var(--line);border-top:3px solid var(--gold);border-radius:20px;background:linear-gradient(135deg,#fffdfa,#f6f1e8);box-shadow:0 12px 30px rgba(39,55,47,.045)}
header p:last-child{max-width:68ch}h1,h2,h3{font-family:ui-serif,Georgia,serif;letter-spacing:-.025em}h1{font-weight:500}h2,h3{font-weight:600}
section,.panel{box-shadow:0 6px 22px rgba(39,55,47,.035)}
button,.button{background:var(--accent);color:#fff}button.secondary,.button.secondary{background:var(--soft);color:var(--accent);border:1px solid var(--line)}
input:not([type=checkbox]):not([type=file]),textarea,select{background:var(--panel);color:var(--text);border-color:#b9c7bc}pre{background:#f3f1eb;color:var(--text);border:1px solid var(--line)}
button:focus-visible,a:focus-visible,summary:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid var(--accent);outline-offset:3px}
#message{background:#ecf1ea;color:var(--text);border:1px solid #b7cab8;box-shadow:0 8px 25px rgba(39,55,47,.12)}#message.error{background:#fff1e6;color:#613f2d;border-color:#dfb997}
@media(max-width:540px){header{margin:18px 0 20px;padding:23px 19px;border-radius:16px}}

'''


def render(n, s=None, locale='fr'):
    import tao_logic
    import tao_worlds as worlds
    locale = locale if locale in WORDS else 'fr'
    w = WORDS[locale]
    catalogue = tao_logic.catalog(locale)
    terms = {row['key']: row for row in catalogue['terms']}
    by_id = {row['id']: row for row in catalogue['terms']}
    models = {row['id']: row for row in catalogue.get('formalisms', [])}
    world = worlds.current()
    esc = lambda value: html.escape(str(value), quote=True)

    def url(path):
        params = {'world': world}
        if path in ('/explore', '/connect', '/trends', '/guide'):
            params['lang'] = locale
        if path == '/':
            params['view'] = 'dialogue'
        if path == '/onboarding':
            params['world'] = 'main'
        return esc(path + '?' + urlencode(params))

    def term_links(keys):
        return ' '.join(f'<a href="#term-{quote(key, safe="")}">{esc(terms[key]["label"])}</a>'
                        for key in keys if key in terms)

    steps = ''.join(f'<li><h3>{esc(title)}</h3><p>{esc(text)}</p><div class="step-terms">{term_links(keys)}</div></li>'
                    for title, text, keys in w['steps'])
    dimensions = ''.join(f'<dt>{esc(terms[key]["label"])}</dt><dd>{esc(text)} '
                         f'<a href="#term-{quote(key, safe="")}">{esc(w["read_more"])}</a></dd>'
                         for key, text in w['coordinates_rows'] if key in terms)
    inheritance = ''.join(f'<dt>{esc(title)}</dt><dd>{esc(text)}</dd>' for title, text in w['inheritance_rows'])
    available = ''.join(f'<div><h3>{esc(title)}</h3><p>{esc(text)}</p></div>' for title, text in w['available_rows'])
    entries = []
    for term in catalogue['terms']:
        status = term['implementation']['status']
        epistemic = term['epistemic_status']
        body = (f'<span class="badge {esc(status)}">{esc(w["status"].get(status, status))}</span>'
                f'<span class="badge">{esc(w["epistemic"].get(epistemic, epistemic))}</span>'
                f'<p>{esc(term["definition"])}</p>')
        if term.get('aliases'):
            body += '<p class="small">' + esc(w['aliases']) + ' : ' + esc(', '.join(term['aliases'])) + '</p>'
        for ident in term.get('formalism_ids', []):
            model = models.get(ident)
            if not model:
                continue
            body += f'<details><summary>{esc(w["formalism"])}</summary><div><p>{esc(model["explanation"])}</p>'
            if model.get('expression'):
                body += '<p><code>' + esc(model['expression']) + '</code></p>'
            assumptions = model.get('assumptions', [])
            if assumptions:
                if isinstance(assumptions, str):
                    assumptions = [assumptions]
                body += '<p class="small">' + esc(w['assumptions']) + '</p><ul>'
                body += ''.join('<li>' + esc(item) + '</li>' for item in assumptions) + '</ul>'
            body += '</div></details>'
        entries.append(f'<details class="term" id="term-{quote(term["key"], safe="")}"><summary>{esc(term["label"])}</summary><div>{body}</div></details>')
    relationships = []
    for relation in catalogue.get('relations', []):
        source, target = by_id.get(relation['source']), by_id.get(relation['target'])
        if source and target:
            relationships.append('<li>' + term_links((source['key'], target['key'])) +
                                 '<p>' + esc(relation['description']) + '</p></li>')
    invariants = ''.join('<li>' + esc(row['text']) + '</li>' for row in catalogue.get('invariants', []))
    language_links = ' '.join(f'<a href="{esc("/guide?" + urlencode({"world": world, "lang": lang}))}" lang="{lang}" hreflang="{lang}">{label}</a>'
                              for lang, label in [('fr', 'FR'), ('en', 'EN')])
    return f'''<!doctype html><html lang="{locale}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tao · {esc(w['title'])}</title><style>{CSS}</style></head><body><main>
<nav aria-label="Tao"><a class="brand" href="{url('/explore')}">tao.</a><a href="{url('/explore')}">{esc(w['back'])}</a><div class="languages" aria-label="{esc(w['language'])}">{language_links}</div></nav>
<header><p class="eyebrow">{'La bibliothèque · comprendre Tao' if locale == 'fr' else 'Library · understanding Tao'}</p><h1>{esc(w['title'])}</h1><p class="lead">{esc(w['intro'])}</p><p class="muted">{esc(w['lead'])}</p></header>
<section aria-labelledby="loop-title"><h2 id="loop-title">{esc(w['path'])}</h2><ol class="steps">{steps}</ol></section>
<section aria-labelledby="start-title"><h2 id="start-title">{esc(w['start'])}</h2><blockquote>{esc(w['example'])}</blockquote><p>{esc(w['start_note'])}</p><div class="actions"><a class="button" href="{url('/')}">{esc(w['talk'])}</a><a class="button secondary" href="{url('/explore')}">{esc(w['back'])}</a></div></section>
<div class="panel"><details><summary>{esc(w['connection'])}</summary><div><p>{esc(w['connection_text'])}</p><p>{esc(w['import_text'])}</p><div class="actions"><a href="{url('/connect')}">{esc(w['connect'])}</a><a href="{url('/onboarding')}">{esc(w['import'])}</a></div></div></details>
<details><summary>{esc(w['coordinates'])}</summary><div><p>{esc(w['coordinates_intro'])}</p><dl>{dimensions}</dl><h3>{esc(w['selves'])}</h3><p>{esc(w['selves_text'])}</p><div class="step-terms">{term_links(('contextual_self','steward'))}</div></div></details>
<details><summary>{esc(w['inheritance'])}</summary><div><dl>{inheritance}</dl><div class="step-terms">{term_links(('heritage','source','mandate'))}</div></div></details>
<details><summary>{esc(w['available'])}</summary><div class="capabilities">{available}<div class="actions"><a href="{url('/tools')}">{esc(w['tools'])}</a><a href="{url('/connect')}">{esc(w['connect'])}</a></div></div></details>
<details><summary>{esc(w['phone'])}</summary><div><p>{esc(w['phone_text'])}</p><a href="{url('/devices')}">{esc(w['devices'])}</a></div></details>
<details><summary>{esc(w['integrability'])}</summary><div><p>{esc(w['integrability_text'])}</p><p>{esc(w['integrability_limit'])}</p><a href="{url('/trends')}">{esc(w['trends'])}</a></div></details></div>
<section aria-labelledby="words-title"><h2 id="words-title">{esc(w['dictionary'])}</h2><p>{esc(w['dictionary_note'])}</p><p class="small">{esc(w['implementation_note'])}</p><div class="terms">{''.join(entries)}</div><details><summary>{esc(w['relations'])}</summary><div><ul>{''.join(relationships)}</ul></div></details><details><summary>{esc(w['invariants'])}</summary><div><ul>{invariants}</ul></div></details></section>
<footer><p>{esc(w['footer'])}</p><p>{esc(w['catalogue_version'])} {esc(catalogue['version'])} · {esc(w['canon_version'])} {esc(catalogue['canon']['version'])}</p></footer>
</main></body></html>'''
