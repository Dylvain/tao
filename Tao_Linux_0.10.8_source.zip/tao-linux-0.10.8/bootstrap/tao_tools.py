"""Owner HTTP/CLI integration for durable recipes and scoped MCP tools.

Registering executable programs is deliberately a local CLI operation. Model
interfaces live in tao_bridge and cannot reach this owner dispatch table.
"""
import json
import sys
import urllib.parse

import tao_bridge as bridge
import tao_connectors as connectors
import tao_reuse as reuse
import tao_worlds as worlds

MAX_BODY = 262144
PREFIXES = ('/api/reuse/', '/api/bridge/', '/api/connectors/')


def owns(path):
    return path.startswith(PREFIXES)


def overview(n):
    return {'reuse': reuse.catalog(n), 'bridge': bridge.owner_view(n),
            'connectors': connectors.catalog(n), 'world': worlds.describe(n, n.load_state())}


def get(n, path):
    if path == '/api/tools':
        return overview(n)
    if path.startswith('/api/reuse/suggest?'):
        values = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query, keep_blank_values=True)
        if set(values) != {'q'} or len(values['q']) != 1 or len(values['q'][0]) > 1000:
            raise ValueError('Une recherche de 1000 caractères maximum est requise')
        n.load_state()
        if not values['q'][0].strip(): return []
        return reuse.suggest(n, values['q'][0])
    if path.startswith('/api/reuse/template?'):
        values = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query, keep_blank_values=True)
        if set(values) != {'name'} or len(values['name']) != 1:
            raise ValueError('Un seul nom de modèle est requis')
        n.load_state()  # Validate the selected world even for a stateless template.
        return reuse.template(values['name'][0])
    raise ValueError('Ressource d’aide inconnue')


def _confirmed(payload):
    if payload.get('confirmed') is not True:
        raise ValueError('Confirmation humaine explicite requise')


def post(n, path, obj):
    if not isinstance(obj, dict):
        raise ValueError('Objet JSON requis')
    routes = {
        '/api/reuse/propose': ({'proposal'}, lambda: reuse.propose(n, obj.get('proposal'))),
        '/api/reuse/qualify': ({'id', 'revision'}, lambda: reuse.qualify(n, obj.get('id'), obj.get('revision'))),
        '/api/reuse/activate': ({'id', 'revision', 'review_digest', 'confirmed'}, lambda: reuse.activate(n, obj.get('id'), obj.get('revision'), obj.get('review_digest'))),
        '/api/reuse/retire': ({'id', 'revision'}, lambda: reuse.retire(n, obj.get('id'), obj.get('revision'))),
        '/api/reuse/run': ({'id', 'inputs', 'revision', 'request_id'}, lambda: reuse.run(n, obj.get('id'), obj.get('inputs'), obj.get('revision'), request_id=obj.get('request_id'))),
        '/api/reuse/report': ({'id', 'receipt_id', 'useful', 'note', 'revision'}, lambda: reuse.report(n, obj.get('id'), obj.get('receipt_id'), obj.get('useful'), obj.get('note', ''), obj.get('revision'))),
        '/api/bridge/grant': ({'label', 'tools', 'sections', 'ttl_seconds', 'max_calls', 'revision', 'confirmed'}, lambda: bridge.create_grant(n, {k: v for k, v in obj.items() if k != 'confirmed'})),
        '/api/bridge/config': ({'id'}, lambda: bridge.config(n, obj.get('id'))),
        '/api/bridge/revoke': ({'id', 'revision'}, lambda: bridge.revoke_grant(n, obj.get('id'), obj.get('revision'))),
        '/api/bridge/capture': ({'id', 'action', 'revision'}, lambda: bridge.review_capture(n, obj.get('id'), obj.get('action'), obj.get('revision'))),
        '/api/connectors/inspect': ({'id', 'revision'}, lambda: connectors.inspect(n, obj.get('id'), obj.get('revision'))),
        '/api/connectors/request': ({'connector_id', 'tool', 'arguments', 'request_id'}, lambda: connectors.request(n, obj.get('connector_id'), obj.get('tool'), obj.get('arguments'), request_id=obj.get('request_id'))),
        '/api/connectors/execute': ({'id', 'revision', 'review_digest', 'confirmed'}, lambda: connectors.execute(n, obj.get('id'), obj.get('revision'), obj.get('review_digest'))),
        '/api/connectors/dismiss': ({'id', 'revision'}, lambda: connectors.dismiss(n, obj.get('id'), obj.get('revision'))),
        '/api/connectors/revoke': ({'id', 'revision'}, lambda: connectors.revoke(n, obj.get('id'), obj.get('revision'))),
    }
    if path not in routes:
        raise ValueError('Action d’aide inconnue')
    allowed, operation = routes[path]
    if set(obj) - allowed:
        raise ValueError('Champs d’aide inconnus')
    if path in {'/api/reuse/activate', '/api/bridge/grant', '/api/connectors/execute'}:
        _confirmed(obj)
    return operation()


def _file(path):
    if path == '-':
        raw = sys.stdin.buffer.read(MAX_BODY + 1)
    else:
        with open(path, 'rb') as stream:
            raw = stream.read(MAX_BODY + 1)
    if len(raw) > MAX_BODY:
        raise ValueError('Document JSON trop grand')
    try:
        value = json.loads(raw)
    except (ValueError, UnicodeError):
        raise ValueError('Document JSON invalide') from None
    if not isinstance(value, dict):
        raise ValueError('Objet JSON requis')
    return value


def add_parser(sub):
    for group, description in [('reuse', 'Méthodes réutilisables sans appel IA'),
                               ('bridge', 'Relier une IA au monde choisi par MCP'),
                               ('tools', 'Outils MCP installés et explicitement autorisés')]:
        actions = sub.add_parser(group, help=description).add_subparsers(dest='action', required=True)
        actions.add_parser('list')
        if group == 'reuse':
            actions.add_parser('template').add_argument('name')
            actions.add_parser('suggest').add_argument('query')
            actions.add_parser('propose').add_argument('file')
            for action in ('qualify', 'activate', 'retire', 'run', 'report'):
                p = actions.add_parser(action); p.add_argument('id'); p.add_argument('--revision', type=int, required=True)
                if action == 'activate':
                    p.add_argument('--review-digest', required=True); p.add_argument('--confirm', action='store_true')
                if action == 'run':
                    p.add_argument('file'); p.add_argument('--request-id')
                if action == 'report':
                    p.add_argument('receipt'); p.add_argument('--useful', choices=['yes', 'no'], required=True); p.add_argument('--note', default='')
        elif group == 'bridge':
            p = actions.add_parser('grant'); p.add_argument('file'); p.add_argument('--confirm', action='store_true')
            actions.add_parser('config').add_argument('id')
            for action in ('revoke', 'capture'):
                p = actions.add_parser(action); p.add_argument('id'); p.add_argument('--revision', type=int, required=True)
                if action == 'capture': p.add_argument('--action', dest='review_action', choices=['accept', 'reject'], required=True)
            actions.add_parser('serve').add_argument('--grant', required=True)
        else:
            p = actions.add_parser('register'); p.add_argument('file'); p.add_argument('--confirm', action='store_true')
            for action in ('inspect', 'revoke', 'dismiss', 'execute'):
                p = actions.add_parser(action); p.add_argument('id'); p.add_argument('--revision', type=int, required=True)
                if action == 'execute':
                    p.add_argument('--review-digest', required=True); p.add_argument('--confirm', action='store_true')
            p = actions.add_parser('request'); p.add_argument('connector'); p.add_argument('tool'); p.add_argument('file'); p.add_argument('--request-id')


def command(n, args):
    group, action = args.cmd, args.action
    if action == 'list':
        return {'reuse': reuse.catalog, 'bridge': bridge.owner_view, 'tools': connectors.catalog}[group](n)
    if group == 'reuse':
        if action == 'template': return reuse.template(args.name)
        if action == 'suggest': return reuse.suggest(n, args.query)
        if action == 'propose': return reuse.propose(n, _file(args.file))
        if action == 'qualify': return reuse.qualify(n, args.id, args.revision)
        if action == 'activate':
            _confirmed({'confirmed': args.confirm})
            return reuse.activate(n, args.id, args.revision, args.review_digest)
        if action == 'retire': return reuse.retire(n, args.id, args.revision)
        if action == 'run': return reuse.run(n, args.id, _file(args.file), args.revision, request_id=args.request_id)
        if action == 'report': return reuse.report(n, args.id, args.receipt, args.useful == 'yes', args.note, args.revision)
    if group == 'bridge':
        if action == 'grant':
            _confirmed({'confirmed': args.confirm})
            return bridge.create_grant(n, _file(args.file))
        if action == 'config': return bridge.config(n, args.id)
        if action == 'revoke': return bridge.revoke_grant(n, args.id, args.revision)
        if action == 'capture': return bridge.review_capture(n, args.id, args.review_action, args.revision)
        if action == 'serve': return bridge.serve(n, args.grant)
    if group == 'tools':
        if action == 'register':
            _confirmed({'confirmed': args.confirm})
            payload = _file(args.file)
            if 'owner_confirmed' in payload:
                raise ValueError('La confirmation vient de --confirm, pas du document')
            return connectors.register(n, dict(payload, owner_confirmed=True))
        if action == 'inspect': return connectors.inspect(n, args.id, args.revision)
        if action == 'revoke': return connectors.revoke(n, args.id, args.revision)
        if action == 'request': return connectors.request(n, args.connector, args.tool, _file(args.file), request_id=args.request_id)
        if action == 'execute':
            _confirmed({'confirmed': args.confirm})
            return connectors.execute(n, args.id, args.revision, args.review_digest)
        if action == 'dismiss': return connectors.dismiss(n, args.id, args.revision)
    raise ValueError('Action inconnue')
