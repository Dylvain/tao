"""Explicit transfer of selected memory as unverified context, never node state.

The digest detects a damaged document; it does not authenticate its author.
No message, need, resolution, job, identity or permission is imported. Receipts
and the existing memory history are retained together in one state transaction.
"""
import copy
import hashlib
import json
import re
from datetime import datetime

import tao_dialogue as dialogue
import tao_worlds as worlds
from tao_work import check_revision, text_field

SCHEMA = 'tao.handoff.v1'
MAX_BYTES = 256 * 1024
MAX_MEMORY = 12000
MAX_RECEIPTS = 40
SOURCE_FIELDS = {'node_id', 'world_id', 'title', 'node_version', 'exported_at'}
FIELDS = {'schema', 'version', 'id', 'source', 'text', 'sha256'}


def _bytes(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(',', ':'), allow_nan=False).encode('utf-8')
    except (TypeError, ValueError, RecursionError, UnicodeError) as exc:
        raise ValueError('Document de mémoire JSON invalide.') from exc


def _digest(value):
    return hashlib.sha256(_bytes(value)).hexdigest()


def _content_digest(document):
    source = document['source']
    return _digest({'node_id': source['node_id'], 'world_id': source['world_id'],
                    'text': document['text']})


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Champ JSON répété : document de mémoire ambigu.')
        result[key] = value
    return result


def validate(document):
    """Validate a private envelope without trusting provenance or changing state."""
    if isinstance(document, (str, bytes)):
        try:
            raw = document.encode('utf-8') if isinstance(document, str) else document
            if len(raw) > MAX_BYTES:
                raise ValueError('Document de mémoire trop volumineux : 256 Kio maximum.')
            document = json.loads(raw.decode('utf-8'), object_pairs_hook=_unique_object)
        except (UnicodeError, RecursionError, json.JSONDecodeError) as exc:
            raise ValueError('Document de mémoire JSON illisible.') from exc
    if not isinstance(document, dict) or set(document) != FIELDS:
        raise ValueError('Champs du document de mémoire invalides ; aucun état exécutable accepté.')
    if len(_bytes(document)) > MAX_BYTES:
        raise ValueError('Document de mémoire trop volumineux : 256 Kio maximum.')
    if document['schema'] != SCHEMA or type(document['version']) is not int or document['version'] != 1:
        raise ValueError('Version du document de mémoire non prise en charge.')
    source = document['source']
    if not isinstance(source, dict) or set(source) != SOURCE_FIELDS:
        raise ValueError('Origine du document de mémoire incomplète.')
    for key, maximum in (('node_id', 100), ('world_id', 100), ('title', 120),
                         ('node_version', 80), ('exported_at', 30)):
        value = source[key]
        text_field(value, 'Origine '+key, maximum, True)
        if any(ord(char) < 32 for char in value):
            raise ValueError('Métadonnées d’origine invalides.')
    if not re.fullmatch(r'node:[A-Za-z0-9._:-]+', source['node_id']):
        raise ValueError('Identifiant du nœud d’origine invalide.')
    if not re.fullmatch(r'main|[a-f0-9]{12}', source['world_id']):
        raise ValueError('Identifiant de l’espace d’origine invalide.')
    try:
        datetime.strptime(source['exported_at'], '%Y-%m-%dT%H:%M:%SZ')
    except ValueError as exc:
        raise ValueError('Date d’export invalide.') from exc
    text_field(document['text'], 'La mémoire sélectionnée', MAX_MEMORY, True)
    if document['id'] != 'handoff:'+_content_digest(document):
        raise ValueError('Identifiant de contenu invalide ; aucun texte importé.')
    signature = document['sha256']
    if (not isinstance(signature, str) or not re.fullmatch(r'[a-f0-9]{64}', signature) or
            signature != _digest({key: value for key, value in document.items() if key != 'sha256'})):
        raise ValueError('Empreinte du document invalide ; aucun texte importé.')
    return copy.deepcopy(document)


def export(n, world='current'):
    """Export only the current selected memory of the explicitly chosen world."""
    ident = worlds.current() if world == 'current' else world
    with worlds.using(ident), n.LOCK:
        state = n.load_state()
        metadata = worlds.describe(n, state)['current']
        text = state.get('dialogue', {}).get('memory', '')
        text_field(text, 'La mémoire sélectionnée à exporter', MAX_MEMORY, True)
        document = {'schema': SCHEMA, 'version': 1,
                    'source': {'node_id': state['id'], 'world_id': ident,
                               'title': metadata['title'], 'node_version': n.NODE_VERSION,
                               'exported_at': n.now()}, 'text': text}
        document['id'] = 'handoff:'+_content_digest(document)
        document['sha256'] = _digest(document)
        return validate(document)


def _block(document):
    source = document['source']
    return '\n'.join([
        '## Mémoire extérieure choisie — contexte non vérifié',
        'Origine déclarée, non authentifiée : '+json.dumps(source, ensure_ascii=False, sort_keys=True),
        'Document : '+document['id'],
        'Ce choix importe du texte seulement : aucun fait confirmé, résultat vérifié ou droit d’exécution.',
        '', *['> '+line for line in document['text'].split('\n')],
        '', 'Fin de la mémoire extérieure sélectionnée.'
    ])


def import_memory(n, document, revision=0):
    """Append explicitly selected external context, preserving local memory."""
    document = validate(document)
    with n.LOCK:
        state = n.load_state(); memory = dialogue.ensure(state)
        receipts = memory.get('handoff_receipts', [])
        if not isinstance(receipts, list) or any(not isinstance(row, dict) for row in receipts):
            raise ValueError('Journal des transferts de mémoire invalide ; aucune donnée remplacée.')
        existing = next((row for row in receipts if row.get('id') == document['id']), None)
        result = {'id': document['id'], 'sha256': document['sha256'],
                  'source': copy.deepcopy(document['source']), 'revision': memory['revision']}
        if existing:
            if existing.get('content_sha256') != _content_digest(document):
                raise ValueError('Reçu de mémoire incohérent ; aucune donnée remplacée.')
            return dict(result, imported=False, already_imported=True)
        check_revision(revision, memory['revision'])
        if len(receipts) >= MAX_RECEIPTS:
            raise ValueError('Quarante transferts de mémoire conservés ; aucun reçu effacé.')
        if len(memory['memory_history']) >= 40:
            raise ValueError('40 versions de mémoire conservées ; ouvrir une nouvelle discussion pour les archiver et poursuivre.')
        combined = '\n\n'.join(part for part in (memory['memory'], _block(document)) if part)
        combined = text_field(combined, 'Mémoire totale après import', MAX_MEMORY, True)
        # Same revision, size and history rules as dialogue.save_memory, with the
        # receipt in the same atomic write: no crash gap can duplicate the text.
        memory['memory_history'].append({'text': memory['memory'], 'at': n.now(),
                                         'include_archives': memory.get('include_archives', False)})
        memory.update(memory=combined, revision=memory['revision']+1,
                      context_version=memory['context_version']+1,
                      memory_source='user_selected_context_not_verified')
        memory.setdefault('handoff_receipts', []).append({
            'schema': 'tao.handoff.receipt.v1', 'id': document['id'],
            'sha256': document['sha256'], 'content_sha256': _content_digest(document),
            'source': copy.deepcopy(document['source']), 'received_at': n.now(),
            'destination_world_id': worlds.current(),
            'status': 'human_selected_external_unverified', 'origin_authenticated': False,
            'authority': 'context_only', 'permissions': 'none', 'execution_enabled': False})
        n.atomic_json(n.STATE, state, backup=True)
        return dict(result, revision=memory['revision'], imported=True, already_imported=False)
