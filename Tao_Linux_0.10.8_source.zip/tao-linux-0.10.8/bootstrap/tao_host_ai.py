"""Owner-only, bounded Codex device login; credential files stay with Codex.

The host gateway authenticates every route before dispatching here. Only a
validated device URL and short code can leave this module; CLI output is never
logged, returned, or persisted by Tao. No model request is made by this module.
"""
from __future__ import annotations

import fcntl
import json
import os
import re
import selectors
import shutil
import signal
import subprocess
import threading
import time
import urllib.parse


DEVICE_URL='https://auth.openai.com/codex/device'
AUTH_TIMEOUT=600
STATUS_TIMEOUT=5
STATUS_CACHE_SECONDS=15
OUTPUT_LIMIT=65536
_ANSI=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
_URL=re.compile(r'https?://[^\s<>"\x00-\x20]+')
_CODE=re.compile(r'[A-Z0-9]{2,12}(?:-[A-Z0-9]{2,12}){0,3}')
_CODE_LABEL=re.compile(r'(?:2\.\s*)?Enter this one-time code(?: \(expires in [0-9]{1,2} minutes?\))?:?')
_ENV_KEYS={'PATH','HOME','CODEX_HOME','LANG','LC_ALL','LC_CTYPE','TMPDIR','TEMP','TMP',
           'SSL_CERT_FILE','SSL_CERT_DIR','CODEX_CA_CERTIFICATE',
           'HTTPS_PROXY','HTTP_PROXY','ALL_PROXY','NO_PROXY',
           'https_proxy','http_proxy','all_proxy','no_proxy'}


def _environment():
    # Inherit the configured persistent Codex home, not project/deployment
    # secrets, API keys, gateway credentials, or another person's auth cache.
    env={key:value for key,value in os.environ.items() if key in _ENV_KEYS}
    env.update(NO_COLOR='1',TERM='dumb')
    return env


def _instructions(text):
    """Parse only complete visible lines, allowing common terminal colouring."""
    text=_ANSI.sub('',text)
    urls=_URL.findall(text)
    if any(url!=DEVICE_URL for url in urls):
        raise ValueError('unsupported_login_output')
    codes=[];expect_code=False
    for line in text.splitlines():
        line=line.strip()
        if not line:continue
        if expect_code:
            if not 6<=len(line)<=32 or not _CODE.fullmatch(line):raise ValueError('unsupported_login_output')
            codes.append(line);expect_code=False
        elif _CODE_LABEL.fullmatch(line):expect_code=True
    if len(set(codes))>1: raise ValueError('ambiguous_login_output')
    return (DEVICE_URL,codes[0]) if urls and codes else (None,None)


def _stop(proc):
    if proc is None: return
    if proc.poll() is None:
        try: os.killpg(proc.pid,signal.SIGTERM)
        except ProcessLookupError: pass
        try: proc.wait(timeout=1)
        except subprocess.TimeoutExpired:
            try: os.killpg(proc.pid,signal.SIGKILL)
            except ProcessLookupError: pass
            proc.wait(timeout=1)
    else: proc.wait()


class HostAI:
    def __init__(self,n,codex_executable=None):
        self.n=n
        self.executable=codex_executable
        self.lock=threading.RLock()
        self.probe_lock=threading.Lock()
        self.thread=None
        self.cancelled=threading.Event()
        self.closed=False
        self.state='idle'
        self.connected=None
        self.checked_at=None
        self.checked_monotonic=None
        self.verification_url=None
        self.user_code=None
        self.expires_at=None
        self.deadline=None
        self.message='Vérifier la connexion de Codex sur ce serveur.'

    def _exe(self):
        return self.executable or shutil.which('codex')

    def _environment(self):
        return _environment()

    def _clear_code(self):
        self.verification_url=None;self.user_code=None;self.expires_at=None

    def _probe(self,force=False):
        with self.probe_lock:
            with self.lock:
                if (not force and self.checked_monotonic is not None and
                        time.monotonic()-self.checked_monotonic<STATUS_CACHE_SECONDS):
                    return self.connected
            exe=self._exe();proc=None;connected=None
            try:
                if exe:
                    proc=subprocess.Popen([exe,'login','status'],cwd=self.n.ROOT,env=self._environment(),
                        stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
                    connected=proc.wait(timeout=STATUS_TIMEOUT)==0
            except (OSError,subprocess.SubprocessError):
                connected=None
            finally:
                try:_stop(proc)
                except (OSError,subprocess.SubprocessError):connected=None
            with self.lock:
                self.connected=connected;self.checked_at=int(time.time());self.checked_monotonic=time.monotonic()
            return connected

    def _snapshot(self):
        with self.lock:
            active=bool(self.thread and self.thread.is_alive())
            if active and self.deadline is not None and time.monotonic()>=self.deadline:
                self._clear_code()
            return {'schema':'tao.host.ai.v1','cli_available':bool(self._exe()),'connected':self.connected,
                    'state':self.state,'message':self.message,'login_in_progress':active,
                    'verification_url':self.verification_url,'user_code':self.user_code,
                    'expires_at':self.expires_at,'checked_at':self.checked_at,
                    'verification':'codex_login_status_exit_code_only','model_request_sent':False,
                    'limits':'La connexion du CLI ne garantit ni les quotas disponibles, ni la qualité d’une réponse.'}

    def status(self):
        with self.lock:active=bool(self.thread and self.thread.is_alive())
        if not active:
            connected=self._probe()
            with self.lock:
                if self.thread and self.thread.is_alive():return self._snapshot()
                if connected:
                    self.state='connected';self.message='Codex confirme sa connexion sur ce serveur.';self._clear_code()
                elif not self._exe():
                    self.state='unavailable';self.message='Codex CLI manque sur ce serveur. Vérifier le déploiement.'
                elif self.state in {'idle','connected','unavailable'}:
                    self.state='disconnected' if connected is False else 'unconfirmed'
                    self.message='Codex ne confirme pas de connexion sur ce serveur.'
        return self._snapshot()

    def start(self):
        # Reuse an existing flow without extending its expiration or spawning
        # another login process when a browser retries the same POST.
        with self.lock:
            if self.closed: raise ValueError('Le service de connexion est arrêté.')
            if self.thread and self.thread.is_alive(): return self._snapshot()
        if self._probe() is True:return self.status()
        with self.lock:
            if self.closed: raise ValueError('Le service de connexion est arrêté.')
            if self.thread and self.thread.is_alive(): return self._snapshot()
            exe=self._exe()
            if not exe: return self.status()
            self.n.ROOT.mkdir(parents=True,exist_ok=True,mode=0o700)
            guard=open(self.n.ROOT/'host-ai-login.lock','a+')
            os.chmod(self.n.ROOT/'host-ai-login.lock',0o600)
            try:fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:
                guard.close();raise ValueError('Une connexion Codex est déjà en cours sur ce serveur.') from None
            self.cancelled=threading.Event();self._clear_code()
            self.deadline=time.monotonic()+AUTH_TIMEOUT;self.expires_at=int(time.time())+AUTH_TIMEOUT
            self.state='starting';self.message='Préparation du code de connexion…'
            self.thread=threading.Thread(target=self._login,args=(exe,guard,self.cancelled),daemon=True)
            try:self.thread.start()
            except BaseException:guard.close();self._clear_code();self.state='failed';raise
            return self._snapshot()

    def _login(self,exe,guard,cancelled):
        proc=None;raw=bytearray();outcome='failed'
        message='Connexion non confirmée. Vérifier que le login par code est autorisé dans les paramètres de sécurité ChatGPT ou par le workspace.'
        try:
            proc=subprocess.Popen([exe,'login','--device-auth'],cwd=self.n.ROOT,env=self._environment(),stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True,bufsize=0,
                pass_fds=(guard.fileno(),))
            with selectors.DefaultSelector() as selector:
                selector.register(proc.stdout,selectors.EVENT_READ)
                while selector.get_map():
                    if cancelled.is_set():outcome='cancelled';break
                    if time.monotonic()>=self.deadline:outcome='expired';break
                    for key,_ in selector.select(.1):
                        chunk=os.read(key.fileobj.fileno(),4096)
                        if not chunk:selector.unregister(key.fileobj);continue
                        raw.extend(chunk)
                        if len(raw)>OUTPUT_LIMIT:raise ValueError('output_limit')
                        visible=raw.decode('utf-8',errors='replace')
                        # A partial chunk must not publish a truncated code/URL.
                        complete=visible[:max(visible.rfind('\n'),visible.rfind('\r'))+1]
                        url,code=_instructions(complete)
                        if url and code:
                            with self.lock:
                                if not cancelled.is_set():
                                    self.verification_url=url;self.user_code=code;self.state='awaiting_authorization'
                                    self.message='Ouvrir le site officiel OpenAI et y saisir ce code pour connecter ce serveur.'
                while proc.poll() is None and not cancelled.is_set() and outcome!='expired':
                    if time.monotonic()>=self.deadline:outcome='expired';break
                    cancelled.wait(.1)
                if not cancelled.is_set() and outcome!='expired':
                    code=proc.wait(timeout=1)
                    with self.lock:self._clear_code();self.state='checking'
                    if code==0 and self._probe(force=True) is True:
                        outcome='connected';message='Codex confirme sa connexion sur ce serveur.'
        except subprocess.TimeoutExpired:
            outcome='expired'
        except (OSError,ValueError,subprocess.SubprocessError):
            outcome='failed'
        finally:
            try:_stop(proc)
            finally:
                if proc and proc.stdout:proc.stdout.close()
                raw.clear();guard.close()
                with self.lock:
                    self._clear_code();self.deadline=None
                    if cancelled.is_set():outcome='cancelled'
                    if outcome=='cancelled':message='Demande annulée. Un compte déjà connecté reste connecté.'
                    elif outcome=='expired':message='Ce code a expiré. Relancer une demande de connexion si nécessaire.'
                    self.state=outcome;self.message=message

    def cancel(self):
        with self.lock:
            if self.thread and self.thread.is_alive():
                self.cancelled.set();self._clear_code();self.state='cancelling';self.message='Arrêt de cette demande de connexion…'
            return self._snapshot()

    def close(self):
        with self.lock:self.closed=True;thread=self.thread
        self.cancel()
        if thread:thread.join(timeout=STATUS_TIMEOUT+3)

    def route(self,handler):
        path=urllib.parse.urlsplit(handler.path).path
        if path not in {'/host/ai','/host/ai/status','/host/ai/start','/host/ai/cancel'}:return False
        session=getattr(handler,'auth_session',None)
        if not isinstance(session,dict) or not session.get('id'):
            handler.json(401,{'error':'Connexion propriétaire requise.'});return True
        if handler.command=='GET' and path=='/host/ai':
            token=json.dumps(handler.browser_token()).replace('<','\\u003c')
            handler.send_body(200,PAGE.replace('__TOKEN__',token).encode(),'text/html; charset=utf-8');return True
        if handler.command=='GET' and path=='/host/ai/status':
            handler.json(200,self.status());return True
        if handler.command=='POST' and path in {'/host/ai/start','/host/ai/cancel'}:
            if getattr(handler,'body_value',None)!={}:
                handler.json(400,{'error':'Cette action n’accepte aucun paramètre.'});return True
            try:handler.json(200,self.start() if path.endswith('/start') else self.cancel())
            except ValueError as exc:handler.json(409,{'error':str(exc)})
            return True
        handler.json(405,{'error':'Méthode non autorisée.'});return True


PAGE='''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Connecter Codex à Tao</title>
<style>
:root{color-scheme:light;--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47;--gold:#c79d67}
*{box-sizing:border-box}body{font:16px/1.6 system-ui,sans-serif;background:radial-gradient(circle at 88% -10%,#eee3d2,transparent 38%),var(--bg);color:var(--text);margin:0;padding:24px;min-height:100vh}main{max-width:680px;margin:5vh auto;padding:clamp(24px,5vw,42px);background:linear-gradient(145deg,var(--panel),#f8f5ee);border:1px solid var(--line);border-top:3px solid var(--gold);border-radius:20px;box-shadow:0 16px 42px rgba(39,55,47,.07)}
.brand{font:600 29px/1 ui-serif,Georgia,serif;letter-spacing:-.045em}.brand span{color:var(--gold)}.eyebrow{font-size:11px;letter-spacing:.15em;text-transform:uppercase;font-weight:700;color:var(--accent);margin-top:32px}h1{font:500 clamp(30px,5vw,43px)/1.16 ui-serif,Georgia,serif;letter-spacing:-.03em;margin:8px 0 15px}p{overflow-wrap:anywhere}a{color:var(--accent);text-underline-offset:3px}
button{font:inherit;min-height:44px;padding:11px 17px;border:1px solid var(--accent);border-radius:9px;margin:8px 8px 8px 0;background:var(--accent);color:#fff;font-weight:600;cursor:pointer}button:disabled{opacity:.55;cursor:not-allowed}button.secondary{background:#edf1ea;color:var(--accent);border-color:var(--line)}code{display:block;font-size:1.8rem;letter-spacing:.12em;margin:16px 0;overflow-wrap:anywhere;color:var(--text)}.muted{color:var(--muted)}
#pairing{padding:20px;border:1px solid var(--line);border-left:3px solid var(--gold);border-radius:12px;background:#f7f4ed}#status{padding:13px 16px;background:#edf1ea;border:1px solid var(--line);border-radius:10px}[hidden]{display:none!important}:focus-visible{outline:3px solid var(--accent);outline-offset:3px}@media(max-width:560px){body{padding:14px}main{margin:2vh auto;padding:24px 18px;border-radius:16px}button{width:100%;margin-right:0}}
</style>
<main><div class="brand">tao<span>.</span></div><p class="eyebrow">Le seuil des IA</p><h1>Connecter mon IA</h1><p>Relie ton compte Codex à ce Tao hébergé. Tu peux ensuite discuter depuis le navigateur de ton téléphone ou de ton ordinateur.</p><p><a href="/">← Revenir à Tao</a></p>
<p id="status" role="status" aria-live="polite">Vérification de la connexion…</p><section id="pairing" hidden><p>Ouvre le site officiel OpenAI, connecte-toi et saisis ce code :</p><code id="code"></code><button id="copy" class="secondary">Copier le code</button><p><a id="auth" href="https://auth.openai.com/codex/device" target="_blank" rel="noopener noreferrer">Ouvrir OpenAI pour connecter ce serveur</a></p><p class="muted">Ce code est personnel et temporaire. Il sera effacé à la fin de cette demande.</p></section>
<button id="start" disabled>Connecter Codex sur ce serveur</button><button id="cancel" class="secondary" hidden>Annuler cette demande</button><button id="refresh" class="secondary">Vérifier la connexion</button><p id="session-expired" hidden><a href="/host/login">Me reconnecter à mon Tao</a></p>
<p class="muted">Si aucun code n’apparaît, active la connexion par code d’appareil dans les paramètres de sécurité de ChatGPT, ou demande la permission correspondante à l’administrateur de ton workspace.</p>
<p class="muted">La connexion est conservée par Codex sur ce serveur. Ce parcours ne copie pas les identifiants de ton ordinateur. Annuler la demande ne déconnecte pas un compte déjà connecté.</p><p class="muted">Le statut confirme seulement la connexion du CLI : les quotas disponibles et la qualité des réponses seront à vérifier lors de tes échanges. Aucun appel au modèle n’est lancé ici.</p>
<p><a href="https://developers.openai.com/codex/auth/" target="_blank" rel="noopener noreferrer">Comprendre la connexion Codex</a></p></main>
<script>const token=__TOKEN__;let timer,sequence=0,posting=false,sessionLost=false;const el=id=>document.getElementById(id);
function hideCode(){el('pairing').hidden=true;el('code').textContent='';el('auth').href='https://auth.openai.com/codex/device'}
function show(s){clearTimeout(timer);el('status').textContent=s.message;const paired=!!(s.verification_url&&s.user_code);el('pairing').hidden=!paired;el('code').textContent=paired?s.user_code:'';el('auth').href=paired?s.verification_url:'https://auth.openai.com/codex/device';el('start').disabled=!!s.login_in_progress||s.connected===true||!s.cli_available;el('cancel').hidden=!s.login_in_progress;el('cancel').disabled=false;el('refresh').disabled=false;if(s.login_in_progress)timer=setTimeout(refresh,1500)}
function failure(message,expired=false){clearTimeout(timer);hideCode();el('status').textContent=message;el('start').disabled=true;el('cancel').hidden=true;el('refresh').disabled=expired;sessionLost=expired;el('session-expired').hidden=!expired}
async function request(path,post=false){if(posting||sessionLost)return;const current=++sequence;clearTimeout(timer);if(post){posting=true;el('start').disabled=true;el('cancel').disabled=true;el('refresh').disabled=true}try{const r=await fetch(path,{method:post?'POST':'GET',cache:'no-store',headers:post?{'Content-Type':'application/json','X-Tao-Token':token}:{},body:post?'{}':undefined});const data=await r.json();if(current!==sequence)return;if(r.status===401||r.status===403){failure('Ta session propriétaire a expiré ou doit être renouvelée. Reconnecte-toi pour continuer.',true);return}if(!r.ok)throw Error(data.error||'Connexion indisponible.');show(data)}catch(e){if(current===sequence)failure(post?'Résultat de cette action non confirmé. Vérifie la connexion avant de relancer une action.':(e.message||'Connexion momentanément indisponible.'))}finally{if(current===sequence)posting=false}}
async function refresh(){await request('/host/ai/status')}
el('start').onclick=async()=>{if(!el('start').disabled)await request('/host/ai/start',true)};
el('cancel').onclick=async()=>{if(!el('cancel').disabled&&!el('cancel').hidden)await request('/host/ai/cancel',true)};
el('copy').onclick=async()=>{try{await navigator.clipboard.writeText(el('code').textContent)}catch(e){el('status').textContent='Sélectionne le code pour le copier.'}};el('refresh').onclick=refresh;el('start').disabled=true;refresh();</script></html>'''
