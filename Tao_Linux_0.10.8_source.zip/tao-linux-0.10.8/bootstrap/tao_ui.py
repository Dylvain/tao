"""Local UI; all user text is escaped and mutation requests use a per-process token."""
import html, json, os
import tao_learning as learning


def hosted():
    return os.environ.get('TAO_HOSTED')=='1'

# Browser-local drafts only. This helper is also exercised without a browser.
DRAFT_STORE_JS = r'''
function createDraftStore(storage,node,world){
  const key='tao-form-drafts:'+node+':'+world, limit=200000;
  function read(){try{const raw=storage.getItem(key);if(!raw||raw.length>limit)return {};const parsed=JSON.parse(raw);return parsed&&parsed.version===1&&parsed.entries&&typeof parsed.entries==='object'&&!Array.isArray(parsed.entries)?parsed.entries:{}}catch(e){return {}}}
  function commit(entries){try{const raw=JSON.stringify({version:1,entries});if(Object.keys(entries).length>60||raw.length>limit)return false;storage.setItem(key,raw);return true}catch(e){return false}}
  function put(id,record){if(typeof id!=='string'||id.length>400)return false;const entries=read();entries[id]=record;return commit(entries)}
  function drop(id){const entries=read();delete entries[id];return commit(entries)}
  return {read,put,drop};
}
function draftFields(form){return [...form.querySelectorAll('textarea,input,select')].filter(field=>field.id||field.name).filter(field=>field.tagName==='TEXTAREA'||field.tagName==='SELECT'||(field.tagName==='INPUT'&&['text','search','url','email'].includes(field.type)));}
function draftValues(form){return Object.fromEntries(draftFields(form).map(field=>[field.id||field.name,field.value]));}
function restoreDraftFields(form,values){for(const field of draftFields(form)){const value=values[field.id||field.name];if(typeof value!=='string'||value.length>12000)continue;if(field.tagName==='SELECT'&&![...field.options].some(option=>option.value===value))continue;if(field.maxLength>0&&value.length>field.maxLength)continue;field.value=value;}}
'''

HANDOFF_JS = r'''
async function handoffDocument(file,revision){
  if(!file)throw new Error('Choisis le fichier JSON exporté depuis ta mémoire Tao.');
  if(file.size>262144)throw new Error('Ce fichier dépasse la limite de 256 Kio. Aucun import envoyé.');
  let value;try{value=JSON.parse(await file.text())}catch(e){throw new Error('Ce fichier ne contient pas un JSON lisible. Aucun import envoyé.')}
  if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('Un document de transfert Tao est attendu. Aucun import envoyé.');
  const data={document:value,revision};
  if(new TextEncoder().encode(JSON.stringify(data)).byteLength>262144)throw new Error('Ce transfert dépasse la limite de 256 Kio. Aucun import envoyé.');
  return data;
}
'''

# A read-only lookup while composing a message. Older requests must never
# replace suggestions for a newer message or trigger a model/tool call.
REUSE_SUGGESTIONS_JS = r'''
function createReuseSuggestions(fetchRows,render){
 let version=0;
 return async function lookup(text){
  const request=++version,query=String(text).trim().slice(0,1000);
  if(!query){render({status:'empty',rows:[]});return}
  try{
   const rows=await fetchRows(query);
   if(request!==version)return;
   if(!Array.isArray(rows))throw Error('Réponse de recherche invalide');
   const active=rows.filter(row=>row&&row.status==='active'&&typeof row.id==='string'&&/^[a-f0-9]{12}$/.test(row.id)&&typeof row.title==='string').slice(0,3);
   render({status:active.length?'matches':'empty',rows:active});
  }catch(error){if(request===version)render({status:'unavailable',rows:[]})}
 };
}
'''

# An explorer action prepares text only. It never replaces a dialogue draft,
# restores permissions, or sends a message when the page opens.
EXPLORER_DRAFT_JS = r'''
try{
 const key='tao-explorer-draft:'+dialogueForm.dataset.node+':'+worldId;
 const raw=sessionStorage.getItem(key),value=raw&&raw.length<=48000?JSON.parse(raw):null;
 if(value&&typeof value.text==='string'&&value.text.trim()&&value.text.length<=6000){
  const panel=document.querySelector('#drafts-panel'),list=document.querySelector('#drafts-list'),card=document.createElement('div');card.className='draft-card';
  const title=document.createElement('p');title.textContent='Question préparée depuis mes espaces';const preview=document.createElement('pre');preview.textContent=value.text;
  const add=document.createElement('button');add.type='button';add.textContent='Ajouter à ma discussion';add.onclick=()=>{
   if(dialogueForm.dataset.pendingDraft){message('Récupère ou écarte d’abord le brouillon existant de ta discussion.',true);return}
   const input=document.querySelector('#dialogue-text'),text=input.value?input.value+'\n\n'+value.text:value.text;
   if(text.length>6000){message('Ta discussion contient déjà un long brouillon. Envoie-le ou raccourcis-le avant d’ajouter cette question.',true);return}
   const focus=value.focus,landmarkFocus=focus&&focus.kind==='landmark'&&/^[a-f0-9]{12}$/.test(focus.id)&&Number.isSafeInteger(focus.revision)&&focus.revision>0,spaceFocus=focus&&focus.kind==='space'&&focus.id===worldId&&Number.isSafeInteger(focus.revision)&&focus.revision>=0;
   if(landmarkFocus||spaceFocus){selectedFocus={focus:{kind:focus.kind,id:focus.id,revision:focus.revision},label:spaceFocus?'cet espace':'un repère de cet espace'};showFocus()}
   input.value=text;input.dispatchEvent(new Event('input',{bubbles:true}));if(!keepFormDraft(dialogueForm)){message('Garde cette page ouverte : le navigateur ne peut pas conserver cette saisie.',true);return}
   sessionStorage.removeItem(key);card.remove();panel.hidden=!list.children.length;input.focus();input.scrollIntoView({block:'center',behavior:'smooth'});message('Question ajoutée au brouillon. Relis-la avant de l’envoyer.');
  };
  const discard=document.createElement('button');discard.type='button';discard.className='secondary';discard.textContent='Écarter cette question';discard.onclick=()=>{sessionStorage.removeItem(key);card.remove();panel.hidden=!list.children.length};
  card.append(title,preview,add,discard);list.appendChild(card);panel.hidden=false;
 }
}catch(error){}
'''

def challenge_button(kind,ident,revision,label):
    focus=html.escape(json.dumps({'kind':kind,'id':ident,'revision':revision},ensure_ascii=False),quote=True)
    return f'<button type="button" class="challenge-part secondary" data-focus="{focus}" data-label="{html.escape(label,quote=True)}">Questionner avec Tao</button>'


def source_caption(quote):
    if quote.get('message_source') == 'external_history_import':
        kinds = {'user_quote': 'citation humaine déclarée', 'reported_observation': 'observation rapportée',
                 'assistant_summary': 'synthèse IA'}
        return 'Import extérieur · ' + str(quote.get('source_label', 'source déclarée')) + ' · ' + kinds.get(quote.get('source_kind'), 'texte déclaré') + ' · origine non authentifiée'
    return str(quote.get('at') or '') + ' · mots d’origine'


INTENT_LABELS={'auto':'À préciser ensemble','understand':'Comprendre','learn':'Apprendre à faire',
               'delegate':'Préparer une délégation','improve':'Améliorer Tao'}


def render_routing(message,latest=False,current=True):
    """A reasoning contribution is a proposal, never a tool authorization."""
    esc=lambda value:html.escape(str(value or ''),quote=True)
    trace=message.get('routing_trace')
    if not isinstance(trace,dict):return ''
    route=trace.get('route') or {};contributions=route.get('contributions') or []
    contributions=[x for x in contributions if isinstance(x,dict)]
    result=''
    if latest and contributions:
        first=contributions[0]
        label='Une piste pour la suite' if current else 'Une piste issue de cet échange · contexte modifié depuis'
        result=f'<div class="next-contribution"><p class="eyebrow">{label}</p><p><b>{esc(first.get("title"))}</b></p><p>{esc(first.get("expected"))}</p>'
        if current:
            text='Poursuivons cette piste : '+str(first.get('title',''))+'. '+str(first.get('expected',''))
            result+=f'<button type="button" class="continue-route secondary" data-text="{esc(text[:1800])}">En parler avec Tao</button>'
        result+='<p class="muted caption">Piste proposée. Ce bouton prépare un message ; aucune action extérieure n’est lancée.</p></div>'
    result+='<details class="routing-trace"><summary>Comment Tao a orienté cette réponse</summary>'
    result+='<p>Pour cet échange : '+esc(INTENT_LABELS.get(trace.get('human_intent'),'À préciser ensemble'))+'.</p>'
    if route.get('intent'):
        result+='<p>Intention comprise : '+esc(route['intent'])+'. Tu peux la corriger dans ton prochain message.</p>'
    for contribution in contributions:
        result+='<p><b>'+esc(contribution.get('title'))+'</b> · '+esc(contribution.get('function_id'))+' @ '+esc(contribution.get('function_version'))+'</p>'
        result+='<p>'+esc(contribution.get('reason'))+'</p><p>Résultat recherché : '+esc(contribution.get('expected'))+'</p>'
        result+='<small>Sources de cette proposition : '+esc(', '.join(str(x) for x in contribution.get('source_ids',[])))+'. Opérateurs : '+esc(', '.join(str(x) for x in contribution.get('operators',[])))+'.</small>'
    for warning in trace.get('warnings',[]):result+='<p class="muted">'+esc(warning)+'</p>'
    costs=trace.get('costs') or {}
    if costs:
        seconds=costs.get('measured_wall_seconds')
        duration=f'{seconds:.2f} s' if isinstance(seconds,(float,int)) else 'durée non mesurée'
        result+='<p class="muted caption">Coût de l’échange entier : '+esc(costs.get('cli_attempts'))+' tentative(s) CLI · '+esc(duration)+'. Ce coût n’est pas mesuré par fonction. Tokens, euros et électricité non mesurés.</p>'
    result+='<p class="muted caption">Cette orientation relie des fonctions de raisonnement à cet échange. Elle ne crée ni droit, ni automatisation, ni preuve de réussite.</p></details>'
    return result

def render_worlds(n,s):
    import tao_worlds as worlds
    esc=lambda value:html.escape(str(value or ''))
    meta=worlds.describe(n,s);current=meta['current'];prefs=s.get('presentation',{})
    crumbs=' <span aria-hidden="true">/</span> '.join(f'<a href="/?world={x["id"]}" data-world-link>{esc(x["title"])}</a>' for x in meta['path'])
    options=''.join(f'<option value="{x["id"]}" {"selected" if x["id"]==current["id"] else ""}>{esc(x["title"])}</option>' for x in meta['spaces'])
    lenses={'needs':'Besoins','problems':'Problèmes','objectives':'Objectifs','solutions':'Pistes de solution'}
    views=''.join(f'<option value="{k}" {"selected" if prefs.get("view","needs")==k else ""}>{v}</option>' for k,v in lenses.items())
    question=challenge_button('space',current['id'],meta['revision'],'cet espace : '+current['title'])
    return f'''<section class="world-panel" aria-label="Mes espaces"><p class="eyebrow">Ici : {esc(current['title'])}</p><p>{crumbs}</p><div class="columns"><form id="world-switch"><label for="world-select">Aller dans un espace</label><select id="world-select">{options}</select><button class="secondary">Ouvrir</button></form><form id="world-presentation" data-revision="{prefs.get('revision',0)}"><label for="world-view">Regarder la situation par les…</label><select id="world-view">{views}</select><button class="secondary">Choisir cette vue</button></form></div><p class="muted caption">La barre de gauche garde toutes les vues de cet espace au même endroit. Chaque espace conserve sa discussion, sa mémoire et ses besoins ; tu choisis les extraits à transmettre.</p>{question}<p><a href="/history?world={current['id']}">Retrouver les conversations importées dans cet espace</a></p><details><summary>Créer un espace dans {esc(current['title'])}</summary><form id="world-create" data-parent="{current['id']}" data-revision="{meta['revision']}"><label for="world-title">Son nom</label><input id="world-title" maxlength="120" required placeholder="Mon travail, ma famille, un projet…"><label for="world-description">À quoi servira-t-il ? (facultatif)</label><textarea id="world-description" maxlength="1000"></textarea><button>Créer et ouvrir</button></form></details></section>'''

def render_transfer(n,s,m):
    import tao_worlds as worlds
    esc=lambda value:html.escape(str(value or ''))
    meta=worlds.describe(n,s);others=[x for x in meta['spaces'] if x['id']!=meta['current']['id']]
    if not others:return ''
    key=esc(m['id']);options=''.join(f'<option value="{x["id"]}">{esc(x["title"])}</option>' for x in others)
    return f'''<details><summary>Transmettre un extrait à un autre espace</summary><p class="muted caption">Seul ce que tu sélectionnes est transmis, avec sa source. Une réponse de Tao reste une réponse IA à vérifier. Ce transfert ne lance aucune action.</p><form class="world-transfer" data-message="{key}" data-revision="{meta['revision']}"><label for="target-{key}">Espace destinataire</label><select name="target_id" id="target-{key}">{options}</select><label for="quote-{key}">Extrait exact à transmettre</label><textarea name="source_quote" id="quote-{key}" maxlength="4000" required>{esc(m['text'][:4000])}</textarea><label for="summary-{key}">Ce que je souhaite en rapprocher ou comprendre</label><textarea name="text" id="summary-{key}" maxlength="4000" required placeholder="Pourquoi cet extrait est utile dans l’autre espace…"></textarea><button>Transmettre cet extrait</button></form></details>'''

def render_continuity(n,s):
    esc=lambda v:html.escape(str(v or ''))
    memory=s.get('continuity',{});revision=memory.get('revision',0)
    needs=[b for b in s.get('buffers',{}).values() if b.get('dialogue_need')]
    opened=[b for b in needs if b.get('status')=='open']
    opened.sort(key=lambda b:(not b['dialogue_need'].get('focused',False),b['dialogue_need'].get('phase')=='paused',b.get('first_seen_at','')))
    focused=next((b for b in opened if b['dialogue_need'].get('focused') and b['dialogue_need'].get('phase')!='paused'),None)
    lens=s.get('presentation',{}).get('view','needs')
    lens_title={'needs':'Les besoins à suivre','problems':'Les problèmes signalés','objectives':'Les objectifs à préciser','solutions':'Les pistes de solution à essayer'}.get(lens,'Les besoins à suivre')
    def action(b,name,label):
        return f'<form class="need-action" data-id="{esc(b["id"])}" data-action="{name}" data-revision="{revision}"><button class="secondary">{label}</button></form>'
    def card(b):
        x=b['dialogue_need'];active=b.get('status')=='open';quote=x.get('source_quote',{})
        phases={'to_clarify':'À clarifier','active':'À explorer','paused':'En pause','reported_resolved':'Résultat déclaré vérifié','withdrawn':'Retiré sans résolution'}
        result=f'<details class="need-card"><summary>{esc(x["title"])} · {phases.get(x.get("phase"),esc(x.get("phase")))}{(" · choisi" if x.get("focused") else "")}</summary>'
        labels={'current':'Situation rapportée','desired':'Résultat souhaité','acceptance':'Comment le vérifier','next_step':'Piste proposée'}
        order={'problems':('current','desired','acceptance','next_step'),'objectives':('desired','acceptance','current','next_step'),'solutions':('next_step','acceptance','current','desired')}.get(lens,('desired','current','next_step','acceptance'))
        result+=''.join(f'<p><b>{labels[k]} :</b> {esc(x.get(k)) or "À préciser ensemble"}</p>' for k in order)
        result+=challenge_button('need',b['id'],x.get('revision',1),'ce besoin : '+x['title'])
        result+=f'<details><summary>Retrouver les mots d’origine</summary><blockquote>{esc(quote.get("quote"))}</blockquote><small>{esc(source_caption(quote))} · interprétation à corriger si nécessaire.</small></details>'
        if active:
            result+='<div class="need-actions">'+(action(b,'focus','Avancer ici') if not x.get('focused') and x.get('phase')!='paused' else '')+action(b,'resume' if x.get('phase')=='paused' else 'pause','Reprendre' if x.get('phase')=='paused' else 'Mettre en pause')+'</div>'
            fields={'title':('Un titre',160),'current':('La situation',1200),'desired':('Ce que je souhaite',1200),'acceptance':('Comment je vérifierai le résultat',1200),'next_step':('La prochaine étape',800)}
            inputs=''.join(f'<label for="need-{esc(b["id"])}-{k}">{label}</label><textarea name="{k}" id="need-{esc(b["id"])}-{k}" maxlength="{limit}" {"required" if k=="title" else ""}>{esc(x.get(k))}</textarea>' for k,(label,limit) in fields.items())
            result+=f'<details><summary>Corriger ce que Tao a compris</summary><form class="need-revise" data-id="{esc(b["id"])}" data-revision="{revision}">{inputs}<button>Conserver ma correction</button></form></details>'
            result+=f'<details><summary>J’ai pu vérifier le résultat</summary><p>Une réponse ou une installation ne suffit pas. Décris ce que tu as essayé et ce que tu as effectivement obtenu.</p><form class="need-resolve" data-id="{esc(b["id"])}" data-revision="{revision}"><label for="evidence-{esc(b["id"])}">Résultat observé et vérification</label><textarea name="evidence" id="evidence-{esc(b["id"])}" maxlength="4000" required></textarea><button>Déclarer ce besoin intégré</button></form></details>'
            result+='<details><summary>Ce besoin ne correspond plus à ce que je veux</summary>'+action(b,'withdraw','Retirer en gardant la trace')+'</details>'
        else:
            result+=action(b,'reopen','Reprendre ce besoin')
        for item in b.get('evidence',[])[-3:]:result+='<p><b>Retour déclaré :</b> '+esc(item.get('text'))+'</p>'
        if x.get('task_ids'): result+='<p><a href="#work-progress">Voir les améliorations préparées pour ce besoin</a></p>'
        return result+'</details>'
    next_step=''
    if focused:
        x=focused['dialogue_need']
        next_step=f'<div class="current-need"><p class="eyebrow">Là où tu as choisi d’avancer</p><h3>{esc(x["title"])}</h3><p>{esc(x.get("next_step"))}</p><button class="continue-need secondary" data-title="{esc(x["title"])}">En parler avec Tao</button><p class="muted caption">Étape proposée ; aucune action extérieure lancée.</p></div>'
    result=f'<div id="continuity-panel">{next_step}<details {"open" if opened and not focused else ""}><summary>{lens_title} · {len(opened)} élément(s)</summary><p class="muted">Ces vues reprennent les mêmes récits : situation, souhait, piste et résultat observé. Une piste n’est pas encore une solution vérifiée. Tu peux corriger ce que Tao comprend et choisir où avancer.</p>'
    result+=''.join(card(b) for b in opened[:8]) or '<p>Aucun besoin retenu pour le moment. Une discussion peut simplement aider à comprendre.</p>'
    if len(opened)>8: result+='<details><summary>Voir les autres besoins conservés</summary>'+''.join(card(b) for b in opened[8:])+'</details>'
    result+='</details>'
    completed=[b for b in needs if b.get('status')!='open']
    if completed:result+='<details><summary>Ce qui a été intégré ou retiré · '+str(len(completed))+'</summary>'+''.join(card(b) for b in completed)+'</details>'
    notes=memory.get('notes',[]);active_notes=[x for x in notes if x.get('status')!='rejected']
    result+=f'<details><summary>Ce que Tao retient entre les discussions · {len(active_notes)} élément(s)</summary><p>Cette mémoire de travail se construit pendant les échanges. Les interprétations restent à vérifier ; tes corrections et les mots d’origine sont conservés.</p><form id="continuity-settings" data-revision="{revision}"><label class="consent"><input id="continuity-enabled" type="checkbox" {"checked" if memory.get("enabled",True) else ""}> Retenir les éléments utiles et les reprendre dans les prochaines réponses.</label><button>Enregistrer ce choix</button></form>'
    kinds={'context':'Contexte','preference':'Préférence','constraint':'Contrainte','question':'Question ouverte'}
    for note in notes:
        key=esc(note['id']);quote=note.get('source_quote',{});status='Retiré' if note.get('status')=='rejected' else 'Relu par toi' if note.get('status')=='kept' else 'Interprétation à vérifier'
        question=challenge_button('note',note['id'],note.get('revision',1),'cette interprétation : '+note['text'][:100])
        result+=f'<details><summary>{kinds.get(note.get("kind"),"Note")} · {status} · {esc(note["text"][:100])}</summary><blockquote>{esc(quote.get("quote"))}</blockquote><small>{esc(source_caption(quote))}</small><form class="continuity-note" data-id="{key}" data-revision="{revision}"><label for="note-{key}">Le texte à garder</label><textarea id="note-{key}" name="text" maxlength="800" required>{esc(note["text"])}</textarea><button name="status" value="kept">Conserver ma version</button><button class="secondary" name="status" value="rejected">Écarter cette interprétation</button></form>{question}</details>'
    result+='<p><a href="/continuity/export" download="tao-continuite.txt">Exporter la mémoire et le suivi des besoins</a></p></details>'
    observed=s.get('observation',{});env=observed.get('environment',{})
    def gib(value): return f'{value/(1024**3):.1f} Gio' if isinstance(value,(int,float)) else 'pas encore mesuré'
    result+=f'<details><summary>Ce que Tao peut observer et faire ici</summary><p>Dernier relevé sur l’ordinateur qui héberge Tao : {esc(observed.get("at") or "en attente")}. Mémoire disponible : {gib(env.get("memory_available"))} ; disque libre : {gib(env.get("disk_free"))}.</p><p>Il reçoit les récits que tu partages et les résultats que tu déclares. La carte reste une interprétation. Les applications métier et les intentions des autres ne sont pas observées automatiquement.</p><p>Le dialogue et l’atelier utilisent Codex lorsque tu les lances. Les comptes et la qualité du modèle restent à vérifier sur ce Linux.</p><p><a href="/lexicon">Comprendre les mots et modèles de Tao</a> · <a href="#advanced">Voir les observations et moyens disponibles</a></p></details></div>'
    return result

def render_dialogue(n,s):
    import tao_dialogue as talk
    import tao_adaptation as adapt
    esc=lambda value:html.escape(str(value or ''))
    d=s.get('dialogue',{}); revision=d.get('revision',0); messages=d.get('messages',[])
    budget=n.ecology.budget(s,n.policy(),n.ecology.day(n),'dialogue')
    rows=[]; current_signature=talk.signature(n,s)
    latest_assistant=next((m for m in reversed(messages) if m['role']=='assistant'),None)
    diagnostic=adapt.diagnose(n);codex_detected=diagnostic.get('codex_detected',False)
    if hosted():
        provider='Codex est détecté sur cette instance hébergée.' if codex_detected else 'Codex n’est pas encore disponible sur cette instance hébergée.'
        readiness='<div class="assistant-readiness"><p><b>'+provider+'</b></p><p>Connecte le modèle depuis ton navigateur, sur téléphone ou ordinateur. Aucun terminal sur ton appareil n’est nécessaire pour cette connexion.</p><p class="muted caption">La présence de Codex ne confirme pas la connexion de ton compte ni ses quotas. Tes messages peuvent être conservés en attendant.</p><a href="/host/ai">Connecter le modèle</a> · <button type="button" class="recheck secondary">Revérifier</button></div>'
    elif codex_detected:
        readiness='<div class="assistant-readiness"><p><b>Codex est détecté sur l’ordinateur qui héberge Tao.</b></p><p class="muted caption">Sa connexion et ses quotas seront vérifiés au prochain envoi. Tu peux discuter sans que l’atelier de code soit prêt.</p><a href="/connect?world='+esc(talk.worlds.current())+'">Vérifier ou connecter mon IA</a></div>'
    else:
        readiness='<div class="assistant-readiness"><p><b>L’assistant attend la connexion de Codex sur l’ordinateur qui héberge Tao.</b></p><p>Tu peux conserver ton message maintenant. Pour obtenir une réponse, installe et connecte Codex sur ce Linux, puis reprends ici.</p><a href="/connect?world='+esc(talk.worlds.current())+'">Préparer ma connexion</a> · <button type="button" class="recheck secondary">Revérifier</button></div>'
    for m in messages[-16:]:
        author='Extrait transmis · '+('réponse IA' if m.get('original_role')=='assistant' else 'paroles rapportées') if m.get('source')=='human_selected_transfer' else 'Toi' if m['role']=='user' else 'Tao'
        body=f'<p class="eyebrow">{author}</p><div class="chat-text">{esc(m["text"])}</div>'
        if m['role']=='user' and m.get('intent','auto')!='auto':body+='<p class="caption">Ton choix pour cet échange : '+esc(INTENT_LABELS.get(m['intent'],'À préciser ensemble'))+'.</p>'
        if m['role']=='assistant':
            captured=m.get('captured',{})
            if captured.get('note_ids') or captured.get('need_ids'):
                body+=f'<p class="caption"><a href="#continuity-panel">{len(captured.get("note_ids",[]))} élément(s) de mémoire et {len(captured.get("need_ids",[]))} besoin(s) conservés</a> · à corriger si nécessaire.</p>'
            for warning in captured.get('warnings',[]): body+='<p class="muted">'+esc(warning)+'</p>'
            reusable=m.get('reusable_capture',{})
            if reusable.get('status')=='candidate':
                body+='<p class="caption">Aide conservée pour examen : <a href="/tools?world='+esc(talk.worlds.current())+'#recipe-'+esc(reusable.get('id'))+'">'+esc(reusable.get('title'))+'</a>. Elle attend ses vérifications et ton activation.</p>'
            for warning in reusable.get('warnings',[]):body+='<p class="muted">'+esc(warning)+'</p>'
            landmark_capture=m.get('landmark_capture',{})
            if landmark_capture.get('ids'):
                body+='<p class="caption"><a href="/explore?world='+esc(talk.worlds.current())+'">'+str(len(landmark_capture['ids']))+' repère(s) proposés dans cet espace</a> · à relire avant de les retenir.</p>'
            for warning in landmark_capture.get('warnings',[]):body+='<p class="muted">'+esc(warning)+'</p>'
            p=m.get('proposal'); valid=m.get('signature')==current_signature
            if m.get('prepared_task'):
                body+='<p><a href="#work-progress">Retrouver cette amélioration dans mes tâches</a></p>'
            elif p:
                body+=f'<details {"open" if valid else ""}><summary>Amélioration proposée : {esc(p["title"])}</summary><p>{esc(p["situation"])}</p><p><b>Résultat attendu :</b> {esc(p["expected"])}</p><p>{esc(p["boundaries"])}</p>'
                if valid:
                    possible=[b for b in s.get('buffers',{}).values() if b.get('dialogue_need') and b.get('status')=='open' and b['dialogue_need'].get('phase')!='paused']
                    link=''
                    if possible:
                        options='<option value="">Sans rattachement</option>'+''.join(f'<option value="{esc(b["id"])}">{esc(b["dialogue_need"]["title"])}</option>' for b in possible)
                        link=f'<label for="link-{esc(m["id"])}">Relier cette aide à un besoin (facultatif)</label><select name="need_id" id="link-{esc(m["id"])}">{options}</select>'
                    body+=f'<form class="dialogue-action" data-action="prepare" data-id="{esc(m["id"])}">{link}<button>Préparer cette amélioration</button><p class="muted caption">Un essai de code sur l’ordinateur qui héberge Tao ; tu reliras les changements avant les tests et l’installation. Si un moyen manque, la fiche reste conservée dans tes tâches.</p></form>'
                else: body+='<p class="muted">Le contexte a évolué depuis cette proposition. Demande-moi de la reformuler avant de la préparer.</p>'
                body+='</details>'
            if m.get('memory_suggestion'):
                body+=f'<details><summary>Une décision à garder ?</summary><p>{esc(m["memory_suggestion"])}</p>'
                if valid: body+=f'<form class="dialogue-action" data-action="remember" data-id="{esc(m["id"])}"><button>Retenir ce texte dans ma mémoire</button></form>'
                body+='</details>'
            body+=render_routing(m,latest=m is latest_assistant,current=valid)
        body+=render_transfer(n,s,m)
        rows.append(f'<article class="chat-turn {"chat-user" if m["role"]=="user" else "chat-assistant"}">{body}</article>')
    status='';context_note=''
    if messages:
        last=next((m for m in reversed(messages) if m['role']=='user' and m.get('job_id')),None)
        if last:
            try:
                job=talk.view(n,last['job_id'])
                context=n.load_json(talk.file(n,last['job_id']).parent/'context.json') or {}
                passages=context.get('recall',{}).get('passages',[])
                sources=''.join(f'<li>{"Toi" if x["role"]=="user" else "Tao (réponse non vérifiée)"} · {esc(x.get("at"))} · {"cette discussion" if x["source"]=="current_discussion" else "discussion archivée"}<p>{esc(x["text"])}{"… (extrait)" if x.get("is_excerpt") else ""}</p></li>' for x in passages)
                imported=context.get('imported_history',{});external=imported.get('excerpts',[])
                for x in external:
                    role='Auteur utilisateur déclaré' if x.get('role')=='user' else 'Réponse IA importée'
                    branch=' · version alternative' if x.get('active_branch') is False else ''
                    sources+=f'<li>{role} · {esc(x.get("title"))}{branch} · source extérieure non vérifiée<p>{esc(x.get("text"))}</p></li>'
                context_note=f'<details><summary>La mémoire utilisée pour cette réponse</summary><p>{len(context.get("memory_selected_by_user",""))} caractères de mémoire choisie · {len(context.get("messages",[]))} messages récents · {len(passages)} passage(s) retrouvé(s) par mots communs.</p><p class="muted">Cette recherche peut manquer des souvenirs. Les extraits gardent leur source ; une ancienne réponse reste à vérifier.</p><ul>{sources}</ul><a href="/dialogue/context?id={esc(job["id"])}" download="tao-contexte.txt">Voir tout le contexte fourni</a></details>'
                if external:context_note+=f'<p class="caption">{len(external)} extrait(s) d’archives importées utilisés. <a href="/history">Consulter les sources de cet espace</a>.</p>'
                if imported.get('warning'):context_note+='<p class="muted">Archives importées : '+esc(imported['warning'])+'</p>'
                if job['status']!='answered':
                    status=f'<div class="dialogue-progress" data-dialogue-id="{esc(job["id"])}" data-state="{esc(job["status"])}"><p role="status">{esc(job["message"])}</p>'
                    if job['status'] in talk.BUSY: status+=f'<form class="dialogue-action" data-action="cancel" data-id="{esc(job["id"])}"><button class="secondary">Arrêter cette réponse</button></form>'
                    elif job.get('log'): status+='<details><summary>Diagnostic local</summary><pre>'+esc(job['log'])+'</pre></details>'
                    if job['status'] in {'blocked','interrupted'} and last is next((m for m in reversed(messages) if m['role']=='user'),None):
                        status+=f'<form class="dialogue-action" data-action="retry" data-id="{esc(job["id"])}" data-revision="{revision}"><button>Reprendre cette question</button><p class="muted caption">Nouvelle tentative explicite avec le contexte actuel. Ta question reste conservée une seule fois ; aucun renvoi automatique.</p></form>'
                    status+='</div>'
            except (ValueError,OSError): status='<p>La trace de cette réponse manque ; le message est conservé.</p>'
    welcome='' if messages else '<p>Raconte-moi ce que tu cherches à comprendre ou à rendre possible. On peut réfléchir ensemble, clarifier tes contraintes, puis préparer une aide concrète.</p>'
    more=f'<p class="muted">Les 16 derniers messages sont affichés sur {len(messages)} conservés.</p>' if len(messages)>16 else ''
    archives=''.join(f'<li><a href="/dialogue/archive?id={esc(a["id"])}" download="tao-dialogue-{esc(a["id"])}.txt">{esc(a["at"])} · {a["messages"]} messages</a></li>' for a in reversed(d.get('archives',[])))
    mapped=next((m for m in reversed(messages) if m.get('situation_map')),None);situation=''
    if mapped:
        labels={'reported':'Ce qui est rapporté','hypotheses':'Hypothèses et questions','objectives':'Objectifs à préciser ensemble','constraints':'Contraintes','people':'Les autres personnes concernées','next_steps':'Prochaines étapes proposées'}
        cards=''.join('<div><h3>'+labels[k]+'</h3><ul>'+''.join('<li>'+esc(x)+'</li>' for x in mapped['situation_map'][k])+'</ul></div>' for k in talk.MAP_FIELDS if mapped['situation_map'][k])
        age=' · contexte modifié depuis' if mapped.get('signature')!=current_signature else ''
        situation=f'<details id="situation-map"><summary>Notre vue de la situation · à vérifier{age}</summary><p class="muted">Synthèse proposée par Tao à partir du dialogue. Corrige-la dans ton prochain message ; elle ne remplace pas tes décisions ni l’accord des autres.</p><div class="columns">{cards}</div></details>'
    intents=''.join(f'<option value="{key}">{label}</option>' for key,label in INTENT_LABELS.items())
    provider_help=('<p>Budget séparé des modifications de code. Tokens et prix non mesurés. La connexion du modèle se fait depuis la page dédiée de cette instance. Le modèle réellement utilisé et sa qualité ne sont pas vérifiés par Tao : ce n’est pas une copie de ta session ChatGPT.</p><a href="/host/ai">Connecter le modèle depuis ce navigateur</a>' if hosted() else '<p>Budget séparé des modifications de code. Tokens et prix non mesurés. Codex doit être installé sur cet hôte. Tu peux vérifier ou connecter ton compte depuis « Connecter mon IA » ; une installation manquante peut encore demander le terminal. Le modèle réellement utilisé et sa qualité ne sont pas vérifiés par Tao : ce n’est pas une copie de ta session ChatGPT.</p><a href="/connect?world='+esc(talk.worlds.current())+'">Préparer ma connexion</a>')
    return f'''<section id="dialogue" class="dialogue-panel" aria-labelledby="dialogue-title"><h2 id="dialogue-title">On réfléchit ensemble, puis on avance.</h2><div id="dialogue-timeline" class="dialogue-timeline" role="log" aria-label="Messages récents et progression" aria-live="off" tabindex="0">{readiness}{welcome}{situation}{more}{''.join(rows)}{status}{context_note}</div>
<form id="dialogue-send" data-revision="{revision}" data-node="{esc(s['id'])}"><p id="dialogue-focus" hidden><span></span> <button type="button" id="clear-focus" class="secondary">Retirer ce contexte</button></p><label for="dialogue-text">Ton message</label><textarea id="dialogue-text" maxlength="6000" required placeholder="Je voudrais comprendre… / Ce qui me bloque… / J’aimerais que Tao puisse…"></textarea><div id="reuse-suggestions" class="next-contribution" role="status" aria-live="polite" hidden></div><details id="dialogue-options"><summary>Orienter cet échange (facultatif)</summary><label for="dialogue-intent">Comment Tao peut-il t’aider ?</label><select id="dialogue-intent" name="intent">{intents}</select><p class="muted caption">Tu peux comprendre, apprendre à faire toi-même ou préparer ce que tu souhaites déléguer. Ce choix oriente la discussion ; il n’autorise aucune action à ta place.</p></details><button type="submit">{'Envoyer à Tao' if codex_detected else 'Conserver ce message'}</button></form>
</section><div class="dialogue-secondary">
<p class="muted caption">Codex reçoit le contexte local utile : mémoire, besoins suivis, histoire, préférences, messages et passages retrouvés, tâches et ressources mesurées. Les éléments retenus restent visibles et corrigeables ci-dessous. Une réponse n’active pas l’atelier.</p>
{render_continuity(n,s)}
<details id="memory-continuity"><summary>Ma mémoire et la continuité</summary><p>Colle ici les décisions et extraits de nos échanges que tu veux garder. Tao ne lit pas automatiquement tes conversations ChatGPT. Tu peux corriger ce texte ; il sera inclus dans les prochaines réponses.</p>
<form id="dialogue-memory" data-revision="{revision}"><label for="dialogue-memory-text">Ce que je souhaite que Tao garde en contexte</label><textarea id="dialogue-memory-text" maxlength="12000" rows="8">{esc(d.get('memory'))}</textarea><label class="consent"><input id="dialogue-archives" type="checkbox" {"checked" if d.get("include_archives") else ""}> Rechercher aussi dans mes discussions archivées et transmettre les extraits pertinents à Codex.</label><button>Enregistrer ma mémoire</button></form>
<p><a href="/dialogue/export" download="tao-dialogue.txt">Exporter cette discussion et sa mémoire</a></p>
<details><summary>Transférer ma mémoire vers un autre Tao</summary><p>Ce transfert volontaire emporte seulement le texte de mémoire déjà enregistré ci-dessus et sa provenance. Il ajoute cette mémoire dans l’espace où tu l’importes, sans remplacer la mémoire déjà présente. Il ne synchronise pas les installations et ne copie ni l’identité du nœud ni sa configuration de comptes et de connexions. Le texte choisi peut contenir des informations privées : relis-le avant de l’exporter.</p><p><a href="/dialogue/handoff" download="tao-memoire.json">Exporter ma mémoire enregistrée</a></p><form id="dialogue-handoff" data-revision="{revision}"><label for="handoff-file">Importer un fichier de mémoire Tao (.json, 256 Kio maximum)</label><input id="handoff-file" type="file" accept=".json,application/json" required><p class="muted caption">Après un rechargement, sélectionne ce fichier à nouveau ; il n’est pas conservé dans les brouillons de l’onglet.</p><button>Ajouter cette mémoire dans cet espace</button></form></details>
<form id="dialogue-new" data-revision="{revision}"><button class="secondary">Nouvelle discussion, garder ma mémoire</button><p class="muted caption">La discussion actuelle sera archivée localement. La recherche dans les archives dépend du choix ci-dessus ; tu peux les exporter ici.</p></form><ul>{archives}</ul>
<p class="muted">Le dialogue utilise déjà le contrat du produit et un extrait du canon courant. Une mémoire importée ou une réponse IA reste un contexte à vérifier. Modifier la mémoire demande de reformuler les anciennes propositions avant de les appliquer.</p></details>
<details><summary>Moyens et budget du dialogue</summary><p>{budget['attempts']} / {budget['attempts_limit']} réponses engagées aujourd’hui (UTC) · {budget['charged_seconds']:.1f} / {budget['seconds_limit']} secondes imputées ou réservées.</p>{provider_help}</details></div>'''

def render_learning(s,b,row):
    esc=lambda value:html.escape(str(value or ''))
    key=b['id']; memory=s.get('learning',{}); revision=memory.get('revision',0)
    state=learning.assessment(s,key); latest=state['latest']
    rows=[r for r in memory.get('reports',[]) if r['task_id']==key]
    context_rows=[r for r in memory.get('context_reports',[]) if r['task_id']==key]
    labels={'success':'Utile sur ce cas','partial':'Encore incomplet','failure':'Cela ne fonctionne pas'}
    result='<div class="learning"><h3>Est-ce que cette aide fonctionne pour toi ?</h3>'
    if state['cases']:
        result+=f'<p>{state["cases"]} cas nommé(s) dans ce contexte · {state["counts"]["success"]} utile(s) · {state["counts"]["partial"]+state["counts"]["failure"]} à reprendre.</p>'
    result+=f'''<p class="muted">Décris ce que tu as réellement essayé. Ton retour préparera la prochaine amélioration.</p>
<form class="learning-report" data-task="{esc(key)}" data-adaptation="{esc(row['id'])}" data-revision="{revision}">
<label for="outcome-{esc(key)}">Le résultat</label><select id="outcome-{esc(key)}" name="outcome"><option value="partial">Encore incomplet</option><option value="success">Utile sur ce cas</option><option value="failure">Cela ne fonctionne pas</option></select>
<label for="observed-{esc(key)}">Qu’as-tu essayé et qu’as-tu obtenu ?</label><textarea id="observed-{esc(key)}" name="observed" maxlength="2000" required></textarea>
<label for="remaining-{esc(key)}">Qu’est-ce qui manque encore ?</label><textarea id="remaining-{esc(key)}" name="remaining" maxlength="2000" required></textarea>
<details><summary>Identifier le cas pour le retrouver</summary><label for="case-{esc(key)}">Un nom pour ce cas</label><input id="case-{esc(key)}" name="case" maxlength="200" required value="Exemple initial"><p class="muted">Réutilise le même nom si tu corriges ton retour sur le même cas.</p></details><button>Conserver ce retour</button></form>
<p class="muted caption">Retours déclarés, sans vérification automatique. Ton besoin reste ouvert et les permissions restent inchangées.</p>'''
    if rows:
        result+='<details><summary>Ce que ces essais nous ont appris</summary>'
        for r in rows[-8:]:
            result+=f'<p><b>{esc(r["case"])} · {labels[r["outcome"]]}</b><br>{esc(r["observed"])}<br>{esc(r["remaining"])}</p><small>{esc(r["at"])} · contexte {r["context_revision"]}, exemple {r["task_revision"]}</small>'
        if len(rows)>8: result+='<p>Les huit derniers retours sont affichés ; les précédents restent dans l’état local.</p>'
        result+='</details>'
    if context_rows:
        result+='<details><summary>Retours conservés dans un autre contexte</summary><p>Autre contexte — conservé, sans validation de la situation actuelle.</p>'
        for r in context_rows[-8:]:
            result+=f'<p><b>{esc(r["case"])} · {labels[r["outcome"]]}</b><br>{esc(r["observed"])}<br>{esc(r["remaining"])}</p><small>{esc(r["at"])} · {esc(r.get("context_change_reason"))}</small>'
        if len(context_rows)>8:result+='<p>Les huit derniers retours sont affichés ; les précédents restent dans l’état local.</p>'
        result+='<p class="muted caption">Ces retours restent distincts du bilan actuel et ne préparent pas de méthode transmissible.</p></details>'
    if state['status']=='reported_useful' and latest:
        fields={'title':'Un nom pour la méthode','applicability':'Dans quelles situations peut-elle aider ?',
                'method':'Quelle méthode transmettre, sans récit privé ?',
                'counterexample':'Dans quel cas ne faut-il pas l’utiliser ?', 'check':'Comment le descendant vérifiera-t-il son résultat ?'}
        inputs=''.join(f'<label for="method-{k}-{esc(key)}">{label}</label><textarea id="method-{k}-{esc(key)}" name="{k}" maxlength="{200 if k=="title" else 1200}" required></textarea>' for k,label in fields.items())
        result+=f'''<details><summary>Préparer une méthode pour un descendant</summary><p>Seul le texte ci-dessous pourra être transmis après ton choix explicite à la naissance. Retire les noms, comptes et données privées. Tao ne sait pas garantir une anonymisation.</p><form class="learning-method" data-report="{esc(latest['id'])}" data-revision="{revision}">{inputs}<label class="consent"><input name="confirmed" type="checkbox" required> J’ai relu ce texte et j’autorise sa transmission aux descendants que je choisirai.</label><button>Conserver cette méthode</button></form></details>'''
    for m in memory.get('methods',[]):
        if m['task_id']!=key: continue
        statuses={'approved_for_transfer':'Prête à choisir pour une naissance, contexte à revérifier','needs_review':'À revoir après un retour défavorable','withdrawn':'Transmission retirée'}
        result+=f'<details><summary>{esc(m["title"])} · {statuses[m["status"]]}</summary>'
        result+=''.join(f'<p><b>{esc(k)}</b> : {esc(m[k])}</p>' for k in learning.FIELDS if k!='title')
        result+=f'<p>Lors d’une naissance locale, ajouter <code>--method {esc(m["id"])}</code>. Le descendant devra la réévaluer.</p>'
        if m['status']!='withdrawn': result+=f'<form class="learning-withdraw" data-id="{esc(m["id"])}" data-revision="{revision}"><button class="secondary">Retirer des transmissions futures</button></form>'
        result+='</details>'
    return result+'</div>'

def render_adaptation(n,b):
    import tao_adaptation as adapt
    esc=lambda value:html.escape(str(value or ''))
    diagnostic=adapt.diagnose(n)
    try: row=adapt.current(n,b['work_task'])
    except (ValueError,RuntimeError,OSError): row=None
    ident=row['id'] if row else ''
    digest=row.get('review_digest','') if row else ''
    def action(name,label,confirmation=None):
        check=(f'<label class="consent"><input type="checkbox" name="confirmed" required> {esc(confirmation)}</label>' if confirmation else '')
        if name=='generate':
            methods=n.load_state().get('learning',{}).get('inherited',[])
            if methods:
                check+='<details><summary>Méthodes héritées à essayer (facultatif)</summary><p>Hypothèses non vérifiées ici. Les méthodes cochées seront transmises à Codex avec cette demande.</p>'
                for m in methods:
                    check+=f'<label class="consent"><input type="checkbox" name="method_ids" value="{esc(m["id"])}"> {esc(m["title"])}</label><p>{esc(m["applicability"])}</p><small>Limite : {esc(m["counterexample"])}</small>'
                check+='</details>'
        return f'<form class="adapt-action" data-task="{esc(b["id"])}" data-id="{esc(ident)}" data-action="{name}" data-digest="{esc(digest)}">{check}<button>{label}</button></form>'
    if not row:
        if not diagnostic['ready']:
            if hosted():
                guidance='<p>Un moyen manque sur le serveur de cette instance ; aucun changement n’a été lancé.</p>'+''.join('<p><b>'+esc(x['message'])+'</b></p>' for x in diagnostic['blockers'])+'<p><a href="/host/ai">Vérifier la connexion du modèle</a></p>'
            else:
                guidance=''.join('<p><b>'+esc(x['message'])+'</b></p><p>'+esc(x['next'])+'</p>'+(f'<a href="{esc(x["url"])}" target="_blank" rel="noopener noreferrer">Installation et connexion de Codex</a>' if x.get('url') else '') for x in diagnostic['blockers'])
            return '<div class="adaptation"><h3>Préparer cette aide</h3>'+guidance+'<p><button class="recheck secondary">Revérifier les moyens disponibles</button></p></div>'
        return '<div class="adaptation"><h3>Je peux préparer une première amélioration.</h3><p>Codex recevra cette tâche, son exemple et tes préférences de travail. Il utilisera son compte connecté sur l’ordinateur qui héberge Tao pour proposer du code dans une copie indépendante.</p>'+action('generate','Préparer avec Codex')+'<p class="muted caption">Un essai borné par ton budget local. Aucun ticket n’est traité par ce lancement.</p></div>'
    state=row['status']
    panel=f'<div class="adaptation" data-adaptation-id="{esc(ident)}" data-state="{esc(state)}"><p class="adapt-message" role="status">{esc(row.get("message"))}</p>'
    if state in adapt.BUSY:
        panel+='<p class="muted">Tu peux laisser Tao travailler et revenir ici. La progression s’actualise automatiquement.</p>'
        if row.get('operation')!='apply': panel+=action('cancel','Arrêter cette préparation')
    else:
        detail=adapt.view(n,ident)
        archived=bool(detail.get('archived'));context_current=detail.get('context_current',True)
        replace_allowed=detail.get('replacement_allowed',True)
        if detail.get('summary'): panel+='<details open><summary>Ce que Codex a préparé — à vérifier</summary><pre class="answer">'+esc(detail['summary'])+'</pre></details>'
        if detail.get('patch'): panel+='<details><summary>Changements à relire</summary><pre>'+esc(detail['patch'])+'</pre></details>'
        if not context_current:
            panel+='<p><b>Le contexte de cet essai a changé.</b> '+esc(detail.get('context_error'))+'</p><p class="muted">Les changements restent consultables ; leur ancienne validation ne suffit pas pour les intégrer au contexte actuel.</p>'
        if not replace_allowed and detail.get('replacement_error'):panel+='<p>'+esc(detail['replacement_error'])+'</p>'
        if archived:
            panel+='<p>Cet essai est archivé. Sa trace est conservée ; cet archivage n’annule pas une installation.</p>'
            if detail.get('restore_allowed',True):panel+=action('restore','Restaurer cet essai')
            elif detail.get('restore_error'):panel+='<p>'+esc(detail['restore_error'])+'</p>'
            if replace_allowed:panel+=action('generate','Préparer une nouvelle tentative')
        elif not context_current and state in {'review','verified','test_failed','install_failed'}:
            if replace_allowed:panel+=action('generate','Préparer à nouveau avec le contexte actuel')
        elif state in {'review','test_failed'}:
            panel+=action('verify','Tester ces changements','J’ai relu les changements et j’autorise leurs tests sur mon compte Linux, sur l’ordinateur qui héberge Tao.')
        elif state in {'verified','install_failed'}:
            panel+=action('apply','Intégrer et redémarrer Tao','J’autorise l’installation de cette version testée sur l’ordinateur qui héberge Tao.')
        if not archived and replace_allowed and state in {'blocked','interrupted','cancelled','no_change','test_failed'} and (context_current or state!='test_failed'):
            panel+='<p>La prochaine tentative recevra les essais précédents de cette tâche et leurs blocages, dans une mémoire bornée.</p>'+action('generate','Préparer une nouvelle tentative')
            panel+=('<p class="muted caption">Si le journal demande une connexion, ouvre <a href="/host/ai">Connecter le modèle</a>, puis reviens ici. Ne colle aucun mot de passe dans la discussion.</p>' if hosted() else '<p class="muted caption">Si le journal demande une connexion, ouvre <a href="/connect?world='+esc(n.worlds.current())+'">Connecter mon IA</a>, puis reviens ici pour réessayer. Ne colle aucun mot de passe dans Tao.</p>')
        if detail.get('log'): panel+='<details><summary>Journal de cette étape</summary><pre>'+esc(detail['log'])+'</pre></details>'
        if state=='installed' and not archived:
            s=n.load_state()
            try:
                report_context=learning.report_context(n,row)
                learning.retained_experiment(n,row['id'])
            except ValueError as exc:
                panel+='<p>'+esc(exc)+'</p><p>Une nouvelle adaptation est nécessaire avant d’évaluer cette aide.</p>'
                if replace_allowed:panel+=action('generate','Préparer la prochaine amélioration')
            else:
                if report_context.get('changed'):
                    panel+='<p>Le contexte a changé : ton retour sera conservé pour cet essai, sans valider la nouvelle situation.</p>'
                panel+=render_learning(s,b,row)
                if replace_allowed and learning.assessment(s,b['id'])['latest']:
                    panel+='<p>La prochaine préparation utilisera les retours et les essais précédents de cette tâche.</p>'+action('generate','Préparer la prochaine amélioration')
        if not archived and detail.get('archive_allowed',False):
            panel+='<details><summary>Classer cet essai</summary><p>Sa trace et les changements restent conservés. Cela n’annule pas une installation.</p>'+action('archive','Archiver cet essai')+'</details>'
    return panel+'</div>'

def render_work(n,s):
    esc=lambda value:html.escape(str(value or ''))
    context=s.get('work_context') or {}
    profile=f'''<form id="work-context" data-revision="{context.get('revision',0)}">
<label for="work-description">Raconte-moi ton travail et ce que tu aimerais me confier.</label>
<textarea id="work-description" maxlength="8000" required placeholder="À quoi ressemblent tes journées ? Quelles tâches reviennent souvent ou te prennent trop de temps ?">{esc(context.get('description'))}</textarea>
<details><summary>Ce que tu veux garder et les limites à respecter</summary>
<label for="work-learning">Ce que tu veux continuer à faire ou à apprendre toi-même</label><textarea id="work-learning" maxlength="2000" placeholder="Facultatif — tu pourras le préciser plus tard.">{esc(context.get('keep_learning'))}</textarea>
<label for="work-boundaries">Les personnes, les outils et les règles à prendre en compte</label><textarea id="work-boundaries" maxlength="2000" placeholder="Par exemple : préparer les réponses, mais me laisser les envoyer.">{esc(context.get('boundaries'))}</textarea></details>
<button>{'Enregistrer les changements' if context else 'Continuer'}</button>
<p class="muted caption">Ce récit est conservé sur l’ordinateur qui héberge Tao. Tu peux le modifier à tout moment.</p></form>'''
    if not context:
        return '<section class="work-panel" aria-label="Commencer avec Tao">'+profile+'</section>'
    tasks=[b for b in s.get('buffers',{}).values() if b.get('work_task') and b.get('status')=='open']
    tasks.sort(key=lambda b:(b['work_task']['phase']!='needs_example',b.get('first_seen_at','')))
    create='''<form id="work-task"><label for="work-task-title">Quelle première tâche aimerais-tu me confier ?</label><textarea id="work-task-title" maxlength="2000" required placeholder="Par exemple : préparer les réponses aux demandes de maintenance de mes clients."></textarea><button>Commencer par cette tâche</button></form>'''
    if tasks:
        create=create.replace('Quelle première tâche','Quelle autre tâche').replace('Commencer par cette tâche','Ajouter cette tâche')
        cards=[]
        for index,b in enumerate(tasks):
            task=b['work_task']; example=task.get('example') or {}; key=b['id']
            form=f'''<form class="work-example" data-id="{esc(key)}" data-revision="{task['revision']}">
<label for="situation-{esc(key)}">Donne-moi un exemple de ce qui arrive.</label><textarea id="situation-{esc(key)}" name="situation" maxlength="2000" required placeholder="Décris une demande typique, sans données confidentielles inutiles.">{esc(example.get('situation'))}</textarea>
<label for="expected-{esc(key)}">À quoi ressemble un travail bien fait dans ce cas ?</label><textarea id="expected-{esc(key)}" name="expected" maxlength="2000" required placeholder="Le résultat que tu voudrais pouvoir vérifier.">{esc(example.get('expected'))}</textarea>
<details><summary>Une limite particulière pour cet exemple ?</summary><label for="boundaries-{esc(key)}">Ce qu’il faut préserver</label><textarea id="boundaries-{esc(key)}" name="boundaries" maxlength="1500">{esc(example.get('boundaries'))}</textarea></details><button>Enregistrer cet exemple</button></form>'''
            if example:
                body=f'''<p class="eyebrow">Exemple enregistré · aide à construire</p><p>{esc(example['situation'])}</p><p><b>Résultat attendu :</b> {esc(example['expected'])}</p>{render_adaptation(n,b)}<details><summary>Mon exemple et ma fiche de travail</summary><a class="text-link" href="/work/brief">Ouvrir ma fiche de travail</a>{form}</details>'''
            else:
                body='<p class="muted">Partons d’un cas concret pour préciser l’aide que tu attends.</p>'+form
            card=f'<section class="work-panel"><h2>{esc(task["title"])}</h2>{body}</section>'
            cards.append(card if index==0 else f'<details class="work-other"><summary>{esc(task["title"])}</summary>{card}</details>')
        main=''.join(cards)+f'<details class="work-other"><summary>Préparer une autre tâche</summary>{create}</details>'
    else:
        main='<section class="work-panel"><h2>Commençons par une tâche qui te prend du temps.</h2><p class="muted">Choisis quelque chose de concret que tu fais régulièrement.</p>'+create+'</section>'
    return main+f'<details class="work-other"><summary>Mon travail et mes préférences</summary>{profile}</details>'

def render_lexicon(data):
    esc=lambda value:html.escape(str(value))
    labels={'operational_definition':'Définition opérationnelle','mathematical_definition':'Définition mathématique',
        'design_hypothesis':'Hypothèse de conception','design_concept':'Concept de conception','design_axiom':'Axiome de conception',
        'historical_reference':'Référence historique','historical_inspiration':'Inspiration historique',
        'historical_mapping':'Correspondance historique','derived_structure':'Structure dérivée',
        'open_scientific_question':'Question ouverte'}
    entries=[]; models=data['formal_models']
    for name,row in sorted(data['dictionary'].items()):
        related=[alias for alias,target in data.get('aliases',{}).items() if target==name]
        examples=''
        for key in row.get('model_refs',[]):
            model=models[key]
            examples+=f"<div class='model'><code>{esc(model['expression'])}</code><p><b>Domaine :</b> {esc(model['domain'])}</p><p><b>Unités :</b> {esc(model['units'])}</p><p><b>Vérification :</b> {esc(model['verification'])}</p></div>"
        if not examples: examples='<p class="muted">Définition seule : aucun modèle explicite relié dans ce registre. Un symbole ne constitue pas une preuve.</p>'
        entries.append(f"<details class='term'><summary>{esc(name.replace('_',' '))} <span>{esc(labels[row['status']])}</span></summary><p>{esc(row['definition'])}</p><small>Alias : {esc(', '.join(related) or '—')} · Symbole : {esc(row.get('symbol','—'))}</small>{examples}</details>")
    count=sum(bool(row.get('model_refs')) for row in data['dictionary'].values())
    return '''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tao · Dictionnaire</title><style>
:root{color-scheme:light;--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47;--soft:#edf1ea;--gold:#c79d67}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 88% -10%,#eee3d2,transparent 38%),var(--bg);color:var(--text);font:16px/1.6 system-ui,sans-serif;min-height:100vh}main{max-width:960px;margin:auto;padding:24px 28px 60px}nav{display:flex;align-items:center;justify-content:space-between;gap:20px;min-height:60px;padding-bottom:18px;border-bottom:1px solid var(--line)}.brand{font:600 29px/1 ui-serif,Georgia,serif;letter-spacing:-.045em;text-decoration:none;color:var(--text)}.brand span{color:var(--gold)}a{color:var(--accent);text-underline-offset:3px}
header{margin:26px 0 28px;padding:clamp(24px,4vw,42px);border:1px solid var(--line);border-top:3px solid var(--gold);border-radius:20px;background:linear-gradient(135deg,#fffdfa,#f6f1e8);box-shadow:0 12px 30px rgba(39,55,47,.045)}.eyebrow{font-size:11px;letter-spacing:.15em;text-transform:uppercase;font-weight:700;color:var(--accent)}h1{font:500 clamp(31px,5vw,44px)/1.2 ui-serif,Georgia,serif;letter-spacing:-.03em;margin:10px 0 15px}p{margin:10px 0;overflow-wrap:anywhere}.muted,small{color:var(--muted)}
label{display:block;font-weight:600;margin:22px 0 8px}input{width:100%;padding:12px 14px;background:var(--panel);color:var(--text);border:1px solid #b9c7bc;border-radius:9px;font:inherit;min-height:44px}#count{color:var(--muted);min-height:1.6em}
.term{padding:0 18px 16px;border:1px solid var(--line);border-radius:12px;background:var(--panel);margin:10px 0;overflow-wrap:anywhere;box-shadow:0 6px 22px rgba(39,55,47,.035)}summary{cursor:pointer;min-height:44px;padding:14px 0;font-weight:600;color:var(--accent)}summary span{display:inline-block;font-size:12px;font-weight:500;color:var(--muted);margin-left:12px}.model{background:#f3f1eb;border-left:2px solid var(--gold);padding:18px;margin-top:12px;border-radius:8px}code{white-space:pre-wrap;overflow-wrap:anywhere}footer{margin-top:28px;font-size:14px;color:var(--muted)}
a:focus-visible,summary:focus-visible,input:focus-visible{outline:3px solid var(--accent);outline-offset:3px}@media(max-width:620px){main{padding:16px 14px 40px}header{margin:18px 0 20px;padding:23px 19px;border-radius:16px}nav{flex-wrap:wrap;gap:12px}}
</style></head><body><main>'''+f'''
<nav><a class="brand" href="/">tao<span>.</span></a><a href="/">← Mon Tao</a></nav><header><p class="eyebrow">La bibliothèque · les mots</p><h1>Des mots au modèle</h1><p>Canon {esc(data['meta']['version'])} · {len(data['dictionary'])} termes · {count} termes reliés à {len(models)} modèles explicites.</p><p class="muted">Les contrôles vérifient la structure et l’intégrité. Ils ne démontrent pas les modèles ni leur validité universelle. Chaque nouvelle révision conserve son contexte et ses limites.</p></header><label for="search">Rechercher un terme, un alias ou une définition</label><input id="search" type="search" autocomplete="off"><p id="count" role="status"></p>{''.join(entries)}<footer><a href="/theory">Canon complet en JSON</a> · Révisions : <code>tao theory proposals</code></footer></main>'''+'''<script>
const terms=[...document.querySelectorAll('.term')];const norm=s=>s.toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g,'');
document.querySelector('#search').addEventListener('input',e=>{let count=0;const query=norm(e.target.value);for(const item of terms){const visible=norm(item.textContent).includes(query);item.hidden=!visible;if(visible)count++}document.querySelector('#count').textContent=count+' terme(s) correspondant(s)'});
</script></body></html>'''

def render(n,s,token):
    import tao_foundations as foundations
    import tao_navigation_ui as navigation
    esc=lambda x:html.escape(str(x or ''))
    p=n.public_state(s); bs=sorted(p['buffers'],key=lambda b:-b.get('importance',0))
    plans=n.evolution_plan(s)
    eco=p['ecology']; met=eco['metabolism']; budget=eco['adaptation']['budget']
    gb=lambda value:'non mesuré' if value is None else f'{value/1024**3:.1f} Gio'
    reason_names={'disk_low':'disque bas','memory_low':'mémoire basse','battery_low':'batterie basse',
        'disk_unknown':'disque non mesuré','memory_unknown':'mémoire non mesurée',
        'daily_attempts_exhausted':'nombre d’essais atteint','daily_time_exhausted':'temps réservé épuisé'}
    adaptation='Disponible sur commande' if eco['adaptation']['eligible'] else 'Différée : '+', '.join(reason_names.get(x,x) for x in eco['adaptation']['blockers'])
    provider_rows=''.join('<li>'+esc(x['id'])+' : '+('détecté' if x['detected'] else 'absent')+
        (' · atelier disponible' if x['adapter']=='manual_workshop' and x['detected'] else ' · connexion non implémentée' if x['detected'] else '')+'</li>' for x in eco['providers'])
    ecology_panel=f'''<section aria-labelledby="ecology-title"><div class="eyebrow">Milieu et ressources</div><h2 id="ecology-title">S’adapter dans les limites du lieu</h2>
<div class="columns"><div><p>Mémoire disponible : <b>{esc(gb(eco['habitat']['memory_available_bytes']))}</b> · disque : <b>{esc(gb(eco['habitat']['disk_free_bytes']))}</b></p>
<p>Adaptation : <b>{esc(adaptation)}</b></p><small>{budget['attempts']} / {budget['attempts_limit']} essais réservés aujourd’hui (UTC) · {budget['charged_seconds']:.1f} / {budget['seconds_limit']} s imputées ou réservées.</small>
<details><summary>Comprendre la dépense</summary><p>{met['measured_cycles']} cycles mesurés · {met['basal_cpu_seconds']:.4f} s CPU dans le cœur de boucle · {met['adaptive_wall_seconds']:.2f} s d’atelier observées.</p><p>Tokens, euros et électricité : non mesurés. Un lancement du CLI ne compte pas les appels réels au fournisseur. Une réservation interrompue reste imputée.</p></details></div>
<div><p>Lignée : génération <b>{eco['lineage']['generation']}</b> · {len(eco['offspring'])} descendant(s) créé(s).</p><small>Espèce non classée. Les spécialisations restent des hypothèses.</small>
<details><summary>Capacités et héritage</summary><ul>{provider_rows}</ul><p>Connexion aux comptes non vérifiée. {eco['heritage']['builtin_recipes']} recettes intégrées ; {eco['heritage']['remote_items']} références distantes inertes.</p><p>Une naissance locale transmet le programme et le patrimoine intégré. Son activation et sa nouvelle histoire sont explicites.</p></details></div></div></section>'''
    def trace_note(b):
        rows=b.get('origin_traces') or []
        if not rows: return ''
        items=''.join(f"<li><small>{esc(row.get('at'))} · {esc(row.get('source'))}</small>"
                      f"<p>Entrée : {esc(row['trace'].get('input'))}</p>"
                      f"<p>Sortie : {esc(row['trace'].get('output'))}</p>"
                      f"<p>Écart : {esc(row['trace'].get('difference'))}</p>"
                      f"<small>{esc(row['trace'].get('source'))} → {esc(row['trace'].get('destination'))}</small></li>" for row in rows)
        return f"<details><summary>Hypothèse {esc(rows[-1]['kind'])} · {len(rows)} trace(s) · cause à vérifier</summary><ol>{items}</ol></details>"
    rows=''.join(f'''<article class="residual"><div class="row"><b>{esc(b['id'])}</b><span class="tag">{esc(b.get('kind'))}</span></div><p>{esc(b['residual'])}</p><small>{b.get('seen',1)} observations · statut ouvert</small><details><summary>But et preuve attendue</summary><p>{esc(b.get('desired','À préciser'))}</p><p>{esc(b.get('acceptance','À préciser'))}</p></details>{trace_note(b)}</article>''' for b in bs) or '<p class="empty">Aucun tampon ouvert. Ajoute une différence réelle que tu veux intégrer.</p>'
    planrows=''.join(f"<li><b>{esc(x['buffer_id'])}</b> · <span class='tag'>{esc(x['phase'])}</span><p>{esc(x['next_step'])}</p><small>{esc(x['why'])}</small><br><small>Preuve attendue : {esc(x['expected_evidence'])}</small></li>" for x in plans) or '<li>Le rythme ralentit lorsque la situation reste stable.</li>'
    st=n.story(); interval=p['scheduler'].get('sleep_seconds',30)
    context=s.get('work_context')
    headline='Discutons et avançons.'
    intro='Cette discussion appartient à ta pièce. Tu peux revenir au plan ou ouvrir l’atelier quand tu veux.'
    alerts=[b for b in bs if b.get('kind')!='user' and b.get('importance',0)>=.9]
    attention=(' <a href="#advanced">'+str(len(alerts))+' point(s) à vérifier sur l’ordinateur qui héberge Tao</a>') if alerts else ''
    room=n.worlds.describe(n,s)['current']
    sidebar=navigation.render(n,s,current='discussion',world=room['id'],
                              overview=foundations.overview(n),languages=False,
                              same_page=True)
    work_panel=(render_dialogue(n,s)
                +'<details id="room-map" class="work-other"><summary>Se repérer dans la maison et changer de pièce</summary>'
                +render_worlds(n,s)+'</details>'
                +'<details id="work-progress" class="work-other"><summary>Atelier · tâches et améliorations</summary>'+render_work(n,s)+'</details>')
    recent=n.epoch()-s.get('last_cycle_epoch',0)<=max(60,interval+30)
    observed='Observations récentes' if recent else 'État de la boucle à vérifier dans les détails'
    place_label='Tao hébergé' if hosted() else 'Tao sur Linux'
    device_note=('Téléphone ou ordinateur : tu retrouves la même instance hébergée, indépendante de ton PC. Le dialogue et les expériences utilisent les fichiers et moyens du serveur. Les connexions aux fichiers et applications de ton PC ne sont pas implémentées ; les installations séparées ne sont pas synchronisées. Les fichiers exportés se téléchargent sur l’appareil que tu utilises.' if hosted() else 'Téléphone ou ordinateur : tu retrouves les mêmes espaces. Codex est lancé sur l’ordinateur qui héberge Tao ; les tests et installations s’y exécutent. Cet ordinateur doit rester accessible. Les fichiers exportés se téléchargent sur l’appareil que tu utilises.')
    host_access='<p><a href="/host/account">Mon accès</a> · <a href="/host/ai">Connecter le modèle</a></p>' if hosted() else ''
    workshop_help=('<details><summary>Atelier sur le serveur</summary><p>Les propositions, tests et installations concernent cette instance hébergée. Utilise les actions de tes tâches pour suivre une expérience et relire les changements ; cela ne donne pas accès aux logiciels de ton PC.</p></details>' if hosted() else '<details><summary>Atelier de code sur ton Linux</summary><p>Une copie Git indépendante, un changement ciblé, puis des tests et une décision. Le tampon reste ouvert jusqu’à une preuve de résolution dans le réel.</p><pre>tao atelier prepare /chemin/tao --buffer ID\ntao atelier run ID_EXPERIENCE\ntao atelier diff ID_EXPERIENCE\ntao atelier verify ID_EXPERIENCE --trust-candidate\ntao atelier accept ID_EXPERIENCE</pre><p>Codex est optionnel. Lancer « run » utilise le compte déjà connecté dans ton terminal. Relis le diff avant les tests locaux.</p></details>')

    return '''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Tao · Comprendre et agir</title><style>
.world-panel,.dialogue-panel{min-width:0;overflow-wrap:anywhere}.columns>*{min-width:0}.need-card{padding:12px 0;border-top:1px solid var(--line)}.need-actions{display:flex;flex-wrap:wrap;gap:10px}.current-need{border-left:3px solid var(--accent);padding:4px 16px;margin:22px 0}blockquote{margin-left:0;padding-left:14px;border-left:2px solid var(--line);white-space:pre-wrap;overflow-wrap:anywhere}#continuity-panel{margin-top:24px}.chat-turn{padding:18px 0;border-bottom:1px solid #333b2f}.chat-user{background:#252c21;padding:18px;border-radius:12px;margin-top:16px}.chat-text{white-space:pre-wrap;overflow-wrap:anywhere}.dialogue-panel{max-width:860px;margin-left:auto;margin-right:auto}.dialogue-panel details{margin-bottom:12px}:root{color-scheme:dark;--bg:#141613;--panel:#1d211c;--text:#e9ede4;--muted:#a5ae9e;--line:#333b2f;--accent:#cae5a7}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.6 system-ui,sans-serif}main{max-width:1140px;margin:auto;padding:28px 28px 60px}nav,.row{display:flex;align-items:center;justify-content:space-between;gap:12px}nav{padding-bottom:28px;border-bottom:1px solid var(--line)}.brand{font-size:24px;font-weight:650;letter-spacing:.13em}.tag{font-size:12px;border:1px solid var(--line);border-radius:20px;padding:4px 12px;color:var(--muted)}.dot{color:var(--accent)}header{padding:36px 0 28px}h1{font-size:clamp(30px,5vw,48px);line-height:1.15;letter-spacing:-.04em;margin:12px 0 18px;max-width:800px}h2{font-size:21px;margin:0 0 14px}p{margin:9px 0}small,.muted{color:var(--muted)}.eyebrow{text-transform:uppercase;font-size:12px;letter-spacing:.12em;color:var(--accent)}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:0 0 26px}.stat{border-top:1px solid var(--line);padding:16px 0}.stat strong{font-size:28px;display:block}.columns{display:grid;grid-template-columns:1.2fr 1fr;gap:20px;align-items:start}section{background:var(--panel);border:1px solid var(--line);padding:24px;border-radius:16px;margin-bottom:20px}label{display:block;margin:12px 0 6px;font-size:14px}textarea,input,select{font:inherit;color:var(--text);width:100%;border:1px solid #46503f;border-radius:8px;background:#141812;padding:12px}textarea{resize:vertical;min-height:85px}button{font:inherit;cursor:pointer;border:0;border-radius:9px;background:var(--accent);color:#20291a;font-weight:600;padding:11px 17px;margin-top:12px}button.secondary{border:1px solid #46503f;background:transparent;color:var(--text);margin:0}.residual{padding:17px 0;border-top:1px solid var(--line)}.residual p,li p{overflow-wrap:anywhere}.residual:first-of-type{border-top:0}details{margin-top:15px}summary{cursor:pointer;color:var(--muted)}li{padding:12px 0}ol{padding-left:23px;margin:0}.empty{color:var(--muted);padding:12px 0}footer{color:var(--muted);font-size:13px;padding-top:12px}a{color:var(--accent)}#message{position:fixed;bottom:22px;left:50%;transform:translateX(-50%);background:#cae5a7;color:#20291a;padding:13px 20px;border-radius:10px;max-width:90%;display:none}pre{overflow:auto;font-size:13px}button:focus-visible,summary:focus-visible{outline:3px solid white;outline-offset:4px}@media(max-width:750px){main{padding:18px}.columns{grid-template-columns:1fr}.stats{gap:8px}section{padding:20px}nav .tag{display:none}.stat strong{font-size:25px}}.work-panel{overflow-wrap:anywhere;min-width:0;padding:30px;margin-bottom:18px}.work-panel h2{overflow-wrap:anywhere}.work-panel textarea{min-height:100px}.work-panel #work-description{min-height:160px}.work-panel label{font-size:17px}.work-other{overflow-wrap:anywhere;padding:16px 0;border-top:1px solid var(--line)}.work-other>summary{color:var(--text)}.caption{font-size:13px;margin-top:12px}#advanced{margin-top:36px;padding-top:20px;border-top:1px solid var(--line)}#advanced>summary{margin-bottom:24px}.adaptation{border-top:1px solid var(--line);margin-top:22px;padding-top:12px}.consent{display:flex;align-items:start;gap:10px;font-size:14px}.consent input{width:auto;margin-top:6px}.answer{white-space:pre-wrap;overflow-wrap:anywhere;font:inherit}h3{font-size:18px}.text-link{display:inline-block;margin-top:14px}button:disabled{opacity:.6;cursor:wait}#message.error{background:#ffe2c5}main{max-width:920px}header{padding:42px 0 20px}footer{margin-top:28px}summary{min-height:30px}h1{max-width:720px}#advanced:target{scroll-margin-top:20px}@media(max-width:750px){.work-panel{padding:20px}header{padding-top:28px}}
.assistant-readiness{border-left:3px solid var(--accent);padding:2px 14px;margin:0 0 20px}.next-contribution{border:1px solid var(--line);border-radius:12px;padding:14px;margin-top:18px}.device-note{font-size:14px;margin:0 0 22px}.draft-card{border-top:1px solid var(--line);padding:14px 0}.draft-card button{margin-right:8px}.draft-card pre{white-space:pre-wrap;overflow-wrap:anywhere}button,summary{min-height:44px}select{max-width:100%}pre{max-width:100%;white-space:pre-wrap;overflow-wrap:anywhere}#message a{color:inherit;text-decoration:underline}#message{max-height:50vh;overflow:auto;z-index:5}nav{flex-wrap:wrap}.row{flex-wrap:wrap}input:focus-visible,textarea:focus-visible,select:focus-visible,a:focus-visible{outline:3px solid var(--accent);outline-offset:3px}.nav-more{margin:0 0 0 auto;position:relative}.nav-more>summary{list-style:none;min-height:44px;padding:8px 12px;border:1px solid var(--line);border-radius:10px}.nav-more>div{position:absolute;right:0;z-index:3;top:100%;min-width:205px;display:flex;flex-direction:column;gap:12px;padding:16px;background:var(--panel);border:1px solid var(--line);border-radius:12px;box-shadow:0 14px 34px #0007}.work-other>.world-panel{margin-top:14px}.device-note{padding:6px 10px}@media(max-width:480px){main{padding:14px}section,.work-panel{padding:16px}.stats{grid-template-columns:1fr}.stat{padding:8px 0}.stat strong{font-size:22px}button{max-width:100%;white-space:normal}nav .tag{display:inline-block}.need-actions form{width:100%}.need-actions button{width:100%}}
:root{color-scheme:light;--bg:#f6f7f3;--panel:#fff;--text:#25312b;--muted:#5c6a60;--line:#dce2d9;--accent:#365c46}textarea,input,select{background:#fff;color:var(--text);border-color:#b7c7b8}.chat-turn{border-color:var(--line)}.chat-user{background:#e8efe5}button{color:#fff}button.secondary{color:var(--accent);border-color:#c6d6c6}.nav-more>div{box-shadow:0 14px 34px #24342b23}#message{background:#365c46;color:#fff}#message.error{background:#80512c;color:#fff}button:focus-visible,summary:focus-visible{outline-color:#63966e}.dialogue-panel{border-color:#d5e2d3;box-shadow:0 12px 34px #24342b0c}
.dialogue-panel{display:flex;flex-direction:column;height:min(52rem,calc(100vh - 12rem));height:min(52rem,calc(100dvh - 12rem));min-height:0}.dialogue-timeline{flex:1 1 auto;min-height:0;overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;scrollbar-gutter:stable;padding-right:8px}.dialogue-timeline:focus-visible{outline:3px solid var(--accent);outline-offset:-3px}#dialogue-send{flex:0 0 auto;border-top:1px solid var(--line);padding-top:8px}#dialogue-options{margin:5px 0}#dialogue-options>summary{font-size:14px;padding:6px 0}#reuse-suggestions{max-height:8rem;overflow-y:auto}.dialogue-secondary{max-width:860px;margin:0 auto;overflow-wrap:anywhere}.dialogue-secondary>p:first-child{margin:12px 0}header{padding:17px 0 9px}header h1{font-size:clamp(26px,3.5vw,36px);margin:5px 0 7px}header .muted{font-size:14px;margin:4px 0}@media(max-width:600px){main{padding:10px 14px 32px}nav{padding-bottom:8px;gap:8px}nav .brand{font-size:22px}header{padding:10px 0 7px}header h1{font-size:clamp(23px,6vw,30px);margin:3px 0 4px}header .muted{font-size:13px;line-height:1.35}.dialogue-panel{height:calc(100vh - 13rem);height:calc(100dvh - 13rem);padding:14px;margin-bottom:12px}#dialogue-send textarea{min-height:72px}#dialogue-send>label{margin-top:8px}}@media(max-height:700px){.dialogue-panel{height:auto}.dialogue-timeline{flex:none;min-height:9rem;max-height:40vh;max-height:40dvh}}
/* Maison Tao: the same materials and navigation as the centre projections. */
:root{--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47}
body{background:radial-gradient(circle at 88% 4%,#e9e8da 0,transparent 27rem),var(--bg)}
h1,h2,h3{font-family:Georgia,ui-serif,serif;font-weight:500;letter-spacing:-.025em}
.brand{font-family:Georgia,ui-serif,serif;letter-spacing:-.08em;color:var(--text);text-decoration:none}.dot{color:#b88a57}
section,.dialogue-panel{background:var(--panel);border-color:var(--line)}
.dialogue-panel{box-shadow:0 18px 45px #27372f10}.chat-user{background:#e9efe8}
textarea,input,select{background:#fffdfa;color:var(--text);border-color:#b9c8b8}
button{border-radius:12px;color:#fff}button.secondary{border-color:var(--line);color:var(--accent);background:var(--panel)}
.house-navigation{display:flex;align-items:center;gap:12px;flex-wrap:nowrap;padding-bottom:12px}.house-main-links{display:flex;gap:5px;align-items:center;margin-left:auto}
.house-main-links>a{color:var(--text);text-decoration:none;font-size:14px;font-weight:600;padding:9px 12px;border-radius:10px;white-space:nowrap}
.house-main-links>a:hover,.house-main-links>a[href="#work-progress"]:focus-visible{background:#e9efe8}
.nav-more{margin-left:0}.nav-more>summary{color:var(--text);font-size:14px;font-weight:600}.nav-more>div{background:var(--panel);border-color:var(--line)}
.work-other>summary{font-weight:600;color:var(--accent)}.work-other[open]{border-top-color:#b88a57}
@media(max-width:600px){.house-navigation{gap:4px}.house-navigation .brand{font-size:22px;margin-right:auto}.house-main-links{gap:0;margin-left:0}.house-main-links>a{font-size:12px;padding:7px 6px}.nav-more>summary{font-size:12px;padding:8px}.nav-more>div{right:0}}
''' + navigation.CSS + '''</style></head><body class="tao-has-sidebar">''' + sidebar + '''<main>
''' + f'''<header><div class="eyebrow">Dans {esc(room['title'])}</div><h1>{headline}</h1><p class="muted">{intro}</p>{attention}</header>
<section id="drafts-panel" hidden aria-label="Saisies non enregistrées"><h2>Retrouver mes saisies</h2><p>Ces brouillons restent dans cet onglet, pour cet espace. Compare-les au contenu actuel avant de les restaurer. Aucune autorisation n’est restaurée ni action lancée.</p><div id="drafts-list"></div></section>
{work_panel}
<details class="device-note"><summary>{place_label} · depuis quel appareil je travaille ?</summary><p class="muted">{device_note}</p></details>
<details id="advanced"><summary>Fonctionnement et outils avancés</summary>{host_access}
<button id="wake" class="secondary">Observer maintenant</button>
<div class="stats"><div class="stat"><small>Observations</small><strong>{p['cycles']}</strong></div><div class="stat"><small>Tampons ouverts</small><strong>{len(bs)}</strong></div><div class="stat"><small>Rythme actuel</small><strong>{interval} s</strong></div></div>
{ecology_panel}
<div class="columns"><div><section><h2>Ton histoire</h2><p>{esc(st.get('text'))}</p><details><summary>Faire évoluer la direction</summary><form id="story"><label for="storytext">Ce que tu souhaites rendre possible</label><textarea id="storytext" maxlength="8000" required>{esc(st.get('text'))}</textarea><button>Enregistrer</button></form></details></section>
<section><div class="row"><h2>Ce qui reste à intégrer</h2><span class="tag">{len(bs)}</span></div>{rows}</section></div>
<div><section><div class="eyebrow">Prochaine contribution</div><h2>Préparer une expérience</h2><ol>{planrows}</ol>{workshop_help}</section>
<section><h2>Ajouter une différence</h2><form id="buffer"><label for="residual">Qu’est-ce qui bloque ou manque ?</label><textarea id="residual" maxlength="4000" required placeholder="Une observation précise, un besoin, un bug…"></textarea><label for="desired">Qu’aimerais-tu obtenir ?</label><input id="desired" maxlength="2000" required placeholder="Un résultat observable"><label for="acceptance">Comment saura-t-on que ça fonctionne ?</label><input id="acceptance" maxlength="2000" required placeholder="Une preuve ou un test"><label for="origin">D’où semble venir cet écart ?</label><select id="origin"><option value="undetermined">Je ne sais pas encore</option><option value="internal">Dans une fonction</option><option value="translation">Entre deux représentations</option><option value="conciliation">Entre deux propositions</option></select><details id="trace-fields"><summary>Décrire la trace observée</summary><p class="muted">Une hypothèse racontée ici ne devient pas un diagnostic. Si tu choisis une origine, renseigne au moins entrée, sortie et écart.</p><label for="trace-source">Source ou proposition A (obligatoire pour une traduction)</label><input id="trace-source" maxlength="1000"><label for="trace-destination">Destination ou proposition B (obligatoire pour une traduction)</label><input id="trace-destination" maxlength="1000"><label for="trace-input">Entrée ou situation avant</label><textarea id="trace-input" maxlength="1000"></textarea><label for="trace-output">Sortie ou proposition obtenue</label><textarea id="trace-output" maxlength="1000"></textarea><label for="trace-difference">Information perdue ou conflit constaté</label><textarea id="trace-difference" maxlength="1000"></textarea></details><button>Conserver en tampon</button></form></section></div></div>
<p><a href="/lexicon">Dictionnaire et modèles</a> · <a href="/state">État complet</a> · <a href="/lens/snapshot">Contexte d’évolution</a> · <a href="/health">Santé du nœud</a></p></details><footer>{observed} · les tâches décrites restent à automatiser.</footer></main><div id="message" role="status" aria-live="polite"></div>'''+'''<script>
const token='''+json.dumps(token)+''';
const worldId='''+json.dumps(n.worlds.current())+''';
function openWorkshop(){if(location.hash==='#work-progress'){const panel=document.getElementById('work-progress');if(panel)panel.open=true}}
document.getElementById('workshop-link').addEventListener('click',openWorkshop);
window.addEventListener('hashchange',openWorkshop);openWorkshop();
function scoped(path){const url=new URL(path,location.origin);url.searchParams.set('world',worldId);return url.pathname+url.search}
let formDirty=false;const dirtyForms=new Set();let currentSubmission=null;
document.addEventListener('submit',e=>{currentSubmission=e.target;queueMicrotask(()=>currentSubmission=null)},true);
function message(text,error=false){const target=document.querySelector('#message');target.textContent=text;target.classList.toggle('error',error);target.style.display='block';return target}
function loginRequired(result){keepAllDrafts();const target=message('Ta session a expiré. Tes saisies restent dans cet onglet. Reconnecte-toi puis restaure tes brouillons.',true);const link=document.createElement('a');link.href='''+("'/host/login'" if hosted() else "'/mobile/login'")+''';link.textContent=' Se reconnecter';target.appendChild(link)}
function retryNotice(panel,text){panel.textContent=text;const button=document.createElement('button');button.type='button';button.className='secondary';button.textContent='Actualiser en gardant les brouillons';button.onclick=()=>{if(keepAllDrafts())location.reload();else message('Le navigateur ne peut pas garder toutes tes saisies. Copie-les avant de quitter cette page.',true)};panel.appendChild(button)}
async function send(path,data){const submitted=currentSubmission;currentSubmission=null;const submittedValues=submitted?draftValues(submitted):null;if(submitted&&submitted.dataset.pendingDraft){message('Récupère ou écarte le brouillon de ce formulaire avant de l’enregistrer.',true);return}if(path==='/api/adaptation'&&data.action==='generate'&&document.querySelector('.learning-report[data-dirty="true"]')){message('Enregistre ton retour avant de préparer la suite.');return}if(!keepAllDrafts()){message('Récupère ou écarte les anciens brouillons avant de poursuivre. Si le stockage est plein, copie tes saisies avant d’actualiser.',true);return}const buttons=[...document.querySelectorAll('button')];buttons.forEach(b=>b.disabled=true);message('Enregistrement…');try{const r=await fetch(scoped(path),{method:'POST',headers:{'Content-Type':'application/json','X-Tao-Token':token},body:JSON.stringify(data)});const result=await r.json();if(r.status===401){loginRequired(result);buttons.forEach(b=>b.disabled=false);return}if(!r.ok)throw new Error(result.error||'Échec');message(result.message||(path==='/api/dialogue/handoff'?(result.already_imported?'Ce document a déjà été importé.':'Mémoire sélectionnée ajoutée ; origine déclarée non vérifiée.'):'Enregistré.'));const editedWhileSending=submitted&&JSON.stringify(draftValues(submitted))!==JSON.stringify(submittedValues);if(path==='/api/dialogue/send')delete dialogueForm.dataset.nonce;if(submitted){draftBaselines.set(submitted,submittedValues);if(editedWhileSending){keepFormDraft(submitted)}else{draftStore.drop(formKey(submitted));dirtyForms.delete(submitted)}}if(path==='/api/dialogue/send'&&!editedWhileSending){document.querySelector('#dialogue-text').value='';selectedFocus=null;showFocus()}if(path==='/api/worlds/create'||path==='/api/worlds/transfer'){location.href='/?world='+encodeURIComponent(result.world_id||result.id);return}if(result.task_id)location.hash='work-progress';if(path==='/api/dialogue/handoff')location.hash='memory-continuity';location.reload()}catch(e){buttons.forEach(b=>b.disabled=false);message(e.message==='Failed to fetch'?'Connexion interrompue : le résultat n’est pas confirmé et la demande a peut-être déjà été appliquée. Tes brouillons sont gardés. Actualise puis vérifie l’état avant tout nouvel envoi.':e.message,true)}}
const contextForm=document.querySelector('#work-context');
const continuityForm=document.querySelector('#continuity-settings');continuityForm.onsubmit=e=>{e.preventDefault();send('/api/continuity/settings',{enabled:document.querySelector('#continuity-enabled').checked,revision:Number(continuityForm.dataset.revision)})};
for(const form of document.querySelectorAll('.continuity-note'))form.onsubmit=e=>{e.preventDefault();send('/api/continuity/note',{id:form.dataset.id,text:form.elements.text.value,status:e.submitter?e.submitter.value:'kept',revision:Number(form.dataset.revision)})};
for(const form of document.querySelectorAll('.need-action'))form.onsubmit=e=>{e.preventDefault();send('/api/continuity/need',{id:form.dataset.id,action:form.dataset.action,revision:Number(form.dataset.revision)})};
for(const form of document.querySelectorAll('.need-revise'))form.onsubmit=e=>{e.preventDefault();const values={};for(const k of ['title','current','desired','acceptance','next_step'])values[k]=form.elements[k].value;send('/api/continuity/need',{id:form.dataset.id,action:'revise',values,revision:Number(form.dataset.revision)})};
for(const form of document.querySelectorAll('.need-resolve'))form.onsubmit=e=>{e.preventDefault();send('/api/continuity/need',{id:form.dataset.id,action:'resolve',evidence:form.elements.evidence.value,revision:Number(form.dataset.revision)})};
for(const button of document.querySelectorAll('.continue-need'))button.onclick=()=>{const input=document.querySelector('#dialogue-text');const text='Reprenons « '+button.dataset.title+' ». Quelle petite étape utile peut-on faire maintenant ?';input.value=input.value?input.value+String.fromCharCode(10)+text:text;input.dispatchEvent(new Event('input',{bubbles:true}));input.focus();input.scrollIntoView({block:'center',behavior:'smooth'})};
for(const button of document.querySelectorAll('.continue-route'))button.onclick=()=>{const input=document.querySelector('#dialogue-text'),combined=input.value?input.value+String.fromCharCode(10)+button.dataset.text:button.dataset.text;if(combined.length>input.maxLength){message('Ton brouillon est déjà long. Envoie-le ou raccourcis-le avant d’ajouter cette piste.');return}input.value=combined;input.dispatchEvent(new Event('input',{bubbles:true}));input.focus();input.scrollIntoView({block:'center',behavior:'smooth'})};
const dialogueForm=document.querySelector('#dialogue-send');
let selectedFocus=null;
function showFocus(){const panel=document.querySelector('#dialogue-focus');panel.hidden=!selectedFocus;panel.querySelector('span').textContent=selectedFocus?'On examine '+selectedFocus.label:''}
'''+DRAFT_STORE_JS+HANDOFF_JS+REUSE_SUGGESTIONS_JS+r'''
let browserDraftStorage;try{browserDraftStorage=sessionStorage}catch(e){browserDraftStorage={getItem:()=>null,setItem:()=>{throw new Error('Stockage indisponible')}}}const draftStore=createDraftStore(browserDraftStorage,dialogueForm.dataset.node,worldId), draftBaselines=new Map();
function formKey(form){return form.id||[form.className,form.dataset.id,form.dataset.task,form.dataset.adaptation,form.dataset.report,form.dataset.message,form.dataset.action].filter(Boolean).join(':')}
for(const form of document.querySelectorAll('form'))draftBaselines.set(form,draftValues(form));
function keepFormDraft(form){if(!form||!draftBaselines.has(form))return true;const values=draftValues(form),base=draftBaselines.get(form);const changed=Object.keys(values).some(key=>values[key]!==base[key]);if(form.dataset.pendingDraft)return !changed;if(!changed)return draftStore.drop(formKey(form));const extra=form===dialogueForm?{nonce:form.dataset.nonce||null,selectedFocus}:{};return draftStore.put(formKey(form),{values,base,revision:form.dataset.revision||null,extra})}
function keepAllDrafts(){let ok=true;for(const form of dirtyForms)if(!keepFormDraft(form))ok=false;return ok}
function keepDialogueDraft(){return !dirtyForms.has(dialogueForm)||keepFormDraft(dialogueForm)}
function renderDrafts(){const panel=document.querySelector('#drafts-panel'),list=document.querySelector('#drafts-list');list.textContent='';for(const [id,record] of Object.entries(draftStore.read())){if(!record||!record.values||!record.base)continue;const form=[...document.querySelectorAll('form')].find(item=>formKey(item)===id);if(form)form.dataset.pendingDraft='true';const card=document.createElement('div');card.className='draft-card';const title=document.createElement('p');const first=form&&form.querySelector('label');title.textContent='Saisie non enregistrée : '+(first?first.textContent:id);card.appendChild(title);const compare=document.createElement('details'),summary=document.createElement('summary'),text=document.createElement('pre');summary.textContent='Comparer le brouillon et le contenu actuel';const current=form?draftValues(form):{};text.textContent=Object.entries(record.values).filter(([key,value])=>typeof value==='string'&&value.length<=12000).map(([key,value])=>key+'\nAu début de la saisie : '+(record.base[key]||'—')+'\nActuellement enregistré : '+(current[key]||'—')+'\nMon brouillon : '+value).join('\n\n');compare.append(summary,text);card.appendChild(compare);if(form){const restore=document.createElement('button');restore.type='button';restore.textContent='Restaurer pour relire';restore.onclick=()=>{delete form.dataset.pendingDraft;restoreDraftFields(form,record.values);if(form===dialogueForm){const extra=record.extra||{};if(extra.nonce&&record.revision===form.dataset.revision)form.dataset.nonce=extra.nonce;if(extra.selectedFocus&&typeof extra.selectedFocus.label==='string'&&extra.selectedFocus.focus){selectedFocus=extra.selectedFocus;showFocus()}}formDirty=true;dirtyForms.add(form);if(form.matches('.learning-report')){form.dataset.dirty='true';form.elements.remaining.required=form.elements.outcome.value!=='success'}keepFormDraft(form);for(let parent=form.parentElement;parent;parent=parent.parentElement)if(parent.tagName==='DETAILS')parent.open=true;card.remove();panel.hidden=!list.children.length;message('Brouillon restauré. Relis le contenu actuel et tes changements avant de les enregistrer.');const field=draftFields(form)[0];if(field)field.focus();form.scrollIntoView({block:'center',behavior:'smooth'})};card.appendChild(restore)}else{const note=document.createElement('p');note.textContent='Ce formulaire a changé ou n’est plus affiché. Tu peux récupérer le texte dans la comparaison.';card.appendChild(note)}const discard=document.createElement('button');discard.type='button';discard.className='secondary';discard.textContent='Écarter le brouillon';discard.onclick=()=>{if(draftStore.drop(id)){if(form){delete form.dataset.pendingDraft;if(dirtyForms.has(form))keepFormDraft(form)}card.remove();panel.hidden=!list.children.length}else message('Impossible d’effacer ce brouillon dans le navigateur.',true)};card.appendChild(discard);list.appendChild(card)}panel.hidden=!list.children.length}
// Migrate the previous chat draft without submitting or restoring it silently.
try{const key='tao-dialogue-draft:'+dialogueForm.dataset.node+':'+worldId,old=JSON.parse(sessionStorage.getItem(key)||'null');if(old&&typeof old.text==='string'&&old.text.length<=6000&&!draftStore.read()['dialogue-send']){if(draftStore.put('dialogue-send',{values:{'dialogue-text':old.text},base:{'dialogue-text':''},revision:null,extra:{selectedFocus:old.selectedFocus||null}}))sessionStorage.removeItem(key)}}catch(e){}
renderDrafts();
'''+EXPLORER_DRAFT_JS+r'''
document.addEventListener('input',e=>{const form=e.target.closest('form');if(!form)return;formDirty=true;dirtyForms.add(form);if(!keepFormDraft(form))message('Un ancien brouillon attend ton choix, ou le stockage du navigateur est plein. Récupère ou écarte les brouillons proposés ; garde cette page ouverte tant que ta saisie n’est pas enregistrée.',true)});
window.addEventListener('beforeunload',keepAllDrafts);
document.querySelector('#clear-focus').onclick=()=>{selectedFocus=null;delete dialogueForm.dataset.nonce;showFocus();keepDialogueDraft()};
for(const button of document.querySelectorAll('.challenge-part'))button.onclick=()=>{const input=document.querySelector('#dialogue-text');const text='J’aimerais remettre en question l’élément sélectionné. Aide-moi à examiner ce qui pose problème, ce qu’il faut préserver et comment vérifier une amélioration.';const combined=input.value?input.value+String.fromCharCode(10)+text:text;if(combined.length>input.maxLength){const msg=document.querySelector('#message');msg.textContent='Ton brouillon est déjà long. Envoie-le ou raccourcis-le avant d’ajouter cette question.';msg.style.display='block';return}selectedFocus={focus:JSON.parse(button.dataset.focus),label:button.dataset.label};showFocus();input.value=combined;input.dispatchEvent(new Event('input',{bubbles:true}));keepDialogueDraft();input.focus();input.scrollIntoView({block:'center',behavior:'smooth'})};
const worldSwitch=document.querySelector('#world-switch');worldSwitch.onsubmit=e=>{e.preventDefault();if(!keepAllDrafts()){message('Garde tes saisies ou récupère les anciens brouillons avant de changer d’espace.',true);return}location.href='/?world='+encodeURIComponent(document.querySelector('#world-select').value)};
for(const link of document.querySelectorAll('[data-world-link],.tao-sidebar a'))link.addEventListener('click',e=>{if(!keepAllDrafts()){e.preventDefault();message('Garde tes saisies ou récupère les anciens brouillons avant de changer de vue ou d’espace.',true)}});
const worldCreate=document.querySelector('#world-create');worldCreate.onsubmit=e=>{e.preventDefault();send('/api/worlds/create',{title:document.querySelector('#world-title').value,description:document.querySelector('#world-description').value,parent_id:worldCreate.dataset.parent,revision:Number(worldCreate.dataset.revision)})};
const worldPresentation=document.querySelector('#world-presentation');worldPresentation.onsubmit=e=>{e.preventDefault();send('/api/worlds/presentation',{view:document.querySelector('#world-view').value,revision:Number(worldPresentation.dataset.revision)})};
for(const form of document.querySelectorAll('.world-transfer'))form.onsubmit=e=>{e.preventDefault();send('/api/worlds/transfer',{target_id:form.elements.target_id.value,text:form.elements.text.value,source_quote:form.elements.source_quote.value,source_message_id:form.dataset.message,revision:Number(form.dataset.revision)})};
const handoffForm=document.querySelector('#dialogue-handoff');handoffForm.onsubmit=async e=>{e.preventDefault();const button=handoffForm.querySelector('button');if(button.disabled)return;button.disabled=true;try{const data=await handoffDocument(document.querySelector('#handoff-file').files[0],Number(handoffForm.dataset.revision));currentSubmission=handoffForm;await send('/api/dialogue/handoff',data)}catch(error){message(error.message,true)}finally{button.disabled=false}};
const newDialogue=document.querySelector('#dialogue-new');newDialogue.onsubmit=e=>{e.preventDefault();send('/api/dialogue/new',{revision:Number(newDialogue.dataset.revision)})};
dialogueForm.addEventListener('input',()=>delete dialogueForm.dataset.nonce);
const reusePanel=document.querySelector('#reuse-suggestions'),dialogueInput=document.querySelector('#dialogue-text');let reuseTimer;
const lookupReuse=createReuseSuggestions(async query=>{const response=await fetch(scoped('/api/reuse/suggest?q='+encodeURIComponent(query)));if(!response.ok)throw Error('Recherche indisponible');return response.json()},result=>{
 reusePanel.replaceChildren();reusePanel.hidden=result.status==='empty';
 if(result.status==='unavailable'){reusePanel.textContent='Les aides locales ne peuvent pas être recherchées maintenant. Ta discussion reste disponible.';return}
 if(result.status!=='matches')return;
 const label=document.createElement('p');label.textContent='Une aide pourrait déjà servir ici, sans appel IA :';reusePanel.appendChild(label);
 for(const row of result.rows){const item=document.createElement('p'),link=document.createElement('a');link.textContent=row.title.slice(0,160);link.href=scoped('/tools')+'#recipe-'+row.id;link.onclick=event=>{if(!keepAllDrafts()){event.preventDefault();message('Copie tes saisies avant de quitter cette page : le navigateur ne peut pas les conserver.',true)}};item.appendChild(link);reusePanel.appendChild(item)}
 const note=document.createElement('small');note.textContent='Correspondance par mots : vérifie son domaine avant de l’utiliser. Tu peux aussi continuer la discussion.';reusePanel.appendChild(note);
});
dialogueInput.addEventListener('input',()=>{clearTimeout(reuseTimer);lookupReuse('');reuseTimer=setTimeout(()=>lookupReuse(dialogueInput.value),350)});
dialogueForm.onsubmit=e=>{e.preventDefault();if(!dialogueForm.dataset.nonce)dialogueForm.dataset.nonce=crypto.randomUUID();send('/api/dialogue/send',{text:document.querySelector('#dialogue-text').value,revision:Number(dialogueForm.dataset.revision),nonce:dialogueForm.dataset.nonce,intent:document.querySelector('#dialogue-intent').value,focus:selectedFocus?selectedFocus.focus:null})};
const memoryForm=document.querySelector('#dialogue-memory');memoryForm.onsubmit=e=>{e.preventDefault();send('/api/dialogue/memory',{text:document.querySelector('#dialogue-memory-text').value,revision:Number(memoryForm.dataset.revision),include_archives:document.querySelector('#dialogue-archives').checked})};
for(const form of document.querySelectorAll('.dialogue-action'))form.onsubmit=e=>{e.preventDefault();const data={id:form.dataset.id};if(form.dataset.action==='retry')data.revision=Number(form.dataset.revision);else data.need_id=form.elements.need_id?form.elements.need_id.value:null;send('/api/dialogue/'+form.dataset.action,data)};
for(const panel of document.querySelectorAll('[data-dialogue-id]')){if(!['queued','running'].includes(panel.dataset.state))continue;let polling=false;const poll=setInterval(async()=>{if(polling)return;polling=true;const status=panel.querySelector('[role="status"]');try{const r=await fetch(scoped('/api/dialogue?id='+encodeURIComponent(panel.dataset.dialogueId)));const result=await r.json();if(r.status===401){clearInterval(poll);loginRequired(result);status.textContent='Session expirée. Reconnecte-toi pour retrouver cette réponse.';return}if(!r.ok)throw new Error(result.error||'Impossible de lire la progression.');status.textContent=result.message;if(!['queued','running'].includes(result.status)){clearInterval(poll);if(!formDirty)location.reload();else retryNotice(status,(result.message||'Réponse disponible.')+' Tes saisies restent ici ; actualise pour voir la réponse, puis restaure les brouillons.')}}catch(e){status.textContent='Connexion à Tao interrompue ou redémarrage en cours. Nouvelle tentative automatique…'}finally{polling=false}},2000)};
for(const form of document.querySelectorAll('.adapt-action'))form.onsubmit=e=>{e.preventDefault();send('/api/adaptation',{task_id:form.dataset.task,action:form.dataset.action,id:form.dataset.id,review_digest:form.dataset.digest,confirmed:form.elements.confirmed?form.elements.confirmed.checked:false,method_ids:[...form.querySelectorAll('[name="method_ids"]:checked')].map(x=>x.value)})};
for(const form of document.querySelectorAll('.learning-report')){form.addEventListener('input',()=>form.dataset.dirty='true');form.elements.outcome.onchange=()=>{form.elements.remaining.required=form.elements.outcome.value!=='success'};form.onsubmit=e=>{e.preventDefault();send('/api/learning/report',{task_id:form.dataset.task,adaptation_id:form.dataset.adaptation,revision:Number(form.dataset.revision),outcome:form.elements.outcome.value,case:form.elements.case.value,observed:form.elements.observed.value,remaining:form.elements.remaining.value})}};
for(const form of document.querySelectorAll('.learning-method'))form.onsubmit=e=>{e.preventDefault();const values={};for(const k of ['title','applicability','method','counterexample','check'])values[k]=form.elements[k].value;send('/api/learning/method',{report_id:form.dataset.report,revision:Number(form.dataset.revision),confirmed:form.elements.confirmed.checked,values})};
for(const form of document.querySelectorAll('.learning-withdraw'))form.onsubmit=e=>{e.preventDefault();send('/api/learning/withdraw',{id:form.dataset.id,revision:Number(form.dataset.revision)})};
for(const button of document.querySelectorAll('.recheck'))button.onclick=()=>location.reload();
for(const panel of document.querySelectorAll('[data-adaptation-id]')){if(!['queued','preparing','running','testing','installing'].includes(panel.dataset.state))continue;let polling=false;const poll=setInterval(async()=>{if(polling)return;polling=true;const status=panel.querySelector('.adapt-message');try{const response=await fetch(scoped('/api/adaptation?id='+encodeURIComponent(panel.dataset.adaptationId)));const result=await response.json();if(response.status===401){clearInterval(poll);loginRequired(result);status.textContent='Session expirée. Reconnecte-toi pour retrouver cette amélioration.';return}if(!response.ok)throw new Error(result.error||'Impossible de lire la progression.');status.textContent=result.message||result.status;if(result.status!==panel.dataset.state){if(!formDirty)location.reload();else if(!['queued','preparing','running','testing','installing'].includes(result.status)){clearInterval(poll);retryNotice(status,(result.message||result.status)+' Tes saisies restent ici ; actualise pour voir le résultat, puis restaure les brouillons.')}}}catch(e){status.textContent='Tao est momentanément indisponible ou redémarre. Reconnexion en cours…'}finally{polling=false}},2000)}
contextForm.onsubmit=e=>{e.preventDefault();send('/api/work/context',{description:document.querySelector('#work-description').value,keep_learning:document.querySelector('#work-learning').value,boundaries:document.querySelector('#work-boundaries').value,revision:Number(contextForm.dataset.revision)})};
const taskForm=document.querySelector('#work-task');if(taskForm)taskForm.onsubmit=e=>{e.preventDefault();send('/api/work/tasks',{title:document.querySelector('#work-task-title').value})};
for(const form of document.querySelectorAll('.work-example'))form.onsubmit=e=>{e.preventDefault();send('/api/work/example',{id:form.dataset.id,revision:Number(form.dataset.revision),situation:form.elements.situation.value,expected:form.elements.expected.value,boundaries:form.elements.boundaries.value})};
const advanced=document.querySelector('#advanced');function showAdvanced(){if(location.hash==='#advanced')advanced.open=true;if(location.hash==='#room-map')document.querySelector('#room-map').open=true;if(location.hash==='#work-progress')document.querySelector('#work-progress').open=true;if(location.hash==='#memory-continuity')document.querySelector('#memory-continuity').open=true}showAdvanced();window.addEventListener('hashchange',showAdvanced);
function followLatestDialogue(){if(location.hash&&location.hash!=='#dialogue')return;const timeline=document.querySelector('#dialogue-timeline');if(timeline&&timeline.querySelector('.chat-turn'))timeline.scrollTop=timeline.scrollHeight}followLatestDialogue();window.addEventListener('load',followLatestDialogue);
document.querySelector('#story').onsubmit=e=>{e.preventDefault();send('/api/story',{text:document.querySelector('#storytext').value})};
document.querySelector('#origin').onchange=e=>{document.querySelector('#trace-fields').open=e.target.value!=='undetermined'};
document.querySelector('#buffer').onsubmit=e=>{e.preventDefault();const origin=document.querySelector('#origin').value;const trace={};if(origin!=='undetermined'){for(const key of ['source','destination','input','output','difference'])trace[key]=document.querySelector('#trace-'+key).value}send('/api/buffers',{residual:document.querySelector('#residual').value,desired:document.querySelector('#desired').value,acceptance:document.querySelector('#acceptance').value,origin_type:origin,trace})};
document.querySelector('#wake').onclick=()=>send('/api/wake',{});
</script></body></html>'''
