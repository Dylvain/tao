"""One stable navigation surface for Tao's human-facing views.

The sidebar is a projection of two independent axes: the selected space and
the selected view.  It does not turn theory terms into runtime capabilities,
nor does it change permissions or private state while rendering.
"""
import html
import os
from urllib.parse import urlencode


TYPE_GROUPS = (
    ('understand', ('story', 'problem', 'question')),
    ('orient', ('objective', 'mission')),
    ('relations', ('person', 'role')),
    ('agreements', ('contract', 'commitment')),
    ('act', ('task', 'method', 'resource')),
    ('measure', ('income', 'expense', 'evidence')),
)


WORDS = {
    'fr': {
        'navigation': 'Navigation principale', 'menu': 'Menu',
        'current_space': 'Espace actuel', 'change_space': 'Changer d’espace',
        'spaces': 'Mes espaces', 'essential': 'Orientation', 'landmarks': 'Repères',
        'centers': 'Mes centres', 'center_factory': 'Centre principal',
        'no_centers': 'Aucun centre spécialisé',
        'work': 'Travailler', 'reference': 'Comprendre et équiper',
        'sources': 'Sources', 'build': 'Construire', 'system': 'Tao',
        'home': 'Accueil', 'discussion': 'Discussion', 'follow': 'À suivre',
        'all_landmarks': 'Tous les repères',
        'understand': 'Comprendre', 'orient': 'Orienter',
        'relations': 'Liens et rôles', 'agreements': 'Accords',
        'act': 'Agir', 'measure': 'Mesurer et vérifier',
        'conversations': 'Conversations', 'import': 'Importer',
        'tools': 'Aides réutilisables', 'workshop': 'Atelier',
        'devices': 'Appareils', 'trends': 'Observatoire',
        'atlas': 'Atlas Tao', 'atlas_note': 'Dictionnaire et modèles',
        'connection': 'Connexion IA', 'guide': 'Guide',
        'account': 'Mon accès', 'model': 'Connexion du modèle',
        'archived': 'archivé',
        'one_context': 'Centres pour agir · vues pour comprendre',
    },
    'en': {
        'navigation': 'Main navigation', 'menu': 'Menu',
        'current_space': 'Current space', 'change_space': 'Change space',
        'spaces': 'My spaces', 'essential': 'Orientation', 'landmarks': 'Landmarks',
        'centers': 'My centers', 'center_factory': 'Main center',
        'no_centers': 'No specialized center',
        'work': 'Work', 'reference': 'Understand and equip',
        'sources': 'Sources', 'build': 'Build', 'system': 'Tao',
        'home': 'Home', 'discussion': 'Discussion', 'follow': 'To follow',
        'all_landmarks': 'All landmarks',
        'understand': 'Understand', 'orient': 'Orient',
        'relations': 'People and roles', 'agreements': 'Agreements',
        'act': 'Act', 'measure': 'Measure and verify',
        'conversations': 'Conversations', 'import': 'Import',
        'tools': 'Reusable aids', 'workshop': 'Workshop',
        'devices': 'Devices', 'trends': 'Observatory',
        'atlas': 'Tao atlas', 'atlas_note': 'Dictionary and models',
        'connection': 'AI connection', 'guide': 'Guide',
        'account': 'My access', 'model': 'Model connection',
        'archived': 'archived',
        'one_context': 'Centers to act · views to understand',
    },
}


CSS = r'''
:root{--tao-nav-width:292px}
body.tao-has-sidebar{padding-left:var(--tao-nav-width)}
.tao-nav-toggle-input{display:none!important}
.tao-mobilebar,.tao-nav-scrim{display:none}
.tao-sidebar{position:fixed;z-index:30;inset:0 auto 0 0;width:var(--tao-nav-width);display:flex;flex-direction:column;overflow:hidden;border-right:1px solid var(--line);background:var(--panel);color:var(--text);font:14px/1.35 system-ui,sans-serif}
.tao-sidebar *{box-sizing:border-box}
.tao-sidebar a{color:var(--text);text-decoration:none}
.tao-sidebar-head{display:flex;align-items:center;justify-content:space-between;min-height:66px;padding:0 19px;border-bottom:1px solid var(--line)}
.tao-sidebar .tao-brand{font-family:Georgia,ui-serif,serif;font-size:29px;font-weight:700;letter-spacing:-.09em;color:var(--text)}
.tao-sidebar-version{color:var(--muted);font-size:11px}
.tao-space-zone{padding:15px 14px 11px}
.tao-nav-label,.tao-nav-section-title{display:block;margin:0 0 7px;color:var(--muted);font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase}
.tao-space-picker{position:relative;margin:0!important}
.tao-space-picker>summary{display:flex!important;align-items:center;justify-content:space-between;gap:10px;min-height:50px!important;padding:8px 11px!important;border:1px solid #b9c8bd;border-radius:10px;background:var(--panel);color:var(--text)!important;list-style:none;cursor:pointer}
.tao-space-picker>summary::-webkit-details-marker{display:none}
.tao-space-picker>summary::after{content:'⌄';color:var(--muted);font-size:17px}
.tao-space-picker[open]>summary::after{content:'⌃'}
.tao-space-picker strong,.tao-space-picker small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tao-space-picker strong{font-size:14px}.tao-space-picker small{margin-top:2px;color:var(--muted);font-size:11px}
.tao-space-options{display:grid;gap:2px;max-height:285px;overflow:auto;margin-top:6px;padding:5px;border:1px solid var(--line);border-radius:10px;background:var(--panel);box-shadow:0 14px 32px #27372f1c}
.tao-space-options a{display:block;padding:8px 9px;border-radius:7px;overflow-wrap:anywhere}
.tao-space-options a:hover,.tao-space-options a[aria-current=location]{background:var(--soft);color:var(--accent)}
.tao-sidebar-scroll{min-height:0;flex:1;overflow-y:auto;padding:0 9px 16px;scrollbar-width:thin}
.tao-nav-block{padding:8px 0}.tao-nav-block+.tao-nav-block{border-top:1px solid var(--line)}
.tao-reference-zone{margin:3px 0!important;border-top:1px solid var(--line)}
.tao-reference-zone>summary{display:flex!important;align-items:center;justify-content:space-between;min-height:43px!important;padding:8px 9px!important;color:var(--muted)!important;font-size:11px;font-weight:800;letter-spacing:.075em;text-transform:uppercase;list-style:none;cursor:pointer}
.tao-reference-zone>summary::-webkit-details-marker{display:none}.tao-reference-zone>summary::after{content:'+';font-size:17px;line-height:1}.tao-reference-zone[open]>summary::after{content:'−'}.tao-reference-zone>.tao-reference-content{padding-bottom:4px}.tao-work-block{padding-top:4px}
.tao-nav-section-title{padding:0 9px;margin-bottom:3px}
.tao-nav-items{display:grid;gap:2px}
.tao-nav-item{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:34px;padding:6px 10px 6px 14px;border-radius:8px}
.tao-nav-item:hover{background:var(--soft)}
.tao-nav-item[aria-current=page]{background:var(--soft);color:var(--accent);font-weight:720;box-shadow:inset 3px 0 0 var(--accent)}
.tao-nav-group{margin:1px 0!important}
.tao-nav-group>summary{display:flex!important;align-items:center;justify-content:space-between;min-height:30px!important;padding:4px 9px!important;color:var(--muted)!important;font-size:12px;font-weight:760;letter-spacing:.025em;list-style:none;cursor:pointer}
.tao-nav-group>summary::-webkit-details-marker{display:none}
.tao-nav-group>summary::after{content:'›';font-size:17px;line-height:1}.tao-nav-group[open]>summary::after{transform:rotate(90deg)}
.tao-nav-group .tao-nav-item{padding-left:17px}
.tao-center-list .tao-nav-item{align-items:flex-start}.tao-center-list .tao-nav-item small{display:block;margin-top:2px;color:var(--muted);font-size:10px;font-weight:500}
.tao-center-empty{margin:5px 10px 7px;color:var(--muted);font-size:11px}
.tao-atlas-link{min-height:45px;border:1px solid var(--line);background:color-mix(in srgb,var(--panel) 82%,var(--soft))}
.tao-atlas-link span,.tao-atlas-link small{display:block}.tao-atlas-link small{margin-top:1px;color:var(--muted);font-size:10px;font-weight:500}
.tao-sidebar-footer{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:46px;padding:8px 16px;border-top:1px solid var(--line);color:var(--muted);font-size:11px}
.tao-sidebar-languages{white-space:nowrap}.tao-sidebar-languages a{color:var(--accent)}
body:has(#continuity-panel:target) .tao-nav-item[data-tao-key=discussion],body:has(#work-progress:target) .tao-nav-item[data-tao-key=discussion]{background:transparent;color:var(--text);font-weight:400;box-shadow:none}
body:has(#continuity-panel:target) .tao-nav-item[data-tao-key=follow],body:has(#work-progress:target) .tao-nav-item[data-tao-key=workshop]{background:var(--soft);color:var(--accent);font-weight:720;box-shadow:inset 3px 0 0 var(--accent)}
@media(max-width:860px){
 body.tao-has-sidebar{padding-left:0}
 .tao-nav-toggle-input{display:block!important;position:fixed!important;width:1px!important;height:1px!important;left:0!important;top:0!important;opacity:0!important;pointer-events:none!important}
 .tao-mobilebar{position:sticky;z-index:31;top:0;display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:56px;margin:0!important;padding:8px 14px!important;border-bottom:1px solid var(--line);background:var(--panel);color:var(--text);cursor:pointer}
 .tao-mobilebar .tao-brand{font-family:Georgia,ui-serif,serif;font-size:24px;font-weight:700;letter-spacing:-.08em}.tao-mobilebar strong{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px}.tao-mobilebar .tao-menu-mark{font-size:20px}
 .tao-nav-toggle-input:focus-visible+.tao-mobilebar{outline:3px solid var(--accent);outline-offset:-3px}
 .tao-sidebar{top:56px;width:min(88vw,320px);transform:translateX(-105%);transition:transform .16s ease;box-shadow:16px 0 38px #27372f24}
 .tao-nav-toggle-input:checked~.tao-sidebar{transform:translateX(0)}
 .tao-nav-scrim{position:fixed;z-index:29;inset:56px 0 0;cursor:pointer;background:#17241d4f}
 .tao-nav-toggle-input:checked~.tao-nav-scrim{display:block}
 .tao-sidebar-head{display:none}
}
@media(prefers-reduced-motion:reduce){.tao-sidebar{transition:none}}
'''


def _url(path, params=(), fragment=''):
    value = path
    if params:
        value += '?' + urlencode(params)
    if fragment:
        value += '#' + fragment
    return html.escape(value, quote=True)


def _item(words, key, label, href, current, *, concept=None, ident=None,
          note=None, link_class='', world_link=True):
    classes = 'tao-nav-item' + (' ' + link_class if link_class else '')
    attrs = [f'class="{classes}"', f'href="{href}"',
             f'data-tao-key="{html.escape(key, quote=True)}"']
    if concept:
        attrs.append(f'data-tao-type="{html.escape(concept, quote=True)}"')
    if ident:
        attrs.append(f'id="{html.escape(ident, quote=True)}"')
    if world_link:
        attrs.append('data-world-link')
    if current == key:
        attrs.append('aria-current="page"')
    content = html.escape(label)
    if note:
        content = f'<span><span>{content}</span><small>{html.escape(note)}</small></span>'
    return '<a ' + ' '.join(attrs) + '>' + content + '</a>'


def _space_url(current, target, locale):
    if current == 'centers' or current.startswith('center:'):
        return _url('/centers', (('world', target), ('lang', locale)))
    if current == 'discussion':
        return _url('/', (('world', target), ('view', 'dialogue')), 'dialogue')
    if current == 'follow':
        return _url('/', (('world', target), ('view', 'dialogue')), 'continuity-panel')
    if current == 'workshop':
        return _url('/', (('world', target), ('view', 'dialogue')), 'work-progress')
    if current in {key for _, keys in TYPE_GROUPS for key in keys}:
        return _url('/explore', (('world', target), ('lang', locale), ('type', current)))
    return _url('/explore', (('world', target), ('lang', locale)))


def render(n, s, locale='fr', current='home', world=None, overview=None,
           languages=True, same_page=False, link_class=''):
    """Return one sidebar; rendering reads metadata and never changes state."""
    import tao_foundations as foundations
    import tao_worlds as worlds
    import tao_centers as centers

    locale = locale if locale in WORDS else 'fr'
    words = WORDS[locale]
    world = world or worlds.current()
    overview = overview or foundations.overview(n, locale=locale)
    spaces = overview.get('spaces', [])
    active_space = next((row for row in spaces if row.get('id') == world), None)
    space_title = ((active_space or {}).get('display_title') or
                   (active_space or {}).get('title') or world)
    concept_rows = {row['key']: row for row in overview.get('concepts', [])}

    space_links = []
    for row in spaces:
        title = row.get('display_title') or row.get('title') or row.get('id')
        if row.get('effective_archived'):
            title += ' · ' + words['archived']
        marker = ' aria-current="location"' if row.get('id') == world else ''
        protected = f' class="{html.escape(link_class, quote=True)}"' if link_class else ''
        space_links.append(f'<a href="{_space_url(current, row["id"], locale)}" data-world-link{protected}{marker}>{html.escape(title)}</a>')

    def local_or(path, params, fragment):
        return '#' + fragment if same_page else _url(path, params, fragment)

    scoped = (('world', world),)
    scoped_locale = (('world', world), ('lang', locale))
    view_scope = scoped_locale if languages else scoped
    top = ''.join((
        _item(words, 'home', words['home'], _url('/', (('world', 'main'), ('lang', locale))), current,
              link_class=link_class),
        _item(words, 'discussion', words['discussion'], local_or('/', (('world', world), ('view', 'dialogue')), 'dialogue'), current,
              link_class=link_class),
        _item(words, 'follow', words['follow'], local_or('/', (('world', world), ('view', 'dialogue')), 'continuity-panel'), current,
              link_class=link_class),
        _item(words, 'landmarks', words['all_landmarks'], _url('/explore', view_scope), current,
              link_class=link_class),
    ))

    center_view = centers.view(n, s)
    center_by_id = {row['id']: row for row in center_view['centers']}
    center_children = {None: []}
    for row in center_view['centers']:
        center_children.setdefault(row.get('parent_id'), []).append(row)
    for rows in center_children.values():
        rows.sort(key=lambda row: (row['status'] == 'retired', row['created_at'], row['id']))
    center_rows = []
    def add_center_rows(parent=None, depth=0):
        for row in center_children.get(parent, []):
            title = ('↳ ' * min(depth, 3)) + row['definition']['title']
            status = row['status']
            center_rows.append(_item(words, 'center:' + row['id'], title,
                _url('/centers', view_scope + (('center', row['id']),)), current,
                note=status, link_class=link_class))
            add_center_rows(row['id'], depth + 1)
    add_center_rows()
    # Invalid orphan rows are rejected by tao_centers before rendering. Keeping
    # this count explicit prevents a navigation bug from silently hiding data.
    if len(center_rows) != len(center_by_id):
        raise ValueError('Hiérarchie des centres incomplète.')
    center_factory = _item(words, 'centers', words['center_factory'],
                           _url('/', view_scope), current, link_class=link_class)
    centers_navigation = center_factory + ''.join(center_rows)
    if not center_rows:
        centers_navigation += '<p class="tao-center-empty">' + html.escape(words['no_centers']) + '</p>'

    groups = []
    for group_key, concept_keys in TYPE_GROUPS:
        rows = []
        for key in concept_keys:
            concept = concept_rows.get(key) or foundations.get_concept(key, locale)
            rows.append(_item(words, key, concept['label'],
                              _url('/explore', view_scope + (('type', key),)), current,
                              concept=key, link_class=link_class))
        opened = current in concept_keys
        groups.append(f'<details class="tao-nav-group"{" open" if opened else ""}><summary>{html.escape(words[group_key])}</summary><div class="tao-nav-items">{"".join(rows)}</div></details>')

    workshop_href = local_or('/', (('world', world), ('view', 'dialogue')), 'work-progress')
    workshop_id = 'workshop-link' if same_page else None
    sources = ''.join((
        _item(words, 'conversations', words['conversations'], _url('/history', scoped), current, link_class=link_class),
        _item(words, 'import', words['import'], _url('/onboarding', (('world', 'main'),)), current, link_class=link_class),
    ))
    build = ''.join((
        _item(words, 'tools', words['tools'], _url('/tools', scoped), current, link_class=link_class),
        _item(words, 'workshop', words['workshop'], workshop_href, current,
              ident=workshop_id, link_class=link_class),
        _item(words, 'devices', words['devices'], _url('/devices', scoped), current, link_class=link_class),
        _item(words, 'trends', words['trends'], _url('/trends', view_scope), current, link_class=link_class),
    ))
    system = ''.join((
        _item(words, 'atlas', words['atlas'], _url('/lexicon'), current,
              note=words['atlas_note'], link_class='tao-atlas-link ' + link_class, world_link=False),
        _item(words, 'connection', words['connection'], _url('/connect', view_scope), current, link_class=link_class),
        _item(words, 'guide', words['guide'], _url('/guide', view_scope), current, link_class=link_class),
    ))
    if os.environ.get('TAO_HOSTED') == '1':
        system += _item(words, 'account', words['account'], _url('/host/account'), current,
                        link_class=link_class, world_link=False)
        system += _item(words, 'model', words['model'], _url('/host/ai'), current,
                        link_class=link_class, world_link=False)

    language_links = ''
    if languages:
        links = []
        for lang, label in (('fr', 'FR'), ('en', 'EN')):
            if current == 'home':
                href = _url('/', (('world', world), ('lang', lang)))
            elif current == 'centers' or current.startswith('center:'):
                params = (('world', world), ('lang', lang))
                if current.startswith('center:'):
                    params += (('center', current.split(':', 1)[1]),)
                href = _url('/centers', params)
            elif current in {key for _, keys in TYPE_GROUPS for key in keys}:
                href = _url('/explore', (('world', world), ('lang', lang), ('type', current)))
            else:
                href = _url('/explore', (('world', world), ('lang', lang)))
            marker = ' aria-current="true"' if lang == locale else ''
            protected = f' class="{html.escape(link_class, quote=True)}"' if link_class else ''
            links.append(f'<a href="{href}" lang="{lang}" hreflang="{lang}"{protected}{marker}>{label}</a>')
        language_links = '<span class="tao-sidebar-languages">' + ' · '.join(links) + '</span>'

    version = html.escape(str(getattr(n, 'NODE_VERSION', '')))
    escaped_title = html.escape(str(space_title))
    reference_open = current != 'home' and current != 'centers' and not current.startswith('center:')
    return f'''<input class="tao-nav-toggle-input" id="tao-nav-toggle" type="checkbox" aria-label="{html.escape(words['menu'])}">
<label class="tao-mobilebar" for="tao-nav-toggle"><span class="tao-brand">tao.</span><strong>{escaped_title}</strong><span class="tao-menu-mark" aria-hidden="true">☰</span></label>
<aside class="tao-sidebar" data-tao-sidebar aria-label="{html.escape(words['navigation'])}">
<div class="tao-sidebar-head"><a class="tao-brand" href="/?world=main">tao.</a><span class="tao-sidebar-version">{version}</span></div>
<div class="tao-space-zone"><span class="tao-nav-label">{html.escape(words['current_space'])}</span>
<details class="tao-space-picker"><summary><span><strong>{escaped_title}</strong><small>{html.escape(words['change_space'])}</small></span></summary><div class="tao-space-options" aria-label="{html.escape(words['spaces'])}">{''.join(space_links)}</div></details></div>
<div class="tao-sidebar-scroll"><div role="navigation" aria-label="{html.escape(words['navigation'])}">
<div class="tao-nav-block tao-center-list tao-work-block"><span class="tao-nav-section-title">{html.escape(words['work'])}</span><div class="tao-nav-items">{centers_navigation}</div></div>
<details class="tao-reference-zone"{' open' if reference_open else ''}><summary>{html.escape(words['reference'])}</summary><div class="tao-reference-content">
<div class="tao-nav-block"><span class="tao-nav-section-title">{html.escape(words['essential'])}</span><div class="tao-nav-items">{top}</div></div>
<div class="tao-nav-block"><span class="tao-nav-section-title">{html.escape(words['landmarks'])}</span>{''.join(groups)}</div>
<div class="tao-nav-block"><span class="tao-nav-section-title">{html.escape(words['sources'])}</span><div class="tao-nav-items">{sources}</div></div>
<div class="tao-nav-block"><span class="tao-nav-section-title">{html.escape(words['build'])}</span><div class="tao-nav-items">{build}</div></div>
<div class="tao-nav-block"><span class="tao-nav-section-title">{html.escape(words['system'])}</span><div class="tao-nav-items">{system}</div></div>
</div></details></div></div><div class="tao-sidebar-footer"><span>{html.escape(words['one_context'])}</span>{language_links}</div></aside>
<label class="tao-nav-scrim" for="tao-nav-toggle" aria-hidden="true"></label>'''
