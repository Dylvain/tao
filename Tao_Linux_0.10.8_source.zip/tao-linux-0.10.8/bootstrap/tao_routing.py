"""Pure validation of proposed conversational contributions, without execution.

Function labels describe available kinds of help. They neither create autonomous
centres nor grant a model, tool, or source any authority over the local runtime.
"""
import copy


INTENTS = ('auto', 'understand', 'learn', 'delegate', 'improve')
_INTENT_LABELS = {
    'auto': 'À préciser dans la discussion',
    'understand': 'M’aider à comprendre',
    'learn': 'M’aider à apprendre et pratiquer',
    'delegate': 'Examiner ce que je peux déléguer',
    'improve': 'Améliorer une aide ou le logiciel',
}

_FUNCTIONS = {
    'explain': {'function_id': 'explain', 'function_version': 1,
                'title': 'Comprendre et expliquer',
                'operators': ['α_abstraction', 'δ_distinction'],
                'contract': 'Expliquer à partir du contexte fourni ; distinguer faits rapportés, hypothèses et inconnues.'},
    'review_provided_source': {'function_id': 'review_provided_source', 'function_version': 1,
                'title': 'Examiner une source fournie',
                'operators': ['δ_distinction', 'α_abstraction'],
                'contract': 'Examiner au moins un message ou passage fourni, avec son attribution ; aucun accès supplémentaire.'},
    'clarify_need': {'function_id': 'clarify_need', 'function_version': 1,
                'title': 'Clarifier un besoin',
                'operators': ['δ_distinction', 'ν_valuation'],
                'contract': 'Préciser résultat souhaité, contraintes et critère ; ne pas transformer une envie en mandat.'},
    'propose_code': {'function_id': 'propose_code', 'function_version': 1,
                'title': 'Proposer une amélioration du logiciel',
                'operators': ['Γ_composition', 'α_abstraction'],
                'contract': 'Accompagner une proposition de code présente ; préparation, tests et installation suivent leurs choix explicites.'},
}

_CONTRIBUTION_SCHEMA = {
    'type': 'object',
    'properties': {
        'function_id': {'type': 'string', 'enum': list(_FUNCTIONS)},
        'reason': {'type': 'string', 'minLength': 1, 'maxLength': 400},
        'expected': {'type': 'string', 'minLength': 1, 'maxLength': 400},
        'source_ids': {'type': 'array', 'maxItems': 4,
                       'items': {'type': 'string', 'minLength': 1, 'maxLength': 120}},
    },
    'required': ['function_id', 'reason', 'expected', 'source_ids'],
    'additionalProperties': False,
}
SCHEMA = {'anyOf': [
    {'type': 'null'},
    {'type': 'object', 'properties': {
        'intent': {'type': 'string', 'minLength': 1, 'maxLength': 500},
        'contributions': {'type': 'array', 'maxItems': 3, 'items': _CONTRIBUTION_SCHEMA},
    }, 'required': ['intent', 'contributions'], 'additionalProperties': False},
]}


def validate_intent(value='auto'):
    if not isinstance(value, str) or value not in INTENTS:
        raise ValueError('Choisir une intention : auto, comprendre, apprendre, déléguer ou améliorer.')
    return value


def context(intent='auto'):
    intent = validate_intent(intent)
    return {'schema': 'tao.routing.context.v1', 'version': 1, 'observer': 'C0',
            'human_intent': intent, 'human_intent_label': _INTENT_LABELS[intent],
            'functions': copy.deepcopy(list(_FUNCTIONS.values())),
            'execution_enabled': False,
            'contract': [
                'Proposer au plus trois contributions distinctes, ou aucune ; elles ne sont pas exécutées par ce routage.',
                'L’intention humaine oriente la discussion sans accorder de permission ; déléguer ne vaut pas autorisation métier.',
                'C0 et les opérateurs sont des descriptions fonctionnelles, pas des centres autonomes ni une conscience.',
                'Utiliser seulement les identifiants des messages et passages fournis ; une source IA reste non vérifiée.',
                'Examiner une source exige au moins un identifiant ; proposer du code exige aussi une proposition de code structurée.',
                'Préserver ce que la personne souhaite comprendre ou pratiquer ; aucun accès à un autre espace n’est déduit.',
            ]}


def _text(value, label, maximum):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError(label + ' : texte requis, ' + str(maximum) + ' caractères maximum.')
    return value.strip()


def _sources(messages):
    if not isinstance(messages, list):
        raise ValueError('Les sources du routage doivent être une liste de messages fournis.')
    sources = {}
    for message in messages:
        if not isinstance(message, dict):
            raise ValueError('Message source invalide.')
        ident = message.get('id', message.get('message_id'))
        if not isinstance(ident, str) or not ident or len(ident) > 120:
            raise ValueError('Identifiant de source invalide.')
        if (message.get('id') is not None and message.get('message_id') is not None
                and message['id'] != message['message_id']):
            raise ValueError('Identifiant de source ambigu.')
        if not isinstance(message.get('text'), str) or message.get('role') not in ('user', 'assistant'):
            raise ValueError('Une source exige son texte et son rôle attribué.')
        signature = (message['text'], message['role'])
        if ident in sources and sources[ident] != signature:
            raise ValueError('Deux sources différentes portent le même identifiant.')
        sources[ident] = signature
    return sources


def resolve(raw, messages, proposal):
    """Return inert, server-enriched contributions from supplied sources only."""
    if raw is None:
        return None
    if not isinstance(raw, dict) or set(raw) != {'intent', 'contributions'}:
        raise ValueError('Routage invalide : intention et contributions seules attendues.')
    intent = _text(raw['intent'], 'L’intention proposée', 500)
    items = raw['contributions']
    if not isinstance(items, list) or len(items) > 3:
        raise ValueError('Trois contributions proposées maximum.')
    sources = _sources(messages)
    contributions, used = [], set()
    for item in items:
        if not isinstance(item, dict) or set(item) != {'function_id', 'reason', 'expected', 'source_ids'}:
            raise ValueError('Champs de contribution invalides ; aucune commande acceptée.')
        ident = item['function_id']
        if not isinstance(ident, str) or ident not in _FUNCTIONS:
            raise ValueError('Fonction inconnue ; seules les fonctions du registre sont admises.')
        if ident in used:
            raise ValueError('Une même fonction ne peut pas être proposée deux fois.')
        used.add(ident)
        reason = _text(item['reason'], 'Le motif', 400)
        expected = _text(item['expected'], 'Le résultat attendu', 400)
        refs = item['source_ids']
        if (not isinstance(refs, list) or len(refs) > 4 or
                any(not isinstance(ref, str) or not ref or len(ref) > 120 for ref in refs)):
            raise ValueError('Quatre identifiants de source valides maximum.')
        if len(set(refs)) != len(refs):
            raise ValueError('Une source ne doit pas être citée deux fois dans la même contribution.')
        if any(ref not in sources for ref in refs):
            raise ValueError('Une source citée n’a pas été fournie dans ce contexte.')
        if ident == 'review_provided_source' and not refs:
            raise ValueError('Examiner une source exige au moins un passage fourni.')
        if ident == 'propose_code' and not isinstance(proposal, dict):
            raise ValueError('Une proposition de code structurée est requise pour cette contribution.')
        registered = _FUNCTIONS[ident]
        contributions.append({key: copy.deepcopy(registered[key])
                              for key in ('function_id', 'function_version', 'title', 'operators')})
        contributions[-1].update(reason=reason, expected=expected, source_ids=list(refs),
                                 status='proposed', execution_enabled=False)
    return {'intent': intent, 'contributions': contributions}
