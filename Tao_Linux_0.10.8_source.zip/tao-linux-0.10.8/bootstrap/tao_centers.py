"""Human-governed center factory over private, world-scoped state.

A typed transformation is not automatically a center.  AI may propose a
candidate or a trial output, but only reported cases and an exact human review
can qualify and activate it.  Model assimilation never calls a tool or external
service.  The owner-only action boundary may delegate one reviewed request to
the connector module, which keeps the exact receipt and prevents replay.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
import uuid
from datetime import datetime

import tao_connectors as connectors
import tao_worlds as worlds
from tao_work import check_revision, text_field


SCHEMA = 'tao.centers.v1'
CENTER_SCHEMA = 'tao.center.v1'
TRIAL_SCHEMA = 'tao.center.trial.v1'
LINK_SCHEMA = 'tao.center.link.v1'
CONTRACT_SCHEMA = 'tao.center.contract.v1'
MAX_CENTERS = 32
MAX_LINKS = 64
MAX_PREPARED_ADAPTERS = 16
MAX_TRIALS = 60
MAX_HISTORY = 20
MAX_ACTION_INPUTS = 24
MAX_ACTION_INPUT_BYTES = 24 * 1024
ACTION_INPUT_STATUSES = ('succeeded', 'tool_error', 'failed', 'blocked', 'unknown')
STATUSES = ('candidate', 'active', 'paused', 'retired')
OUTCOMES = ('success', 'partial', 'failure', 'counterexample')
DEFINITION_FIELDS = ('title', 'purpose', 'input', 'process', 'output', 'benefit',
                     'acceptance', 'boundaries')
CONTRACT_FIELDS = {'schema', 'version', 'id', 'source', 'definition', 'authority',
                   'permissions', 'automatic_execution', 'sha256'}
CONTRACT_SOURCE_FIELDS = {'publisher', 'center_title', 'node_version', 'exported_at'}
MAX_CONTRACT_BYTES = 24 * 1024


AI_PROPOSAL_SCHEMA = {'anyOf': [{'type': 'null'}, {'type': 'object', 'properties': {
    'title': {'type': 'string'},
    'purpose': {'type': 'string'},
    'input': {'type': 'string'},
    'process': {'type': 'array', 'items': {'type': 'string'}},
    'output': {'type': 'string'},
    'benefit': {'type': 'string'},
    'acceptance': {'type': 'string'},
    'boundaries': {'type': 'string'},
}, 'required': list(DEFINITION_FIELDS), 'additionalProperties': False}]}


AI_OUTPUT_SCHEMA = {'anyOf': [{'type': 'null'}, {'type': 'object', 'properties': {
    'output': {'type': 'string'},
    'process': {'type': 'array', 'items': {'type': 'string'}},
    'benefit': {'type': 'string'},
    'residual': {'type': 'string'},
}, 'required': ['output', 'process', 'benefit', 'residual'],
    'additionalProperties': False}]}


# Structural suggestions are data, never tool calls.  Creation and revision use
# the same visible x -> f -> f(x) contract; their allowed focus differs locally.
AI_REVISION_SCHEMA = AI_PROPOSAL_SCHEMA
AI_LINK_SCHEMA = {'anyOf': [{'type': 'null'}, {'type': 'object', 'properties': {
    'source_id': {'type': 'string'},
    'target_id': {'type': 'string'},
    'translation': {'type': 'string'},
    'purpose': {'type': 'string'},
}, 'required': ['source_id', 'target_id', 'translation', 'purpose'],
    'additionalProperties': False}]}


# An organ is a provider-neutral coupling around a center.  The model describes
# semantics and requested effect classes only: no command, endpoint, credential,
# package or implementation is accepted here.  A retained plan is still inert.
ORGAN_SCHEMA = 'tao.center.organ.v1'
ORGAN_ROLES = ('input', 'output', 'tool', 'bridge')
ORGAN_EFFECTS = ('read', 'write', 'execute', 'network', 'interactive_ui')
ORGAN_FIELDS = ('name', 'role', 'interface', 'operation', 'input', 'output',
                'translation', 'requested_effects', 'requirements', 'purpose',
                'acceptance', 'boundaries')
AI_ORGAN_SCHEMA = {'anyOf': [{'type': 'null'}, {'type': 'object', 'properties': {
    'name': {'type': 'string'},
    'role': {'type': 'string', 'enum': list(ORGAN_ROLES)},
    'interface': {'type': 'string'},
    'operation': {'type': 'string'},
    'input': {'type': 'string'},
    'output': {'type': 'string'},
    'translation': {'type': 'string'},
    'requested_effects': {'type': 'array', 'items': {
        'type': 'string', 'enum': list(ORGAN_EFFECTS)}},
    'requirements': {'type': 'array', 'items': {'type': 'string'}},
    'purpose': {'type': 'string'},
    'acceptance': {'type': 'string'},
    'boundaries': {'type': 'string'},
}, 'required': list(ORGAN_FIELDS), 'additionalProperties': False}]}


# A center action is an exact, inert request for one already installed MCP
# tool. Arbitrary arguments cross the strict provider schema as JSON text and
# are decoded again by the connector boundary. The model can never name a
# command, credential or connector configuration here.
ACTION_FIELDS = ('connector_id', 'tool', 'arguments_json', 'purpose', 'expected',
                 'risk', 'rollback')
AI_ACTION_SCHEMA = {'anyOf': [{'type': 'null'}, {'type': 'object', 'properties': {
    'connector_id': {'type': 'string'},
    'tool': {'type': 'string'},
    'arguments_json': {'type': 'string'},
    'purpose': {'type': 'string'},
    'expected': {'type': 'string'},
    'risk': {'type': 'string'},
    'rollback': {'type': 'string'},
}, 'required': list(ACTION_FIELDS), 'additionalProperties': False}]}

# Compatibility reader for blueprints retained by the former narrow pilot.
# New model responses never use this shape.  Keeping it separate lets existing
# attributed records survive byte-for-byte and makes rollback non-destructive.
LEGACY_ADAPTER_FIELDS = ('provider', 'capability', 'source', 'selection', 'mapping',
                         'purpose', 'acceptance', 'boundaries')


def _empty():
    return {'schema': SCHEMA, 'revision': 0, 'centers': {}, 'links': []}


def _identifier(value, label='Centre'):
    if not isinstance(value, str) or not re.fullmatch(r'[a-f0-9]{12}', value):
        raise ValueError(label + ' inconnu : identifiant invalide.')
    return value


def _steps(value, label='Le processus'):
    if not isinstance(value, list) or not 1 <= len(value) <= 8:
        raise ValueError(label + ' : une à huit étapes sont requises.')
    return [text_field(step, label, 500, True) for step in value]


def definition(value):
    """Validate the visible input → process → output contract."""
    if not isinstance(value, dict) or set(value) != set(DEFINITION_FIELDS):
        raise ValueError('Définition de centre incomplète ou ambiguë.')
    return {
        'title': text_field(value['title'], 'Le nom du centre', 120, True),
        'purpose': text_field(value['purpose'], 'La raison du centre', 1200, True),
        'input': text_field(value['input'], 'L’entrée', 2000, True),
        'process': _steps(value['process']),
        'output': text_field(value['output'], 'La sortie', 2000, True),
        'benefit': text_field(value['benefit'], 'Le bénéfice attendu', 1500, True),
        'acceptance': text_field(value['acceptance'], 'La preuve attendue', 1500, True),
        'boundaries': text_field(value['boundaries'], 'Les limites', 1500),
    }


def validate_ai_proposal(value):
    return None if value is None else definition(value)


def _contract_bytes(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(',', ':'), allow_nan=False).encode('utf-8')
    except (TypeError, ValueError, OverflowError, RecursionError, UnicodeError) as exc:
        raise ValueError('Contrat de centre JSON invalide.') from exc


def _contract_digest(value):
    return hashlib.sha256(_contract_bytes(value)).hexdigest()


def _contract_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Champ JSON répété : contrat de centre ambigu.')
        result[key] = value
    return result


def validate_contract_document(document):
    """Read one inert, content-addressed center contract without trusting its author."""
    if isinstance(document, (str, bytes)):
        try:
            raw = document.encode('utf-8') if isinstance(document, str) else document
            if len(raw) > MAX_CONTRACT_BYTES:
                raise ValueError('Contrat de centre trop volumineux : 24 Kio maximum.')
            document = json.loads(raw.decode('utf-8'), object_pairs_hook=_contract_object)
        except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
            raise ValueError('Contrat de centre JSON illisible.') from exc
    if not isinstance(document, dict) or set(document) != CONTRACT_FIELDS:
        raise ValueError('Champs du contrat de centre incomplets ou inconnus.')
    if len(_contract_bytes(document)) > MAX_CONTRACT_BYTES:
        raise ValueError('Contrat de centre trop volumineux : 24 Kio maximum.')
    if (document.get('schema') != CONTRACT_SCHEMA
            or type(document.get('version')) is not int or document.get('version') != 1):
        raise ValueError('Version du contrat de centre non prise en charge.')
    source = document.get('source')
    if not isinstance(source, dict) or set(source) != CONTRACT_SOURCE_FIELDS:
        raise ValueError('Source déclarée du contrat incomplète ou ambiguë.')
    normalized_source = {
        'publisher': text_field(source.get('publisher'), 'La source déclarée', 160, True),
        'center_title': text_field(source.get('center_title'), 'Le titre de centre source', 120, True),
        'node_version': text_field(source.get('node_version'), 'La version Tao source', 80, True),
        'exported_at': text_field(source.get('exported_at'), 'La date d’export', 30, True),
    }
    if normalized_source != source:
        raise ValueError('Source déclarée du contrat non canonique.')
    try:
        datetime.strptime(source['exported_at'], '%Y-%m-%dT%H:%M:%SZ')
    except ValueError as exc:
        raise ValueError('Date d’export du contrat invalide.') from exc
    validated_definition = definition(document.get('definition'))
    if validated_definition != document['definition']:
        raise ValueError('Définition de contrat non canonique.')
    if (document.get('authority') != 'external_unverified_contract'
            or document.get('permissions') != 'none'
            or document.get('automatic_execution') is not False):
        raise ValueError('Un contrat partagé ne peut contenir ni autorité ni exécution.')
    content = {key: copy.deepcopy(value) for key, value in document.items()
               if key not in ('id', 'sha256')}
    expected_id = 'contract:' + _contract_digest(content)
    if document.get('id') != expected_id:
        raise ValueError('Identifiant de contenu du contrat invalide.')
    signature = document.get('sha256')
    expected_signature = _contract_digest(
        {key: copy.deepcopy(value) for key, value in document.items() if key != 'sha256'})
    if (not isinstance(signature, str) or not re.fullmatch(r'[a-f0-9]{64}', signature)
            or signature != expected_signature):
        raise ValueError('Empreinte du contrat invalide ; aucun changement préparé.')
    return copy.deepcopy(document)


def validate_ai_output(value):
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) != {'output', 'process', 'benefit', 'residual'}:
        raise ValueError('Sortie de centre incomplète ou ambiguë.')
    return {
        'output': text_field(value['output'], 'La sortie proposée', 6000, True),
        'process': _steps(value['process'], 'Le processus annoncé'),
        'benefit': text_field(value['benefit'], 'Le bénéfice proposé', 1500, True),
        'residual': text_field(value['residual'], 'Le résidu proposé', 2000),
    }


def validate_ai_revision(value):
    return None if value is None else definition(value)


def validate_ai_link(value):
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) != {
            'source_id', 'target_id', 'translation', 'purpose'}:
        raise ValueError('Proposition de liaison incomplète ou ambiguë.')
    return {
        'source_id': _identifier(value['source_id'], 'Centre source'),
        'target_id': _identifier(value['target_id'], 'Centre destination'),
        'translation': text_field(value['translation'], 'La traduction entre centres', 1200, True),
        'purpose': text_field(value['purpose'], 'La raison du lien', 1200, True),
    }


def _requirements(value):
    if not isinstance(value, list) or len(value) > 8:
        raise ValueError('Les prérequis doivent former une liste de huit éléments maximum.')
    return [text_field(item, 'Un prérequis', 500, True) for item in value]


def validate_ai_organ(value):
    """Validate one semantic organ blueprint without accepting executable data."""
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) != set(ORGAN_FIELDS):
        raise ValueError('Proposition d’organe incomplète ou ambiguë.')
    role = value.get('role')
    if role not in ORGAN_ROLES:
        raise ValueError('Rôle d’organe inconnu.')
    effects = value.get('requested_effects')
    if (not isinstance(effects, list) or not 1 <= len(effects) <= len(ORGAN_EFFECTS)
            or any(not isinstance(effect, str) for effect in effects)
            or len(set(effects)) != len(effects)
            or any(effect not in ORGAN_EFFECTS for effect in effects)):
        raise ValueError('Effets demandés invalides, dupliqués ou absents.')
    return {
        'name': text_field(value['name'], 'Le nom de l’organe', 120, True),
        'role': role,
        'interface': text_field(value['interface'], 'L’interface visée', 240, True),
        'operation': text_field(value['operation'], 'L’opération sémantique', 500, True),
        'input': text_field(value['input'], 'L’entrée de l’organe', 1600, True),
        'output': text_field(value['output'], 'La sortie de l’organe', 1600, True),
        'translation': text_field(value['translation'], 'Le couplage avec le centre', 1600, True),
        'requested_effects': list(effects),
        'requirements': _requirements(value['requirements']),
        'purpose': text_field(value['purpose'], 'La raison de l’organe', 1200, True),
        'acceptance': text_field(value['acceptance'], 'La preuve attendue de l’organe', 1500, True),
        'boundaries': text_field(value['boundaries'], 'Les limites de l’organe', 1500, True),
    }


def validate_ai_action(value):
    """Validate one proposed tool call as data, never as an instruction."""
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) != set(ACTION_FIELDS):
        raise ValueError('Proposition d’action incomplète ou ambiguë.')
    connector_id = value.get('connector_id')
    tool = value.get('tool')
    if not isinstance(connector_id, str) or not re.fullmatch(connectors.ID_RE, connector_id):
        raise ValueError('Connecteur proposé inconnu.')
    if not isinstance(tool, str) or not re.fullmatch(connectors.TOOL_RE, tool):
        raise ValueError('Outil proposé inconnu.')
    return {
        'connector_id': connector_id,
        'tool': tool,
        'arguments': connectors.proposal_arguments(value.get('arguments_json')),
        'purpose': text_field(value['purpose'], 'La raison de l’action', 1200, True),
        'expected': text_field(value['expected'], 'Le résultat attendu de l’action', 1500, True),
        'risk': text_field(value['risk'], 'Le risque de l’action', 1500, True),
        'rollback': text_field(value['rollback'], 'Le retour arrière de l’action', 1500, True),
    }


def validate_legacy_adapter(value):
    """Read the former provider/capability shape without making it a default."""
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) != set(LEGACY_ADAPTER_FIELDS):
        raise ValueError('Ancien plan d’adaptateur incomplet ou ambigu.')
    # This is a compatibility boundary, not an alternative proposal protocol:
    # accept only the exact shape the former runtime was able to sign.
    if value.get('provider') != 'gitlab' or value.get('capability') != 'issues.read':
        raise ValueError('Ce plan ne correspond pas au format hérité pris en charge.')
    return {
        'provider': 'gitlab',
        'capability': 'issues.read',
        'source': text_field(value['source'], 'L’ancienne source', 800, True),
        'selection': text_field(value['selection'], 'L’ancienne sélection', 1200, True),
        'mapping': text_field(value['mapping'], 'L’ancienne traduction', 1600, True),
        'purpose': text_field(value['purpose'], 'L’ancienne raison', 1200, True),
        'acceptance': text_field(value['acceptance'], 'L’ancienne preuve attendue', 1500, True),
        'boundaries': text_field(value['boundaries'], 'Les anciennes limites', 1500, True),
    }


def _registry(s):
    value = copy.deepcopy(s.get('centers', _empty()))
    if not isinstance(value, dict) or value.get('schema') != SCHEMA:
        raise ValueError('Registre des centres invalide.')
    if set(value) - {'schema', 'revision', 'centers', 'links'}:
        raise ValueError('Registre des centres ambigu.')
    revision, rows, links = value.get('revision'), value.get('centers'), value.get('links')
    if type(revision) is not int or revision < 0 or not isinstance(rows, dict) or not isinstance(links, list):
        raise ValueError('Registre des centres incomplet.')
    if len(rows) > MAX_CENTERS or len(links) > MAX_LINKS:
        raise ValueError('Capacité du registre des centres dépassée.')
    for ident, row in rows.items():
        _identifier(ident)
        if not isinstance(row, dict) or row.get('schema') != CENTER_SCHEMA or row.get('id') != ident:
            raise ValueError('Centre conservé invalide.')
        required = {'schema', 'id', 'revision', 'status', 'parent_id', 'definition',
                    'trials', 'history', 'origin', 'authority', 'execution_enabled',
                    'world_id', 'created_at', 'updated_at', 'provenance'}
        allowed = required | {'origin_reply_id', 'qualification', 'activation'}
        if not required <= set(row) or set(row) - allowed:
            raise ValueError('Centre conservé incomplet ou ambigu.')
        if row.get('status') not in STATUSES or type(row.get('revision')) is not int or row['revision'] < 1:
            raise ValueError('État de centre invalide.')
        if (row.get('origin') not in ('human', 'ai') or
                row.get('authority') != 'human_review_required' or
                row.get('execution_enabled') is not False):
            raise ValueError('Autorité de centre invalide.')
        if row.get('world_id') != worlds.current():
            raise ValueError('Centre conservé dans un autre espace.')
        text_field(row.get('provenance'), 'La provenance du centre', 1000, True)
        if row.get('origin_reply_id') is not None:
            text_field(row['origin_reply_id'], 'La réponse d’origine', 100, True)
        definition(row.get('definition'))
        parent = row.get('parent_id')
        if parent is not None:
            _identifier(parent, 'Centre parent')
            if parent == ident or parent not in rows:
                raise ValueError('Centre parent invalide.')
        trials = row.get('trials', [])
        if not isinstance(trials, list) or len(trials) > MAX_TRIALS:
            raise ValueError('Essais de centre invalides.')
        seen = set()
        for trial in trials:
            if not isinstance(trial, dict) or trial.get('schema') != TRIAL_SCHEMA:
                raise ValueError('Essai de centre invalide.')
            trial_required = {'schema', 'id', 'status', 'input', 'expected', 'output',
                              'process', 'benefit', 'residual', 'origin', 'authority',
                              'execution_enabled', 'created_at'}
            trial_allowed = trial_required | {'source_reply_id', 'outcome', 'observed',
                                               'evidence', 'reviewed_at'}
            if not trial_required <= set(trial) or set(trial) - trial_allowed:
                raise ValueError('Essai de centre incomplet ou ambigu.')
            tid = _identifier(trial.get('id'), 'Essai')
            if tid in seen:
                raise ValueError('Essai de centre dupliqué.')
            seen.add(tid)
            if trial.get('status') not in ('review', 'reported'):
                raise ValueError('État d’essai de centre invalide.')
            expected_authority = 'human_report' if trial['status'] == 'reported' else 'review_required'
            if (trial.get('origin') not in ('human', 'ai') or
                    trial.get('authority') != expected_authority or
                    trial.get('execution_enabled') is not False):
                raise ValueError('Autorité d’essai de centre invalide.')
            text_field(trial.get('input'), 'L’entrée du cas', 6000, True)
            text_field(trial.get('expected'), 'Le résultat attendu du cas', 2000, True)
            text_field(trial.get('output'), 'La sortie du cas', 6000, True)
            _steps(trial.get('process'), 'Le processus du cas')
            text_field(trial.get('benefit'), 'Le bénéfice du cas', 1500, True)
            text_field(trial.get('residual'), 'Le résidu du cas', 2000)
            if trial.get('source_reply_id') is not None:
                text_field(trial['source_reply_id'], 'La réponse d’origine', 100, True)
            if trial['status'] == 'reported':
                if trial.get('outcome') not in OUTCOMES:
                    raise ValueError('Résultat d’essai de centre invalide.')
                text_field(trial.get('observed'), 'Le résultat observé', 3000, True)
                text_field(trial.get('evidence'), 'La preuve du cas', 3000, True)
            elif any(key in trial for key in ('outcome', 'observed', 'evidence', 'reviewed_at')):
                raise ValueError('Une proposition non relue ne peut pas annoncer un résultat observé.')
        history = row.get('history', [])
        if not isinstance(history, list) or len(history) > MAX_HISTORY:
            raise ValueError('Historique de centre invalide.')
        for previous in history:
            if not isinstance(previous, dict) or set(previous) != {
                    'revision', 'definition', 'parent_id', 'status', 'updated_at'}:
                raise ValueError('Version historique de centre invalide.')
            if type(previous['revision']) is not int or previous['revision'] < 1 or previous['status'] not in STATUSES:
                raise ValueError('Version historique de centre invalide.')
            definition(previous['definition'])
        qualification = row.get('qualification')
        if qualification is not None:
            if not isinstance(qualification, dict) or set(qualification) != {
                    'at', 'review_digest', 'case_ids', 'scope', 'universal_proof'}:
                raise ValueError('Qualification de centre invalide.')
            if (not isinstance(qualification['review_digest'], str) or
                    not re.fullmatch(r'[a-f0-9]{64}', qualification['review_digest']) or
                    not isinstance(qualification['case_ids'], list) or
                    qualification['universal_proof'] is not False or
                    qualification['scope'] != 'local_cases_only'):
                raise ValueError('Qualification de centre invalide.')
            if any(_identifier(case_id, 'Essai qualifié') not in seen
                   for case_id in qualification['case_ids']):
                raise ValueError('Qualification liée à un essai absent.')
        activation = row.get('activation')
        if activation is not None:
            if not isinstance(activation, dict) or set(activation) != {
                    'at', 'review_digest', 'authority', 'automatic_execution'}:
                raise ValueError('Activation de centre invalide.')
        if row['status'] == 'active' and activation is None:
            raise ValueError('Un centre actif sans activation relue est invalide.')
            if (not qualification or activation['review_digest'] != qualification['review_digest'] or
                    activation['authority'] != 'human_confirmation' or
                    activation['automatic_execution'] is not False):
                raise ValueError('Activation de centre invalide.')
    for ident in rows:
        _parent_path(rows, ident)
    seen_links = set()
    for link in links:
        if not isinstance(link, dict) or link.get('schema') != LINK_SCHEMA:
            raise ValueError('Lien de centres invalide.')
        if set(link) != {'schema', 'id', 'source_id', 'target_id', 'translation',
                         'purpose', 'created_at', 'authority', 'automatic_dispatch',
                         'execution_enabled'}:
            raise ValueError('Lien de centres incomplet ou ambigu.')
        ident = _identifier(link.get('id'), 'Lien')
        if ident in seen_links:
            raise ValueError('Lien de centres dupliqué.')
        seen_links.add(ident)
        source, target = link.get('source_id'), link.get('target_id')
        if source not in rows or target not in rows or source == target:
            raise ValueError('Extrémités de lien invalides.')
        text_field(link.get('translation'), 'La traduction', 1200, True)
        text_field(link.get('purpose'), 'La raison du lien', 1200, True)
        if (link.get('authority') != 'description_only' or
                link.get('automatic_dispatch') is not False or
                link.get('execution_enabled') is not False):
            raise ValueError('Autorité de lien invalide.')
    return value


def _parent_path(rows, ident):
    path, seen = [], set()
    while ident is not None:
        if ident in seen or ident not in rows:
            raise ValueError('La hiérarchie des centres contient une boucle.')
        seen.add(ident)
        path.append(ident)
        if len(path) > MAX_CENTERS:
            raise ValueError('Hiérarchie des centres invalide.')
        ident = rows[ident].get('parent_id')
    return list(reversed(path))


def migrate_state(s):
    """Add the optional v1 registry without interpreting legacy candidates."""
    result = copy.deepcopy(s)
    if 'centers' not in result:
        result['centers'] = _empty()
    _registry(result)
    return result


def rollback_state(s):
    """Rollback the additive migration only while it is lossless."""
    result = copy.deepcopy(s)
    if 'centers' not in result:
        return result
    registry = _registry(result)
    if registry['centers'] or registry['links']:
        raise ValueError('Des centres sont conservés ; les archiver ou les exporter ne permet pas de les effacer silencieusement.')
    result.pop('centers')
    return result


def ensure(s):
    if 'centers' not in s:
        s['centers'] = _empty()
    registry = _registry(s)
    s['centers'] = registry
    return registry


def _new_id(existing):
    ident = uuid.uuid4().hex[:12]
    while ident in existing:
        ident = uuid.uuid4().hex[:12]
    return ident


def _definition_digest(n, row):
    return n.digest_bytes(n.json_bytes({'schema': CENTER_SCHEMA, 'id': row['id'],
        'definition': row['definition'], 'parent_id': row.get('parent_id')}))


def _proposal_digest(n, payload):
    """Bind a review card to the exact local structure it displays."""
    return n.digest_bytes(n.json_bytes({'schema': 'tao.center.change.v1', **payload}))


def _same_title(rows, title, exclude=None):
    key = title.casefold()
    return any(ident != exclude and row['definition']['title'].casefold() == key
               and row['status'] != 'retired' for ident, row in rows.items())


def _center(registry, ident):
    ident = _identifier(ident)
    row = registry['centers'].get(ident)
    if not row:
        raise ValueError('Ce centre n’existe pas dans cet espace.')
    return row


def _invalidate(row):
    row.pop('qualification', None)
    row.pop('activation', None)
    if row['status'] == 'active':
        row['status'] = 'paused'


def _create_in_state(n, s, values, parent_id=None, origin='human', reply_id=None):
    registry = ensure(s)
    values = definition(values)
    if len(registry['centers']) >= MAX_CENTERS:
        raise ValueError('32 centres maximum dans cet espace ; aucun centre existant n’a été supprimé.')
    if _same_title(registry['centers'], values['title']):
        raise ValueError('Un centre actif ou candidat porte déjà ce nom dans cet espace.')
    if parent_id is not None:
        parent_id = _identifier(parent_id, 'Centre parent')
        parent = _center(registry, parent_id)
        if parent['status'] == 'retired':
            raise ValueError('Un centre retiré ne peut pas recevoir un nouveau sous-centre.')
    ident = _new_id(registry['centers'])
    row = {'schema': CENTER_SCHEMA, 'id': ident, 'revision': 1, 'status': 'candidate',
           'parent_id': parent_id, 'definition': values, 'trials': [], 'history': [],
           'origin': origin, 'authority': 'human_review_required',
           'execution_enabled': False, 'world_id': worlds.current(),
           'created_at': n.now(), 'updated_at': n.now()}
    if reply_id:
        row['origin_reply_id'] = reply_id
        row['provenance'] = 'Proposition IA non vérifiée, retenue comme candidate depuis ' + reply_id + '.'
    else:
        row['provenance'] = 'Définition saisie par le propriétaire.'
    registry['centers'][ident] = row
    registry['revision'] += 1
    return row


def create(n, values, parent_id=None, revision=0):
    with n.LOCK:
        s = n.load_state()
        registry = ensure(s)
        check_revision(revision, registry['revision'])
        row = _create_in_state(n, s, values, parent_id)
        n.atomic_json(n.STATE, s, backup=True)
        n.event('center_candidate_created', {'id': row['id'], 'world_id': worlds.current(), 'origin': 'human'})
        return copy.deepcopy(row)


def _revise_in_state(n, registry, ident, values, parent_id=None):
    values = definition(values)
    row = _center(registry, ident)
    if row['status'] == 'retired':
        raise ValueError('Restaurer ce centre avant de réviser sa transformation.')
    if _same_title(registry['centers'], values['title'], row['id']):
        raise ValueError('Un autre centre porte déjà ce nom dans cet espace.')
    if parent_id is not None:
        parent_id = _identifier(parent_id, 'Centre parent')
        if parent_id == row['id'] or _center(registry, parent_id)['status'] == 'retired':
            raise ValueError('Centre parent invalide.')
        test = copy.deepcopy(registry['centers'])
        test[row['id']]['parent_id'] = parent_id
        _parent_path(test, row['id'])
    previous = {key: copy.deepcopy(row.get(key)) for key in
                ('revision', 'definition', 'parent_id', 'status', 'updated_at')}
    row.setdefault('history', []).append(previous)
    row['history'] = row['history'][-MAX_HISTORY:]
    row.update(definition=values, parent_id=parent_id, revision=row['revision'] + 1,
               status='candidate', updated_at=n.now(), execution_enabled=False)
    _invalidate(row)
    registry['revision'] += 1
    return row


def revise(n, ident, values, parent_id=None, revision=0):
    values = definition(values)
    with n.LOCK:
        s = n.load_state(); registry = ensure(s); check_revision(revision, registry['revision'])
        row = _revise_in_state(n, registry, ident, values, parent_id)
        n.atomic_json(n.STATE, s, backup=True)
        n.event('center_candidate_revised', {'id': row['id'], 'world_id': worlds.current()})
        return copy.deepcopy(row)


def export_contract(n, ident, center_revision, publisher):
    """Export only the visible transformation contract, never cases, memory or tools."""
    publisher = text_field(publisher, 'La source déclarée', 160, True)
    with n.LOCK:
        state = n.load_state(); registry = _registry(state); row = _center(registry, ident)
        check_revision(center_revision, row['revision'])
        base = {
            'schema': CONTRACT_SCHEMA,
            'version': 1,
            'source': {
                'publisher': publisher,
                'center_title': row['definition']['title'],
                'node_version': n.NODE_VERSION,
                'exported_at': n.now(),
            },
            'definition': copy.deepcopy(row['definition']),
            'authority': 'external_unverified_contract',
            'permissions': 'none',
            'automatic_execution': False,
        }
        document = dict(base, id='contract:' + _contract_digest(base))
        document['sha256'] = _contract_digest(document)
        document = validate_contract_document(document)
        slug = re.sub(r'[^a-z0-9]+', '-', row['definition']['title'].casefold()).strip('-')[:60]
        return {'document': document,
                'filename': 'tao-center-' + (slug or row['id']) + '.json',
                'authentication': 'not_authenticated', 'permissions': 'none',
                'execution_enabled': False}


def _contract_review_in_state(n, state, document, center_id, center_revision,
                              registry_revision):
    document = validate_contract_document(document)
    registry = ensure(state)
    check_revision(registry_revision, registry['revision'])
    values = document['definition']
    row = None
    if center_id is None:
        if center_revision is not None:
            raise ValueError('Aucune révision de centre n’est attendue depuis C0.')
        if _same_title(registry['centers'], values['title']):
            raise ValueError('Un centre actif ou candidat porte déjà ce nom dans cet espace.')
        operation, changed_fields = 'creation', list(DEFINITION_FIELDS)
    else:
        row = _center(registry, center_id)
        check_revision(center_revision, row['revision'])
        if row['status'] == 'retired':
            raise ValueError('Restaurer ce centre avant d’importer un contrat.')
        if _same_title(registry['centers'], values['title'], row['id']):
            raise ValueError('Un autre centre porte déjà ce nom dans cet espace.')
        operation = 'revision'
        changed_fields = [key for key in DEFINITION_FIELDS
                          if row['definition'][key] != values[key]]
    payload = {
        'schema': 'tao.center.contract.review.v1',
        'contract_id': document['id'],
        'contract_sha256': document['sha256'],
        'operation': operation,
        'center_id': row['id'] if row else None,
        'center_revision': row['revision'] if row else None,
        'registry_revision': registry['revision'],
        'definition': copy.deepcopy(values),
        'changed_fields': changed_fields,
    }
    return dict(payload,
                review_digest=n.digest_bytes(n.json_bytes(payload)),
                source=copy.deepcopy(document['source']),
                already_current=operation == 'revision' and not changed_fields,
                authority='external_unverified_contract', permissions='none',
                automatic_execution=False,
                warnings=[
                    'La source est déclarée par le fichier ; son empreinte détecte une modification mais n’authentifie pas son auteur.',
                    'Importer ce contrat ne transmet aucun compte, secret, outil, permission ou droit d’exécution.',
                ])


def review_contract(n, document, center_id, center_revision, registry_revision):
    """Prepare an exact, read-only import review against the current center state."""
    with n.LOCK:
        state = n.load_state()
        return _contract_review_in_state(
            n, state, document, center_id, center_revision, registry_revision)


def import_contract(n, document, center_id, center_revision, registry_revision,
                    review_digest, confirmed=False):
    """Create or revise one candidate only after the owner reviews the exact file."""
    if confirmed is not True:
        raise ValueError('Confirmer explicitement l’import exact du contrat.')
    if not isinstance(review_digest, str) or not re.fullmatch(r'[a-f0-9]{64}', review_digest):
        raise ValueError('Empreinte de revue du contrat invalide.')
    with n.LOCK:
        state = n.load_state()
        review = _contract_review_in_state(
            n, state, document, center_id, center_revision, registry_revision)
        if review['review_digest'] != review_digest:
            raise ValueError('Le contrat ou le centre a changé depuis l’aperçu ; relire avant import.')
        registry = ensure(state)
        if review['already_current']:
            row = _center(registry, review['center_id'])
            return {'imported': False, 'already_current': True, 'center_id': row['id'],
                    'center_revision': row['revision'], 'registry_revision': registry['revision'],
                    'contract_id': review['contract_id'], 'execution_enabled': False}
        if review['operation'] == 'creation':
            row = _create_in_state(n, state, review['definition'])
        else:
            current = _center(registry, review['center_id'])
            row = _revise_in_state(n, registry, current['id'], review['definition'],
                                   current.get('parent_id'))
        publisher = review['source']['publisher']
        row['provenance'] = text_field(
            'Contrat partagé choisi par le propriétaire ; source déclarée non authentifiée : '
            + publisher + ' ; document ' + review['contract_id'] + '.',
            'La provenance du centre', 1000, True)
        n.atomic_json(n.STATE, state, backup=True)
        n.event('center_contract_imported', {
            'id': row['id'], 'contract_id': review['contract_id'],
            'operation': review['operation'], 'world_id': worlds.current(),
            'authority': 'human_confirmation', 'execution_enabled': False})
        return {'imported': True, 'already_current': False, 'center_id': row['id'],
                'center_revision': row['revision'], 'registry_revision': registry['revision'],
                'contract_id': review['contract_id'], 'status': row['status'],
                'execution_enabled': False}


def assimilate_ai_proposal(n, s, proposal, reply_id, focus, current):
    """Capture a creation suggestion for review without creating a center."""
    result = {'status': 'none', 'warnings': [], 'execution_enabled': False}
    if proposal is None:
        return result
    if not current:
        result.update(status='deferred')
        result['warnings'].append('Centre non retenu : le contexte a changé pendant la réponse.')
        return result
    if not isinstance(focus, dict) or focus.get('kind') not in ('center_factory', 'center'):
        result.update(status='rejected')
        result['warnings'].append('Centre non retenu : aucune fabrique ou centre parent n’était sélectionné.')
        return result
    try:
        registry = ensure(s)
        values = definition(proposal)
        parent_id = None
        if focus.get('kind') == 'center':
            parent = _center(registry, focus.get('id'))
            check_revision(focus.get('revision'), parent['revision'])
            if parent['status'] == 'retired':
                raise ValueError('Le centre parent sélectionné est retiré.')
            parent_id = parent['id']
        elif focus.get('id') != 'new':
            raise ValueError('Fabrique de centres inconnue.')
        if len(registry['centers']) >= MAX_CENTERS:
            raise ValueError('32 centres maximum dans cet espace.')
        if _same_title(registry['centers'], values['title']):
            raise ValueError('Un centre actif ou candidat porte déjà ce nom dans cet espace.')
        payload = {'kind': 'creation', 'definition': values, 'parent_id': parent_id,
                   'registry_revision': registry['revision']}
        result.update(payload, status='review', title=values['title'],
                      digest=_proposal_digest(n, payload))
    except ValueError as exc:
        result.update(status='rejected')
        result['warnings'].append('Centre non retenu : ' + str(exc))
    return result


def assimilate_ai_revision(n, s, proposal, reply_id, focus, current):
    """Capture an exact contract revision; do not mutate the selected center."""
    result = {'status': 'none', 'warnings': [], 'execution_enabled': False}
    if proposal is None:
        return result
    if not current:
        result.update(status='deferred')
        result['warnings'].append('Évolution non retenue : le contexte a changé pendant la réponse.')
        return result
    if not isinstance(focus, dict) or focus.get('kind') != 'center':
        result.update(status='rejected')
        result['warnings'].append('Évolution non retenue : aucun centre n’était sélectionné.')
        return result
    try:
        registry = ensure(s); row = _center(registry, focus.get('id'))
        check_revision(focus.get('revision'), row['revision'])
        values = definition(proposal)
        if row['status'] == 'retired':
            raise ValueError('Le centre sélectionné est retiré.')
        if _same_title(registry['centers'], values['title'], row['id']):
            raise ValueError('Un autre centre porte déjà ce nom dans cet espace.')
        payload = {'kind': 'revision', 'center_id': row['id'],
                   'center_revision': row['revision'], 'definition': values,
                   'parent_id': row.get('parent_id'),
                   'registry_revision': registry['revision']}
        result.update(payload, status='review', title=values['title'],
                      digest=_proposal_digest(n, payload))
    except ValueError as exc:
        result.update(status='rejected')
        result['warnings'].append('Évolution non retenue : ' + str(exc))
    return result


def assimilate_ai_link(n, s, proposal, reply_id, focus, current):
    """Capture a typed T(source->target) suggestion without creating a link."""
    result = {'status': 'none', 'warnings': [], 'execution_enabled': False,
              'automatic_dispatch': False}
    if proposal is None:
        return result
    if not current:
        result.update(status='deferred')
        result['warnings'].append('Liaison non retenue : le contexte a changé pendant la réponse.')
        return result
    if not isinstance(focus, dict) or focus.get('kind') not in ('center', 'center_factory'):
        result.update(status='rejected')
        result['warnings'].append('Liaison non retenue : aucune fabrique ou centre n’était sélectionné.')
        return result
    try:
        registry = ensure(s); values = validate_ai_link(proposal)
        source = _center(registry, values['source_id'])
        target = _center(registry, values['target_id'])
        if source['id'] == target['id']:
            raise ValueError('Un centre ne se relie pas à lui-même.')
        if source['status'] == 'retired' or target['status'] == 'retired':
            raise ValueError('Un centre retiré ne peut pas recevoir de nouveau lien.')
        if focus.get('kind') == 'center':
            selected = _center(registry, focus.get('id'))
            check_revision(focus.get('revision'), selected['revision'])
            if selected['id'] not in (source['id'], target['id']):
                raise ValueError('La liaison ne concerne pas le centre sélectionné.')
        elif focus.get('id') != 'new':
            raise ValueError('Fabrique de centres inconnue.')
        prior = next((row for row in registry['links']
                      if row['source_id'] == source['id'] and row['target_id'] == target['id']
                      and row['translation'] == values['translation']), None)
        if prior:
            raise ValueError('Cette traduction est déjà décrite entre ces deux centres.')
        payload = dict(values, kind='link', registry_revision=registry['revision'])
        result.update(payload, status='review', source_title=source['definition']['title'],
                      target_title=target['definition']['title'],
                      digest=_proposal_digest(n, payload))
    except ValueError as exc:
        result.update(status='rejected')
        result['warnings'].append('Liaison non retenue : ' + str(exc))
    return result


def _prepared_adapters(n, s, row, exclude_reply_id=None):
    """Project accepted organ blueprints without changing center schema.

    New generic organs live under ``center_capture.organ``.  The former narrow
    adapter record remains readable under ``adapter`` but is projected into the
    same generic view.  Neither form is a configured connector.
    """
    dialogue = s.get('dialogue', {})
    messages = dialogue.get('messages', []) if isinstance(dialogue, dict) else []
    result = []
    for message in messages:
        if (not isinstance(message, dict) or message.get('role') != 'assistant' or
                message.get('id') == exclude_reply_id):
            continue
        center_capture = message.get('center_capture')
        if not isinstance(center_capture, dict):
            continue
        for capture_key in ('organ', 'adapter'):
            capture = center_capture.get(capture_key)
            if not isinstance(capture, dict) or capture.get('status') != 'accepted':
                continue
            payload = _captured_payload(capture)
            if payload.get('kind') not in ('organ', 'adapter') or payload.get('center_id') != row['id']:
                continue
            if capture.get('digest') != _proposal_digest(n, payload):
                raise ValueError('Un organe préparé ne correspond plus à son aperçu exact.')
            values = _organ_projection(payload)
            task_id = _organ_build_task_id(n, message.get('id'), capture.get('digest'))
            task = s.get('buffers', {}).get(task_id)
            build = {'status': 'not_started', 'task_id': task_id,
                     'adaptation_id': None}
            if task is not None:
                if not _matches_organ_build_task(task, row['id'], payload['center_revision'],
                                                 message.get('id'), capture.get('digest')):
                    raise ValueError('La fiche de construction de cet organe ne correspond plus à son origine exacte.')
                build.update(status=('adaptation_started'
                                     if task.get('work_task', {}).get('adaptation_id')
                                     else 'task_saved'),
                             adaptation_id=task.get('work_task', {}).get('adaptation_id'))
            values.update({
                'status': 'prepared',
                'center_id': row['id'],
                'center_revision': payload['center_revision'],
                'current_contract': payload['center_revision'] == row['revision'],
                'origin_reply_id': message.get('id'),
                'digest': capture.get('digest'),
                'build': build,
                'decided_at': capture.get('decided_at'),
                'credentials_configured': False,
                'connection_tested': False,
                'automatic_dispatch': False,
                'automatic_polling': False,
                'execution_enabled': False,
            })
            result.append(values)
    if len(result) > MAX_PREPARED_ADAPTERS:
        raise ValueError('Trop d’organes préparés pour ce centre.')
    return result


def _organ_build_task_id(n, reply_id, digest):
    """Give one accepted blueprint one stable work task in its private world."""
    if (not isinstance(reply_id, str) or not re.fullmatch(r'reply:[a-f0-9]{12}', reply_id)
            or not isinstance(digest, str) or not re.fullmatch(r'[a-f0-9]{64}', digest)):
        raise ValueError('Origine de l’organe incomplète.')
    suffix = n.digest_bytes(n.json_bytes([worlds.current(), reply_id, digest]))[:12]
    return 'user:work:organ:' + suffix


def _matches_organ_build_task(task, center_id, center_revision, reply_id, digest):
    work_task = task.get('work_task', {}) if isinstance(task, dict) else {}
    example = work_task.get('example', {}) if isinstance(work_task, dict) else {}
    origin = example.get('organ_origin', {}) if isinstance(example, dict) else {}
    return (task.get('kind') == 'work' and work_task.get('schema') == 'tao.work.task.v1'
            and work_task.get('source') == 'human_accepted_center_organ'
            and origin == {'reply_id': reply_id, 'digest': digest,
                           'center_id': center_id, 'center_revision': center_revision})


def build_organ(n, center_id, center_revision, reply_id, digest):
    """Create one exact code task, then reuse the explicit local workshop.

    The accepted blueprint remains data.  This owner action authorizes one code
    candidate only; it never authorizes the organ's requested effects or duty.
    """
    _identifier(center_id)
    if type(center_revision) is not int:
        raise ValueError('Révision de centre requise.')
    task_id = _organ_build_task_id(n, reply_id, digest)
    created = False
    with n.LOCK:
        s = n.load_state(); registry = ensure(s)
        row = _center(registry, center_id)
        check_revision(center_revision, row['revision'])
        if row['status'] == 'retired':
            raise ValueError('Restaurer ce centre avant de construire un de ses organes.')
        dialogue = s.get('dialogue', {})
        messages = dialogue.get('messages', []) if isinstance(dialogue, dict) else []
        message = next((item for item in messages
                        if isinstance(item, dict) and item.get('role') == 'assistant'
                        and item.get('id') == reply_id), None)
        capture = (message.get('center_capture', {}).get('organ')
                   if isinstance(message, dict) else None)
        if not isinstance(capture, dict) or capture.get('status') != 'accepted':
            raise ValueError('Un plan d’organe générique validé est requis avant sa construction.')
        payload = _captured_payload(capture)
        if (payload.get('kind') != 'organ' or payload.get('center_id') != row['id']
                or payload.get('center_revision') != row['revision']):
            raise ValueError('Le contrat du centre a changé ; faire reformuler cet organe avant de le construire.')
        exact_digest = _proposal_digest(n, payload)
        if capture.get('digest') != exact_digest or digest != exact_digest:
            raise ValueError('Le plan d’organe ne correspond plus à l’aperçu validé.')

        task = s.get('buffers', {}).get(task_id)
        if task is not None:
            if not _matches_organ_build_task(task, row['id'], row['revision'], reply_id, digest):
                raise ValueError('Une autre fiche occupe l’identité de cette construction ; rien n’a été remplacé.')
            if task.get('status') != 'open':
                raise ValueError('Cette fiche de construction est terminée ; son histoire reste conservée.')
            adaptation_id = task['work_task'].get('adaptation_id')
            if adaptation_id:
                return {'task_id': task_id, 'adaptation_id': adaptation_id,
                        'prepared': True, 'already_prepared': True,
                        'message': 'Cet organe possède déjà un essai dans l’atelier.'}
        else:
            if len(n.open_buffers(s)) >= 200:
                raise ValueError('200 besoins ouverts ; aucun nouveau besoin de construction créé.')
            if not s.get('work_context'):
                s['work_context'] = {
                    'schema': 'tao.work.context.v1',
                    'id': 'work:' + s['id'] + (':' + worlds.current()
                                                   if worlds.current() != 'main' else ''),
                    'description': ('Construire et perfectionner les capacités locales choisies '
                                    'pour mes centres, sans leur donner d’autorité implicite.'),
                    'keep_learning': ('La revue des changements, des preuves et des effets '
                                      'reste au propriétaire.'),
                    'boundaries': ('Un plan d’organe n’accorde aucun secret, accès, compte, '
                                   'permission ou effet externe.'),
                    'revision': 1, 'updated_at': n.now(),
                    'source': 'accepted_center_organ', 'authority': 'description_only',
                    'history': [],
                }
            context = s['work_context']
            blueprint = _organ_projection(payload)
            situation = (f'Le plan validé « {blueprint["name"]} » du centre '
                         f'« {row["definition"]["title"]} » reste inerte. Construire son '
                         f'premier parcours local pour « {blueprint["operation"]} » via '
                         f'« {blueprint["interface"]} », sans exercer les effets demandés.')
            boundaries = (blueprint['boundaries'] + '\n\nLa génération prépare seulement '
                          'du code à relire. Elle ne lit aucun secret, ne contacte aucun service '
                          'métier et n’exécute pas la fonction du centre.')
            task = n.make_buffer(task_id, 'work',
                                 'Organe validé mais encore inutilisable : ' + blueprint['name'],
                                 authority='human')
            task.update(
                desired=('Rendre cet organe utilisable dans Tao par la plus petite expérience '
                         'locale, réversible et supervisée.'),
                acceptance=blueprint['acceptance'], story_id=context['id'],
                work_task={
                    'schema': 'tao.work.task.v1',
                    'title': (f'Construire l’organe « {blueprint["name"]} » pour '
                              f'« {row["definition"]["title"]} »'),
                    'phase': 'example_recorded', 'revision': 1,
                    'context_revision': context['revision'],
                    'source': 'human_accepted_center_organ',
                    'authority': 'description_only', 'execution_enabled': False,
                    'example': {
                        'situation': situation,
                        'expected': blueprint['acceptance'],
                        'boundaries': boundaries,
                        'source': 'human_accepted_center_organ',
                        'status': 'unverified', 'at': n.now(),
                        'organ_origin': {'reply_id': reply_id, 'digest': digest,
                                         'center_id': row['id'],
                                         'center_revision': row['revision']},
                        'organ_blueprint': blueprint,
                        'center_contract': {
                            'id': row['id'], 'revision': row['revision'],
                            'definition': copy.deepcopy(row['definition']),
                        },
                    },
                })
            s['buffers'][task_id] = task
            n.atomic_json(n.STATE, s, backup=True)
            created = True
    if created:
        n.event('center_organ_build_task_created', {'center_id': center_id,
                                                    'reply_id': reply_id,
                                                    'task_id': task_id,
                                                    'world_id': worlds.current()})

    # The click is the only authorization for generation.  Missing local means
    # keep the exact task visible rather than replacing failure with success.
    import tao_adaptation as adaptation
    diagnostic = adaptation.diagnose(n)
    if not diagnostic['ready']:
        return {'task_id': task_id, 'prepared': False,
                'blockers': diagnostic['blockers'],
                'message': ('La fiche exacte est conservée. ' + ' '.join(
                    item['message'] + ' ' + item['next'] for item in diagnostic['blockers']))}
    try:
        candidate = adaptation.request(n, task_id, 'generate')
    except (ValueError, OSError, RuntimeError) as exc:
        # A concurrent double click may have won the launch.  Recover only the
        # linked receipt; otherwise surface the real blocker and keep the task.
        with n.LOCK:
            current = n.load_state().get('buffers', {}).get(task_id, {})
            adaptation_id = current.get('work_task', {}).get('adaptation_id')
        if adaptation_id:
            return {'task_id': task_id, 'adaptation_id': adaptation_id,
                    'prepared': True, 'already_prepared': True,
                    'message': 'Cet organe possède déjà un essai dans l’atelier.'}
        return {'task_id': task_id, 'prepared': False,
                'message': 'La fiche exacte est conservée : ' + str(exc)}
    return {'task_id': task_id, 'adaptation_id': candidate['id'],
            'prepared': True, 'already_prepared': False,
            'message': 'La construction est ouverte dans l’atelier ; rien n’est encore installé.'}


def _organ_projection(payload):
    """Return one provider-neutral view while preserving a legacy raw record."""
    if payload.get('kind') == 'organ':
        values = {key: copy.deepcopy(payload[key]) for key in ORGAN_FIELDS}
        return dict(values, schema=ORGAN_SCHEMA, legacy=False)
    legacy = {key: copy.deepcopy(payload[key]) for key in LEGACY_ADAPTER_FIELDS}
    return {
        'schema': ORGAN_SCHEMA,
        'legacy': True,
        'name': legacy['provider'] + ' · ' + legacy['capability'],
        'role': 'input',
        'interface': legacy['provider'],
        'operation': legacy['capability'],
        'input': legacy['source'],
        'output': legacy['mapping'],
        'translation': legacy['mapping'],
        'requested_effects': ['read'],
        'requirements': [legacy['selection']],
        'purpose': legacy['purpose'],
        'acceptance': legacy['acceptance'],
        'boundaries': legacy['boundaries'],
    }


def _same_organ(left, right):
    return all(left.get(key) == right.get(key) for key in ORGAN_FIELDS)


def assimilate_ai_organ(n, s, proposal, reply_id, focus, current):
    """Capture one provider-neutral organ blueprint without configuring it."""
    result = {'status': 'none', 'warnings': [], 'organ_schema': ORGAN_SCHEMA,
              'credentials_configured': False, 'connection_tested': False,
              'automatic_dispatch': False, 'automatic_polling': False,
              'execution_enabled': False}
    if proposal is None:
        return result
    if not current:
        result.update(status='deferred')
        result['warnings'].append('Organe non retenu : le contexte a changé pendant la réponse.')
        return result
    if not isinstance(focus, dict) or focus.get('kind') != 'center':
        result.update(status='rejected')
        result['warnings'].append('Organe non retenu : aucun centre n’était sélectionné.')
        return result
    try:
        registry = ensure(s); row = _center(registry, focus.get('id'))
        check_revision(focus.get('revision'), row['revision'])
        if row['status'] == 'retired':
            raise ValueError('Le centre sélectionné est retiré.')
        values = validate_ai_organ(proposal)
        existing = _prepared_adapters(n, s, row)
        if len(existing) >= MAX_PREPARED_ADAPTERS:
            raise ValueError('16 organes préparés maximum pour ce centre.')
        if any(_same_organ(adapter, values) for adapter in existing):
            raise ValueError('Cet organe est déjà préparé pour ce centre.')
        payload = dict(values, kind='organ', organ_schema=ORGAN_SCHEMA, center_id=row['id'],
                       center_revision=row['revision'],
                       registry_revision=registry['revision'])
        result.update(payload, status='review', center_title=row['definition']['title'],
                      digest=_proposal_digest(n, payload))
    except ValueError as exc:
        result.update(status='rejected')
        result['warnings'].append('Organe non retenu : ' + str(exc))
    return result


def _provided_tool(context, connector_id, tool):
    if not isinstance(context, dict) or context.get('status') != 'available':
        raise ValueError('Aucun catalogue d’outils vérifié n’était fourni à cette réponse.')
    revision = context.get('registry_revision')
    rows = context.get('tools')
    if type(revision) is not int or revision < 0 or not isinstance(rows, list):
        raise ValueError('Catalogue d’outils fourni invalide.')
    matches = [row for row in rows if isinstance(row, dict)
               and row.get('connector_id') == connector_id and row.get('tool') == tool]
    if len(matches) != 1:
        raise ValueError('L’action ne vise pas un outil fourni au centre dans cet échange.')
    source = matches[0]
    digest = source.get('descriptor_digest')
    if not isinstance(digest, str) or not re.fullmatch(r'[a-f0-9]{64}', digest):
        raise ValueError('Empreinte de l’outil fourni invalide.')
    return source, revision


def _request_matches_action(request, values, source):
    return (request.get('connector_id') == values['connector_id']
            and request.get('tool') == values['tool']
            and request.get('arguments') == values['arguments']
            and request.get('descriptor_digest') == source['descriptor_digest']
            and request.get('origin') == 'dialogue')


def assimilate_ai_action(n, s, proposal, reply_id, focus, current, tool_context=None):
    """Retain one exact connector request; never call the selected tool."""
    result = {'status': 'none', 'warnings': [], 'authority': 'human_review_required',
              'automatic_execution': False, 'execution_enabled': False}
    if proposal is None:
        return result
    if not current:
        result.update(status='deferred')
        result['warnings'].append('Action non retenue : le contexte a changé pendant la réponse.')
        return result
    if not isinstance(focus, dict) or focus.get('kind') != 'center':
        result.update(status='rejected')
        result['warnings'].append('Action non retenue : aucun centre n’était sélectionné.')
        return result
    try:
        registry = ensure(s); row = _center(registry, focus.get('id'))
        check_revision(focus.get('revision'), row['revision'])
        if row['status'] == 'retired':
            raise ValueError('Le centre sélectionné est retiré.')
        values = validate_ai_action(proposal)
        source, source_revision = _provided_tool(
            tool_context, values['connector_id'], values['tool'])
        request_id = n.digest_bytes(n.json_bytes({
            'schema': 'tao.center.action.request.v1', 'world_id': worlds.current(),
            'reply_id': reply_id, 'center_id': row['id'], 'center_revision': row['revision'],
            'connector_id': values['connector_id'], 'tool': values['tool'],
            'arguments': values['arguments'], 'descriptor_digest': source['descriptor_digest'],
        }))[:32]

        # Reuse an exact request if a worker stopped after retaining it but
        # before saving the dialogue reply. Otherwise require the frozen tool
        # catalogue to remain current before creating a new review item.
        catalog = connectors.catalog(n)
        request = next((item for item in catalog['requests'] if item['id'] == request_id), None)
        if request is None:
            if catalog['revision'] != source_revision:
                raise ValueError('Le catalogue d’outils a changé ; demander une nouvelle proposition.')
            connector = next((item for item in catalog['connectors']
                              if item['id'] == values['connector_id']), None)
            if (not connector or connector.get('status') != 'ready'
                    or connector.get('tool_digests', {}).get(values['tool'])
                    != source['descriptor_digest']):
                raise ValueError('Le connecteur ou son outil a changé depuis le contexte fourni.')
            request = connectors.request(
                n, values['connector_id'], values['tool'], values['arguments'],
                origin='dialogue', request_id=request_id)
        if not _request_matches_action(request, values, source):
            raise ValueError('La demande d’outil conservée ne correspond pas à la proposition exacte.')
        payload = {
            'kind': 'action', 'center_id': row['id'], 'center_revision': row['revision'],
            'connector_id': values['connector_id'],
            'connector_label': text_field(request.get('connector_label'), 'Le connecteur', 120, True),
            'tool': values['tool'], 'arguments': copy.deepcopy(values['arguments']),
            'descriptor_digest': source['descriptor_digest'], 'request_id': request['id'],
            'review_digest': request['review_digest'], 'purpose': values['purpose'],
            'expected': values['expected'], 'risk': values['risk'],
            'rollback': values['rollback'],
        }
        result.update(payload, status=request['status'], connector_revision=request['revision'],
                      digest=_proposal_digest(n, payload))
    except (ValueError, OSError, RuntimeError) as exc:
        result.update(status='rejected')
        result['warnings'].append('Action non retenue : ' + str(exc))
    return result


def _captured_action_payload(capture):
    if not isinstance(capture, dict) or capture.get('kind') != 'action':
        raise ValueError('Proposition d’action inconnue.')
    request_id = capture.get('request_id')
    review_digest = capture.get('review_digest')
    descriptor_digest = capture.get('descriptor_digest')
    connector_id = capture.get('connector_id')
    tool = capture.get('tool')
    center_revision = capture.get('center_revision')
    if type(center_revision) is not int or center_revision < 1:
        raise ValueError('Révision du centre d’action invalide.')
    if not isinstance(request_id, str) or not re.fullmatch(connectors.ID_RE, request_id):
        raise ValueError('Demande d’action invalide.')
    for value, label in ((review_digest, 'Empreinte de revue'),
                         (descriptor_digest, 'Empreinte d’outil')):
        if not isinstance(value, str) or not re.fullmatch(r'[a-f0-9]{64}', value):
            raise ValueError(label + ' invalide.')
    if not isinstance(connector_id, str) or not re.fullmatch(connectors.ID_RE, connector_id):
        raise ValueError('Connecteur d’action invalide.')
    if not isinstance(tool, str) or not re.fullmatch(connectors.TOOL_RE, tool):
        raise ValueError('Outil d’action invalide.')
    arguments = copy.deepcopy(capture.get('arguments'))
    connectors.proposal_arguments(n_json(arguments))
    return {
        'kind': 'action', 'center_id': _identifier(capture.get('center_id')),
        'center_revision': center_revision, 'connector_id': connector_id,
        'connector_label': text_field(capture.get('connector_label'), 'Le connecteur', 120, True),
        'tool': tool, 'arguments': arguments, 'descriptor_digest': descriptor_digest,
        'request_id': request_id, 'review_digest': review_digest,
        'purpose': text_field(capture.get('purpose'), 'La raison de l’action', 1200, True),
        'expected': text_field(capture.get('expected'), 'Le résultat attendu de l’action', 1500, True),
        'risk': text_field(capture.get('risk'), 'Le risque de l’action', 1500, True),
        'rollback': text_field(capture.get('rollback'), 'Le retour arrière de l’action', 1500, True),
    }


def n_json(value):
    """Canonical JSON text for reuse by the strict connector argument reader."""
    import json
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                      allow_nan=False)


def project_action_capture(n, capture, catalog=None):
    """Reconcile a stored center card with its immutable connector receipt."""
    payload = _captured_action_payload(capture)
    if capture.get('digest') != _proposal_digest(n, payload):
        raise ValueError('La proposition d’action ne correspond plus à son aperçu exact.')
    catalog = connectors.catalog(n) if catalog is None else catalog
    request = next((row for row in catalog.get('requests', [])
                    if row.get('id') == payload['request_id']), None)
    if request is None or not _request_matches_action(request, payload, payload):
        raise ValueError('Le reçu de l’action proposée est absent ou ne correspond plus.')
    if request.get('review_digest') != payload['review_digest']:
        raise ValueError('L’empreinte de revue de l’action a changé.')
    receipt = {
        'status': request['status'],
        'call_dispatched': bool(request.get('call_dispatched', False)),
        'result_authority': request.get('result_authority', 'external_untrusted_data'),
        'automatic_retry': False,
    }
    for key in ('reason', 'elapsed_seconds', 'finished_at'):
        if request.get(key) is not None:
            receipt[key] = copy.deepcopy(request[key])
    if request.get('result') is not None:
        result_bytes = len(n.json_bytes(request['result']))
        if result_bytes <= 24000:
            receipt['result'] = copy.deepcopy(request['result'])
        else:
            receipt.update(result_omitted=True, result_bytes=result_bytes)
    result = copy.deepcopy(capture)
    result.update(status=request['status'], connector_revision=catalog['revision'],
                  call_dispatched=receipt['call_dispatched'], receipt=receipt,
                  result_authority=receipt['result_authority'],
                  automatic_execution=False, execution_enabled=False)
    return result


def _action_capture_for_request(s, request_id):
    """Find one exact retained proposal; duplicated provenance is ambiguous."""
    matches = []
    for message in s.get('dialogue', {}).get('messages', []):
        captures = message.get('center_capture')
        capture = captures.get('action') if isinstance(captures, dict) else None
        if (isinstance(capture, dict) and capture.get('kind') == 'action'
                and capture.get('request_id') == request_id):
            matches.append(capture)
    if len(matches) != 1:
        raise ValueError('Le reçu choisi ne possède pas une provenance unique dans cette discussion.')
    return matches[0]


def action_input(n, s, reference, target_id, catalog=None):
    """Resolve one terminal external receipt through one existing directed link.

    The client supplies identity only.  Content, terminal state and direction are
    recovered from the private dialogue, connector catalog and center registry.
    This read creates no dispatch, model call, permission or recurring mandate.
    """
    if (not isinstance(reference, dict)
            or set(reference) != {'kind', 'id', 'link_id'}
            or reference.get('kind') != 'center_receipt'):
        raise ValueError('Référence de reçu de centre invalide.')
    request_id = reference.get('id')
    if not isinstance(request_id, str) or not re.fullmatch(connectors.ID_RE, request_id):
        raise ValueError('Identifiant de reçu de centre invalide.')
    link_id = _identifier(reference.get('link_id'), 'Lien')
    target_id = _identifier(target_id, 'Centre destination')
    registry = _registry(s)
    target = _center(registry, target_id)
    if target['status'] == 'retired':
        raise ValueError('Restaurer le centre destination avant de lui joindre un reçu.')
    link = next((row for row in registry['links'] if row['id'] == link_id), None)
    if link is None or link['target_id'] != target_id:
        raise ValueError('Ce lien ne conduit pas vers le centre sélectionné.')
    capture = _action_capture_for_request(s, request_id)
    projected = project_action_capture(n, capture, catalog)
    if projected['center_id'] != link['source_id']:
        raise ValueError('Le reçu ne provient pas du centre source de ce lien.')
    if projected['status'] not in ACTION_INPUT_STATUSES:
        raise ValueError('Seul le reçu terminal d’une action tentée peut devenir une entrée.')

    source = _center(registry, link['source_id'])
    arguments = copy.deepcopy(projected['arguments'])
    argument_bytes = len(n.json_bytes(arguments))
    if argument_bytes > 4000:
        arguments = None
    receipt = copy.deepcopy(projected['receipt'])
    if receipt.get('result') is not None:
        result_bytes = len(n.json_bytes(receipt['result']))
        if result_bytes > 10000:
            receipt.pop('result')
            receipt.update(result_omitted=True, result_bytes=result_bytes)
    context = {
        'concept_id': 'tao.center.receipt',
        'title': (source['definition']['title'] + ' · ' + projected['tool'])[:240],
        'status': projected['status'],
        'source_center': {
            'id': source['id'], 'title': source['definition']['title'],
            'action_revision': projected['center_revision'],
        },
        'target_center': {'id': target['id'], 'title': target['definition']['title']},
        'request': {
            'id': request_id, 'connector_id': projected['connector_id'],
            'connector_label': projected['connector_label'], 'tool': projected['tool'],
        },
        'action': {
            'purpose': projected['purpose'], 'expected': projected['expected'],
            'arguments': arguments,
            'arguments_omitted': arguments is None,
            'argument_bytes': argument_bytes,
        },
        'receipt': receipt,
        'link': {
            'id': link['id'], 'source_id': link['source_id'],
            'target_id': link['target_id'], 'translation': link['translation'],
            'purpose': link['purpose'],
        },
        'result_authority': 'external_untrusted_data',
        'execution_enabled': False,
    }
    result = {
        'ref': dict(reference), 'context': context, 'authority': 'context_only',
        'role': 'center_input',
        'verification': 'attributed_external_result_not_independently_verified',
        'automatic_dispatch': False, 'execution_enabled': False,
    }
    # Preserve whole JSON values or omit them explicitly; never cut a result
    # into a misleading fragment just to fit the provider context.
    if len(n.json_bytes(result)) > MAX_ACTION_INPUT_BYTES:
        context['action']['arguments'] = None
        context['action']['arguments_omitted'] = True
    if len(n.json_bytes(result)) > MAX_ACTION_INPUT_BYTES and context['receipt'].get('result') is not None:
        result_bytes = len(n.json_bytes(context['receipt']['result']))
        context['receipt'].pop('result')
        context['receipt'].update(result_omitted=True, result_bytes=result_bytes)
    if len(n.json_bytes(result)) > MAX_ACTION_INPUT_BYTES:
        raise ValueError('Ce reçu reste trop volumineux pour devenir une entrée bornée.')
    return result


def action_input_choices(n, s, target_id, locale='fr'):
    """List recent terminal receipts eligible for this exact destination."""
    registry = _registry(s)
    target = _center(registry, target_id)
    if target['status'] == 'retired':
        return []
    incoming = [link for link in registry['links'] if link['target_id'] == target_id]
    if not incoming:
        return []
    by_source = {}
    for link in incoming:
        by_source.setdefault(link['source_id'], []).append(link)
    catalog = connectors.catalog(n)
    result = []
    seen = set()
    messages = s.get('dialogue', {}).get('messages', [])
    for message in reversed(messages):
        captures = message.get('center_capture')
        capture = captures.get('action') if isinstance(captures, dict) else None
        if not isinstance(capture, dict) or capture.get('kind') != 'action':
            continue
        if capture.get('center_id') not in by_source:
            continue
        projected = project_action_capture(n, capture, catalog)
        if projected['status'] not in ACTION_INPUT_STATUSES:
            continue
        for link in by_source[projected['center_id']]:
            key = (projected['request_id'], link['id'])
            if key in seen:
                raise ValueError('Le reçu proposé comme entrée possède une provenance dupliquée.')
            selected = action_input(n, s, {
                'kind': 'center_receipt', 'id': projected['request_id'],
                'link_id': link['id'],
            }, target_id, catalog)
            context = selected['context']
            receipt = context['receipt']
            if receipt.get('result') is not None:
                preview = n_json(receipt['result'])
            elif receipt.get('reason'):
                preview = receipt['reason']
            else:
                preview = projected['status']
            result.append({
                'id': projected['request_id'] + ':' + link['id'], 'revision': 1,
                'kind': 'center_receipt', 'reference': selected['ref'],
                'concept_id': 'tao.center.receipt',
                'concept_label': 'Reçu d’action' if locale == 'fr' else 'Action receipt',
                'title': context['title'], 'text': preview[:800],
                'text_truncated': len(preview) > 800, 'status': projected['status'],
            })
            seen.add(key)
            if len(result) >= MAX_ACTION_INPUTS:
                return result
    return result


def decide_action(n, reply_id, decision, request_id, review_digest,
                  connector_revision, confirmed=False):
    """Execute or dismiss one exact request after an owner-only browser action."""
    if not isinstance(reply_id, str) or not re.fullmatch(r'reply:[a-f0-9]{12}', reply_id):
        raise ValueError('Réponse d’action inconnue.')
    if decision not in ('execute', 'dismiss'):
        raise ValueError('Décision d’action inconnue.')
    if decision == 'execute' and confirmed is not True:
        raise ValueError('Confirmer explicitement l’appel exact avant son exécution.')
    if type(connector_revision) is not int or connector_revision < 0:
        raise ValueError('Révision du connecteur invalide.')
    with n.LOCK:
        s = n.load_state(); dialogue = s.get('dialogue', {})
        message = next((row for row in dialogue.get('messages', [])
                        if row.get('id') == reply_id and row.get('role') == 'assistant'), None)
        capture = ((message or {}).get('center_capture', {}).get('action')
                   if isinstance(message, dict) else None)
        payload = _captured_action_payload(capture)
        if capture.get('digest') != _proposal_digest(n, payload):
            raise ValueError('La proposition d’action ne correspond plus à son aperçu exact.')
        if request_id != payload['request_id'] or review_digest != payload['review_digest']:
            raise ValueError('La décision ne correspond pas à l’appel affiché.')
        registry = ensure(s); center = _center(registry, payload['center_id'])
        check_revision(payload['center_revision'], center['revision'])
        if center['status'] == 'retired':
            raise ValueError('Le centre a été retiré ; demander une nouvelle action si nécessaire.')
        catalog = connectors.catalog(n)
        request = next((row for row in catalog['requests'] if row['id'] == request_id), None)
        if (request is None or not _request_matches_action(request, payload, payload)
                or request.get('review_digest') != review_digest):
            raise ValueError('Le reçu de l’action ne correspond pas à la proposition affichée.')
        if request.get('status') != 'review':
            raise ValueError('Cette action a déjà été décidée ; son reçu reste conservé.')
        check_revision(connector_revision, catalog['revision'])
    if decision == 'execute':
        receipt = connectors.execute(n, request_id, connector_revision, review_digest)
    else:
        receipt = connectors.dismiss(n, request_id, connector_revision)
    n.event('center_action_' + ('executed' if decision == 'execute' else 'dismissed'), {
        'center_id': payload['center_id'], 'request_id': request_id,
        'status': receipt['status'], 'world_id': worlds.current(),
    })
    return receipt


def assimilate_ai_adapter(n, s, proposal, reply_id, focus, current):
    """Compatibility capture for a response produced by the former pilot."""
    result = {'status': 'none', 'warnings': [], 'legacy': True,
              'credentials_configured': False, 'connection_tested': False,
              'automatic_dispatch': False, 'automatic_polling': False,
              'execution_enabled': False}
    if proposal is None:
        return result
    if not current:
        result.update(status='deferred')
        result['warnings'].append('Ancien adaptateur non retenu : le contexte a changé.')
        return result
    if not isinstance(focus, dict) or focus.get('kind') != 'center':
        result.update(status='rejected')
        result['warnings'].append('Ancien adaptateur non retenu : aucun centre sélectionné.')
        return result
    try:
        registry = ensure(s); row = _center(registry, focus.get('id'))
        check_revision(focus.get('revision'), row['revision'])
        if row['status'] == 'retired':
            raise ValueError('Le centre sélectionné est retiré.')
        values = validate_legacy_adapter(proposal)
        payload = dict(values, kind='adapter', center_id=row['id'],
                       center_revision=row['revision'],
                       registry_revision=registry['revision'])
        result.update(payload, status='review', center_title=row['definition']['title'],
                      digest=_proposal_digest(n, payload))
    except ValueError as exc:
        result.update(status='rejected')
        result['warnings'].append('Ancien adaptateur non retenu : ' + str(exc))
    return result


def _new_trial(n, row, input_text, expected, output, process, benefit, residual,
               origin, source_reply_id=None, status='review', outcome=None,
               observed='', evidence=''):
    if len(row['trials']) >= MAX_TRIALS:
        raise ValueError('60 essais conservés pour ce centre ; aucun ancien cas n’a été effacé.')
    existing = {trial['id'] for trial in row['trials']}
    ident = _new_id(existing)
    trial = {'schema': TRIAL_SCHEMA, 'id': ident, 'status': status,
             'input': text_field(input_text, 'L’entrée du cas', 6000, True),
             'expected': text_field(expected, 'Le résultat attendu du cas', 2000, True),
             'output': text_field(output, 'La sortie du cas', 6000, True),
             'process': _steps(process, 'Le processus du cas'),
             'benefit': text_field(benefit, 'Le bénéfice du cas', 1500, True),
             'residual': text_field(residual, 'Le résidu du cas', 2000),
             'origin': origin, 'authority': 'review_required', 'execution_enabled': False,
             'created_at': n.now()}
    if source_reply_id:
        trial['source_reply_id'] = source_reply_id
    if status == 'reported':
        if outcome not in OUTCOMES:
            raise ValueError('Résultat de cas inconnu.')
        trial.update(outcome=outcome,
                     observed=text_field(observed, 'Le résultat observé', 3000, True),
                     evidence=text_field(evidence, 'La preuve du cas', 3000, True),
                     reviewed_at=n.now(), authority='human_report')
    row['trials'].append(trial)
    row['revision'] += 1; row['updated_at'] = n.now()
    if status == 'reported':
        _invalidate(row)
    return trial


def _source_input(source_message):
    """Project one frozen selected input into x without changing trial schema."""
    selected=source_message.get('input_context')
    if selected is None:
        return source_message.get('text','')
    if (not isinstance(selected,dict) or selected.get('authority')!='context_only' or
            selected.get('execution_enabled') is not False or
            selected.get('role')!='center_input'):
        raise ValueError('L’entrée jointe au message est invalide.')
    reference=selected.get('ref');context=selected.get('context')
    if not isinstance(reference,dict) or not isinstance(context,dict):
        raise ValueError('L’entrée jointe ne peut pas servir à ce centre.')
    if reference.get('kind')=='landmark':
        if context.get('status')=='archived':
            raise ValueError('Le repère joint ne peut pas servir d’entrée à ce centre.')
        concept=text_field(context.get('concept_id'),'Le type du repère',100,True)
        title=text_field(context.get('title'),'Le titre du repère',160,True)
        body=text_field(context.get('text'),'Le contenu du repère',4000,True)
        return ('Repère choisi comme entrée · '+concept+' · '+reference.get('id','')+
                '@v'+str(reference.get('revision',''))+' · contexte attribué non vérifié\n'+
                title+'\n\n'+body)
    if reference.get('kind')!='center_receipt':
        raise ValueError('Type d’entrée jointe inconnu.')
    if (set(reference)!={'kind','id','link_id'} or
            selected.get('verification')!='attributed_external_result_not_independently_verified' or
            selected.get('automatic_dispatch') is not False or
            context.get('concept_id')!='tao.center.receipt' or
            context.get('result_authority')!='external_untrusted_data' or
            context.get('execution_enabled') is not False):
        raise ValueError('Le reçu joint ne conserve pas ses limites d’autorité.')
    link=context.get('link');request=context.get('request');receipt=context.get('receipt')
    source=context.get('source_center')
    if (not isinstance(link,dict) or not isinstance(request,dict) or
            not isinstance(receipt,dict) or not isinstance(source,dict) or
            link.get('id')!=reference.get('link_id') or
            request.get('id')!=reference.get('id') or
            receipt.get('status') not in ACTION_INPUT_STATUSES or
            receipt.get('result_authority')!='external_untrusted_data'):
        raise ValueError('Le reçu joint ne correspond pas à sa provenance figée.')
    source_title=text_field(source.get('title'),'Le centre source',120,True)
    tool=text_field(request.get('tool'),'L’outil source',128,True)
    translation=text_field(link.get('translation'),'La traduction du lien',1200,True)
    if receipt.get('result') is not None:
        body=n_json(receipt['result'])
    else:
        body=str(receipt.get('reason') or 'Aucun contenu de résultat conservé.')
    if len(body)>3400:
        body=body[:3400]+'\n[… résultat tronqué ici ; reçu complet conservé dans sa provenance …]'
    return ('Reçu externe choisi comme entrée · '+reference['id']+' · statut '+
            receipt['status']+' · donnée attribuée non vérifiée\n'+source_title+
            ' · '+tool+'\nTraduction du lien : '+translation+'\n\n'+body)


def assimilate_ai_output(n, s, output, reply_id, focus, source_message, current):
    result = {'status': 'none', 'warnings': [], 'execution_enabled': False}
    if output is None:
        return result
    if not current:
        result.update(status='deferred')
        result['warnings'].append('Sortie de centre non retenue : le contexte a changé pendant la réponse.')
        return result
    if not isinstance(focus, dict) or focus.get('kind') != 'center':
        result.update(status='rejected')
        result['warnings'].append('Sortie de centre non retenue : aucun centre n’était sélectionné.')
        return result
    try:
        registry = ensure(s); row = _center(registry, focus.get('id'))
        if row['status'] == 'retired':
            raise ValueError('Le centre sélectionné est retiré.')
        prior = next((trial for trial in row['trials'] if trial.get('source_reply_id') == reply_id), None)
        trial = prior or _new_trial(n, row, _source_input(source_message),
            row['definition']['acceptance'], output['output'], output['process'],
            output['benefit'], output['residual'], 'ai', source_reply_id=reply_id)
        if prior is None:
            registry['revision'] += 1
        result.update(status='review', center_id=row['id'], trial_id=trial['id'],
                      center_title=row['definition']['title'])
    except ValueError as exc:
        result.update(status='rejected')
        result['warnings'].append('Sortie de centre non retenue : ' + str(exc))
    return result


def record_trial(n, ident, input_text, expected, output, process, benefit,
                 residual, outcome, observed, evidence, revision=0):
    with n.LOCK:
        s = n.load_state(); registry = ensure(s); check_revision(revision, registry['revision'])
        row = _center(registry, ident)
        if row['status'] == 'retired':
            raise ValueError('Restaurer ce centre avant d’ajouter un cas.')
        trial = _new_trial(n, row, input_text, expected, output, process, benefit,
                           residual, 'human', status='reported', outcome=outcome,
                           observed=observed, evidence=evidence)
        registry['revision'] += 1
        n.atomic_json(n.STATE, s, backup=True)
        n.event('center_case_reported', {'center_id': row['id'], 'trial_id': trial['id'],
                                        'outcome': outcome, 'world_id': worlds.current()})
        return copy.deepcopy(trial)


def review_trial(n, ident, trial_id, outcome, observed, evidence, residual, revision=0):
    if outcome not in OUTCOMES:
        raise ValueError('Résultat de cas inconnu.')
    with n.LOCK:
        s = n.load_state(); registry = ensure(s); check_revision(revision, registry['revision'])
        row = _center(registry, ident)
        trial_id = _identifier(trial_id, 'Essai')
        trial = next((item for item in row['trials'] if item['id'] == trial_id), None)
        if not trial:
            raise ValueError('Cet essai n’existe pas dans ce centre.')
        if trial['status'] == 'reported':
            if (trial.get('outcome'), trial.get('observed'), trial.get('evidence'), trial.get('residual')) == (
                    outcome, str(observed).strip(), str(evidence).strip(), str(residual).strip()):
                return copy.deepcopy(trial)
            raise ValueError('Cet essai a déjà été relu ; conserver son histoire et ajouter un nouveau cas.')
        trial.update(status='reported', outcome=outcome,
                     observed=text_field(observed, 'Le résultat observé', 3000, True),
                     evidence=text_field(evidence, 'La preuve du cas', 3000, True),
                     residual=text_field(residual, 'Le résidu du cas', 2000),
                     reviewed_at=n.now(), authority='human_report')
        row['revision'] += 1; row['updated_at'] = n.now(); _invalidate(row)
        registry['revision'] += 1
        n.atomic_json(n.STATE, s, backup=True)
        n.event('center_output_reviewed', {'center_id': row['id'], 'trial_id': trial['id'],
                                          'outcome': outcome, 'world_id': worlds.current()})
        return copy.deepcopy(trial)


def readiness(row):
    reported = [trial for trial in row.get('trials', []) if trial.get('status') == 'reported']
    successes = [trial for trial in reported if trial.get('outcome') == 'success']
    counterexamples = [trial for trial in reported if trial.get('outcome') == 'counterexample']
    distinct = {trial.get('input') for trial in successes}
    requirements = {
        'two_successes': len(successes) >= 2 and len(distinct) >= 2,
        'counterexample': bool(counterexamples),
        'evidence': all(trial.get('evidence') and trial.get('observed') for trial in successes + counterexamples),
    }
    return {'ready': all(requirements.values()), 'requirements': requirements,
            'reported': len(reported), 'successes': len(successes),
            'counterexamples': len(counterexamples)}


def qualify(n, ident, revision=0):
    with n.LOCK:
        s = n.load_state(); registry = ensure(s); check_revision(revision, registry['revision'])
        row = _center(registry, ident)
        if row['status'] == 'retired':
            raise ValueError('Un centre retiré ne peut pas être qualifié.')
        state = readiness(row)
        if not state['ready']:
            raise ValueError('Deux réussites distinctes, leurs preuves et un contre-exemple relu sont requis.')
        cases = [trial for trial in row['trials'] if trial.get('status') == 'reported' and
                 trial.get('outcome') in ('success', 'counterexample')]
        digest = n.digest_bytes(n.json_bytes({'definition_digest': _definition_digest(n, row),
            'cases': [{key: trial.get(key) for key in ('id', 'input', 'expected', 'output',
                       'outcome', 'observed', 'evidence', 'residual')} for trial in cases]}))
        row['qualification'] = {'at': n.now(), 'review_digest': digest,
                                'case_ids': [trial['id'] for trial in cases],
                                'scope': 'local_cases_only', 'universal_proof': False}
        row['revision'] += 1; row['updated_at'] = n.now(); registry['revision'] += 1
        n.atomic_json(n.STATE, s, backup=True)
        n.event('center_qualified', {'id': row['id'], 'world_id': worlds.current(),
                                     'universal_proof': False})
        return copy.deepcopy(row)


def action(n, ident, operation, revision=0, review_digest=None, confirmed=False):
    if operation not in ('activate', 'pause', 'restore', 'retire'):
        raise ValueError('Action de centre inconnue.')
    with n.LOCK:
        s = n.load_state(); registry = ensure(s); check_revision(revision, registry['revision'])
        row = _center(registry, ident)
        if operation == 'activate':
            qualification = row.get('qualification')
            if not confirmed or not qualification or review_digest != qualification.get('review_digest'):
                raise ValueError('Relire la qualification exacte et confirmer avant activation.')
            if row['status'] == 'retired':
                raise ValueError('Restaurer ce centre avant de l’activer.')
            row['status'] = 'active'
            row['activation'] = {'at': n.now(), 'review_digest': review_digest,
                                 'authority': 'human_confirmation',
                                 'automatic_execution': False}
        elif operation == 'pause':
            if row['status'] != 'active':
                raise ValueError('Seul un centre actif peut être mis en pause.')
            row['status'] = 'paused'
        elif operation == 'restore':
            if row['status'] != 'retired':
                raise ValueError('Seul un centre retiré peut être restauré.')
            row['status'] = 'paused' if row.get('qualification') else 'candidate'
        else:
            if any(other.get('parent_id') == row['id'] and other['status'] != 'retired'
                   for other in registry['centers'].values()):
                raise ValueError('Retirer ou déplacer d’abord les sous-centres encore présents.')
            row['status'] = 'retired'; row.pop('activation', None)
        row['revision'] += 1; row['updated_at'] = n.now(); registry['revision'] += 1
        n.atomic_json(n.STATE, s, backup=True)
        n.event('center_status_changed', {'id': row['id'], 'status': row['status'],
                                          'world_id': worlds.current()})
        return copy.deepcopy(row)


def _link_in_state(n, registry, source_id, target_id, translation, purpose):
    translation = text_field(translation, 'La traduction entre centres', 1200, True)
    purpose = text_field(purpose, 'La raison du lien', 1200, True)
    source = _center(registry, source_id); target = _center(registry, target_id)
    if source['id'] == target['id']:
        raise ValueError('Un centre ne se relie pas à lui-même.')
    if source['status'] == 'retired' or target['status'] == 'retired':
        raise ValueError('Un centre retiré ne peut pas recevoir de nouveau lien.')
    prior = next((row for row in registry['links'] if row['source_id'] == source['id']
                  and row['target_id'] == target['id'] and row['translation'] == translation), None)
    if prior:
        if prior['purpose'] != purpose:
            raise ValueError('Ce lien existe avec la même traduction mais une autre raison ; conserver cette différence et la relire.')
        return prior, False
    if len(registry['links']) >= MAX_LINKS:
        raise ValueError('64 liens maximum dans cet espace ; aucun lien existant n’a été supprimé.')
    row = {'schema': LINK_SCHEMA, 'id': _new_id({link['id'] for link in registry['links']}),
           'source_id': source['id'], 'target_id': target['id'],
           'translation': translation, 'purpose': purpose, 'created_at': n.now(),
           'authority': 'description_only', 'automatic_dispatch': False,
           'execution_enabled': False}
    registry['links'].append(row); registry['revision'] += 1
    return row, True


def link(n, source_id, target_id, translation, purpose, revision=0):
    with n.LOCK:
        s = n.load_state(); registry = ensure(s); check_revision(revision, registry['revision'])
        row, created = _link_in_state(n, registry, source_id, target_id, translation, purpose)
        if not created:
            return copy.deepcopy(row)
        n.atomic_json(n.STATE, s, backup=True)
        n.event('center_link_created', {'id': row['id'], 'source_id': row['source_id'],
                                        'target_id': row['target_id'], 'world_id': worlds.current()})
        return copy.deepcopy(row)


def _captured_payload(capture):
    kind = capture.get('kind')
    if kind == 'creation':
        return {'kind': kind, 'definition': definition(capture.get('definition')),
                'parent_id': capture.get('parent_id'),
                'registry_revision': capture.get('registry_revision')}
    if kind == 'revision':
        return {'kind': kind, 'center_id': _identifier(capture.get('center_id')),
                'center_revision': capture.get('center_revision'),
                'definition': definition(capture.get('definition')),
                'parent_id': capture.get('parent_id'),
                'registry_revision': capture.get('registry_revision')}
    if kind == 'link':
        values = validate_ai_link({key: capture.get(key) for key in
                                  ('source_id', 'target_id', 'translation', 'purpose')})
        return dict(values, kind=kind, registry_revision=capture.get('registry_revision'))
    if kind == 'organ':
        if capture.get('organ_schema') != ORGAN_SCHEMA:
            raise ValueError('Version de plan d’organe inconnue.')
        values = validate_ai_organ({key: capture.get(key) for key in ORGAN_FIELDS})
        return dict(values, kind=kind, organ_schema=ORGAN_SCHEMA,
                    center_id=_identifier(capture.get('center_id')),
                    center_revision=capture.get('center_revision'),
                    registry_revision=capture.get('registry_revision'))
    if kind == 'adapter':
        values = validate_legacy_adapter({key: capture.get(key)
                                          for key in LEGACY_ADAPTER_FIELDS})
        return dict(values, kind=kind,
                    center_id=_identifier(capture.get('center_id')),
                    center_revision=capture.get('center_revision'),
                    registry_revision=capture.get('registry_revision'))
    raise ValueError('Type de proposition de centre inconnu.')


def decide_proposal(n, reply_id, kind, decision, dialogue_revision=0):
    """Accept or reject one exact AI suggestion stored in a dialogue message.

    Rejection only records the human decision.  Acceptance performs one local
    registry mutation; it never starts a connector, model, dispatch or tool.
    """
    if not isinstance(reply_id, str) or not re.fullmatch(r'reply:[a-f0-9]{12}', reply_id):
        raise ValueError('Réponse de proposition inconnue.')
    if kind not in ('proposal', 'revision', 'link', 'organ', 'adapter') or decision not in ('accept', 'reject'):
        raise ValueError('Décision de proposition inconnue.')
    with n.LOCK:
        s = n.load_state(); dialogue = s.get('dialogue')
        if not isinstance(dialogue, dict) or not isinstance(dialogue.get('messages'), list):
            raise ValueError('Discussion de proposition introuvable.')
        check_revision(dialogue_revision, dialogue.get('revision', 0))
        message = next((row for row in dialogue['messages']
                        if row.get('id') == reply_id and row.get('role') == 'assistant'), None)
        if not message:
            raise ValueError('Réponse de proposition introuvable.')
        center_capture = message.get('center_capture')
        if not isinstance(center_capture, dict) or not isinstance(center_capture.get(kind), dict):
            raise ValueError('Cette réponse ne contient pas cette proposition.')
        capture = center_capture[kind]
        status = capture.get('status')
        terminal = 'accepted' if decision == 'accept' else 'rejected_by_owner'
        if status == terminal:
            return copy.deepcopy(dict(capture, dialogue_revision=dialogue['revision']))
        if status != 'review':
            raise ValueError('Cette proposition n’est plus en attente de ta décision.')
        payload = _captured_payload(capture)
        if (type(payload.get('registry_revision')) is not int or
                capture.get('digest') != _proposal_digest(n, payload)):
            raise ValueError('La proposition conservée ne correspond plus à son aperçu exact.')
        if decision == 'reject':
            capture.update(status='rejected_by_owner', decided_at=n.now())
            dialogue['revision'] += 1
            n.atomic_json(n.STATE, s, backup=True)
            n.event('center_proposal_rejected', {'kind': payload['kind'],
                                                  'reply_id': reply_id,
                                                  'world_id': worlds.current()})
            return copy.deepcopy(dict(capture, dialogue_revision=dialogue['revision']))

        registry = ensure(s)
        check_revision(payload['registry_revision'], registry['revision'])
        event = {'kind': payload['kind'], 'reply_id': reply_id,
                 'world_id': worlds.current()}
        if payload['kind'] == 'creation':
            row = _create_in_state(n, s, payload['definition'], payload['parent_id'],
                                   origin='ai', reply_id=reply_id)
            capture['center_id'] = row['id']; event['center_id'] = row['id']
        elif payload['kind'] == 'revision':
            row = _center(registry, payload['center_id'])
            check_revision(payload['center_revision'], row['revision'])
            row = _revise_in_state(n, registry, row['id'], payload['definition'],
                                   payload['parent_id'])
            capture['center_id'] = row['id']; event['center_id'] = row['id']
        elif payload['kind'] == 'link':
            row, created = _link_in_state(n, registry, payload['source_id'],
                                          payload['target_id'], payload['translation'],
                                          payload['purpose'])
            if not created:
                raise ValueError('Cette liaison existe déjà ; aucune seconde liaison n’a été créée.')
            capture['link_id'] = row['id']; event['link_id'] = row['id']
        elif payload['kind'] in ('organ', 'adapter'):
            row = _center(registry, payload['center_id'])
            check_revision(payload['center_revision'], row['revision'])
            existing = _prepared_adapters(n, s, row, exclude_reply_id=reply_id)
            if len(existing) >= MAX_PREPARED_ADAPTERS:
                raise ValueError('16 organes préparés maximum pour ce centre.')
            candidate = _organ_projection(payload)
            if any(_same_organ(adapter, candidate) for adapter in existing):
                raise ValueError('Cet organe est déjà préparé pour ce centre.')
            # The accepted dialogue record is the blueprint.  It still has no
            # implementation, credentials, polling or execution authority.
            event['center_id'] = row['id']
        else:
            raise ValueError('Type de proposition de centre inconnu.')
        capture.update(status='accepted', decided_at=n.now())
        dialogue['revision'] += 1
        n.atomic_json(n.STATE, s, backup=True)
        n.event('center_proposal_accepted', event)
        return copy.deepcopy(dict(capture, dialogue_revision=dialogue['revision'],
                                  registry_revision=registry['revision']))


def rollback_empty(n, revision=0):
    with n.LOCK:
        s = n.load_state(); registry = ensure(s); check_revision(revision, registry['revision'])
        result = rollback_state(s)
        n.atomic_json(n.STATE, result, backup=True)
        n.event('centers_schema_rolled_back', {'world_id': worlds.current()})
        return {'rolled_back': True, 'schema': SCHEMA}


def _public_center(row):
    value = copy.deepcopy(row)
    value['readiness'] = readiness(row)
    value['execution_enabled'] = False
    return value


def _focus_center(row, adapters=None):
    """Bounded center context; full private cases stay in the owner view."""
    definition_value = copy.deepcopy(row['definition'])
    for key in ('purpose', 'input', 'output', 'benefit', 'acceptance', 'boundaries'):
        definition_value[key] = definition_value[key][:700]
    definition_value['process'] = [step[:240] for step in definition_value['process']]
    trial_rows = []
    for trial in row.get('trials', [])[-4:]:
        kept = {key: copy.deepcopy(trial.get(key)) for key in
                ('id', 'status', 'origin', 'outcome', 'input', 'expected', 'output',
                 'process', 'benefit', 'residual', 'observed', 'evidence') if key in trial}
        for key, limit in (('input', 500), ('expected', 400), ('output', 700),
                           ('benefit', 300), ('residual', 500), ('observed', 500),
                           ('evidence', 500)):
            if isinstance(kept.get(key), str):
                kept[key] = kept[key][:limit]
        if isinstance(kept.get('process'), list):
            kept['process'] = [step[:180] for step in kept['process']]
        kept['execution_enabled'] = False
        trial_rows.append(kept)
    adapter_rows = []
    for adapter in (adapters or [])[-6:]:
        kept = {key: copy.deepcopy(adapter.get(key)) for key in
                ('schema', 'legacy', 'name', 'role', 'interface', 'operation', 'input',
                 'output', 'translation', 'requested_effects', 'requirements',
                 'purpose', 'acceptance', 'boundaries', 'current_contract')}
        for key in ('input', 'output', 'translation', 'purpose', 'acceptance', 'boundaries'):
            if isinstance(kept.get(key), str):
                kept[key] = kept[key][:400]
        if isinstance(kept.get('requirements'), list):
            kept['requirements'] = [item[:240] for item in kept['requirements'][:8]]
        kept.update(credentials_configured=False, connection_tested=False,
                    automatic_dispatch=False, automatic_polling=False,
                    execution_enabled=False)
        adapter_rows.append(kept)
    result = {'id': row['id'], 'revision': row['revision'], 'status': row['status'],
              'parent_id': row.get('parent_id'),
              'provenance': row.get('provenance', '')[:1000],
              'definition': definition_value, 'readiness': readiness(row),
              'recent_trials': trial_rows,
              'omitted_trials': max(0, len(row.get('trials', [])) - len(trial_rows)),
              'qualification': copy.deepcopy(row.get('qualification')),
              'prepared_adapters': adapter_rows,
              'omitted_prepared_adapters': max(0, len(adapters or []) - len(adapter_rows)),
              'execution_enabled': False}
    return result


def view(n, s=None):
    state = n.load_state() if s is None else s
    registry = _registry(state)
    rows = []
    for row in registry['centers'].values():
        public = _public_center(row)
        public['prepared_adapters'] = _prepared_adapters(n, state, row)
        rows.append(public)
    rows.sort(key=lambda row: (row['status'] == 'retired', row['created_at'], row['id']))
    return {'schema': SCHEMA, 'revision': registry['revision'], 'world_id': worlds.current(),
            'centers': rows, 'links': copy.deepcopy(registry['links']),
            'specialized_count': sum(row['status'] == 'active' for row in rows),
            'seed': {'id': 'C0', 'status': 'proto_center',
                     'note': 'Aucun centre spécialisé n’est imposé à la naissance.'},
            'automatic_ai': False, 'automatic_dispatch': False}


def focus(n, s, reference):
    registry = _registry(s)
    if reference.get('kind') == 'center_factory':
        if reference.get('id') != 'new':
            raise ValueError('Fabrique de centres inconnue.')
        check_revision(reference.get('revision'), registry['revision'])
        return {'kind': 'center_factory', 'registry_revision': registry['revision'],
                'existing_centers': [{'id': row['id'], 'title': row['definition']['title'],
                                      'status': row['status'], 'parent_id': row.get('parent_id')}
                                     for row in registry['centers'].values()],
                'contract': 'Proposer une transformation candidate inerte ; aucune activation ni exécution.'}
    row = _center(registry, reference.get('id'))
    check_revision(reference.get('revision'), row['revision'])
    parent = registry['centers'].get(row.get('parent_id'))
    children = [candidate for candidate in registry['centers'].values()
                if candidate.get('parent_id') == row['id']]
    return {'kind': 'center', 'center': _focus_center(row, _prepared_adapters(n, s, row)),
            'hierarchy': {
                'parent': ({'id': parent['id'], 'title': parent['definition']['title'],
                            'status': parent['status']} if parent else None),
                'children': [{'id': child['id'], 'title': child['definition']['title'],
                              'status': child['status']} for child in children[:12]],
                'omitted_children': max(0, len(children) - 12),
            },
            'links': [copy.deepcopy(link) for link in registry['links']
                      if row['id'] in (link['source_id'], link['target_id'])],
            'contract': 'La réponse peut proposer une sortie à relire ; elle ne produit aucun effet externe.'}


def context(n, s, focus_reference=None):
    registry = _registry(s)
    rows = list(registry['centers'].values())
    summaries = [{'id': row['id'], 'revision': row['revision'], 'status': row['status'],
                  'parent_id': row.get('parent_id'),
                  'title': row['definition']['title'],
                  'purpose': row['definition']['purpose'][:300],
                  'input': row['definition']['input'][:300],
                  'output': row['definition']['output'][:300],
                  'prepared_adapter_count': len(_prepared_adapters(n, s, row)),
                  'execution_enabled': False} for row in rows[:12]]
    selected = None
    if isinstance(focus_reference, dict) and focus_reference.get('kind') in ('center', 'center_factory'):
        selected = focus(n, s, focus_reference)
    return {'schema': SCHEMA, 'world_id': worlds.current(), 'registry_revision': registry['revision'],
            'centers': summaries, 'omitted_centers': max(0, len(rows) - len(summaries)),
            'selected': selected,
            'rules': ['Une transformation stateless ne suffit pas à prouver un centre.',
                      'Une proposition IA reste candidate et sans autorité.',
                      'Deux réussites distinctes et un contre-exemple relu précèdent une activation locale.',
                      'La hiérarchie parent-enfant décrit une décomposition fonctionnelle, jamais une simple catégorie ou une autorité globale.',
                      'Un échange entre branches est un lien dirigé de traduction ; il ne change pas leur parent.',
                      'Le contrat courant contraint la transformation ; un contrat importé reste une source externe non authentifiée et ne transmet aucune permission.',
                      'Le contrat opérationnel visible compose la fonction et son processus avec l’IA de conversation, les organes préparés et l’autorité humaine ; cette projection ne crée aucun nouveau droit.',
                      'Les étapes métier et points de validation restent dans le processus ; agents spécialisés et outils sont des organes séparés dont les effets demandés ne sont jamais des permissions acquises.',
                      'Si plusieurs contrats se contredisent, conserver le conflit comme résidu et proposer une révision explicite plutôt que les fusionner silencieusement.',
                      'L’intendance peut proposer une création, une révision, un traducteur ou un organe générique ; une décision humaine exacte reste requise.',
                      'Les liens traduisent des sorties ; ils ne transmettent ni mémoire privée ni permission.',
                      'Un organe préparé décrit des effets demandés, mais reste sans implémentation, identifiant, permission, polling ou exécution.'],
            'automatic_ai': False, 'automatic_dispatch': False}
