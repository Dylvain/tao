"""Versioned, bilingual descriptions of Tao's concepts, not an agent runtime.

This catalogue reads no private state, grants no permission, and leaves canon
4.3.0 intact. Formal expressions define bounded design contracts; they do not
certify a model's intelligence or the empirical truth of a user's hypothesis.
"""
import copy


SCHEMA = 'tao.logic.catalog.v1'
VERSION = '2.0.0'
LOCALES = ('fr', 'en')
EPISTEMIC_STATUSES = ('math', 'operational', 'proposed')
IMPLEMENTATION_STATUSES = ('implemented', 'partial', 'proposed', 'not_applicable')
PREFIX = 'tao.concept.'


def _term(key, labels, definitions, status, implementation, references,
          formalisms=(), aliases=((), ())):
    return {'id': PREFIX + key, 'key': key,
            'labels': dict(zip(LOCALES, labels)),
            'definitions': dict(zip(LOCALES, definitions)),
            'aliases': {lang: list(items) for lang, items in zip(LOCALES, aliases)},
            'epistemic_status': status,
            'implementation': {'status': implementation, 'references': list(references)},
            'formalism_ids': ['tao.logic.formalism.' + key for key in formalisms]}


TERMS = (
    _term('system', ('Système', 'System'), (
        'Entité décrite avec état, frontière, histoire et contraintes. La décrire ne crée ni accès ni agent.',
        'An entity described by its state, boundary, history and constraints. Describing it creates neither access nor an agent.'),
        'operational', 'partial', ('docs/theory.json', 'bootstrap/tao_node.py'), ('system',)),
    _term('story', ('Histoire', 'Story'), (
        'Récit situé d’événements et de leurs sources ; distinguer les faits rapportés du résultat souhaité et des hypothèses.',
        'A situated account of events and their sources; reported facts, desired outcomes and hypotheses remain distinct.'),
        'operational', 'implemented', ('bootstrap/tao_node.py', 'bootstrap/tao_continuity.py'), (),
        (('récit',), ('history',))),
    _term('difference', ('Écart', 'Difference'), (
        'Comparaison dans un contexte entre une observation et une référence. Soustraire exige des grandeurs et unités compatibles.',
        'A contextual comparison between an observation and a reference. Subtraction requires compatible quantities and units.'),
        'operational', 'partial', ('bootstrap/tao_integrability.py', 'docs/TECHNICAL.md'), ('difference',),
        (('différence',), ('gap',))),
    _term('need', ('Besoin', 'Need'), (
        'Écart pertinent encore à comprendre ou à traiter, relié à une histoire et à un critère. Sa description ne commande pas une action.',
        'A relevant gap still to understand or address, linked to a story and a criterion. Describing it does not command an action.'),
        'operational', 'implemented', ('bootstrap/tao_continuity.py',), ('difference',)),
    _term('objective', ('Objectif', 'Objective'), (
        'Situation souhaitée dont le contexte et le critère de réalisation sont explicites ; elle peut être révisée ou rester en conflit avec une autre.',
        'A desired situation with explicit context and achievement criteria; it may be revised or remain in conflict with another.'),
        'operational', 'partial', ('bootstrap/tao_foundations.py', 'bootstrap/tao_landmarks.py')),
    _term('task', ('Tâche', 'Task'), (
        'Contribution délimitée, proposée ou suivie, avec résultat attendu. La décrire, l’exécuter et constater son utilité sont trois événements distincts.',
        'A bounded proposed or tracked contribution with an expected result. Describing it, executing it and observing its usefulness are distinct events.'),
        'operational', 'implemented', ('bootstrap/tao_work.py', 'bootstrap/tao_landmarks.py')),
    _term('house', ('Maison', 'House'), (
        'Foyer logique de pièces et d’histoires, servi aujourd’hui par un seul nœud Tao dont il emprunte l’identifiant local. Cet identifiant ne prouve pas l’unicité entre copies ou réinstallations ; une identité de maison indépendante et la synchronisation entre nœuds restent à construire.',
        'A logical home for rooms and histories, currently served by one Tao node whose local identifier it uses. This identifier does not prove uniqueness across copies or reinstalls; a separate house identity and cross-node synchronization remain to be built.'),
        'operational', 'partial', ('bootstrap/tao_node.py', 'bootstrap/tao_worlds.py', 'docs/TECHNICAL.md'), (),
        (('manoir',), ('mansion',))),
    _term('space', ('Espace', 'Space'), (
        'Pièce ou monde : même contexte privé de discussion et de données dans une maison. Le parent voit les métadonnées de navigation, pas automatiquement les souvenirs de ses enfants ; un projet professionnel et un projet d’écriture peuvent avoir des pièces distinctes.',
        'Room or world: the same private context for discussion and data within a house. A parent sees navigation metadata, not automatically its children’s memories; a professional project and a writing project may use distinct rooms.'),
        'operational', 'implemented', ('bootstrap/tao_worlds.py',), ('invocation',),
        (('monde', 'pièce'), ('world', 'room'))),
    _term('view', ('Vue', 'View'), (
        'Présentation ou filtre d’objets existants. Une nouvelle vue ne crée pas une nouvelle identité, mémoire ou permission.',
        'A presentation or filter of existing objects. A new view creates no new identity, memory or permission.'),
        'operational', 'implemented', ('bootstrap/tao_worlds.py', 'bootstrap/tao_home_ui.py')),
    _term('address', ('Adresse', 'Address'), (
        'Repère de lecture d’une maison, pièce, vue, sujet typé facultatif et attributs de présentation. Une URL encode une route et certains de ces choix ; elle ne transporte ni mémoire, ni outil disponible, ni permission.',
        'A reading reference for a house, room, view, optional typed focus and presentation attributes. A URL encodes a route and some of these choices; it carries neither memory, available tool nor permission.'),
        'operational', 'partial', ('bootstrap/tao_node.py', 'bootstrap/tao_home_ui.py', 'docs/TECHNICAL.md'),
        ('address', 'address_url'), (('adresse logique', 'URL'), ('logical address', 'URL'))),
    _term('conversation_thread', ('Fil de conversation', 'Conversation thread'), (
        'Fil local proposé avec identifiant stable dans une pièce et sujet révisable. Une URL de conversation ChatGPT peut être une référence externe facultative, jamais son identité locale ni un mandat. En cas de dérive, Tao proposerait continuer, changer de fil ou créer un fil local ; la personne choisit.',
        'A proposed local thread with a stable identifier within a room and a revisable topic. A ChatGPT conversation URL may be an optional external reference, never its local identity or a mandate. On topic drift, Tao would offer to continue, switch or create a local thread; the person chooses.'),
        'proposed', 'proposed', ('docs/TECHNICAL.md',), ('conversation_thread',),
        (('conversation locale',), ('local thread',))),
    _term('center', ('Centre fonctionnel', 'Functional centre'), (
        'Spécialisation candidate avec état, langage, mémoire, rythme et résidus propres. Sa séparation exige un bénéfice observé ; C₀ peut garder les fonctions réunies.',
        'A candidate specialization with its own state, language, memory, rhythm and residuals. Separation requires observed benefit; C₀ can keep functions together.'),
        'operational', 'partial', ('docs/theory.json', 'bootstrap/tao_node.py', 'docs/TECHNICAL.md'), (),
        (('centre',), ('center', 'centre'))),
    _term('function', ('Fonction', 'Function'), (
        'Transformation définie par ses entrées, sorties, préconditions et effets. Une fonction sans état propre ne suffit pas à constituer un centre.',
        'A transformation defined by inputs, outputs, preconditions and effects. A stateless function alone does not constitute a centre.'),
        'operational', 'partial', ('bootstrap/tao_routing.py', 'bootstrap/tao_reuse.py'), ('invocation',)),
    _term('mode', ('Mode de travail', 'Work mode'), (
        'Manière proposée de travailler : appliquer, composer ou réexaminer le cadre. Ces modes ne sont ni trois agents, ni trois permissions, ni une mesure d’intelligence.',
        'A proposed way of working: apply, compose or reconsider the framing. These modes are not three agents, three permissions or a measure of intelligence.'),
        'proposed', 'proposed', ('docs/TECHNICAL.md',)),
    _term('contextual_self', ('Moi contextuel', 'Contextual self'), (
        'Position de travail proposée : une intention, des préférences, une mémoire sélectionnée et un horizon dans un espace. Elle n’est ni une personne consciente ni un compte autorisé.',
        'A proposed working position: an intention, preferences, selected memory and a horizon within a space. It is neither a conscious person nor an authorized account.'),
        'proposed', 'proposed', ('docs/TECHNICAL.md',), ('contextual_self',),
        (('moi local',), ('local self',))),
    _term('steward', ('Intendant', 'Steward'), (
        'Modèle proposé de coordination bornée entre centres. C₀ peut préparer des centres, liens et organes à relire, mais la lecture transversale et un intendant IA autonome ne sont pas livrés ; aucun droit supplémentaire n’en découle.',
        'Proposed model for bounded coordination between centres. C₀ can prepare centres, links and organs for review, but cross-centre reading and an autonomous AI steward are not delivered; no extra right follows.'),
        'proposed', 'proposed', ('docs/TECHNICAL.md',), ('coordination', 'budget', 'capabilities'),
        (('coordinateur',), ('coordinator',))),
    _term('actor', ('Acteur', 'Actor'), (
        'Participant ou moyen mobilisé : humain, programme déterministe ou invocation de modèle. Son rôle déclaré ne prouve ni sa disponibilité, ni sa capacité, ni son autorité.',
        'A participant or means used: a human, deterministic program or model invocation. A declared role proves neither availability, capability nor authority.'),
        'operational', 'partial', ('bootstrap/tao_dialogue.py', 'bootstrap/tao_reuse.py', 'bootstrap/tao_connectors.py'), ('invocation',)),
    _term('role', ('Rôle', 'Role'), (
        'Responsabilité décrite dans une pièce et reliée, si les sources le justifient, à une personne, une mission ou un contrat. Un rôle professionnel n’est ni un rôle éditorial ni une permission informatique.',
        'A responsibility described within a room and linked, if sources warrant it, to a person, mission or contract. A professional role is neither an editorial role nor a software permission.'),
        'operational', 'partial', ('bootstrap/tao_foundations.py', 'bootstrap/tao_landmarks.py'), ('scoped_record',)),
    _term('mission', ('Mission métier', 'Mission'), (
        'Ensemble décrit de résultats attendus et de responsabilités dans une pièce, distinct d’une invocation. Une mission client et une mission d’écriture conservent leurs sources propres ; une fiche ne lance pas de job ni n’accorde de mandat.',
        'A described set of expected outcomes and responsibilities within a room, distinct from an invocation. A client mission and a writing mission keep their own sources; a record starts no job and grants no mandate.'),
        'operational', 'partial', ('bootstrap/tao_foundations.py', 'bootstrap/tao_landmarks.py'), ('scoped_record',)),
    _term('contract', ('Contrat', 'Contract'), (
        'Accord rapporté entre parties, avec conditions et obligations, conservé et sourcé dans une pièce. Une fiche de contrat ne signe pas l’accord et ne donne pas accès aux outils de cette pièce ni d’une autre.',
        'A reported agreement between parties, with terms and obligations, stored and sourced within a room. A contract record neither signs the agreement nor grants access to tools in this or another room.'),
        'operational', 'partial', ('bootstrap/tao_foundations.py', 'bootstrap/tao_landmarks.py'), ('scoped_record',)),
    _term('method', ('Méthode', 'Method'), (
        'Procédure réutilisable décrite avec domaine, limites et contre-exemple, éventuellement retenue dans une pièce. La consigner ou la transmettre ne l’active pas comme outil exécutable.',
        'A reusable procedure described with domain, limits and counterexample, possibly retained within a room. Recording or transmitting it does not activate an executable tool.'),
        'operational', 'partial', ('bootstrap/tao_foundations.py', 'bootstrap/tao_learning.py', 'bootstrap/tao_landmarks.py'), ('scoped_record',),
        (('procédure',), ('procedure',))),
    _term('process', ('Processus de travail', 'Work process'), (
        'Enchaînement décrit d’étapes, d’acteurs, d’entrées et de vérifications pour une mission ou une méthode dans un contexte. Son dessin ne programme ni n’exécute ces étapes.',
        'A described sequence of steps, actors, inputs and checks for a mission or method in a context. Drawing it neither programs nor runs those steps.'),
        'proposed', 'proposed', ('docs/TECHNICAL.md',), (),
        (('processus',), ('workflow', 'process'))),
    _term('automation', ('Automatisation exécutable', 'Executable automation'), (
        'Capacité codée qui traite des entrées selon un contrat borné. Les recettes déterministes par pièce existent après qualification et activation ; décrire un processus ou une méthode ne crée pas cette capacité.',
        'A coded capability that handles inputs under a bounded contract. Per-room deterministic recipes exist after qualification and activation; describing a process or method does not create that capability.'),
        'operational', 'partial', ('bootstrap/tao_reuse.py', 'docs/TECHNICAL.md'), ('capabilities',)),
    _term('tool', ('Outil', 'Tool'), (
        'Référence à une opération possible, locale ou externe, dans le contexte d’une pièce. Le nom d’un service n’établit ni installation, ni disponibilité, ni droit d’appel.',
        'A reference to a possible local or external operation in a room’s context. Naming a service establishes neither installation, availability nor authority to call it.'),
        'operational', 'partial', ('bootstrap/tao_reuse.py', 'bootstrap/tao_connectors.py', 'docs/TECHNICAL.md'), ('capabilities',)),
    _term('connector', ('Connecteur', 'Connector'), (
        'Adaptateur configuré pour exposer et appeler des outils d’un programme extérieur. Le client MCP local fonctionne par pièce sous revue ; enregistrer un connecteur ne prouve ni que le service métier est disponible ni que tout appel est autorisé.',
        'A configured adapter exposing and calling tools from an external program. The local MCP client works per room under review; registering a connector proves neither that the business service is available nor that every call is authorized.'),
        'operational', 'partial', ('bootstrap/tao_connectors.py', 'docs/TECHNICAL.md'), ('capabilities',)),
    _term('invocation', ('Invocation', 'Invocation'), (
        'Contrat général proposé pour un essai borné : espace, sources, fonction, acteur, mandat et budget. Les jobs existants ont des contrats spécialisés, pas un ordonnanceur universel.',
        'A proposed general contract for a bounded attempt: space, sources, function, actor, mandate and budget. Existing jobs have specialized contracts, not a universal scheduler.'),
        'proposed', 'proposed', ('docs/TECHNICAL.md',), ('invocation', 'capabilities', 'budget')),
    _term('workshop', ('Atelier', 'Workshop'), (
        'Expérience de code dans une copie Git indépendante, avec candidat, revue et vérifications. Cette séparation ne constitue pas une isolation complète du système Linux.',
        'A code experiment in an independent Git copy, with a candidate, review and checks. This separation does not provide complete Linux system isolation.'),
        'operational', 'implemented', ('bootstrap/tao_workshop.py', 'bootstrap/tao_adaptation.py', 'docs/TECHNICAL.md')),
    _term('heritage', ('Héritage', 'Heritage'), (
        'Acquis versionnés : vocabulaire, code et méthodes transmissibles choisis. L’histoire privée, les comptes et les permissions ne sont pas transmis automatiquement.',
        'Versioned acquisitions: selected vocabulary, code and transmissible methods. Private history, accounts and permissions are not automatically inherited.'),
        'operational', 'partial', ('bootstrap/tao_ecology.py', 'bootstrap/tao_learning.py', 'docs/TECHNICAL.md'), (),
        (('patrimoine',), ('inheritance',))),
    _term('provenance', ('Provenance', 'Provenance'), (
        'Lien d’une affirmation à ses sources, auteurs déclarés, transformations et révisions. Une citation attribuée n’est pas nécessairement authentifiée ou vraie.',
        'A claim’s link to sources, declared authors, transformations and revisions. An attributed quotation is not necessarily authenticated or true.'),
        'operational', 'implemented', ('bootstrap/tao_landmarks.py', 'bootstrap/tao_history_store.py')),
    _term('integration', ('Intégration', 'Integration'), (
        'Incorporation d’un résultat ou d’une différence dans un contexte, en préservant les contraintes et les résidus importants. Le nom ne garantit ni résolution universelle ni intégrabilité future.',
        'Incorporation of a result or difference within a context while preserving constraints and significant residuals. The name guarantees neither universal resolution nor future integrability.'),
        'operational', 'partial', ('docs/theory.json', 'docs/TECHNICAL.md', 'bootstrap/tao_adaptation.py'), ('integration',)),
    _term('buffer', ('Tampon Tao', 'Tao buffer'), (
        'Trace visible d’un résidu important encore non intégré ; elle conserve l’écart au lieu de le masquer.',
        'A visible record of a significant residual not yet integrated; it preserves the discrepancy instead of hiding it.'),
        'operational', 'implemented', ('bootstrap/tao_node.py', 'bootstrap/tao_continuity.py', 'docs/TECHNICAL.md'), ('integration',),
        (('tampon',), ('buffer',))),
    _term('source', ('Source', 'Source'), (
        'Message, observation ou document explicitement fourni avec sa référence et son origine déclarée. Une source importée ou IA conserve son incertitude.',
        'An explicitly provided message, observation or document with its reference and declared origin. Imported or AI sources retain their uncertainty.'),
        'operational', 'implemented', ('bootstrap/tao_history_archive.py', 'bootstrap/tao_landmarks.py'), ('history',)),
    _term('mandate', ('Mandat', 'Mandate'), (
        'Autorisation bornée sur des opérations concrètes, leurs paramètres, durée et quotas. Un rôle, un mode, un titre ou une réponse IA ne crée pas cette autorisation.',
        'Bounded authorization for concrete operations, parameters, duration and quotas. A role, mode, title or AI response does not create that authorization.'),
        'operational', 'partial', ('bootstrap/tao_bridge.py', 'bootstrap/tao_connectors.py', 'bootstrap/tao_devices.py'), ('capabilities',)),
    _term('resource', ('Ressource', 'Resource'), (
        'Moyen mesuré ou requis dans une unité propre : durée, mémoire, argent ou autre grandeur. Les coûts inconnus restent inconnus ; les unités ne sont pas additionnées implicitement.',
        'A measured or required means in its own unit: duration, memory, money or another quantity. Unknown costs remain unknown; units are not implicitly added.'),
        'operational', 'partial', ('bootstrap/tao_ecology.py', 'bootstrap/tao_integrability.py'), ('budget',)),
    _term('evidence', ('Élément de preuve', 'Evidence'), (
        'Observation ou document utilisé pour examiner une affirmation dans un contexte. Une source citée, un test réussi et une utilité constatée ne sont pas la même preuve.',
        'An observation or document used to examine a claim in context. A cited source, passing test and observed usefulness are not the same evidence.'),
        'operational', 'partial', ('bootstrap/tao_learning.py', 'bootstrap/tao_landmarks.py', 'docs/VALIDATION.md')),
)


def _formalism(key, expression, explanations, assumptions, status='operational'):
    return {'id': 'tao.logic.formalism.' + key, 'expression': expression,
            'explanations': dict(zip(LOCALES, explanations)),
            'assumptions': {lang: list(items) for lang, items in zip(LOCALES, assumptions)},
            'epistemic_status': status}


FORMALISMS = (
    _formalism('system', 'S = (X, ∂S, F, M, Λ, Auth)', (
        'Projection courte : état, frontière, dynamique, mémoire, contraintes et autorité. Le canon décrit aussi observation et action.',
        'A short projection: state, boundary, dynamics, memory, constraints and authority. The canon also describes observation and action.'), (
        ('Définir le système et son périmètre avant de comparer deux états.',),
        ('Define the system and its scope before comparing two states.',))),
    _formalism('history', 'H = [(t, observation, action, source)]', (
        'Modèle candidat d’une trajectoire structurée, distinct de la fiche récit actuellement conservée en texte. Un champ inconnu n’est pas reconstruit par supposition.',
        'Candidate model of a structured trajectory, distinct from the currently stored narrative text record. Unknown fields are not reconstructed by assumption.'), (
        ('Distinguer événement rapporté, observation et interprétation.',),
        ('Distinguish reported events, observations and interpretations.',))),
    _formalism('difference', 'Δ = compare(observation, reference | context)', (
        'Le contrat de comparaison dépend du domaine. Une soustraction numérique exige une unité commune.',
        'The comparison contract depends on the domain. Numerical subtraction requires a common unit.'), (
        ('La référence, sa date, l’unité éventuelle et l’incertitude sont explicites.',),
        ('The reference, date, possible unit and uncertainty are explicit.',))),
    _formalism('address', 'L = (N, w, v, f, a)', (
        'Adresse logique de lecture : identifiant local de nœud N, pièce w, vue v, focus facultatif f et attributs a. Les références (N,w) et (N,w,type,id) restent situées dans un même état continu.',
        'Logical reading address: local node identifier N, room w, view v, optional focus f and attributes a. References (N,w) and (N,w,type,id) remain scoped to one continuous local state.'), (
        ('w existe sur N ; N ne prouve ni unicité globale ni identité entre copies ; f est absent ou une référence (type,id[,version]) vérifiée dans w.',
         'a contient seulement des clés et valeurs déclarées et bornées par la vue.'),
        ('w exists on N; N proves neither global uniqueness nor identity across copies; f is absent or a (type,id[,version]) reference verified within w.',
         'a contains only keys and values declared and bounded by the view.'))),
    _formalism('address_url', 'encode_N(L) = origin + route(v) + query(w,f,a) + fragment', (
        'L’URL représente une partie de l’adresse pour naviguer et filtrer. world et le filtre type de /explore sont présents ; un focus typé en URL et d’autres filtres restent proposés.',
        'A URL represents part of the address for navigation and filtering. world and /explore’s type filter exist; typed focus in a URL and further filters remain proposed.'), (
        ('Le décodage valide route, espace, types et attributs ; une clé inconnue ne devient pas une action.',
         'Résoudre ou copier une URL ne confère aucune permission, mémoire ni disponibilité d’outil.'),
        ('Decoding validates route, space, types and attributes; an unknown key does not become an action.',
         'Resolving or copying a URL grants no permission, memory or tool availability.')), 'proposed'),
    _formalism('scoped_record', 'identity(record) = (N, w, type, id)', (
        'Rôle, mission, contrat et méthode peuvent employer les mêmes types de repères dans deux pièces ; leurs fiches, versions et sources restent distinctes. Ce tuple décrit l’identité, pas un schéma de stockage.',
        'Roles, missions, contracts and methods may use the same record types in two rooms; their records, versions and sources remain distinct. This tuple describes identity, not a storage schema.'), (
        ('La pièce w est résolue sur N ; une relation entre pièces demande un transfert ou un lien explicite.',),
        ('Room w is resolved on N; a cross-room relation requires an explicit transfer or link.',))),
    _formalism('conversation_thread', 'identity(thread) = (N, w, thread_id)', (
        'Identité locale proposée d’un fil. Une référence à ChatGPT est un attribut de provenance facultatif, pas un identifiant de Tao ni un canal d’accès aux données ou outils externes.',
        'Proposed local thread identity. A ChatGPT reference is optional provenance, not a Tao identifier or access channel for external data or tools.'), (
        ('Un détecteur de dérive ne change pas le fil seul : continuer, changer ou créer requiert un choix explicite.',
         'Les droits futurs sur une opération se vérifient à l’intersection de la pièce, du compte, du connecteur pertinent et de la tâche, au moment de l’effet.'),
        ('A drift detector does not switch threads alone: continuing, switching or creating needs an explicit choice.',
         'Future rights for an operation are checked at the intersection of room, account, relevant connector and task at effect time.')), 'proposed'),
    _formalism('contextual_self', 'M = (E, I, P, L, T)', (
        'Position locale proposée : espace E, intention I, préférences P, mémoire sélectionnée L et horizon T. Aucun fournisseur ou moi conscient n’en découle.',
        'A proposed local position: space E, intention I, preferences P, selected memory L and horizon T. No provider or conscious self follows from it.'), (
        ('Mémoire limitée aux sources autorisées ; préférences attribuées et révisables.',
         'Une intention n’est ni un fait ni une permission.'),
        ('Memory limited to authorized sources; preferences attributed and revisable.',
         'An intention is neither a fact nor a permission.')), 'proposed'),
    _formalism('coordination', '(plan, residuals) = Coord(proposals, constraints, G, B)', (
        'L’intendant proposé compare des contributions sous un mandat G et un budget B. Le refus et le désaccord conservé sont des résultats possibles.',
        'The proposed steward compares contributions under mandate G and budget B. Refusal and preserved disagreement are possible outcomes.'), (
        ('Aucun accès ni mandat créé par le coordinateur.',
         'Profondeur, nombre d’appels et durée bornés ; arrêt explicite.'),
        ('No access or mandate created by the coordinator.',
         'Bounded depth, call count and duration; explicit stopping.')), 'proposed'),
    _formalism('invocation', 'J = (E, S, F, A, G, B)', (
        'Essai proposé : espace E, sources S, fonction F, acteur A, mandat G, budget B. Les références et versions retenues doivent être traçables.',
        'A proposed attempt: space E, sources S, function F, actor A, mandate G, budget B. Selected references and versions must be traceable.'), (
        ('Résultat attendu et preuve définis ; préconditions vérifiées avant effet.',),
        ('Expected result and evidence defined; preconditions checked before effects.',)), 'proposed'),
    _formalism('capabilities', 'Op = actor ∩ adapter ∩ mandate ∩ space ∩ policy', (
        'Intersection d’opérations concrètes avec paramètres autorisés. Cette règle est un contrat de conception, pas un moteur global déjà livré.',
        'Intersection of concrete operations with permitted parameters. This is a design contract, not an already delivered global engine.'), (
        ('Une condition inconnue ne vaut pas accord ; mandat valide, non révoqué, quota disponible.',
         'Un autre mode ou un intendant supérieur ne peut agrandir l’intersection.'),
        ('An unknown condition is not approval; mandate valid, not revoked, quota available.',
         'Another mode or a higher steward cannot enlarge the intersection.')), 'proposed'),
    _formalism('budget', 'B_coord + Σ B_child ≤ B_mission', (
        'Inégalité composante par composante de réservations de ressources, incluant la coordination et tous les enfants. Les unités restent séparées.',
        'A componentwise inequality for resource reservations, including coordination and every child. Units remain separate.'), (
        ('Ne sommer que la même ressource, la même unité et le même périmètre.',
         'Plafonds finis déclarés ; coûts inconnus signalés ; aucune régression infinie.'),
        ('Only sum the same resource, unit and scope.',
         'Declared finite limits; unknown costs flagged; no infinite regress.')), 'math'),
    _formalism('integration', '(state_next, residuals) = Int(state, proposal, constraints)', (
        'Convention opérationnelle : intégrer transforme l’état et conserve les écarts pertinents. Ce n’est pas l’intégrale d’un texte ni une preuve de résolution.',
        'An operational convention: integration changes state and retains relevant gaps. It is neither the integral of a text nor proof of resolution.'), (
        ('Examen des résultats réels ; provenance et possibilités de retour préservées.',
         'Différences admissibles dans un modèle observé ne garantissent pas le futur.'),
        ('Review actual results; preserve provenance and recovery possibilities.',
         'Admissible differences in an observed model do not guarantee the future.'))),
)


RELATIONS = (
    ('has_history', 'system', 'story', 'possède une histoire décrite', 'has a described history'),
    ('contains_room', 'house', 'space', 'contient la pièce sans en confondre les mémoires', 'contains the room without conflating its memories'),
    ('scopes_sources', 'space', 'source', 'délimite le contexte des sources', 'scopes the source context'),
    ('addresses_room', 'address', 'space', 'sélectionne une pièce sans donner de droit', 'selects a room without granting access'),
    ('addresses_view', 'address', 'view', 'sélectionne sa présentation sans action', 'selects its presentation without action'),
    ('scopes_thread', 'space', 'conversation_thread', 'situe le fil local dans une seule pièce', 'situates a local thread in one room'),
    ('presents', 'view', 'task', 'peut présenter une tâche sans l’exécuter', 'can present a task without executing it'),
    ('makes_relevant', 'need', 'difference', 'qualifie la pertinence d’un écart', 'qualifies the relevance of a gap'),
    ('aims_at', 'task', 'objective', 'contribue à un objectif sans le garantir', 'contributes to an objective without guaranteeing it'),
    ('may_specialize', 'center', 'function', 'peut spécialiser des fonctions sous preuve', 'may specialize functions given evidence'),
    ('uses_mode', 'function', 'mode', 'peut être travaillée dans un mode', 'may be worked on in a mode'),
    ('situated_in', 'contextual_self', 'space', 'est situé dans un contexte autorisé', 'is situated in an authorized context'),
    ('routes_to', 'steward', 'space', 'suggère une pièce d’après ses seules métadonnées', 'suggests a room using its metadata only'),
    ('may_reorient_thread', 'steward', 'conversation_thread', 'pourrait proposer de continuer, changer ou créer un fil après un choix humain', 'could suggest continuing, switching or creating a thread after a human choice'),
    ('coordinates', 'steward', 'invocation', 'propose une coordination bornée des invocations', 'proposes bounded coordination of invocations'),
    ('uses_actor', 'invocation', 'actor', 'mobilise un moyen disponible', 'uses an available means'),
    ('bounded_by', 'invocation', 'mandate', 'reste bornée par un mandat', 'remains bounded by a mandate'),
    ('reserves', 'invocation', 'resource', 'doit réserver les ressources nécessaires', 'must reserve necessary resources'),
    ('supports', 'task', 'mission', 'peut contribuer à une mission métier', 'may contribute to a mission'),
    ('scopes_role', 'space', 'role', 'contient une fiche de rôle située', 'contains a situated role record'),
    ('scopes_mission', 'space', 'mission', 'contient une fiche de mission située', 'contains a situated mission record'),
    ('scopes_contract', 'space', 'contract', 'contient une fiche de contrat située', 'contains a situated contract record'),
    ('scopes_method', 'space', 'method', 'contient une méthode située', 'contains a situated method'),
    ('governs_role', 'contract', 'role', 'peut encadrer une responsabilité déclarée', 'may govern a declared responsibility'),
    ('governs_mission', 'contract', 'mission', 'peut encadrer une mission déclarée', 'may govern a declared mission'),
    ('describes_method', 'process', 'method', 'peut ordonner l’usage d’une méthode sans l’exécuter', 'may order use of a method without executing it'),
    ('may_automate', 'automation', 'method', 'peut réaliser une méthode après qualification et activation', 'may realize a method after qualification and activation'),
    ('registers_tool', 'space', 'tool', 'peut référencer un outil sans autoriser son appel', 'may reference a tool without authorizing a call'),
    ('exposes_tool', 'connector', 'tool', 'peut exposer un outil externe décrit et vérifié', 'may expose a described and checked external tool'),
    ('experiments_on', 'workshop', 'function', 'peut préparer une évolution de fonction', 'may prepare an evolution of a function'),
    ('transmits', 'heritage', 'function', 'peut transmettre une capacité sans ses permissions', 'may transmit a capability without its permissions'),
    ('attributes', 'provenance', 'source', 'référence une origine sans garantir sa vérité', 'references an origin without guaranteeing its truth'),
    ('examines', 'evidence', 'objective', 'aide à examiner la réalisation d’un objectif', 'helps assess achievement of an objective'),
    ('retains_residual', 'integration', 'buffer', 'conserve le résidu pertinent non intégré', 'retains the relevant unintegrated residual'),
)


INVARIANTS = (
    ('private_context', 'Un nom d’espace ou un sujet évoqué n’ouvre pas sa mémoire privée.',
     'A space name or mentioned topic does not open its private memory.'),
    ('address_not_authority', 'Route, pièce, vue, focus et attributs d’URL sont des choix de lecture ; aucun ne porte un mandat.',
     'Route, room, view, focus and URL attributes are reading choices; none carries a mandate.'),
    ('room_scoped_records', 'Rôles, missions, contrats et méthodes de deux pièces ne fusionnent pas par leur type ou leur titre.',
     'Roles, missions, contracts and methods in two rooms do not merge by type or title.'),
    ('tool_not_connector', 'Une fiche d’outil ou un nom de service ne prouve ni connecteur disponible ni appel approuvé.',
     'A tool record or service name proves neither an available connector nor an approved call.'),
    ('description_not_execution', 'Décrire un processus ou une méthode ne crée pas une automatisation active.',
     'Describing a process or method does not create an active automation.'),
    ('thread_not_authority', 'Une URL ChatGPT citée ou un identifiant de fil ne donne aucun droit ; dérive et changement de fil demandent un choix explicite.',
     'A cited ChatGPT URL or thread identifier grants no right; drift and thread changes require an explicit choice.'),
    ('no_role_authority', 'Centre, moi, rôle, mode, modèle et intendant ne sont pas des permissions.',
     'Centre, self, role, mode, model and steward are not permissions.'),
    ('bounded_coordination', 'La coordination et ses enfants partagent des plafonds finis et une condition d’arrêt.',
     'Coordination and its children share finite limits and a stopping condition.'),
    ('no_agent_per_object', 'Créer un espace, une vue ou une tâche ne démarre pas une IA permanente.',
     'Creating a space, view or task does not start a permanent AI.'),
    ('attribution_not_truth', 'La provenance et la revue humaine ne valent pas preuve indépendante.',
     'Provenance and human review are not independent proof.'),
    ('visible_residual', 'Un tampon Tao rend un résidu visible ; il ne doit pas masquer une contradiction.',
     'A Tao buffer makes a residual visible; it must not conceal a contradiction.'),
    ('no_universal_score', 'Comparer résultats, erreurs, coûts et charge humaine séparément, sans score universel d’intelligence.',
     'Compare results, errors, costs and human workload separately, without a universal intelligence score.'),
    ('empty_is_unknown', 'Une donnée absente reste inconnue ; aucun chiffre ou récit personnel n’est ajouté par ce catalogue.',
     'Missing data remains unknown; this catalogue adds no number or personal story.'),
    ('proposals_not_engine', 'Les moi et intendants sont des modèles proposés ; aucun ordonnanceur récursif autonome n’est livré ici.',
     'Selves and stewards are proposed models; no autonomous recursive scheduler is delivered here.'),
    ('no_fixed_centres', 'Le nombre de centres dépend d’un bénéfice démontré ; cinq centres séparés ne sont pas imposés.',
     'The number of centres depends on demonstrated benefit; five separate centres are not imposed.'),
)


def catalog(locale='fr'):
    """Return detached, localized metadata without consulting private state."""
    if not isinstance(locale, str):
        raise ValueError('Langue disponible : fr ou en.')
    locale = locale.lower().split('-', 1)[0].split('_', 1)[0]
    if locale not in LOCALES:
        raise ValueError('Langue disponible : fr ou en.')
    terms = []
    for row in TERMS:
        terms.append({key: copy.deepcopy(row[key]) for key in
                      ('id', 'key', 'epistemic_status', 'implementation', 'formalism_ids')})
        terms[-1].update(label=row['labels'][locale], definition=row['definitions'][locale],
                         aliases=list(row['aliases'][locale]))
    formalisms = [{key: copy.deepcopy(row[key]) for key in ('id', 'expression', 'epistemic_status')}
                  for row in FORMALISMS]
    for out, row in zip(formalisms, FORMALISMS):
        out.update(explanation=row['explanations'][locale], assumptions=list(row['assumptions'][locale]))
    index = LOCALES.index(locale)
    return {'schema': SCHEMA, 'version': VERSION, 'status': 'descriptive_not_executable',
            'locale': locale, 'available_locales': list(LOCALES),
            'canon': {'version': '4.3.0', 'modified': False, 'reference': 'docs/theory.json'},
            'terms': terms, 'formalisms': formalisms,
            'relations': [{'id': 'tao.logic.relation.' + row[0], 'source': PREFIX + row[1],
                           'target': PREFIX + row[2], 'description': row[3 + index]} for row in RELATIONS],
            'invariants': [{'id': 'tao.logic.invariant.' + row[0], 'text': row[1 + index]} for row in INVARIANTS],
            'execution_enabled': False}
