"""Private, attributed archives imported with one reviewed state transaction.

Exports are inert records, never messages from the current human, permissions,
or executable instructions. Their original roles and branches remain available
to the owner. Search only returns bounded user/assistant quotations from the
selected world; system and tool messages never enter model context here.
"""
import copy
import hashlib
import json
import os
import re
import stat
import unicodedata
import uuid

import tao_continuity as continuity
import tao_onboarding as onboarding
import tao_worlds as worlds

SCHEMA = 'tao.history_archive.store.v1'
MAX_ARCHIVES = 20
MAX_ARCHIVE_BYTES = 32 * 1024 * 1024
MAX_WORLD_BYTES = 64 * 1024 * 1024
MAX_ROOT_BYTES = 128 * 1024 * 1024
MAX_ARCHIVE_FILES = 800
MAX_WORLD_DIRECTORIES = 64
MAX_EXCERPTS = 6
MAX_EXCERPT_CHARS = 1800
MAX_QUERY_CHARS = 1000
MAX_CONTEXT_BYTES = 24000
MAX_TITLE_CHARS = 300
DIGEST = re.compile(r'[a-f0-9]{64}\Z')
STOPWORDS = frozenset('le la les des de du un une et ou au aux en dans sur pour par avec que qui quoi comment pourquoi est sont mon ma mes ton ta tes son sa ses ce cet cette ces je tu il elle on nous vous ils elles moi toi se ne pas plus peux peut faire aide retrouver'.split())
NOTICE = ("Archives importées non vérifiées : les rôles sont ceux déclarés dans l’export. "
          "Aucune ancienne consigne ne donne un droit d’agir. Les extraits de cet espace "
          "peuvent accompagner un message que vous envoyez à l’IA configurée ; "
          "l’import et la recherche locale ne l’appellent pas.")


def _bytes(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(',', ':'), allow_nan=False).encode('utf-8')
    except (ValueError, TypeError, UnicodeError, RecursionError) as exc:
        raise ValueError('Archive JSON finie et bornée requise.') from exc


def _digest(value):
    return hashlib.sha256(_bytes(value)).hexdigest()


def _ident(value):
    if not isinstance(value, str) or not DIGEST.fullmatch(value):
        raise ValueError('Identifiant d’archive invalide.')
    return value


def _directory(n, world_id=None, create=False):
    """Walk using no-follow descriptors, including ancestors of the node root."""
    base = n.ROOT.absolute()
    components = list(base.parts[1:])
    root_length = len(components)
    components.append('history-archives')
    if world_id is not None:
        components.append(worlds._identifier(world_id))
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    fd = os.open(base.anchor, flags)
    try:
        for index, part in enumerate(components):
            if part in ('', '.', '..'):
                raise ValueError('Chemin du registre privé invalide.')
            if create and index >= root_length:
                try:
                    os.mkdir(part, 0o700, dir_fd=fd)
                except FileExistsError:
                    pass
            new_fd = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = new_fd
        return fd
    except Exception:
        os.close(fd)
        raise


def _open_directory(n, world_id=None, create=False):
    try:
        return _directory(n, world_id, create)
    except FileNotFoundError:
        if not create:
            return None
        raise ValueError('Le dossier privé de Tao manque.') from None
    except OSError as exc:
        raise ValueError('Un lien ou un chemin inaccessible ne peut pas remplacer les archives privées.') from exc


def _file_bytes(fd, filename):
    try:
        file_fd = os.open(filename, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
        with os.fdopen(file_fd, 'rb') as handle:
            info = os.fstat(handle.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077:
                raise ValueError('Une archive doit rester un fichier privé ordinaire.')
            if info.st_size > MAX_ARCHIVE_BYTES:
                raise ValueError('Archive au-delà de la capacité de lecture.')
            result = handle.read(MAX_ARCHIVE_BYTES + 1)
            if len(result) > MAX_ARCHIVE_BYTES:
                raise ValueError('Archive au-delà de la capacité de lecture.')
            return result
    except OSError as exc:
        raise ValueError('Archive absente, inaccessible ou remplacée par un lien.') from exc


def _write(n, world_id, ident, data):
    """Install immutably. Existing bytes must match; never overwrite a record."""
    fd = _open_directory(n, world_id, create=True)
    filename = _ident(ident) + '.json'
    temporary = '.pending-' + uuid.uuid4().hex
    try:
        try:
            info = os.stat(filename, dir_fd=fd, follow_symlinks=False)
        except FileNotFoundError:
            info = None
        if info is not None:
            if _file_bytes(fd, filename) != data:
                raise ValueError('Une archive différente occupe déjà cette empreinte ; aucun écrasement.')
            return
        file_fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                          0o600, dir_fd=fd)
        try:
            with os.fdopen(file_fd, 'wb') as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            try:
                os.link(temporary, filename, src_dir_fd=fd, dst_dir_fd=fd, follow_symlinks=False)
            except FileExistsError:
                if _file_bytes(fd, filename) != data:
                    raise ValueError('Une archive différente existe ; aucun écrasement.') from None
            os.fsync(fd)
        finally:
            os.unlink(temporary, dir_fd=fd)
    except OSError as exc:
        raise ValueError('L’archive privée n’a pas pu être conservée ; état inchangé.') from exc
    finally:
        os.close(fd)


def _inventory(n):
    """Bound retained data, including harmless orphan files from interrupted imports."""
    root_fd = _open_directory(n)
    if root_fd is None:
        return {}, 0
    files, total, seen = {}, 0, 0
    try:
        names = os.listdir(root_fd)
        if len(names) > MAX_WORLD_DIRECTORIES:
            raise ValueError('Trop de dossiers d’archives ; examiner les imports interrompus.')
        for name in names:
            worlds._identifier(name)
            try:
                fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=root_fd)
            except OSError as exc:
                raise ValueError('Dossier d’archives non ordinaire ou lien refusé.') from exc
            try:
                rows = os.listdir(fd)
                seen += len(rows)
                if seen > MAX_ARCHIVE_FILES:
                    raise ValueError('Trop de fichiers d’archives ; examiner les imports interrompus.')
                for filename in rows:
                    info = os.stat(filename, dir_fd=fd, follow_symlinks=False)
                    if not stat.S_ISREG(info.st_mode):
                        raise ValueError('Les archives ne peuvent contenir ni liens ni dossiers imbriqués.')
                    total += info.st_size
                    files[(name, filename)] = info.st_size
                    if total > MAX_ROOT_BYTES:
                        raise ValueError('Capacité totale des archives atteinte ; aucune suppression automatique.')
            finally:
                os.close(fd)
        return files, total
    finally:
        os.close(root_fd)


def _descriptors(view):
    memory = view.get('continuity', {})
    if not isinstance(memory, dict):
        raise ValueError('Mémoire privée invalide.')
    rows = memory.get('external_archives', [])
    if not isinstance(rows, list) or len(rows) > MAX_ARCHIVES:
        raise ValueError('Registre d’archives privées invalide ou plein.')
    seen = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError('Descripteur d’archive invalide.')
        ident = _ident(row.get('id'))
        if ident in seen or row.get('digest') != ident or row.get('world_id') != worlds.current():
            raise ValueError('Archive attribuée au mauvais espace ou dupliquée.')
        seen.add(ident)
        for field in ('messages', 'conversations', 'bytes'):
            if type(row.get(field)) is not int or row[field] < 0:
                raise ValueError('Comptage d’archive invalide.')
        _ident(row.get('archive_digest'))
    return copy.deepcopy(rows)


def _read(n, descriptor):
    world_id = worlds.current()
    fd = _open_directory(n, world_id)
    if fd is None:
        raise ValueError('Le contenu de cette archive manque ; son pointeur a été préservé.')
    try:
        raw = _file_bytes(fd, _ident(descriptor['id']) + '.json')
    finally:
        os.close(fd)
    if len(raw) != descriptor['bytes'] or hashlib.sha256(raw).hexdigest() != descriptor['digest']:
        raise ValueError('L’empreinte de l’archive ne correspond plus ; aucun contenu utilisé.')
    try:
        value = json.loads(raw)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ValueError('Archive JSON illisible.') from exc
    if (not isinstance(value, dict) or value.get('schema') != SCHEMA or
            value.get('world_id') != world_id or value.get('archive_digest') != descriptor['archive_digest'] or
            not isinstance(value.get('conversations'), list)):
        raise ValueError('L’archive ne correspond pas à cet espace.')
    if (len(value['conversations']) != descriptor['conversations'] or
            sum(len(row.get('messages', [])) for row in value['conversations']) != descriptor['messages']):
        raise ValueError('Comptage de l’archive incohérent.')
    return value


def _proposal(archive_input, assignments, n=None):
    # Delayed import also keeps older installations able to start during an upgrade.
    import tao_history_archive as adapter
    archive = adapter.parse(archive_input)
    proposal = adapter.propose(archive, assignments=assignments)
    if n is not None and assignments is None:
        packages = onboarding._history(n.load_raw_state())['packages']
        if proposal['document']['id'] not in packages:
            # Expanded categories must never turn an exact prior import into a
            # second copy. Retain the old lexical proposal only when a receipt
            # proves that exact legacy document was already imported.
            legacy = adapter.propose(archive, _legacy=True)
            prior = packages.get(legacy['document']['id'])
            if isinstance(prior, dict) and prior.get('document_digest') == onboarding._digest(legacy['document']):
                proposal = legacy
    return proposal


def _parts(proposal, space_map):
    archive = proposal['archive']
    groups = {}
    by_id = {row['id']: row for row in archive['conversations']}
    for assignment in proposal['assignments']:
        key = assignment['document_space_key']
        if key not in space_map or assignment['conversation_id'] not in by_id:
            raise ValueError('Répartition des conversations incomplète.')
        world_id = space_map[key]
        groups.setdefault(world_id, []).append(copy.deepcopy(by_id[assignment['conversation_id']]))
    output = []
    for world_id, conversations in groups.items():
        value = {'schema': SCHEMA, 'world_id': world_id, 'archive_digest': archive['digest'],
                 'source': copy.deepcopy(archive['source']), 'authority': 'unverified_import',
                 'context_only': True, 'conversations': conversations}
        data = _bytes(value)
        if len(data) > MAX_ARCHIVE_BYTES:
            raise ValueError('Une archive dépasse la capacité privée ; sélectionner moins de conversations.')
        ident = hashlib.sha256(data).hexdigest()
        descriptor = {'id': ident, 'digest': ident, 'world_id': world_id,
                      'archive_digest': archive['digest'], 'source': copy.deepcopy(archive['source']),
                      'conversations': len(conversations),
                      'messages': sum(len(row['messages']) for row in conversations),
                      'bytes': len(data), 'authority': 'unverified_import', 'context_only': True}
        output.append((world_id, descriptor, data))
    return output


def _capacity(n, raw, parts):
    files, total = _inventory(n)
    for world_id, descriptor, data in parts:
        destination = raw if world_id == worlds.MAIN else raw.get('worlds', {}).get('spaces', {}).get(world_id, {})
        with worlds.using(world_id):
            previous = _descriptors(destination)
        if descriptor['id'] not in {row['id'] for row in previous} and len(previous) >= MAX_ARCHIVES:
            raise ValueError('Vingt archives maximum par espace ; aucune archive supprimée.')
        old_bytes = files.get((world_id, descriptor['id'] + '.json'), 0)
        added = len(data) - old_bytes
        total += max(0, added)
        world_bytes = sum(size for (ident, filename), size in files.items() if ident == world_id) + max(0, added)
        if total > MAX_ROOT_BYTES or world_bytes > MAX_WORLD_BYTES:
            raise ValueError('Capacité des archives atteinte ; aucune donnée supprimée.')


def _review(plan, proposal):
    assignments = [{'conversation_id': row['conversation_id'], 'space_key': row['space_key']}
                   for row in proposal['assignments']]
    return _digest({'review_digest': plan['review_digest'], 'archive': proposal['archive'],
                    'assignments': assignments})


def _targets(n, proposal, targets):
    if targets is not None:
        return targets
    raw = n.load_raw_state()
    # A repeated exact import must keep its recorded destinations, even if a
    # template was subsequently created or renamed.
    if proposal['document']['id'] in onboarding._history(raw)['packages']:
        return None
    semantics = {'work': 'work', 'computing': 'tools', 'learning': 'learning',
                 'creation': 'projects', 'personal': 'personal', 'money': 'money',
                 'relationships': 'relationships'}
    keys = {row['document_space_key']: semantics[row['space_key']]
            for row in proposal['assignments'] if row['space_key'] in semantics}
    selected = onboarding.suggested_targets(raw, keys)
    if selected:
        # This wrapper contains only structural export metadata, never child
        # quotes. Preserve it in main instead of creating a redundant folder.
        selected[proposal['document']['spaces'][0]['key']] = worlds.MAIN
    return selected


def preview(n, archive_input, assignments=None, targets=None):
    with n.LOCK:
        proposal = _proposal(archive_input, assignments, n=n)
        plan = onboarding.preview(n, proposal['document'], targets=_targets(n, proposal, targets))
        parts = _parts(proposal, {row['key']: row['id'] for row in plan['spaces']})
        _capacity(n, n.load_raw_state(), parts)
        result = copy.deepcopy(plan)
        result['review_digest'] = _review(plan, proposal)
        result.update(archive={'digest': proposal['archive']['digest'],
                               'source': copy.deepcopy(proposal['archive']['source']),
                               'counts': copy.deepcopy(proposal.get('counts', proposal['archive'].get('counts', {})))},
                      assignments=copy.deepcopy(proposal['assignments']),
                      categories=copy.deepcopy(proposal.get('categories', [])),
                      warnings=copy.deepcopy(proposal.get('warnings', [])),
                      archive_limits=_limits(), archive_notice=NOTICE)
        return result


def destinations(n, archive_input, assignments=None):
    with n.LOCK:
        proposal = _proposal(archive_input, assignments, n=n)
        return onboarding.destinations(n, proposal['document'], targets=_targets(n, proposal, None))


def apply(n, archive_input, review_digest, confirmed=False, assignments=None, targets=None):
    if confirmed is not True:
        raise ValueError('Confirmer l’import et la conservation des archives prévisualisées.')
    _ident(review_digest)
    with n.LOCK:
        proposal = _proposal(archive_input, assignments, n=n)
        plan = onboarding.preview(n, proposal['document'], targets=_targets(n, proposal, targets))
        if not plan['already_imported'] and _review(plan, proposal) != review_digest:
            raise ValueError('L’archive, sa répartition ou les espaces ont changé ; relancer la prévisualisation.')
        new_world_ids = {row['id'] for row in plan['spaces'] if not row['existing']}

        def attach(node, raw, space_map):
            import tao_dialogue as dialogue
            parts = _parts(proposal, space_map)
            _capacity(node, raw, parts)
            for world_id, descriptor, data in parts:
                _write(node, world_id, descriptor['id'], data)
            for world_id, descriptor, data in parts:
                destination = raw if world_id == worlds.MAIN else raw['worlds']['spaces'][world_id]
                memory = continuity.ensure(destination)
                memory.setdefault('external_archives', []).append(descriptor)
                # The reviewed import authorizes future attributed recall in
                # these new spaces. The existing memory checkbox can turn it
                # off again; no live message or existing preference is changed.
                if world_id in new_world_ids:
                    discussion = dialogue.ensure(destination)
                    if discussion.get('include_archives') is not True:
                        discussion['include_archives'] = True
                        discussion['revision'] += 1
                        discussion['context_version'] += 1

        result = onboarding.apply(n, proposal['document'], plan['review_digest'], confirmed=True,
                                  _attach=attach, targets=plan['targets'])
        result['archive_digest'] = proposal['archive']['digest']
        return result


def _limits():
    return {'archives_per_space': MAX_ARCHIVES, 'archive_bytes': MAX_ARCHIVE_BYTES,
            'space_bytes': MAX_WORLD_BYTES, 'total_bytes': MAX_ROOT_BYTES,
            'excerpts': MAX_EXCERPTS, 'excerpt_chars': MAX_EXCERPT_CHARS,
            'context_bytes': MAX_CONTEXT_BYTES}


def list_archives(n):
    with n.LOCK:
        rows = _descriptors(n.load_state())
        for row in rows:
            _read(n, row)  # Never advertise a corrupt archive as readable.
        return {'world_id': worlds.current(), 'archives': rows, 'limits': _limits(), 'notice': NOTICE}


def read_archive(n, ident):
    ident = _ident(ident)
    with n.LOCK:
        rows = _descriptors(n.load_state())
        descriptor = next((row for row in rows if row['id'] == ident), None)
        if descriptor is None:
            raise ValueError('Cette archive n’appartient pas à l’espace ouvert.')
        value = _read(n, descriptor)
        return dict(value, id=ident, notice=NOTICE)


def _normalized(value):
    return ''.join(char for char in unicodedata.normalize('NFKD', value.casefold())
                   if not unicodedata.combining(char))


def _tokens(value):
    return [token for token in re.findall(r'[^\W_]+', _normalized(value), re.UNICODE)
            if len(token) >= 2 and token not in STOPWORDS]


def search(n, query):
    if not isinstance(query, str) or len(query) > MAX_QUERY_CHARS:
        raise ValueError('Rechercher avec un texte de 1 000 caractères maximum.')
    terms = list(dict.fromkeys(_tokens(query)))[:32]
    with n.LOCK:
        rows = _descriptors(n.load_state())
        candidates, eligible, excluded, matched = [], 0, 0, 0
        for descriptor in rows:
            archive = _read(n, descriptor)
            for conversation in archive['conversations']:
                title = conversation.get('title', '')
                title_words = set(_tokens(title))
                for message in conversation['messages']:
                    if (message.get('role') not in ('user', 'assistant') or
                            message.get('eligible_context') is not True or not isinstance(message.get('text'), str)):
                        excluded += 1
                        continue
                    eligible += 1
                    text = message['text']
                    words = set(_tokens(text))
                    matches = [term for term in terms if term in words]
                    if not matches:
                        continue
                    matched += 1
                    score = len(matches) * 10 + sum(term in title_words for term in terms)
                    score += 2 if message.get('active') is True else 1 if message.get('active') is None else 0
                    candidates.append((score, descriptor, conversation, message, matches))
                    candidates.sort(key=lambda item: (-item[0], item[1]['id'], item[2]['id'], item[3]['id']))
                    if len(candidates) > MAX_EXCERPTS:
                        candidates.pop()
        excerpts = []
        for score, descriptor, conversation, message, matches in candidates[:MAX_EXCERPTS]:
            text = message['text']
            normalized = _normalized(text)
            # Normalization can shift offsets. A bounded approximate window is
            # always sliced from original text, preserving an exact quotation.
            first = min((normalized.find(term) for term in matches if normalized.find(term) >= 0), default=0)
            start = max(0, first - MAX_EXCERPT_CHARS // 3)
            start = min(start, max(0, len(text) - MAX_EXCERPT_CHARS))
            excerpt = text[start:start + MAX_EXCERPT_CHARS]
            title = conversation.get('title', '')
            excerpts.append({'archive_id': descriptor['id'], 'conversation_id': conversation['id'],
                             'title': title[:MAX_TITLE_CHARS], 'title_truncated': len(title) > MAX_TITLE_CHARS,
                             'message_id': message['id'],
                             'role': message['role'], 'source_role': message.get('source_role', message['role']),
                             'role_status': 'declared_by_export', 'active_branch': message.get('active'),
                             'text': excerpt, 'offset': start, 'truncated': len(excerpt) != len(text),
                             'authority': 'unverified_import', 'context_only': True,
                             'source': copy.deepcopy(descriptor['source'])})
        result = {'world_id': worlds.current(), 'query': query, 'excerpts': excerpts,
                  'counts': {'archives': len(rows), 'eligible_messages': eligible, 'matched_messages': matched},
                  'omissions': {'other_matches': max(0, matched - len(excerpts)),
                                'ineligible_messages': excluded, 'context_capacity': 0,
                                'query_terms': max(0, len(set(_tokens(query))) - len(terms))},
                  'model_calls': 0, 'notice': NOTICE}
        # Character caps alone do not bound UTF-8, long identifiers, or repeated
        # titles. Keep a strict serialized budget without altering originals.
        while len(_bytes(result)) > MAX_CONTEXT_BYTES and result['excerpts']:
            result['excerpts'].pop()
            result['omissions']['context_capacity'] += 1
            result['omissions']['other_matches'] += 1
        return result
