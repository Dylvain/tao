"""Bounded deterministic recipes, qualified locally and activated by their owner.

No recipe can call a model, command, network or filesystem. Inputs are values
provided by the caller; even paths and code are literal data. The owner-only
functions (activate, retire, report) must remain behind the owner HTTP/CLI
boundary and must never be exported as external bridge tools.

A qualification proves only its supplied examples. A completed computation is
not a successful real-world outcome, saved model call, or energy measurement.
Private sidecars deliberately leave the node state schema unchanged.
"""
import copy
import csv
import hashlib
import io
import json
import math
import re
import time
import uuid

import tao_worlds as worlds
from tao_work import check_revision

SCHEMA = 'tao.reuse.v1'
MAX_RECIPES = 40
MAX_RECEIPTS = 200
MAX_REPORTS = 400
MAX_STORE_BYTES = 4 * 1024 * 1024
MAX_IO_BYTES = 65536
MAX_RECIPE_BYTES = 131072
MAX_ROWS = 500
MAX_COLUMNS = 32
MAX_CASES = 12
OPERATIONS = ('csv.audit', 'records.audit', 'text.template')
ORIGINS = ('human', 'ai', 'external')
NAME = re.compile(r'[A-Za-z_][A-Za-z0-9_]{0,63}\Z')
IDENT = re.compile(r'[a-f0-9]{12}\Z')
PLACEHOLDER = re.compile(r'\{\{([A-Za-z_][A-Za-z0-9_]{0,63})\}\}')


class DomainError(ValueError):
    """The recipe does not accept this input. No automatic escalation occurs."""
    code = 'domain'


def _json(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(',', ':'), allow_nan=False).encode('utf-8')
    except (TypeError, ValueError, OverflowError, RecursionError, UnicodeError) as exc:
        raise ValueError('Données JSON finies et bornées requises.') from exc


def _digest(value):
    return hashlib.sha256(_json(value)).hexdigest()


def _bounded(value, limit, label):
    if len(_json(value)) > limit:
        raise ValueError(label + ' : capacité dépassée ; aucune donnée supprimée.')


def _keys(value, required, optional=(), error=ValueError):
    if not isinstance(value, dict) or not set(required) <= set(value) or set(value) - set(required) - set(optional):
        raise error('Champs manquants ou inconnus : ' + ', '.join(required))


def _text(value, limit, label, required=True):
    if not isinstance(value, str) or len(value) > limit or (required and not value.strip()):
        raise ValueError(label + ' : texte requis, ' + str(limit) + ' caractères maximum.')
    # Preserve literal templates, CSV and explanatory text exactly.
    _json(value)
    return value


def _int(value, low, high, label):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(label + ' : entier hors limites.')
    return value


def _names(value, label, allow_empty=False):
    if (not isinstance(value, list) or len(value) > MAX_COLUMNS or
            (not value and not allow_empty) or
            any(not isinstance(x, str) or not NAME.fullmatch(x) for x in value) or
            len(set(value)) != len(value)):
        raise ValueError(label + ' : noms simples distincts requis (32 maximum).')
    return value


def _origin(value):
    if not isinstance(value, str) or value not in ORIGINS:
        raise ValueError('Origine inconnue.')
    return value


def _config(operation, config):
    if operation not in OPERATIONS:
        raise ValueError('Opération déterministe inconnue.')
    if operation == 'text.template':
        _keys(config, ('template', 'variables', 'max_value_chars'))
        source = _text(config['template'], 12000, 'Modèle')
        names = _names(config['variables'], 'Variables')
        _int(config['max_value_chars'], 1, 4000, 'Longueur des valeurs')
        found = set(PLACEHOLDER.findall(source))
        residue = PLACEHOLDER.sub('', source)
        if found != set(names) or '{{' in residue or '}}' in residue:
            raise ValueError('Utiliser uniquement des substitutions littérales {{nom}} déclarées.')
    else:
        keys = ('columns', 'required', 'unique', 'max_rows')
        _keys(config, keys + (('delimiter',) if operation == 'csv.audit' else ()))
        columns = _names(config['columns'], 'Colonnes')
        for key in ('required', 'unique'):
            names = _names(config[key], key, allow_empty=True)
            if not set(names) <= set(columns):
                raise ValueError('Les contrôles doivent viser les colonnes déclarées.')
        if not config['required'] and not config['unique']:
            raise ValueError('Déclarer au moins un contrôle requis ou unique.')
        _int(config['max_rows'], 1, MAX_ROWS, 'Nombre de lignes')
        if operation == 'csv.audit' and config['delimiter'] not in (',', ';', '\t', '|'):
            raise ValueError('Séparateur CSV non pris en charge.')
    return config


def _definition(payload):
    _keys(payload, ('title', 'description', 'operation', 'config', 'cases'), ('provenance', 'replaces_id', 'replaces_revision'))
    _bounded(payload, MAX_RECIPE_BYTES, 'Méthode')
    result = {key: copy.deepcopy(payload[key]) for key in ('title', 'description', 'operation', 'config', 'cases')}
    _text(result['title'], 160, 'Titre')
    _text(result['description'], 2000, 'Domaine et limites')
    if not isinstance(result['operation'], str):
        raise ValueError('Opération textuelle requise.')
    _config(result['operation'], result['config'])
    result['provenance'] = _text(payload.get('provenance', ''), 1000, 'Provenance', required=False)
    cases = result['cases']
    if not isinstance(cases, list) or not 3 <= len(cases) <= MAX_CASES:
        raise ValueError('Trois à douze cas requis : deux cas positifs et un contre-exemple.')
    labels = set()
    for case in cases:
        _keys(case, ('label', 'input'), ('expected', 'error'))
        label = _text(case['label'], 160, 'Nom du cas')
        if label in labels or ('expected' in case) == ('error' in case):
            raise ValueError('Cas distincts avec une sortie attendue ou une erreur attendue.')
        labels.add(label)
        if 'error' in case and case['error'] != 'domain':
            raise ValueError('Seul le refus de domaine est une erreur attendue.')
        _bounded(case['input'], MAX_IO_BYTES, 'Entrée du cas')
        if 'expected' in case:
            _bounded(case['expected'], MAX_IO_BYTES, 'Sortie attendue')
    return result


def _path(n):
    n.load_state()  # Validate existence and selected world before touching a sidecar.
    directory = n.ROOT / 'reuse'
    path = directory / (worlds.current() + '.json')
    if directory.is_symlink() or path.is_symlink():
        raise ValueError('Un lien symbolique ne peut pas remplacer le registre privé.')
    return path


def _new_store():
    return {'schema': SCHEMA, 'world_id': worlds.current(), 'revision': 0, 'recipes': []}


def _validate_row(row):
    _keys(row, ('id', 'lineage_id', 'version', 'revision', 'definition', 'digest', 'status',
                'origin', 'created_at', 'qualification', 'activation', 'receipts', 'reports'))
    if any(not isinstance(row[key], str) or not IDENT.fullmatch(row[key]) for key in ('id', 'lineage_id')):
        raise ValueError('Identifiant de méthode invalide.')
    _int(row['version'], 1, MAX_RECIPES, 'Version')
    _int(row['revision'], 0, 1000000, 'Révision')
    definition = _definition(row['definition'])
    if definition != row['definition'] or _digest(definition) != row['digest']:
        raise ValueError('La méthode a changé hors de son parcours de revue.')
    _origin(row['origin'])
    if row['status'] not in ('candidate', 'qualified', 'active', 'retired'):
        raise ValueError('Statut de méthode invalide.')
    if not isinstance(row['receipts'], list) or not isinstance(row['reports'], list):
        raise ValueError('Reçus de méthode invalides.')
    if row['status'] in ('qualified', 'active'):
        q = row['qualification']
        if not isinstance(q, dict) or q.get('ok') is not True or q.get('recipe_digest') != row['digest']:
            raise ValueError('Qualification absente ou périmée.')
        review = {k: v for k, v in q.items() if k != 'review_digest'}
        if q.get('review_digest') != _digest(review):
            raise ValueError('Revue de qualification altérée.')
    if row['status'] == 'active':
        active = row['activation']
        if (not isinstance(active, dict) or active.get('authority') != 'owner' or
                active.get('recipe_digest') != row['digest'] or
                active.get('review_digest') != row['qualification']['review_digest']):
            raise ValueError('Activation absente ou périmée.')


def _load(n):
    path = _path(n)
    if not path.exists():
        return _new_store()
    if not path.is_file() or path.stat().st_size > MAX_STORE_BYTES:
        raise ValueError('Registre privé illisible ou au-delà de sa capacité ; fichier conservé.')
    try:
        store = json.loads(path.read_text(encoding='utf-8'))
    except (ValueError, OSError, UnicodeError, RecursionError) as exc:
        raise ValueError('Registre privé illisible ; fichier conservé.') from exc
    _keys(store, ('schema', 'world_id', 'revision', 'recipes', '_integrity'))
    checksum = store.pop('_integrity')
    if checksum != _digest(store):
        raise ValueError('Intégrité du registre privé invalide ; fichier conservé.')
    if store['schema'] != SCHEMA or store['world_id'] != worlds.current():
        raise ValueError('Registre appartenant à un autre espace ou format.')
    _int(store['revision'], 0, 1000000, 'Révision du registre')
    if not isinstance(store['recipes'], list) or len(store['recipes']) > MAX_RECIPES:
        raise ValueError('Capacité de méthodes dépassée.')
    ids = set()
    for row in store['recipes']:
        _validate_row(row)
        if row['id'] in ids:
            raise ValueError('Méthode dupliquée.')
        ids.add(row['id'])
    if sum(len(row['receipts']) for row in store['recipes']) > MAX_RECEIPTS or sum(len(row['reports']) for row in store['recipes']) > MAX_REPORTS:
        raise ValueError('Capacité de reçus ou retours dépassée.')
    return store


def _save(n, store):
    store['revision'] += 1
    result = copy.deepcopy(store)
    result['_integrity'] = _digest(store)
    # atomic_json writes indented JSON; bound exactly that representation.
    if len(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')) > MAX_STORE_BYTES:
        raise ValueError('Capacité du registre atteinte ; aucune trace supprimée. Exporter et revoir la rétention.')
    n.atomic_json(_path(n), result)


def _row(store, ident):
    if not isinstance(ident, str) or not IDENT.fullmatch(ident):
        raise ValueError('Identifiant de méthode invalide.')
    result = next((row for row in store['recipes'] if row['id'] == ident), None)
    if result is None:
        raise ValueError('Méthode inconnue dans cet espace.')
    return result


def _records(operation, config, inputs):
    if operation == 'csv.audit':
        _keys(inputs, ('csv',), error=DomainError)
        if not isinstance(inputs['csv'], str) or '\x00' in inputs['csv']:
            raise DomainError('CSV textuel sans octet nul requis.')
        try:
            reader = csv.reader(io.StringIO(inputs['csv'], newline=''), delimiter=config['delimiter'], strict=True)
            header = next(reader, [])
            if len(header) != len(set(header)) or set(header) != set(config['columns']):
                raise DomainError('Les en-têtes CSV doivent correspondre exactement aux colonnes déclarées.')
            result = []
            for cells in reader:
                if len(cells) != len(header) or len(result) >= config['max_rows']:
                    raise DomainError('Nombre de cellules ou de lignes hors du domaine déclaré.')
                result.append(dict(zip(header, cells)))
        except csv.Error as exc:
            raise DomainError('CSV mal formé.') from exc
    else:
        _keys(inputs, ('records',), error=DomainError)
        result = inputs['records']
        if not isinstance(result, list) or len(result) > config['max_rows']:
            raise DomainError('Liste de lignes au-delà du domaine déclaré.')
        for row in result:
            if not isinstance(row, dict) or set(row) - set(config['columns']):
                raise DomainError('Une ligne contient un champ inconnu.')
            for value in row.values():
                if value is not None and type(value) not in (str, int, float, bool):
                    raise DomainError('Cellules scalaires uniquement.')
                if isinstance(value, str) and len(value) > 12000:
                    raise DomainError('Cellule trop longue.')
                if type(value) is int and value.bit_length() > 128:
                    raise DomainError('Entier hors domaine.')
                if type(value) is float and not math.isfinite(value):
                    raise DomainError('Valeur numérique non finie.')
    return result


def _execute(definition, inputs):
    try:
        _bounded(inputs, MAX_IO_BYTES, 'Entrée')
    except ValueError as exc:
        raise DomainError(str(exc)) from exc
    config = definition['config']
    operation = definition['operation']
    if operation == 'text.template':
        _keys(inputs, ('values',), error=DomainError)
        values = inputs['values']
        if not isinstance(values, dict) or set(values) != set(config['variables']):
            raise DomainError('Les variables doivent correspondre exactement au modèle.')
        for value in values.values():
            if not isinstance(value, str) or len(value) > config['max_value_chars']:
                raise DomainError('Valeur textuelle hors du domaine déclaré.')
        # One pass: substituted text is never interpreted again, including braces.
        result = {'text': PLACEHOLDER.sub(lambda match: values[match.group(1)], config['template'])}
        fingerprint = _digest(inputs)
    else:
        records = _records(operation, config, inputs)
        issues = []
        seen = {column: {} for column in config['unique']}
        for number, row in enumerate(records, 1):
            for column in config['columns']:
                value = row.get(column)
                blank = value is None or (isinstance(value, str) and not value.strip())
                if blank and column in config['required']:
                    issues.append({'kind': 'missing', 'row': number, 'column': column})
                if not blank and column in seen:
                    key = _json(value)
                    if key in seen[column]:
                        issues.append({'kind': 'duplicate', 'row': number, 'column': column,
                                       'first_row': seen[column][key]})
                    else:
                        seen[column][key] = number
        result = {'row_count': len(records), 'issues': issues,
                  'issue_count': len(issues), 'valid': not issues}
        fingerprint = _digest(records)
    try:
        _bounded(result, MAX_IO_BYTES, 'Sortie')
    except ValueError as exc:
        raise DomainError(str(exc)) from exc
    return result, fingerprint


def _qualification(row, at):
    results, positive, negative = [], set(), set()
    for case in row['definition']['cases']:
        try:
            output, fingerprint = _execute(row['definition'], case['input'])
            passed = 'expected' in case and _json(output) == _json(case['expected'])
            kind = 'negative' if output.get('valid') is False else 'positive'
            # An empty audit is a valid runtime input but is not a meaningful
            # positive qualification example.
            if passed and (kind == 'negative' or output.get('row_count', 1) > 0):
                (negative if kind == 'negative' else positive).add(fingerprint)
            result = {'label': case['label'], 'passed': passed, 'kind': kind,
                      'input_digest': fingerprint, 'output_digest': _digest(output)}
        except DomainError:
            fingerprint = _digest(case['input'])
            passed = case.get('error') == 'domain'
            if passed:
                negative.add(fingerprint)
            result = {'label': case['label'], 'passed': passed, 'kind': 'negative',
                      'input_digest': fingerprint, 'error': 'domain'}
        results.append(result)
    q = {'ok': all(x['passed'] for x in results) and len(positive) >= 2 and len(negative - positive) >= 1,
         'recipe_digest': row['digest'], 'cases': results, 'positive_cases': len(positive),
         'negative_cases': len(negative - positive), 'at': at,
         'scope': 'supplied_examples_only', 'model_calls': 0}
    q['review_digest'] = _digest(q)
    return q


def _metrics(store):
    receipts = [receipt for row in store['recipes'] for receipt in row['receipts']]
    # A corrected human assessment remains one observation per receipt.
    latest = {}
    for row in store['recipes']:
        for report in row['reports']:
            latest[report['receipt_id']] = report
    return {'completed_no_model_runs': len(receipts),
            'human_useful': sum(r['useful'] for r in latest.values()),
            'human_not_useful': sum(not r['useful'] for r in latest.values()),
            'wall_seconds': sum(r['duration_seconds'] for r in receipts),
            'model_calls': 0, 'euros': None, 'joules': None,
            'measurement_scope': 'deterministic_recipe_runs_only'}


def catalog(n):
    with n.LOCK:
        store = _load(n)
        return dict(copy.deepcopy(store), metrics=_metrics(store),
                    limits={'recipes': MAX_RECIPES, 'receipts': MAX_RECEIPTS,
                            'reports': MAX_REPORTS, 'bytes': MAX_STORE_BYTES,
                            'input_bytes': MAX_IO_BYTES, 'rows': MAX_ROWS},
                    templates=list(OPERATIONS))


def suggest(n, query):
    query = _text(query, 1000, 'Recherche')
    terms = set(re.findall(r'\w+', query.casefold()))
    proposals = []
    for row in catalog(n)['recipes']:
        if row['status'] == 'retired':
            continue
        definition = row['definition']
        haystack = set(re.findall(r'\w+', (definition['title'] + ' ' + definition['description']).casefold()))
        score = len(terms & haystack)
        if score:
            proposals.append({'id': row['id'], 'title': definition['title'], 'revision': row['revision'],
                              'status': row['status'], 'score': score, 'proposal_only': True})
    return sorted(proposals, key=lambda x: (-x['score'], x['id']))[:10]


def propose(n, payload, origin='human'):
    definition = _definition(payload)
    origin = _origin(origin)
    with n.LOCK:
        store = _load(n)
        if len(store['recipes']) >= MAX_RECIPES:
            raise ValueError('Capacité de méthodes atteinte ; aucune méthode supprimée.')
        ident = uuid.uuid4().hex[:12]
        lineage, version = ident, 1
        if ('replaces_id' in payload) != ('replaces_revision' in payload):
            raise ValueError('La révision remplacée et son identifiant sont requis ensemble.')
        if 'replaces_id' in payload:
            previous = _row(store, payload['replaces_id'])
            check_revision(payload['replaces_revision'], previous['revision'])
            lineage = previous['lineage_id']
            version = max(r['version'] for r in store['recipes'] if r['lineage_id'] == lineage) + 1
        row = {'id': ident, 'lineage_id': lineage, 'version': version, 'revision': 0,
               'definition': definition, 'digest': _digest(definition), 'status': 'candidate',
               'origin': origin, 'created_at': n.now(), 'qualification': None,
               'activation': None, 'receipts': [], 'reports': []}
        store['recipes'].append(row)
        _save(n, store)
        return copy.deepcopy(row)


def qualify(n, ident, revision):
    with n.LOCK:
        store = _load(n)
        row = _row(store, ident)
        check_revision(revision, row['revision'])
        if row['status'] not in ('candidate', 'qualified'):
            raise ValueError('Qualifier une proposition ; une version retirée reste retirée.')
        row['qualification'] = _qualification(row, n.now())
        row['status'] = 'qualified' if row['qualification']['ok'] else 'candidate'
        row['revision'] += 1
        _save(n, store)
        return copy.deepcopy(row)


def activate(n, ident, revision, review_digest):
    """Owner boundary only: explicit review is required even for AI proposals."""
    with n.LOCK:
        store = _load(n)
        row = _row(store, ident)
        check_revision(revision, row['revision'])
        q = row['qualification']
        if (row['status'] != 'qualified' or not q or q['ok'] is not True or
                not isinstance(review_digest, str) or review_digest != q['review_digest']):
            raise ValueError('Relire la qualification de cette version exacte avant de l’activer.')
        for previous in store['recipes']:
            if previous['lineage_id'] == row['lineage_id'] and previous['status'] == 'active':
                previous['status'] = 'retired'
                previous['revision'] += 1
        row['status'] = 'active'
        row['activation'] = {'authority': 'owner', 'at': n.now(), 'recipe_digest': row['digest'],
                             'review_digest': review_digest}
        row['revision'] += 1
        _save(n, store)
        return copy.deepcopy(row)


def retire(n, ident, revision):
    with n.LOCK:
        store = _load(n)
        row = _row(store, ident)
        check_revision(revision, row['revision'])
        row['status'] = 'retired'
        row['revision'] += 1
        _save(n, store)
        return copy.deepcopy(row)


def run(n, ident, inputs, revision=None, origin='human', request_id=None):
    origin = _origin(origin)
    if request_id is not None:
        if not isinstance(request_id, str) or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,100}', request_id):
            raise ValueError('Clé de répétition invalide.')
    _bounded(inputs, MAX_IO_BYTES, 'Entrée')
    with n.LOCK:
        store = _load(n)
        row = _row(store, ident)
        if revision is not None:
            check_revision(revision, row['revision'])
        # Revoke before reading a cached result: cache never resurrects authority.
        if row['status'] != 'active':
            raise ValueError('Méthode inactive ; revue et activation humaine requises.')
        input_digest = _digest(inputs)
        if request_id is not None:
            cached = next((receipt for item in store['recipes'] for receipt in item['receipts']
                           if receipt['request_id'] == request_id and receipt['origin'] == origin), None)
            if cached is not None:
                if cached['recipe_id'] != ident or cached['recipe_digest'] != row['digest'] or cached['input_digest'] != input_digest:
                    raise ValueError('Cette clé de répétition désigne déjà une autre demande.')
                return copy.deepcopy(cached)
        if sum(len(item['receipts']) for item in store['recipes']) >= MAX_RECEIPTS:
            raise ValueError('Capacité de reçus atteinte ; aucune exécution supplémentaire ni suppression.')
        started = time.perf_counter()
        output, _ = _execute(row['definition'], inputs)
        duration = max(0.0, time.perf_counter() - started)
        receipt = {'id': uuid.uuid4().hex[:12], 'recipe_id': ident, 'recipe_version': row['version'],
                   'recipe_digest': row['digest'], 'input_digest': input_digest, 'output': output,
                   'duration_seconds': duration, 'model_calls': 0, 'euros': None, 'joules': None,
                   'at': n.now(), 'origin': origin, 'request_id': request_id}
        row['receipts'].append(receipt)
        _save(n, store)
        return copy.deepcopy(receipt)


def report(n, ident, receipt_id, useful, note, revision):
    if type(useful) is not bool:
        raise ValueError('Choisir explicitement utile ou non utile.')
    note = _text(note, 2000, 'Observation humaine')
    with n.LOCK:
        store = _load(n)
        row = _row(store, ident)
        check_revision(revision, row['revision'])
        if not any(receipt['id'] == receipt_id for receipt in row['receipts']):
            raise ValueError('Reçu inconnu pour cette méthode.')
        if sum(len(item['reports']) for item in store['recipes']) >= MAX_REPORTS:
            raise ValueError('Capacité de retours atteinte ; aucune observation supprimée.')
        row['reports'].append({'id': uuid.uuid4().hex[:12], 'receipt_id': receipt_id,
                               'useful': useful, 'note': note, 'source': 'human_report',
                               'verified_automatically': False, 'at': n.now()})
        # An adverse observation contests future execution immediately. A fresh
        # candidate and qualification are needed; no automatic learning/activation.
        if not useful and row['status'] == 'active':
            row['status'] = 'retired'
        row['revision'] += 1
        _save(n, store)
        return copy.deepcopy(row)


def template(name):
    """Examples are inert until copied, qualified, reviewed and activated."""
    if name not in OPERATIONS:
        raise ValueError('Modèle de méthode inconnu.')
    if name == 'text.template':
        return {'title': 'Préparer un brouillon de suivi',
                'description': 'Assembler un brouillon avec un nom et une prochaine étape fournis ; aucun envoi.',
                'operation': name,
                'config': {'template': 'Bonjour {{name}},\nProchaine étape : {{next_step}}.',
                           'variables': ['name', 'next_step'], 'max_value_chars': 500},
                'cases': [
                    {'label': 'Premier suivi', 'input': {'values': {'name': 'Alexis', 'next_step': 'relire le contenu'}},
                     'expected': {'text': 'Bonjour Alexis,\nProchaine étape : relire le contenu.'}},
                    {'label': 'Autre suivi', 'input': {'values': {'name': 'Camille', 'next_step': 'vérifier les liens'}},
                     'expected': {'text': 'Bonjour Camille,\nProchaine étape : vérifier les liens.'}},
                    {'label': 'Étape manquante refusée', 'input': {'values': {'name': 'Alexis'}}, 'error': 'domain'}]}
    config = {'columns': ['id', 'title', 'url'], 'required': ['id', 'title', 'url'], 'unique': ['id'], 'max_rows': 500}
    if name == 'csv.audit':
        config['delimiter'] = ','
    examples = [
        [{'id': '1', 'title': 'Accueil', 'url': '/'}],
        [{'id': '2', 'title': 'Contact', 'url': '/contact'}, {'id': '3', 'title': 'Offres', 'url': '/offres'}],
        [{'id': '1', 'title': 'Accueil', 'url': '/'}, {'id': '1', 'title': '', 'url': '/autre'}]]
    inputs = []
    for records in examples:
        if name == 'records.audit':
            inputs.append({'records': records})
        else:
            out = io.StringIO(newline='')
            writer = csv.DictWriter(out, fieldnames=config['columns'], lineterminator='\n')
            writer.writeheader()
            writer.writerows(records)
            inputs.append({'csv': out.getvalue()})
    return {'title': 'Contrôler un export de contenus',
            'description': 'Vérifier les champs id, title, url et les identifiants en double, sur 500 lignes maximum. Ne lit ni site ni fichier.',
            'operation': name, 'config': config,
            'cases': [
                {'label': 'Une page complète', 'input': inputs[0],
                 'expected': {'row_count': 1, 'issues': [], 'issue_count': 0, 'valid': True}},
                {'label': 'Deux autres pages complètes', 'input': inputs[1],
                 'expected': {'row_count': 2, 'issues': [], 'issue_count': 0, 'valid': True}},
                {'label': 'Identifiant répété et titre absent', 'input': inputs[2],
                 'expected': {'row_count': 2, 'issues': [
                     {'kind': 'duplicate', 'row': 2, 'column': 'id', 'first_row': 1},
                     {'kind': 'missing', 'row': 2, 'column': 'title'}], 'issue_count': 2, 'valid': False}}]}
