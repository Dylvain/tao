"""Attributed working memory and unresolved differences, never execution mandates.

The model can propose bounded data anchored in a human quotation. Only explicit
human operations can change retained notes or close, pause, or focus a need.
All state additions are optional: earlier runtimes can preserve and ignore them.
"""
import copy
import json

from tao_work import text_field, check_revision

MAX_NOTES = 120
MAX_NEEDS = 200
MAX_EVENTS = 2000
MAX_HISTORY = 40
MAX_CONTEXT_BYTES = 24000
NOTE_KINDS = ('context', 'preference', 'constraint', 'question')
NEED_LIMITS = {'title': 160, 'current': 1200, 'desired': 1200,
               'acceptance': 1200, 'next_step': 800}


def _object(properties):
    return {'type': 'object', 'properties': properties,
            'required': list(properties), 'additionalProperties': False}


def _string(limit, minimum=0):
    return {'type': 'string', 'minLength': minimum, 'maxLength': limit}


_SOURCE_SCHEMA = {'message_id': _string(100, 1), 'quote': _string(1000, 8)}
EXTRACTION_SCHEMA = _object({
    'notes': {'type': 'array', 'maxItems': 4, 'items': _object(dict(
        {'kind': {'type': 'string', 'enum': list(NOTE_KINDS)},
         'text': _string(800, 1)}, **_SOURCE_SCHEMA))},
    'needs': {'type': 'array', 'maxItems': 3, 'items': _object(dict(
        {key: _string(limit, 1 if key == 'title' else 0)
         for key, limit in NEED_LIMITS.items()}, **_SOURCE_SCHEMA))}})


def ensure(s):
    memory = s.setdefault('continuity', {'schema': 'tao.continuity.v1',
                                        'revision': 0, 'notes': [], 'events': [],
                                        'enabled': True, 'completed_needs': {}})
    # 0.6.5 prunes generic resolved buffers. Preserve the authoritative history
    # separately so a rollback cannot erase these new records or their evidence.
    for ident, row in memory.setdefault('completed_needs', {}).items():
        if ident not in s.setdefault('buffers', {}):
            s['buffers'][ident] = copy.deepcopy(row)
    return memory


def _human_messages(messages):
    if not isinstance(messages, list):
        raise ValueError('Les messages sources doivent être fournis explicitement.')
    result = {}
    for message in messages:
        if not isinstance(message, dict) or message.get('role') != 'user':
            continue
        # Selecting a quotation is a human act; it does not make its author
        # human. Preserve this distinction through any number of transfers.
        if any(message.get(key) not in (None, 'user') for key in ('original_role', 'origin_role')):
            continue
        if message.get('source') == 'human_selected_transfer':
            origin = message.get('origin')
            if (message.get('original_role') != 'user' or
                    not all(isinstance(message.get(key), str) and message[key].strip() and len(message[key]) <= 100
                            for key in ('source_world_id', 'source_message_id')) or
                    not isinstance(origin, dict) or origin.get('role') != 'user' or
                    not all(isinstance(origin.get(key), str) and origin[key].strip() and len(origin[key]) <= 100
                            for key in ('world_id', 'message_id')) or
                    not isinstance(origin.get('quote'), str) or not origin['quote'].strip() or
                    len(origin['quote']) > 6000 or
                    (origin.get('at') is not None and (not isinstance(origin['at'], str) or len(origin['at']) > 80))):
                continue
        ident, text = message.get('id'), message.get('text')
        if not isinstance(ident, str) or not isinstance(text, str):
            continue
        if ident in result and result[ident]['text'] != text:
            raise ValueError('Identifiant de message source ambigu.')
        result[ident] = message
    return result


def validate_extraction(value, allowed_messages):
    """Validate the entire extraction before retaining any item, without coercion."""
    if not isinstance(value, dict) or set(value) != {'notes', 'needs'}:
        raise ValueError('Mémoire structurée invalide : notes et besoins requis.')
    allowed = _human_messages(allowed_messages)
    clean = {'notes': [], 'needs': []}
    for key, limit in (('notes', 4), ('needs', 3)):
        rows = value[key]
        if not isinstance(rows, list) or len(rows) > limit:
            raise ValueError('Extraction trop longue : quatre notes et trois besoins maximum.')
        fields = {'kind', 'text'} if key == 'notes' else set(NEED_LIMITS)
        for row in rows:
            if not isinstance(row, dict) or set(row) != fields | {'message_id', 'quote'}:
                raise ValueError('Champs de mémoire inattendus ; aucune commande acceptée.')
            ident = text_field(row['message_id'], 'Le message source', 100, True)
            quote = text_field(row['quote'], 'La citation source', 1000, True)
            if len(quote) < 8 or ident not in allowed or quote not in allowed[ident]['text']:
                raise ValueError('Une citation exacte d’au moins huit caractères d’un message humain fourni est requise.')
            if (allowed[ident].get('source') == 'human_selected_transfer' and
                    quote not in allowed[ident]['origin']['quote']):
                raise ValueError('La citation doit provenir des mots humains d’origine, pas de l’enveloppe du transfert.')
            item = {'message_id': ident, 'quote': quote}
            if key == 'notes':
                if not isinstance(row['kind'], str) or row['kind'] not in NOTE_KINDS:
                    raise ValueError('Type de note inconnu.')
                item.update(kind=row['kind'], text=text_field(row['text'], 'La note', 800, True))
            else:
                item.update({field: text_field(row[field], field, maximum, field == 'title')
                             for field, maximum in NEED_LIMITS.items()})
            clean[key].append(item)
    return clean


def _needs(s):
    return [b for b in s.get('buffers', {}).values()
            if b.get('kind') == 'dialogue' and isinstance(b.get('dialogue_need'), dict)]


def _event(n, memory, action, ident, source):
    if len(memory['events']) >= MAX_EVENTS:
        raise ValueError('Journal de continuité plein ; exporter et revoir sa rétention. Aucune trace supprimée.')
    memory['events'].append({'at': n.now(), 'action': action, 'id': ident, 'source': source})
    memory['revision'] += 1


def assimilate(n, s, extraction, reply_id):
    """Mutate a caller-owned locked state; the caller persists it with the reply.

Revalidating against live human messages also protects direct module callers.
A quotation establishes provenance, never the truth of its interpretation.
"""
    memory = ensure(s)
    result = {'note_ids': [], 'need_ids': [], 'warnings': []}
    if not memory['enabled']:
        return result
    reply_id = text_field(reply_id, 'La réponse source', 100, True)
    messages = s.get('dialogue', {}).get('messages', [])
    clean = validate_extraction(extraction, messages)
    humans = _human_messages(messages)
    story = n.story()
    story_text = str(story.get('text', ''))
    origin_story = {'id': story.get('id'), 'text': story_text[:1200],
                    'text_truncated': len(story_text) > 1200,
                    'digest': n.digest_bytes(n.json_bytes(story))}
    for key in ('notes', 'needs'):
        for item in clean[key]:
            category = item['kind'] if key == 'notes' else 'need'
            fingerprint = n.digest_bytes(n.json_bytes([category, item['message_id'], item['quote']]))
            prior = next((row for row in memory['notes']
                          if row['fingerprint'] == fingerprint), None) if key == 'notes' else next(
                (b for b in _needs(s) if b['dialogue_need']['fingerprint'] == fingerprint), None)
            output_key = 'note_ids' if key == 'notes' else 'need_ids'
            if prior is not None:
                if prior['id'] not in result[output_key]:
                    result[output_key].append(prior['id'])
                continue  # Never reactivate rejected, resolved, or withdrawn data.
            full = (len(memory['notes']) >= MAX_NOTES if key == 'notes' else
                    len(_needs(s)) >= MAX_NEEDS or len(n.open_buffers(s)) >= MAX_NEEDS)
            if full or len(memory['events']) >= MAX_EVENTS:
                warning = ('Mémoire de travail pleine : aucune note supprimée.' if key == 'notes' else
                           'Registre de besoins plein : aucun tampon supprimé.')
                if len(memory['events']) >= MAX_EVENTS:
                    warning = 'Journal de continuité plein : aucune trace supprimée.'
                if warning not in result['warnings']:
                    result['warnings'].append(warning + ' Les éléments non retenus restent dans la réponse brute.')
                continue
            ident = ('note:' if key == 'notes' else 'user:dialogue:') + fingerprint[:20]
            source_quote = {'message_id': item['message_id'], 'quote': item['quote'],
                            'at': humans[item['message_id']].get('at'), 'reply_id': reply_id}
            human = humans[item['message_id']]
            if human.get('source') == 'human_selected_transfer':
                source_quote.update(message_source='human_selected_transfer', original_role='user',
                                    source_world_id=human['source_world_id'],
                                    source_message_id=human['source_message_id'],
                                    origin={key: human['origin'].get(key) for key in ('world_id', 'message_id', 'role', 'at')})
            row = dict(id=ident, fingerprint=fingerprint, at=n.now(), updated_at=n.now(),
                       source='ai_interpretation', verification='unverified',
                       source_quote=source_quote, history=[], revision=1,
                       execution_enabled=False, origin_story_id=story.get('id'),
                       origin_story=copy.deepcopy(origin_story))
            if key == 'notes':
                row.update(kind=item['kind'], text=item['text'], status='proposed', authority='context_only')
                memory['notes'].append(row)
            else:
                row.update({field: item[field] for field in NEED_LIMITS})
                row.update(schema='tao.dialogue.need.v1', phase='to_clarify', focused=False,
                           authority='description_only', task_ids=[])
                b = n.make_buffer(ident, 'dialogue', item['current'] or item['title'], authority='human')
                b.update(desired=item['desired'], acceptance=item['acceptance'], dialogue_need=row,
                         story_id=story.get('id'))
                s.setdefault('buffers', {})[ident] = b
            _event(n, memory, 'note_proposed' if key == 'notes' else 'need_proposed', ident, 'ai_interpretation')
            result[output_key].append(ident)
    return result


def _history(n, row, action, **extra):
    if len(row['history']) >= MAX_HISTORY:
        raise ValueError('40 révisions conservées ; exporter et revoir la rétention. Aucun historique supprimé.')
    before = {key: copy.deepcopy(value) for key, value in row.items() if key != 'history'}
    row['history'].append(dict(at=n.now(), action=action, source='human_report', before=before, **extra))
    row['revision'] += 1
    row['updated_at'] = n.now()


def _persist(n, s):
    n.atomic_json(n.STATE, s, backup=True)
    n.WAKE.set()


def save_settings(n, enabled, revision):
    if type(enabled) is not bool:
        raise ValueError('Choix de continuité invalide.')
    with n.LOCK:
        s = n.load_state(); memory = ensure(s)
        check_revision(revision, memory['revision'])
        if enabled != memory['enabled']:
            if not enabled and len(memory['events']) >= MAX_EVENTS:
                # Stopping AI memory use must not depend on spare audit capacity.
                # Keep the saturated journal intact and one bounded receipt in
                # the same private, version-compatible continuity container.
                memory['revision'] += 1
                memory['disable_receipt'] = {
                    'schema': 'tao.continuity.disable_receipt.v1', 'at': n.now(),
                    'action': 'continuity_disabled', 'source': 'human_report',
                    'reason': 'event_capacity', 'event_count': len(memory['events']),
                    'previous_revision': revision, 'revision': memory['revision']}
            else:
                # Re-enabling still requires an ordinary durable audit event.
                _event(n, memory, 'continuity_enabled' if enabled else 'continuity_disabled', 'settings', 'human_report')
                if enabled and memory.get('disable_receipt'):
                    # Before a later stop can replace the single fallback slot,
                    # archive its prior receipt inside this activation event.
                    memory['events'][-1]['previous_disable_receipt'] = copy.deepcopy(memory['disable_receipt'])
            memory['enabled'] = enabled
            _persist(n, s)
        return {'enabled': memory['enabled'], 'revision': memory['revision']}


def edit_note(n, ident, text, status, revision):
    text = text_field(text, 'La note', 800, True)
    if not isinstance(status, str) or status not in ('kept', 'rejected'):
        raise ValueError('Choisir de retenir ou d’écarter la note.')
    with n.LOCK:
        s = n.load_state(); memory = ensure(s)
        check_revision(revision, memory['revision'])
        note = next((row for row in memory['notes'] if row['id'] == ident), None)
        if note is None:
            raise ValueError('Note inconnue.')
        if note['text'] != text or note['status'] != status:
            _event(n, memory, 'note_' + status, ident, 'human_report')
            _history(n, note, status)
            note.update(text=text, status=status, source='human_revision', verification='unverified')
            _persist(n, s)
        return note


def _need(s, ident):
    if not isinstance(ident, str):
        raise ValueError('Besoin inconnu.')
    b = s.get('buffers', {}).get(ident)
    if not b or b.get('kind') != 'dialogue' or not b.get('dialogue_need'):
        raise ValueError('Besoin issu de la discussion inconnu.')
    return b, b['dialogue_need']


def need_action(n, ident, action, revision, values=None, evidence=''):
    if not isinstance(action, str) or action not in ('focus', 'pause', 'resume', 'revise', 'resolve', 'reopen', 'withdraw'):
        raise ValueError('Action sur le besoin inconnue.')
    if action == 'revise':
        if not isinstance(values, dict) or not values or not set(values).issubset(NEED_LIMITS):
            raise ValueError('Seuls titre, situation, résultat attendu, vérification et prochaine étape se modifient.')
        values = {key: text_field(value, key, NEED_LIMITS[key], key == 'title') for key, value in values.items()}
    elif values not in (None, {}):
        raise ValueError('Cette action ne modifie pas les champs du besoin.')
    evidence = text_field(evidence, 'Le résultat réellement observé', 4000, action == 'resolve')
    if action != 'resolve' and evidence:
        raise ValueError('Une preuve de résolution accompagne seulement une clôture explicite.')
    with n.LOCK:
        s = n.load_state(); memory = ensure(s)
        check_revision(revision, memory['revision'])
        b, row = _need(s, ident)
        if action == 'reopen':
            if b['status'] not in ('resolved', 'withdrawn'):
                raise ValueError('Ce besoin est déjà ouvert.')
        elif b['status'] != 'open':
            raise ValueError('Rouvrir le besoin avant de le modifier.')
        if action == 'focus' and row['phase'] == 'paused':
            raise ValueError('Reprendre ce besoin avant de le choisir comme priorité.')
        if action == 'resume' and row['phase'] != 'paused':
            raise ValueError('Ce besoin n’est pas en pause.')
        if (action == 'focus' and row['focused']) or (action == 'pause' and row['phase'] == 'paused'):
            return b
        # Validate all affected rows before any persisted mutation.
        changed = [r for other in _needs(s) for r in [other['dialogue_need']]
                   if action == 'focus' and r['focused'] and r['id'] != ident]
        if any(len(r['history']) >= MAX_HISTORY for r in [row] + changed):
            raise ValueError('40 révisions conservées ; aucune histoire supprimée.')
        _event(n, memory, 'need_' + action, ident, 'human_report')
        _history(n, row, action, buffer_status=b['status'])
        for other in changed:
            _history(n, other, 'focus_replaced', focused_by=ident)
            other['focused'] = False
            if other['id'] in memory['completed_needs']:
                memory['completed_needs'][other['id']] = copy.deepcopy(s['buffers'][other['id']])
        if action == 'focus':
            row['focused'] = True
        elif action in ('pause', 'resume'):
            row.update(phase='paused' if action == 'pause' else 'to_clarify', focused=False)
        elif action == 'revise':
            row.update(values, source='human_revision', verification='unverified')
            b.update(residual=row['current'] or row['title'], desired=row['desired'], acceptance=row['acceptance'])
        elif action == 'resolve':
            observed = {'at': n.now(), 'source': 'human_report', 'text': evidence,
                        'verified_automatically': False, 'need_revision': row['revision']}
            b['evidence'].append(observed)
            b.update(status='resolved', resolved_at=n.now(),
                     resolution='Résolution déclarée par le propriétaire avec résultat observé.')
            row.update(phase='reported_resolved', focused=False, resolution_source='human_report')
        elif action == 'withdraw':
            b.update(status='withdrawn', withdrawn_at=n.now())
            row.update(phase='withdrawn', focused=False)
        elif action == 'reopen':
            b.update(status='open', reopened_at=n.now())
            row.update(phase='to_clarify', focused=False)
        if b['status'] in ('resolved', 'withdrawn') or ident in memory['completed_needs']:
            memory['completed_needs'][ident] = copy.deepcopy(b)
        _persist(n, s)
        return b


def attach_task(n, s, need_id, task_id):
    """Link an explicitly prepared task; caller persists the shared transaction."""
    b, row = _need(s, need_id)
    if not isinstance(task_id, str) or not s.get('buffers', {}).get(task_id, {}).get('work_task'):
        raise ValueError('Une tâche de travail existante est requise.')
    if task_id in row['task_ids']:
        return b
    if b['status'] != 'open' or row['phase'] == 'paused':
        raise ValueError('Reprendre ce besoin avant de lui associer une aide.')
    if len(row['task_ids']) >= 20 or len(row['history']) >= MAX_HISTORY:
        raise ValueError('Limite des liens ou révisions atteinte ; aucun lien supprimé.')
    memory = ensure(s)
    _event(n, memory, 'need_task_attached', need_id, 'human_report')
    _history(n, row, 'task_attached', task_id=task_id)
    row['task_ids'].append(task_id)
    if need_id in memory['completed_needs']:
        memory['completed_needs'][need_id] = copy.deepcopy(b)
    return b


def context(n, s):
    """Bound the supplied context without deleting stored notes or needs."""
    memory = ensure(s)
    active_notes = [row for row in memory['notes'] if row['status'] != 'rejected'
                    and (memory['enabled'] or row['source'] == 'human_revision')]
    active_notes.sort(key=lambda row: (row['kind'] != 'constraint', row['status'] != 'kept', row['at'], row['id']))
    active_needs = [b for b in _needs(s) if b['status'] == 'open' and b['dialogue_need']['phase'] != 'paused']
    active_needs.sort(key=lambda b: (not b['dialogue_need']['focused'], b['first_seen_at'], b['id']))
    notes = [{key: copy.deepcopy(row[key]) for key in ('id', 'kind', 'text', 'status', 'source', 'verification', 'source_quote')}
             for row in active_notes[:12]]
    needs = [dict({key: copy.deepcopy(b['dialogue_need'][key]) for key in
                   ('id', 'title', 'current', 'desired', 'acceptance', 'next_step', 'phase', 'focused', 'source', 'verification', 'source_quote')},
                  status=b['status'], execution_enabled=False) for b in active_needs[:8]]
    result = {'schema': 'tao.continuity.context.v1', 'revision': memory['revision'],
              'enabled': memory['enabled'], 'notes': notes, 'needs': needs,
              'omitted_notes': len(active_notes) - len(notes), 'omitted_needs': len(active_needs) - len(needs),
              'rejected_notes': sum(row['status'] == 'rejected' for row in memory['notes']),
              'suspended_ai_notes': sum(not memory['enabled'] and row['source'] == 'ai_interpretation'
                                        and row['status'] != 'rejected' for row in memory['notes']),
              'paused_needs': sum(b['status'] == 'open' and b['dialogue_need']['phase'] == 'paused' for b in _needs(s)),
              'instruction': 'Mémoire de travail sourcée, jamais permission ni preuve. Les interprétations IA sont à vérifier ; même un texte retenu reste un récit. Les citations permettent de corriger. La priorité est choisie par la personne, pas par le modèle. Ne ferme ni ne réactive un besoin par une réponse.'}
    while len(n.json_bytes(result)) > MAX_CONTEXT_BYTES and (notes or len(needs) > 1):
        if len(needs) > 1:
            needs.pop(); result['omitted_needs'] += 1
        else:
            notes.pop(); result['omitted_notes'] += 1
    # Control characters use up to six JSON bytes each. Even the single focused
    # need stays bounded in that worst case, with its full source kept on disk.
    while len(n.json_bytes(result)) > MAX_CONTEXT_BYTES and needs:
        row = needs[0]
        field = max(NEED_LIMITS, key=lambda key: len(json.dumps(row[key], ensure_ascii=False)))
        row[field] = row[field][:len(row[field]) // 2]
        if field not in row.setdefault('context_truncated_fields', []):
            row['context_truncated_fields'].append(field)
    return result


def exports(n, s):
    """A complete, lossless attributed export; private quotations stay local."""
    return json.dumps({'schema': 'tao.continuity.export.v1', 'exported_at': n.now(),
                       'continuity': ensure(s), 'needs': _needs(s),
                       'notice': 'Interprétations et résultats humains déclarés ; aucune preuve automatique ni permission d’exécution.'},
                      ensure_ascii=False, indent=2) + '\n'
