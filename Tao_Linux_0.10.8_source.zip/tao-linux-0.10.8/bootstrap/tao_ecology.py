"""Measured local ecology. Descriptions never grant authority or activate providers."""
from __future__ import annotations
import copy, math, os, shutil, tempfile, uuid
from pathlib import Path
from tao_runtime import RUNTIME_ASSETS, RUNTIME_FILES

CONTRACT='tao.seed.contract.v1'


def ensure(s):
    """Additive migration: preserve old identity, memories, buffers and unknown fields."""
    s.setdefault('lineage',{'schema':'tao.lineage.v1','founder_id':s['id'],
        'parent_id':None,'generation':0,'contract':CONTRACT,'species_status':'unclassified'})
    s.setdefault('metabolism',{'schema':'tao.metabolism.v1','basal_cpu_seconds':0.0,
        'basal_wall_seconds':0.0,'measured_cycles':0,'adaptive_attempts':0,
        'adaptive_wall_seconds':0.0,'receipts':[]})
    return s


def day(n):
    return n.now()[:10]  # Explicit UTC accounting; not a local calendar inference.


def budget(s,p,today,scope='adaptation'):
    if scope not in ('adaptation','dialogue'): raise ValueError('Budget inconnu')
    m=ensure(s)['metabolism']; b=m.get('daily_budget' if scope=='adaptation' else 'dialogue_daily_budget')
    if b is None or today>b['day_utc']:
        b={'day_utc':today,'attempts':0,'charged_seconds':0.0}
    # A backwards wall clock cannot restore spent credits.
    return dict(b,attempts_limit=p[scope+'_runs_per_day'],seconds_limit=p[scope+'_seconds_per_day'])


def effective_memory(total,available,cgroup_root=Path('/sys/fs/cgroup')):
    """Conservative headroom within the supplied cgroup namespace, in bytes.

    Linux: https://docs.kernel.org/admin-guide/cgroup-v2.html#memory
    and https://docs.kernel.org/admin-guide/cgroup-v1/memory.html . The v1
    usage counter is approximate. Cache is not subtracted from usage here.
    This reads only the namespace root, not ancestor limits, memory.high,
    swap or CPU quotas. It is an observation, not a reservation guarantee.
    """
    total=total if type(total) is int and total>0 else None
    available=available if type(available) is int and available>=0 else None
    if total is not None and available is not None:available=min(total,available)
    result={'memory_total':total,'memory_available':available,'memory_scope':'host'}
    root=Path(cgroup_root)
    def read(path):
        try:
            with path.open('r',encoding='ascii') as stream:value=stream.read(129)
            return value.strip() if len(value)<=128 else ''
        except FileNotFoundError:return None
        except (OSError,UnicodeError):return ''
    def number(value):
        return int(value) if value and value.isascii() and value.isdecimal() else None
    limit_text=read(root/'memory.max');scope='cgroup_v2';usage_path=root/'memory.current'
    if limit_text is None:
        scope='cgroup_v1';limit_text=read(root/'memory'/'memory.limit_in_bytes')
        usage_path=root/'memory'/'memory.usage_in_bytes'
    if limit_text is None or limit_text=='max' and scope=='cgroup_v2' or limit_text=='-1' and scope=='cgroup_v1':
        return result
    limit=number(limit_text)
    if limit is None:
        result.update(memory_available=None,memory_scope=scope+'_unknown');return result
    # v1 commonly reports its unlimited sentinel as a very large numeric limit.
    # A v1 limit above known physical RAM is not a tighter capacity restriction.
    if scope=='cgroup_v1' and total is not None and limit>total:return result
    result.update(memory_total=min(total,limit) if total is not None else limit,memory_scope=scope)
    usage=number(read(usage_path))
    if usage is None:
        result.update(memory_available=None,memory_scope=scope+'_unknown')
    elif available is not None:
        result['memory_available']=min(available,result['memory_total'],max(0,limit-usage))
    return result


def constraints(env):
    reasons=[]
    for label,free,total in [('disk',env.get('disk_free'),env.get('disk_total')),
                             ('memory',env.get('memory_available'),env.get('memory_total'))]:
        if free is None or not total: reasons.append(label+'_unknown')
        elif free/total<.10: reasons.append(label+'_low')
    for b in env.get('battery') or []:
        if b.get('capacity') is not None and b['capacity']<12 and str(b.get('status','')).lower() not in ('charging','full'):
            reasons.append('battery_low')
    return reasons


def providers(n=None):
    return [{'id':name,'detected':(n.adaptation.executable(n,name) if n else shutil.which(name)) is not None,
             'adapter':'manual_workshop' if name=='codex' else 'not_implemented',
             'authentication':'not_checked','permission':'explicit_invocation_required'}
            for name in ('codex','claude','ollama')]


def snapshot(n,s=None):
    s=copy.deepcopy(s if s is not None else n.load_state()); ensure(s)
    env=s.get('observation',{}).get('environment',{})
    b=budget(s,n.policy(),day(n)); blockers=constraints(env)
    if b['attempts']>=b['attempts_limit']: blockers.append('daily_attempts_exhausted')
    if b['seconds_limit']-b['charged_seconds']<=7: blockers.append('daily_time_exhausted')
    return {'schema':'tao.ecology.v1','observed_at':s.get('observation',{}).get('at'),
        'lineage':s['lineage'],'offspring':s.get('offspring',[]),
        'habitat':{'os':env.get('os'),'architecture':env.get('machine'),
            'disk_free_bytes':env.get('disk_free'),'memory_available_bytes':env.get('memory_available'),
            'battery':env.get('battery')},
        'adaptation':{'eligible':not blockers,'blockers':blockers,'budget':b,'authority':'explicit_workshop_only'},
        'metabolism':s['metabolism'],
        'unmeasured':{'electricity_joules':None,'provider_api_calls':None,'tokens':None,
                      'money':None,'human_attention_seconds':None},
        'providers':providers(n),
        'heritage':{'builtin_recipes':len(n.heritage().get('builtin',[])),
                    'remote_items':len(n.heritage().get('remote',[])),
                    'remote_executable':False},
        'centers':{'status':'observer_model','specializations':s.get('observer_model',{}).get('specialization_candidates',[])}}


def measure_cycle(s,cpu_seconds,wall_seconds):
    m=ensure(s)['metabolism']
    m['basal_cpu_seconds']=round(m['basal_cpu_seconds']+max(0,cpu_seconds),6)
    m['basal_wall_seconds']=round(m['basal_wall_seconds']+max(0,wall_seconds),6)
    m['measured_cycles']+=1


def reserve(n,experiment,scope='adaptation'):
    """Reserve before a CLI attempt. Crash retains its full charge; no false refund."""
    with n.LOCK:
        s=ensure(n.load_state()); p=n.policy(); blockers=constraints(n.observe_environment())
        b=budget(s,p,day(n),scope)
        if b['attempts']>=b['attempts_limit']: blockers.append('daily_attempts_exhausted')
        remaining=b['seconds_limit']-b['charged_seconds']
        if remaining<=7: blockers.append('daily_time_exhausted')
        if blockers: raise ValueError(('Dialogue' if scope=='dialogue' else 'Adaptation')+' différé : '+', '.join(blockers))
        timeout=min(180 if scope=='dialogue' else 600,remaining-7)
        receipt={'id':uuid.uuid4().hex,'experiment':experiment,'at':n.now(),
            'day_utc':b['day_utc'],'timeout_seconds':timeout,'charged_seconds':timeout+7,
            'status':'reserved','source':'local_cli_attempt','scope':scope}
        b['attempts']+=1; b['charged_seconds']+=receipt['charged_seconds']
        m=s['metabolism']; m['daily_budget' if scope=='adaptation' else 'dialogue_daily_budget']=b
        key='adaptive_attempts' if scope=='adaptation' else 'dialogue_attempts'
        m[key]=m.get(key,0)+1
        m['receipts']=(m['receipts']+[receipt])[-100:]
        n.atomic_json(n.STATE,s,backup=True)
        return dict(receipt)


def settle(n,ident,seconds,ok):
    if not isinstance(seconds,(int,float)) or isinstance(seconds,bool) or not math.isfinite(seconds) or seconds<0:
        raise ValueError('Durée mesurée invalide')
    with n.LOCK:
        s=ensure(n.load_state()); m=s['metabolism']
        receipt=next((r for r in m['receipts'] if r['id']==ident),None)
        if receipt is None or receipt['status']!='reserved': raise ValueError('Réservation absente ou déjà comptabilisée')
        scope=receipt.get('scope','adaptation')
        measured=round(seconds,6); b=m['daily_budget' if scope=='adaptation' else 'dialogue_daily_budget']
        if b['day_utc']==receipt['day_utc']:
            b['charged_seconds']=round(max(0,b['charged_seconds']-receipt['charged_seconds']+measured),6)
        receipt.update({'status':'completed' if ok else 'failed','measured_seconds':measured})
        key='adaptive_wall_seconds' if scope=='adaptation' else 'dialogue_wall_seconds'
        m[key]=round(m.get(key,0)+measured,6)
        n.atomic_json(n.STATE,s,backup=True)


def birth(n,destination,purpose,port,method_ids=None):
    """One explicit local birth. Independent frozen runtime; dormant, never installed."""
    if not isinstance(purpose,str) or not purpose.strip() or len(purpose)>2000:
        raise ValueError('Une histoire de naissance explicite est requise (2000 caractères maximum)')
    if type(port) is not int or not 1024<=port<=65535: raise ValueError('Port invalide')
    raw=Path(destination).expanduser()
    if raw.is_symlink() or raw.exists(): raise ValueError('Choisir un dossier de destination inexistant')
    dest=raw.resolve()
    if n.ROOT==dest or n.ROOT in dest.parents or dest in n.ROOT.parents:
        raise ValueError('La naissance doit être séparée du dossier du parent')
    if not dest.parent.is_dir(): raise ValueError('Le dossier parent doit déjà exister')
    with n.LOCK:
        parent=ensure(n.load_state()); p=n.policy()
        import tao_learning as learning
        selected=learning.select_for_birth(n,parent,method_ids)
        if port==p['http_port']: raise ValueError('Choisir un port différent du parent')
        if any(x.get('port')==port for x in parent.get('offspring',[])):
            raise ValueError('Ce port est déjà affecté à un descendant connu')
        if len(parent.get('offspring',[]))>=20: raise ValueError('Vingt descendants locaux déjà enregistrés')
        failures=constraints(n.observe_environment())
        if failures: raise ValueError('Naissance différée : '+', '.join(failures))
        source=Path(n.__file__).resolve().parent
        code={name:(source/name).read_bytes() for name in RUNTIME_FILES}
        # Source checkouts keep compiled assets in tao_frontend while installed
        # runtimes and descendants keep the same immutable files flat.  A
        # descendant must be able to give birth without reaching back into the
        # parent's source tree.
        for name in RUNTIME_ASSETS:
            path=source/name
            if not path.is_file(): path=source/'tao_frontend'/name
            code[name]=path.read_bytes()
        n.theory.load(n.THEORY)
        code['theory.canonical.json']=n.theory.canonical_path().read_bytes()
        hashes={name:n.digest_bytes(data) for name,data in code.items()}
        ident='node:'+uuid.uuid4().hex
        child=ensure(n.initial_state()); child['id']=ident
        if selected: learning.ensure(child)['inherited']=selected
        child['lineage']={'schema':'tao.lineage.v1','founder_id':parent['lineage']['founder_id'],
            'parent_id':parent['id'],'generation':parent['lineage']['generation']+1,
            'contract':CONTRACT,'species_status':'unclassified','runtime_hashes_at_birth':hashes}
        child_story=dict(n.DEFAULT_STORY,id='story:'+uuid.uuid4().hex,text=purpose.strip(),authority='human')
        child['story']=child_story
        child_policy=dict(n.DEFAULT_POLICY,http_port=port)
        # Private reports stay with the parent. Only explicitly approved text
        # fields of selected methods can cross this boundary.
        manifest={'schema':'tao.birth.v1','child_id':ident,'parent_id':parent['id'],
            'at':n.now(),'runtime_hashes':hashes,'authority':'explicit_local_command',
            'activation':'manual','inherited':['runtime','default_genome','builtin_heritage'],
            'private_memory_inherited':False,'permissions_inherited':False}
        manifest['selected_method_ids']=[m['id'] for m in selected]
        if selected: manifest['inherited'].append('selected_inert_methods')
        staging=Path(tempfile.mkdtemp(prefix='.tao-birth-',dir=dest.parent))
        try:
            for name,data in code.items(): n.durable_bytes(staging/'runtime'/name,data)
            values={'genome.json':n.DEFAULT_GENOME,'reflexes.json':n.DEFAULT_REFLEXES,
                'development.json':n.DEFAULT_DEVELOPMENT,'heritage.json':n.DEFAULT_HERITAGE,
                'theory.json':n.THEORY,'policy.json':child_policy,'story.json':child_story,
                'habits.json':{'schema':'tao.habits.v1','habits':[]},'birth.json':manifest}
            for name,value in values.items(): n.durable_bytes(staging/name,n.json_bytes(value))
            child['_integrity']=n.digest_bytes(n.json_bytes(child))
            raw_state=n.json_bytes(child)
            n.durable_bytes(staging/'state.json',raw_state)
            n.durable_bytes(staging/'state.sha256',(n.digest_bytes(raw_state)+'\n').encode())
            # Reserve a fresh name, then publish the complete state tree in one rename.
            dest.mkdir(mode=0o700)
            try:
                os.replace(staging,dest)
            except BaseException:
                dest.rmdir(); raise
        except BaseException:
            shutil.rmtree(staging,ignore_errors=True); raise
        parent.setdefault('offspring',[]).append({'id':ident,'created_at':n.now(),
            'path':str(dest),'port':port,'generation':child['lineage']['generation'],'activation':'manual'})
        n.atomic_json(n.STATE,parent,backup=True)
        n.event('offspring_created',{'child_id':ident,'activation':'manual'})
        return dict(manifest,path=str(dest),runtime=str(dest/'runtime/tao_node.py'))
