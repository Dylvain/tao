"""Private conversation spaces over one local node, without inherited authority.

The original top-level private fields remain the principal space for rollback.
Only metadata crosses a space boundary automatically. This is application-level
context separation, not separation between operating-system accounts.
"""
import copy
import os
import re
import uuid
from contextlib import contextmanager
from contextvars import ContextVar

from tao_work import text_field, check_revision

SCHEMA = 'tao.worlds.v1'
MAIN = 'main'
MAX_SPACES = 20
MAX_DEPTH = 6
PRIVATE_FIELDS = ('dialogue', 'continuity', 'learning', 'work_context', 'story',
                  'theory_proposals', 'presentation', 'development',
                  'observer_model', 'last_evidence', 'centers')
PRIVATE_KINDS = ('user', 'work', 'dialogue', 'code_projection')
PRESENTATION_VIEWS = ('needs', 'problems', 'objectives', 'solutions')
_CONTEXT = ContextVar('tao_current_world', default=None)


def _identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r'main|[a-f0-9]{12}', value):
        raise ValueError('Espace inconnu : identifiant invalide.')
    return value


def current():
    return _identifier(_CONTEXT.get() or os.environ.get('TAO_WORLD', MAIN))


@contextmanager
def using(ident):
    token = _CONTEXT.set(_identifier(ident))
    try:
        yield ident
    finally:
        _CONTEXT.reset(token)


def _registry(raw):
    """Validate without changing the caller's state or inventing a missing child."""
    registry = copy.deepcopy(raw.get('worlds', {
        'schema': SCHEMA, 'revision': 0,
        'spaces': {MAIN: {'id': MAIN, 'title': 'Principal', 'parent_id': None}}
    }))
    if not isinstance(registry, dict) or registry.get('schema') != SCHEMA:
        raise ValueError('Registre des espaces invalide.')
    revision, spaces = registry.get('revision'), registry.get('spaces')
    if type(revision) is not int or revision < 0 or not isinstance(spaces, dict) or MAIN not in spaces:
        raise ValueError('Registre des espaces incomplet.')
    if len(spaces) > MAX_SPACES:
        raise ValueError('Registre des espaces au-delà de la capacité prévue.')
    for ident, row in spaces.items():
        _identifier(ident)
        if not isinstance(row, dict) or row.get('id') != ident:
            raise ValueError('Métadonnées d’espace invalides.')
        text_field(row.get('title'), 'Le nom de cet espace', 120, True)
        text_field(row.get('description', ''), 'La description de cet espace', 1000)
        for field in ('archived', 'title_custom', 'description_custom'):
            if field in row and type(row[field]) is not bool:
                raise ValueError('Métadonnées d’espace invalides.')
        if 'template_key' in row and (not isinstance(row['template_key'], str)
                or not re.fullmatch(r'[a-z][a-z_]{0,40}', row['template_key'])):
            raise ValueError('Modèle d’espace invalide.')
        if 'template_locale' in row and row['template_locale'] not in ('fr', 'en'):
            raise ValueError('Langue du modèle d’espace invalide.')
        parent = row.get('parent_id')
        if ident == MAIN:
            if parent is not None:
                raise ValueError('L’espace principal ne peut pas avoir de parent.')
        else:
            _identifier(parent)
            if parent not in spaces or parent == ident:
                raise ValueError('Parent d’espace invalide.')
    for ident in spaces:
        _path(spaces, ident)
    return registry


def _path(spaces, ident):
    result, seen = [], set()
    while ident is not None:
        if ident in seen or ident not in spaces:
            raise ValueError('La hiérarchie des espaces contient une boucle.')
        seen.add(ident)
        result.append(ident)
        if len(result) > MAX_DEPTH + 1:
            raise ValueError('Six niveaux sous l’espace principal maximum.')
        ident = spaces[ident].get('parent_id')
    return list(reversed(result))


def _metadata(row):
    return {key: copy.deepcopy(row[key]) for key in ('id', 'title', 'parent_id', 'description',
            'template_key', 'template_locale', 'title_custom', 'description_custom', 'archived') if key in row}


def _private_buffer(ident, row):
    return (isinstance(ident, str) and ident.startswith('user:')) or (
        isinstance(row, dict) and row.get('kind') in PRIVATE_KINDS)


def _buffers(raw):
    value = raw.get('buffers', {})
    if not isinstance(value, dict):
        raise ValueError('Registre de tampons invalide.')
    return value


def project(raw_state):
    """Return an independent view containing only the current private context."""
    ident = current()
    registry = _registry(raw_state)
    spaces = registry['spaces']
    if ident not in spaces:
        raise ValueError('Cet espace n’existe pas.')
    view = copy.deepcopy(raw_state)
    source = raw_state if ident == MAIN else spaces[ident]
    for field in PRIVATE_FIELDS:
        view.pop(field, None)
        if field in source:
            view[field] = copy.deepcopy(source[field])
    # These descriptions are derived from private buffers by a cycle. An empty
    # child must not inherit the principal's candidates or evidence, but still
    # needs a valid observer when an explicit child cycle is requested.
    if ident != MAIN:
        view.setdefault('development', {'internalization_candidates': [], 'experiments': [], 'adaptations': []})
        view.setdefault('observer_model', {'status': 'observer_hypothesis', 'interpretation': 'C0',
                                          'specialization_candidates': []})
    shared = {bid: copy.deepcopy(b) for bid, b in _buffers(raw_state).items()
              if not _private_buffer(bid, b)}
    private = ({bid: copy.deepcopy(b) for bid, b in _buffers(raw_state).items()
                if _private_buffer(bid, b)} if ident == MAIN else copy.deepcopy(_buffers(source)))
    if set(shared) & set(private):
        raise ValueError('Un tampon privé entre en conflit avec un capteur partagé.')
    view['buffers'] = dict(shared, **private)
    view['worlds'] = {'schema': SCHEMA, 'revision': registry['revision'],
                      'spaces': {key: _metadata(row) for key, row in spaces.items()}}
    if 'foundations' in registry:
        # This marker contains catalogue metadata only. Never forward unknown
        # fields from the raw registry through a child projection.
        import tao_foundations as foundations
        view['worlds']['foundations'] = foundations._marker(registry)
    view['_world_view'] = ident
    return view


def merge(raw_state, view):
    """Merge the selected projection while preserving every other private space."""
    ident = current()
    if not isinstance(view, dict) or view.get('_world_view') != ident:
        raise ValueError('Cet état appartient à un autre espace ; aucune modification retenue.')
    registry = _registry(raw_state)
    if ident not in registry['spaces']:
        raise ValueError('Cet espace n’existe plus.')
    result = copy.deepcopy(raw_state)
    result.pop('_world_view', None)
    for field, value in view.items():
        if field not in PRIVATE_FIELDS and field not in ('buffers', 'worlds', '_world_view', '_integrity'):
            result[field] = copy.deepcopy(value)
    result['worlds'] = registry
    destination = result if ident == MAIN else result['worlds']['spaces'][ident]
    for field in PRIVATE_FIELDS:
        destination.pop(field, None)
        if field in view:
            destination[field] = copy.deepcopy(view[field])
    existing_private = set(_buffers(registry['spaces'][ident])) if ident != MAIN else set()
    private, shared = {}, {}
    for bid, row in _buffers(view).items():
        target = private if bid in existing_private or _private_buffer(bid, row) else shared
        target[bid] = copy.deepcopy(row)
    if ident == MAIN:
        result['buffers'] = dict(shared, **private)
    else:
        principal = {bid: copy.deepcopy(row) for bid, row in _buffers(raw_state).items()
                     if _private_buffer(bid, row)}
        if set(principal) & set(shared):
            raise ValueError('Un capteur ne peut pas remplacer un tampon principal privé.')
        result['buffers'] = dict(shared, **principal)
        destination['buffers'] = private
    return result


def describe(n, s=None):
    # A projected view is sufficient: it already contains all readable metadata.
    raw = n.load_raw_state() if s is None else s
    registry = _registry(raw)
    ident = current()
    spaces = registry['spaces']
    if ident not in spaces:
        raise ValueError('Cet espace n’existe pas.')
    row = spaces[ident]
    parent = row.get('parent_id')
    return {'schema': SCHEMA, 'revision': registry['revision'], 'current': _metadata(row),
            'parent': _metadata(spaces[parent]) if parent is not None else None,
            'path': [_metadata(spaces[key]) for key in _path(spaces, ident)],
            'spaces': [_metadata(value) for value in spaces.values()]}


def create(n, title, parent_id=None, description='', revision=0):
    title = text_field(title, 'Le nom de cet espace', 120, True)
    description = text_field(description, 'La description de cet espace', 1000)
    parent_id = current() if parent_id is None else _identifier(parent_id)
    with n.LOCK:
        raw = n.load_raw_state()
        registry = _registry(raw)
        check_revision(revision, registry['revision'])
        spaces = registry['spaces']
        if current() not in spaces or parent_id not in spaces:
            raise ValueError('L’espace parent n’existe pas.')
        if len(spaces) >= MAX_SPACES:
            raise ValueError('Vingt espaces maximum ; aucun espace existant n’a été supprimé.')
        if len(_path(spaces, parent_id)) > MAX_DEPTH:
            raise ValueError('Six niveaux sous l’espace principal maximum.')
        ident = uuid.uuid4().hex[:12]
        while ident in spaces:
            ident = uuid.uuid4().hex[:12]
        row = {'id': ident, 'title': title, 'parent_id': parent_id, 'description': description,
               'buffers': {}}
        spaces[ident] = row
        registry['revision'] += 1
        raw['worlds'] = registry
        n.atomic_json(n.STATE, raw, backup=True)
        return dict(_metadata(row), revision=registry['revision'])


def save_presentation(n, view, revision=0):
    """Choose a local reading of existing needs, without changing their meaning."""
    if not isinstance(view, str) or view not in PRESENTATION_VIEWS:
        raise ValueError('Choisir une vue : besoins, problèmes, objectifs ou pistes de solution.')
    with n.LOCK:
        raw = n.load_raw_state()
        registry = _registry(raw)
        ident = current()
        if ident not in registry['spaces']:
            raise ValueError('Cet espace n’existe pas.')
        destination = raw if ident == MAIN else registry['spaces'][ident]
        previous = destination.get('presentation', {'schema': 'tao.presentation.v1',
                                                    'view': 'needs', 'revision': 0})
        check_revision(revision, previous['revision'])
        if previous['view'] == view:
            return copy.deepcopy(previous)
        presentation = {'schema': 'tao.presentation.v1', 'view': view,
                        'revision': previous['revision'] + 1}
        destination['presentation'] = presentation
        raw['worlds'] = registry
        n.atomic_json(n.STATE, raw, backup=True)
        return copy.deepcopy(presentation)


def transfer(n, target_id, text, source_quote, source_message_id, revision=0):
    """Carry only a human-selected passage into another space, without an AI call."""
    import tao_dialogue as dialogue
    target_id = _identifier(target_id)
    text = text_field(text, 'Le texte à transmettre', 4000, True)
    quote = text_field(source_quote, 'La citation exacte', 4000, True)
    source_message_id = text_field(source_message_id, 'Le message source', 100, True)
    if target_id == current():
        raise ValueError('Choisir un autre espace pour cette transmission.')
    with n.LOCK:
        raw = n.load_raw_state()
        registry = _registry(raw)
        spaces = registry['spaces']
        if current() not in spaces or target_id not in spaces:
            raise ValueError('Espace source ou destination inconnu.')
        source = raw if current() == MAIN else spaces[current()]
        destination = raw if target_id == MAIN else spaces[target_id]
        candidates = [m for m in source.get('dialogue', {}).get('messages', [])
                      if m.get('id') == source_message_id and m.get('role') in ('user', 'assistant')]
        if len(candidates) != 1 or quote not in candidates[0].get('text', ''):
            raise ValueError('Une citation exacte d’un message de cet espace est requise.')
        message = candidates[0]
        original_role = (message.get('original_role') if message.get('source') == 'human_selected_transfer'
                         else message['role'])
        if original_role not in ('user', 'assistant'):
            raise ValueError('Le rôle original du passage est inconnu.')
        fingerprint = n.digest_bytes(n.json_bytes([current(), source_message_id, quote, target_id, text]))
        prior = next((m for m in destination.get('dialogue', {}).get('messages', [])
                      if m.get('transfer_fingerprint') == fingerprint), None)
        if prior is not None:
            return {'world_id': target_id, 'message_id': prior['id'],
                    'revision': registry['revision'], 'already_transferred': True}
        check_revision(revision, registry['revision'])
        # A running dialogue owns a frozen context. Do not insert a competing
        # human contribution before its response has been retained.
        with using(target_id):
            if dialogue.active(n):
                raise ValueError('Attendre la fin du dialogue avant de transmettre ce passage.')
        d = dialogue.ensure(destination)
        if len(d['messages']) >= dialogue.MAX_MESSAGES:
            raise ValueError('Discussion destinataire pleine ; l’archiver avant de transmettre.')
        selected_source = {'world_id': current(), 'message_id': source_message_id,
                           'quote': quote, 'role': original_role, 'at': message.get('at')}
        if message.get('source') == 'human_selected_transfer' and isinstance(message.get('origin'), dict):
            previous_origin = message['origin']
            origin = {key: copy.deepcopy(previous_origin.get(key))
                      for key in ('world_id', 'message_id', 'role', 'at')}
            # A second transfer shares only its newly selected passage, not the
            # original (possibly much longer) quotation hidden in provenance.
            # Selecting a transfer's wrapper or human reformulation does not
            # make that text a quotation from the original author. Empty quote
            # deliberately excludes it from source-validated AI extraction.
            original_quote = previous_origin.get('quote')
            origin['quote'] = quote if isinstance(original_quote, str) and quote in original_quote else ''
        else:
            origin = copy.deepcopy(selected_source)
        source_label = 'réponse IA' if original_role == 'assistant' else 'message humain'
        rendered = ('Transmission choisie par l’utilisateur depuis « ' + spaces[current()]['title']
                    + ' » (' + source_label + '). Sélection humaine, contenu non vérifié ; '
                    'aucune autorisation d’exécution transmise.\n\n'
                    + text + '\n\nCitation exacte du passage sélectionné :\n' + quote)
        row = {'id': 'transfer:' + fingerprint[:24], 'role': 'user', 'text': rendered,
               'at': n.now(), 'source': 'human_selected_transfer', 'verification': 'unverified',
               'original_role': original_role, 'source_world_id': current(),
               'source_message_id': source_message_id, 'selected_source': selected_source,
               'origin': origin, 'transfer_fingerprint': fingerprint, 'execution_enabled': False}
        d['messages'].append(row)
        d['revision'] += 1
        d['context_version'] += 1
        registry['revision'] += 1
        raw['worlds'] = registry
        n.atomic_json(n.STATE, raw, backup=True)
        return {'world_id': target_id, 'message_id': row['id'],
                'revision': registry['revision'], 'already_transferred': False}
