"""An empty, navigable inheritance: stable meanings, translated labels.

The catalogue is a set of proposed places and definitions, never a biography.
Only a fresh-state caller uses ``seed``. Existing installations opt in through
``initialize``; names alone never identify or take over an existing space.
"""
import copy
import hashlib
import uuid
from pathlib import Path

import tao_worlds as worlds
from tao_work import check_revision, text_field

SCHEMA = 'tao.foundations.v1'
CATALOG_VERSION = '1.0.0'
LOCALES = ('fr', 'en')
PREFIX = 'tao.concept.'


def _concept(key, fr, en, definition_fr, definition_en, **relations):
    return {'id': PREFIX + key, 'key': key, 'labels': {'fr': fr, 'en': en},
            'definitions': {'fr': definition_fr, 'en': definition_en},
            'relations': [{'predicate': predicate, 'target_types': [PREFIX + target for target in targets]}
                          for predicate, targets in relations.items()]}


CONCEPTS = {
    'story': _concept('story', 'Histoire', 'Story',
        'Récit situé d’événements, de leur contexte et de leurs sources ; distinct du résultat souhaité.',
        'A situated account of events, context and sources, distinct from a desired outcome.',
        concerns=('person', 'resource', 'mission', 'contract'), supported_by=('evidence',)),
    'objective': _concept('objective', 'Objectif', 'Objective',
        'Situation souhaitée avec un périmètre et un critère permettant d’examiner sa réalisation.',
        'A desired situation with a scope and a criterion for assessing achievement.',
        addresses=('problem',), supported_by=('evidence',), depends_on=('resource', 'objective')),
    'problem': _concept('problem', 'Problème', 'Problem',
        'Écart jugé gênant dans un contexte donné ; une difficulté signalée ne prouve pas sa cause.',
        'A difference judged troublesome in a given context; a reported difficulty does not prove its cause.',
        concerns=('story', 'person', 'resource', 'task'), supported_by=('evidence',)),
    'question': _concept('question', 'Question', 'Question',
        'Incertitude formulée à examiner, sans supposer qu’une réponse soit déjà connue.',
        'An expressed uncertainty to investigate without assuming an answer is already known.',
        concerns=('story', 'objective', 'problem', 'method', 'contract'), supported_by=('evidence',)),
    'person': _concept('person', 'Personne', 'Person',
        'Personne décrite ou concernée ; cette fiche n’accorde aucun accès et ne prouve aucune identité.',
        'A described or affected person; this record grants no access and proves no identity.',
        holds=('role',), participates_in=('mission', 'task', 'contract')),
    'role': _concept('role', 'Rôle', 'Role',
        'Responsabilité située, distincte d’une personne et d’un droit informatique.',
        'A situated responsibility, distinct from a person or a software permission.',
        contributes_to=('mission', 'objective'), governed_by=('contract', 'commitment')),
    'mission': _concept('mission', 'Mission', 'Mission',
        'Ensemble cohérent de résultats attendus et de responsabilités dans un contexte.',
        'A coherent set of expected outcomes and responsibilities in a context.',
        contributes_to=('objective',), assigned_to=('person', 'role'), governed_by=('contract',)),
    'task': _concept('task', 'Tâche', 'Task',
        'Action délimitée proposée ou suivie ; la décrire ne l’exécute pas et ne résout pas automatiquement un problème.',
        'A bounded proposed or tracked action; describing it neither executes it nor automatically resolves a problem.',
        contributes_to=('mission', 'objective'), assigned_to=('person', 'role'),
        uses=('method', 'resource'), addresses=('problem', 'question'), depends_on=('task',)),
    'contract': _concept('contract', 'Contrat', 'Contract',
        'Accord rapporté entre parties avec conditions, durée et obligations ; son enregistrement ne le signe pas.',
        'A reported agreement between parties with terms, duration and obligations; recording it does not sign it.',
        involves=('person',), concerns=('mission', 'role', 'commitment'), supported_by=('evidence',)),
    'income': _concept('income', 'Revenu', 'Income',
        'Entrée monétaire observée ou prévue, avec devise et période explicites ; une prévision n’est pas un encaissement.',
        'An observed or expected monetary inflow with explicit currency and period; a forecast is not a receipt.',
        arises_from=('contract', 'mission', 'resource'), supported_by=('evidence',)),
    'expense': _concept('expense', 'Dépense', 'Expense',
        'Sortie monétaire observée ou prévue, avec devise et période explicites ; une saisie n’autorise aucun paiement.',
        'An observed or expected monetary outflow with explicit currency and period; recording it authorizes no payment.',
        concerns=('resource', 'contract', 'commitment', 'task'), supported_by=('evidence',)),
    'commitment': _concept('commitment', 'Engagement', 'Commitment',
        'Promesse ou obligation rapportée avec parties, conditions et échéance ; distincte d’un simple souhait.',
        'A reported promise or obligation with parties, conditions and a due date, distinct from a wish.',
        assigned_to=('person', 'role'), contributes_to=('objective',), governed_by=('contract',)),
    'resource': _concept('resource', 'Ressource', 'Resource',
        'Moyen disponible ou requis dont quantité, unité, disponibilité et limites doivent être précisées.',
        'An available or required means whose quantity, unit, availability and limits must be specified.',
        supports=('task', 'mission', 'objective'), supported_by=('evidence',)),
    'method': _concept('method', 'Méthode', 'Method',
        'Procédure candidate dans un domaine, avec limites et contre-exemples ; distincte d’une capacité exécutée.',
        'A candidate procedure within a domain, with limits and counterexamples, distinct from an executed capability.',
        addresses=('problem', 'question'), supports=('task', 'mission'), supported_by=('evidence',)),
    'evidence': _concept('evidence', 'Élément de preuve', 'Evidence',
        'Observation ou document attribué à une source pour examiner une affirmation ; provenance ne signifie pas vérité.',
        'An observation or document attributed to a source for assessing a claim; provenance does not imply truth.',
        concerns=('story', 'objective', 'problem', 'method', 'task', 'income', 'expense', 'contract')),
}

RELATIONS = {
    'concerns': ('concerne', 'concerns'),
    'supported_by': ('étayé par', 'supported by'),
    'addresses': ('cherche à traiter', 'addresses'),
    'depends_on': ('dépend de', 'depends on'),
    'holds': ('occupe', 'holds'),
    'participates_in': ('participe à', 'participates in'),
    'contributes_to': ('contribue à', 'contributes to'),
    'governed_by': ('encadré par', 'governed by'),
    'assigned_to': ('attribué à', 'assigned to'),
    'uses': ('utilise', 'uses'),
    'involves': ('implique', 'involves'),
    'arises_from': ('provient de', 'arises from'),
    'supports': ('soutient', 'supports'),
}


def _area(key, fr, en, description_fr, description_en, concepts):
    return {'key': key, 'labels': {'fr': fr, 'en': en},
            'descriptions': {'fr': description_fr, 'en': description_en},
            'concept_ids': [PREFIX + key for key in concepts]}


AREAS = {
    'personal': _area('personal', 'Ma vie', 'My life',
        'Tes histoires, tes objectifs, tes questions et ce qui compte pour toi.',
        'Your stories, goals, questions and what matters to you.',
        ('story', 'objective', 'problem', 'question', 'commitment')),
    'work': _area('work', 'Travail', 'Work',
        'Les missions, rôles, tâches, contrats et engagements que tu souhaites comprendre ou suivre.',
        'The missions, roles, tasks, contracts and commitments you want to understand or track.',
        ('mission', 'role', 'task', 'contract', 'person', 'commitment')),
    'money': _area('money', 'Argent et ressources', 'Money and resources',
        'Tes revenus, dépenses, moyens et engagements ; aucune connexion bancaire implicite.',
        'Your income, expenses, resources and commitments; no implicit bank connection.',
        ('income', 'expense', 'resource', 'contract', 'commitment', 'objective')),
    'relationships': _area('relationships', 'Relations', 'Relationships',
        'Les personnes, histoires partagées et engagements que tu choisis de décrire.',
        'The people, shared stories and commitments you choose to describe.',
        ('person', 'story', 'question', 'commitment', 'problem')),
    'learning': _area('learning', 'Apprendre et comprendre', 'Learn and understand',
        'Les questions à explorer, connaissances à vérifier et méthodes à pratiquer.',
        'Questions to explore, knowledge to check and methods to practise.',
        ('question', 'objective', 'method', 'evidence', 'story')),
    'projects': _area('projects', 'Projets', 'Projects',
        'Les réalisations que tu envisages et les actions nécessaires pour avancer.',
        'The outcomes you envisage and the actions needed to make progress.',
        ('objective', 'mission', 'task', 'problem', 'resource', 'evidence')),
    'tools': _area('tools', 'Outils et appareils', 'Tools and devices',
        'Les outils, appareils, possibilités et limites que tu souhaites documenter.',
        'The tools, devices, capabilities and limits you want to document.',
        ('resource', 'method', 'problem', 'question', 'evidence')),
    'tao': _area('tao', 'Faire évoluer Tao', 'Evolve Tao',
        'Les questions, écarts et expériences pour améliorer Tao avec des résultats vérifiables.',
        'Questions, gaps and experiments to improve Tao with verifiable results.',
        ('question', 'problem', 'objective', 'method', 'task', 'evidence')),
}


def _locale(locale):
    if not isinstance(locale, str):
        raise ValueError('Langue attendue : fr ou en.')
    selected = locale.lower().split('-', 1)[0].split('_', 1)[0]
    if selected not in LOCALES:
        raise ValueError('Langue disponible : fr ou en. Les identifiants restent communs.')
    return selected


def get_concept(value, locale='fr'):
    locale = _locale(locale)
    key = value[len(PREFIX):] if isinstance(value, str) and value.startswith(PREFIX) else value
    if not isinstance(key, str) or key not in CONCEPTS:
        raise ValueError('Type de repère inconnu.')
    row = CONCEPTS[key]
    return {'id': row['id'], 'key': key, 'label': row['labels'][locale],
            'definition': row['definitions'][locale], 'relations': copy.deepcopy(row['relations'])}


def catalog(locale='fr'):
    locale = _locale(locale)
    return {'schema': SCHEMA, 'catalog_version': CATALOG_VERSION, 'locale': locale,
            'available_locales': list(LOCALES),
            'areas': [{'key': key, 'label': row['labels'][locale],
                       'description': row['descriptions'][locale],
                       'concept_ids': list(row['concept_ids'])} for key, row in AREAS.items()],
            'concepts': [get_concept(key, locale) for key in CONCEPTS],
            'relations': [{'id': key, 'label': pair[LOCALES.index(locale)]}
                          for key, pair in RELATIONS.items()],
            'classification': 'proposed_operational_vocabulary',
            'permissions_granted': False, 'personal_data_seeded': False}


def _marker(registry):
    marker = copy.deepcopy(registry.get('foundations', {}))
    if not marker:
        return None
    if (not isinstance(marker, dict) or marker.get('schema') != SCHEMA
            or marker.get('catalog_version') != CATALOG_VERSION
            or type(marker.get('initialized')) is not bool
            or not isinstance(marker.get('removed_templates'), list)
            or len(marker['removed_templates']) > len(AREAS)
            or any(not isinstance(key, str) or key not in AREAS for key in marker['removed_templates'])
            or len(set(marker['removed_templates'])) != len(marker['removed_templates'])):
        raise ValueError('Héritage des espaces invalide ; aucune réinitialisation automatique.')
    return {key: marker[key] for key in ('schema', 'catalog_version', 'initialized', 'removed_templates')}


def _new_marker():
    return {'schema': SCHEMA, 'catalog_version': CATALOG_VERSION,
            'initialized': True, 'removed_templates': []}


def _template_row(key, ident, locale):
    row = AREAS[key]
    return {'id': ident, 'title': row['labels'][locale], 'parent_id': worlds.MAIN,
            'description': row['descriptions'][locale], 'template_key': key,
            'template_locale': locale, 'title_custom': False, 'description_custom': False,
            'archived': False, 'buffers': {}}


def _template_map(registry):
    found = {}
    for ident, row in registry['spaces'].items():
        key = row.get('template_key')
        if key is None:
            continue
        if key not in AREAS or key in found:
            raise ValueError('Association d’un modèle d’espace ambiguë ; conserver les espaces pour examen.')
        found[key] = ident
    return found


def seed(raw, locale='fr'):
    """Pure fresh-state constructor. Existing registries and histories are untouched."""
    locale = _locale(locale)
    if not isinstance(raw, dict):
        raise ValueError('État initial invalide.')
    result = copy.deepcopy(raw)
    if ('worlds' in result or result.get('cycles', 0) != 0
            or any(field in result for field in ('dialogue', 'continuity', 'work_context', 'story', 'landmarks'))
            or result.get('buffers')):
        return result
    registry = worlds._registry(result)
    for key in AREAS:
        ident = hashlib.sha256(('tao.empty-area.v1:' + key).encode()).hexdigest()[:12]
        if ident in registry['spaces']:
            raise ValueError('Collision d’identifiants de modèles ; aucun espace modifié.')
        registry['spaces'][ident] = _template_row(key, ident, locale)
    registry['foundations'] = _new_marker()
    # The inherited empty map is the initial snapshot, not an owner mutation.
    result['worlds'] = registry
    worlds._registry(result)
    return result


def _archived(spaces, ident):
    return any(spaces[parent].get('archived', False) for parent in worlds._path(spaces, ident))


def overview(n, s=None, locale='fr'):
    """Catalogue and navigation metadata only, including for a projected child."""
    result = catalog(locale)
    raw = n.load_raw_state() if s is None else s
    registry = worlds._registry(raw)
    marker = _marker(registry)
    found = _template_map(registry)
    rows = []
    for ident, row in registry['spaces'].items():
        meta = worlds._metadata(row)
        key = row.get('template_key')
        meta['archived'] = bool(row.get('archived', False))
        meta['effective_archived'] = _archived(registry['spaces'], ident)
        meta['display_title'] = (AREAS[key]['labels'][result['locale']]
                                 if key and not row.get('title_custom', True) else row['title'])
        meta['display_description'] = (AREAS[key]['descriptions'][result['locale']]
                                       if key and not row.get('description_custom', True)
                                       else row.get('description', ''))
        rows.append(meta)
    for row in result['areas']:
        ident = found.get(row['key'])
        row['world_id'] = ident
        row['status'] = ('archived' if _archived(registry['spaces'], ident) else 'active') if ident else (
            'removed' if marker and row['key'] in marker['removed_templates'] else 'missing')
    result.update(revision=registry['revision'], initialized=bool(marker and marker['initialized']),
                  spaces=rows, limits={'spaces': worlds.MAX_SPACES, 'depth': worlds.MAX_DEPTH},
                  template_count=len(AREAS))
    return result


def initialize(n, revision, locale='fr'):
    """Explicit additive migration: no name matching, deletion or private-data import."""
    locale = _locale(locale)
    with n.LOCK:
        raw = n.load_raw_state()
        registry = worlds._registry(raw)
        check_revision(revision, registry['revision'])
        marker = _marker(registry) or _new_marker()
        found = _template_map(registry)
        missing = [key for key in AREAS if key not in found and key not in marker['removed_templates']]
        if len(registry['spaces']) + len(missing) > worlds.MAX_SPACES:
            raise ValueError('Place insuffisante pour ajouter tous les espaces vides ; aucun espace existant modifié.')
        changed = bool(missing) or not registry.get('foundations') or not marker['initialized']
        for key in missing:
            ident = uuid.uuid4().hex[:12]
            while ident in registry['spaces']:
                ident = uuid.uuid4().hex[:12]
            registry['spaces'][ident] = _template_row(key, ident, locale)
        marker['initialized'] = True
        registry['foundations'] = marker
        if changed:
            registry['revision'] += 1
            raw['worlds'] = registry
            worlds._registry(raw)
            n.atomic_json(n.STATE, raw, backup=True)
        return overview(n, raw, locale)


def update(n, world_id, revision, title=None, description=None, parent_id=None, locale='fr'):
    world_id = worlds._identifier(world_id)
    locale = _locale(locale)
    if title is not None:
        title = text_field(title, 'Le nom de cet espace', 120, True)
    if description is not None:
        description = text_field(description, 'La description de cet espace', 1000)
    if parent_id is not None:
        parent_id = worlds._identifier(parent_id)
    with n.LOCK:
        raw = n.load_raw_state(); registry = worlds._registry(raw)
        check_revision(revision, registry['revision'])
        _marker(registry); _template_map(registry)
        spaces = registry['spaces']
        if world_id not in spaces:
            raise ValueError('Cet espace n’existe pas.')
        row = spaces[world_id]; previous = copy.deepcopy(row)
        if title is not None and title != row['title']:
            row['title'] = title; row['title_custom'] = True
        if description is not None and description != row.get('description', ''):
            row['description'] = description; row['description_custom'] = True
        if parent_id is not None and parent_id != row.get('parent_id'):
            if world_id == worlds.MAIN:
                raise ValueError('L’espace principal ne peut pas être déplacé.')
            if parent_id not in spaces or _archived(spaces, parent_id):
                raise ValueError('Choisir un parent existant et actif.')
            row['parent_id'] = parent_id
        if row != previous:
            registry['revision'] += 1; raw['worlds'] = registry
            worlds._registry(raw)  # Includes descendant-depth and cycle checks.
            n.atomic_json(n.STATE, raw, backup=True)
        return overview(n, raw, locale)


def _set_archived(n, world_id, revision, value, locale):
    world_id = worlds._identifier(world_id); locale = _locale(locale)
    if world_id == worlds.MAIN:
        raise ValueError('L’espace principal reste accessible.')
    with n.LOCK:
        raw = n.load_raw_state(); registry = worlds._registry(raw)
        check_revision(revision, registry['revision'])
        _marker(registry); _template_map(registry)
        spaces = registry['spaces']
        if world_id not in spaces:
            raise ValueError('Cet espace n’existe pas.')
        row = spaces[world_id]
        if not value and _archived(spaces, row['parent_id']):
            raise ValueError('Restaurer d’abord l’espace parent archivé.')
        if row.get('archived', False) != value:
            row['archived'] = value
            registry['revision'] += 1; raw['worlds'] = registry
            n.atomic_json(n.STATE, raw, backup=True)
        return overview(n, raw, locale)


def archive(n, world_id, revision, locale='fr'):
    """Hide a branch in active navigation, preserving all context and its permissions."""
    return _set_archived(n, world_id, revision, True, locale)


def restore(n, world_id, revision, locale='fr'):
    return _set_archived(n, world_id, revision, False, locale)


def _external_world_data(n, world_id):
    """A pristine state row does not imply that all its sidecars are empty.

    Never delete or transfer receipts, capabilities or device mandates while
    removing an empty navigation space. Existing or unreadable references make
    archival the appropriate reversible operation instead.
    """
    root = getattr(n, 'ROOT', None)
    if root is None:
        return False
    root = Path(root)
    paths = [root / folder / world_id for folder in
             ('history-archives', 'world-snapshots', 'bridge')]
    paths += [root / folder / (world_id + '.json') for folder in ('reuse', 'connectors')]
    if any(path.exists() or path.is_symlink() or path.parent.is_symlink() for path in paths):
        return True
    import tao_devices as devices
    # The bounded existing loader validates the shared registry and rejects
    # symlinks or corruption. Only the matching world reference is inspected.
    registry = devices._load(n)
    return any(row['world_id'] == world_id for kind in ('devices', 'pairings', 'jobs')
               for row in registry[kind].values())


def remove_empty(n, world_id, revision, confirm=False, locale='fr'):
    """Only pristine empty leaves can be removed; used spaces must be archived."""
    world_id = worlds._identifier(world_id); locale = _locale(locale)
    if confirm is not True:
        raise ValueError('Confirmer explicitement la suppression de cet espace vide.')
    if world_id == worlds.MAIN:
        raise ValueError('L’espace principal reste accessible.')
    with n.LOCK:
        raw = n.load_raw_state(); registry = worlds._registry(raw)
        check_revision(revision, registry['revision'])
        _marker(registry); _template_map(registry)
        spaces = registry['spaces']
        if world_id not in spaces:
            raise ValueError('Cet espace n’existe pas.')
        row = spaces[world_id]
        allowed = set(worlds._metadata(row)) | {'buffers'}
        if (any(key not in allowed for key in row) or row.get('buffers')
                or any(item.get('parent_id') == world_id for item in spaces.values())):
            raise ValueError('Cet espace possède des données ou des enfants : l’archiver pour conserver son histoire.')
        if _external_world_data(n, world_id):
            raise ValueError('Cet espace possède des fichiers privés, des outils ou des appareils : l’archiver pour les conserver.')
        marker = _marker(registry)
        if marker is None:
            marker = _new_marker()
            marker['initialized'] = False
        key = row.get('template_key')
        if key and key not in marker['removed_templates']:
            marker['removed_templates'].append(key)
        registry['foundations'] = marker
        spaces.pop(world_id)
        registry['revision'] += 1; raw['worlds'] = registry
        n.atomic_json(n.STATE, raw, backup=True)
        return overview(n, raw, locale)
