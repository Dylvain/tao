"""Owner-reviewed workspace data; these routes never grant tool authority."""
from urllib.parse import parse_qs, urlsplit

import tao_foundations as foundations
import tao_integrability as integrability
import tao_landmarks as landmarks
import tao_logic as logic


def owns(path):
    return urlsplit(path).path.startswith(('/api/foundations', '/api/landmarks', '/api/integrability', '/api/logic'))


def _keys(value, required, optional=()):
    if not isinstance(value, dict) or not set(required) <= set(value) or set(value) - set(required) - set(optional):
        raise ValueError('Champs de cette opération incomplets ou inconnus.')


def get(n, path):
    parsed = urlsplit(path)
    params = parse_qs(parsed.query, keep_blank_values=True)
    if parsed.path == '/api/logic' and set(params) <= {'lang'}:
        if 'lang' in params and len(params['lang']) != 1:
            raise ValueError('Choisir une seule langue.')
        return logic.catalog(locale=params.get('lang', ['fr'])[0])
    if parsed.path == '/api/foundations' and set(params) <= {'lang'}:
        if 'lang' in params and len(params['lang']) != 1:
            raise ValueError('Choisir une seule langue.')
        return foundations.overview(n, locale=params.get('lang', ['fr'])[0])
    if parsed.path == '/api/landmarks' and not params:
        return landmarks.view(n)
    raise ValueError('Consultation de cet espace inconnue.')


def post(n, path, obj):
    if path == '/api/foundations/initialize':
        _keys(obj, ('revision',), ('locale',))
        return foundations.initialize(n, obj['revision'], obj.get('locale', 'fr'))
    if path == '/api/foundations/update':
        _keys(obj, ('world_id', 'revision'), ('title', 'description', 'parent_id'))
        return foundations.update(n, obj['world_id'], obj['revision'], **{
            key: obj[key] for key in ('title', 'description', 'parent_id') if key in obj})
    if path in ('/api/foundations/archive', '/api/foundations/restore'):
        _keys(obj, ('world_id', 'revision'))
        fn = foundations.archive if path.endswith('/archive') else foundations.restore
        return fn(n, obj['world_id'], obj['revision'])
    if path == '/api/foundations/remove-empty':
        _keys(obj, ('world_id', 'revision', 'confirm'))
        return foundations.remove_empty(n, obj['world_id'], obj['revision'], obj['confirm'])
    if path == '/api/landmarks':
        if not isinstance(obj, dict):
            raise ValueError('Objet de repère requis.')
        action = obj.get('action')
        if action == 'create':
            _keys(obj, ('action', 'concept_id', 'title', 'text', 'revision'))
            return landmarks.create(n, obj['concept_id'], obj['title'], obj['text'], obj['revision'])
        if action == 'update':
            _keys(obj, ('action', 'id', 'title', 'text', 'revision'), ('concept_id',))
            return landmarks.update(n, obj['id'], obj['title'], obj['text'], obj['revision'],
                                    concept_id=obj.get('concept_id'))
        if action in ('review', 'archive', 'restore'):
            _keys(obj, ('action', 'id', 'revision'))
            return getattr(landmarks, action)(n, obj['id'], obj['revision'])
        if action == 'merge':
            _keys(obj, ('action', 'ids', 'title', 'text', 'revision'))
            return landmarks.merge(n, obj['ids'], obj['title'], obj['text'], obj['revision'])
        raise ValueError('Action de repère inconnue.')
    if path == '/api/integrability/evaluate':
        return integrability.evaluate(obj)
    raise ValueError('Action de cet espace inconnue.')
