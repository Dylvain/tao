"""Deterministic, inert conversion of explicitly supplied conversation exports.

No account access, file access, archive extraction, model call or persistence lives
here. All imported roles are data, never instructions or permissions.
"""
import hashlib
import json
import re
import unicodedata

SCHEMA = 'tao.history_archive.v1'
MAX_BYTES = 16 * 1024 * 1024
MAX_CONVERSATIONS = 1000
MAX_MESSAGES = 20000
MAX_DEPTH = 64
MAX_DOCUMENT_BYTES = 256 * 1024
MAX_IDENTIFIER_CHARS = 500
MAX_PREVIEW_TITLE_CHARS = 300
CATEGORIES = (
    ('work', 'Travail et projets'), ('computing', 'Informatique'),
    ('learning', 'Apprentissage'), ('creation', 'Création'),
    ('personal', 'Vie personnelle'), ('money', 'Argent et ressources'),
    ('relationships', 'Relations et famille'), ('unclassified', 'À classer'),
)
_CATEGORY_NAMES = dict(CATEGORIES)
_LEGACY_WORDS = {
    'work': ('travail', 'taf', 'entreprise', 'client', 'projet', 'support', 'maintenance', 'devis', 'employe', 'professionnel', 'job', 'work', 'business', 'customer'),
    'computing': ('linux', 'tao', 'logiciel', 'github', 'gitlab', 'python', 'code', 'programmation', 'intellij', 'api', 'docker', 'plugin', 'codex', 'software', 'computer'),
    'learning': ('apprendre', 'comprendre', 'theorie', 'mathematique', 'cours', 'expliquer', 'definition', 'learn', 'explain', 'theory', 'study'),
    'creation': ('roman', 'manuscrit', 'auteur', 'narrateur', 'personnage', 'ecriture', 'dessin', 'poeme', 'fiction', 'novel', 'storytelling', 'creative'),
    'personal': ('famille', 'copine', 'couple', 'sante', 'voiture', 'vacances', 'maison', 'parents', 'enfant', 'allergie', 'family', 'health', 'personal'),
}
_WORDS = dict(_LEGACY_WORDS,
              personal=('sante', 'voiture', 'vacances', 'maison', 'allergie', 'health', 'personal'),
              money=('argent', 'budget', 'depense', 'depenses', 'revenu', 'revenus', 'salaire', 'loyer', 'epargne',
                     'facture', 'factures', 'xpf', 'euros', 'money', 'expense', 'expenses', 'income', 'salary', 'savings'),
              relationships=('famille', 'copine', 'couple', 'parents', 'enfant', 'enfants', 'ami', 'amis', 'voisin',
                             'voisins', 'relation', 'relations', 'family', 'relationship', 'relationships', 'friends'))
_WANT = re.compile(r"\b(?:je\s+(?:veux|voudrais|souhaite)|j['’]\s*aimerais|i\s+(?:want|would\s+like|wish))\b", re.I)


def _json(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
    except (TypeError, ValueError, UnicodeError, RecursionError) as exc:
        raise ValueError('archive: JSON invalide ou non représentable en UTF-8') from exc


def _hash(value):
    return hashlib.sha256(_json(value)).hexdigest()


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('archive: clé JSON répétée')
        result[key] = value
    return result


def _constant(value):
    raise ValueError('archive: nombre JSON non fini')


def _load(raw):
    if isinstance(raw, bytes):
        if len(raw) > MAX_BYTES:
            raise ValueError('archive: fichier JSON limité à 16 Mio')
        if raw[:2] == b'PK':
            raise ValueError('archive: extraire conversations.json du ZIP avant de l’importer')
        try:
            raw = raw.decode('utf-8-sig')
        except UnicodeError as exc:
            raise ValueError('archive: fichier UTF-8 attendu') from exc
    if isinstance(raw, str):
        try:
            if len(raw.encode('utf-8')) > MAX_BYTES:
                raise ValueError('archive: fichier JSON limité à 16 Mio')
            raw = json.loads(raw, object_pairs_hook=_pairs, parse_constant=_constant)
        except (json.JSONDecodeError, UnicodeError, RecursionError) as exc:
            raise ValueError('archive: fichier JSON valide attendu') from exc
    elif not isinstance(raw, (dict, list)):
        raise ValueError('archive: objet ou liste JSON attendu')
    encoded = _json(raw)
    if len(encoded) > MAX_BYTES:
        raise ValueError('archive: fichier JSON limité à 16 Mio')
    stack = [(raw, 0)]
    while stack:
        value, depth = stack.pop()
        if depth > MAX_DEPTH:
            raise ValueError('archive: profondeur JSON excessive')
        if isinstance(value, dict):
            if any(not isinstance(key, str) for key in value):
                raise ValueError('archive: clés JSON textuelles attendues')
            stack.extend((item, depth + 1) for item in value.values())
        elif isinstance(value, list):
            stack.extend((item, depth + 1) for item in value)
    return raw


def _text(value, label, default=''):
    if value is None:
        return default
    if not isinstance(value, str):
        raise ValueError('archive: ' + label + ' doit être du texte')
    return value


def _identifier(value, fallback):
    value = _text(value, 'identifiant', fallback)
    if not value:
        value = fallback
    if len(value) > MAX_IDENTIFIER_CHARS:
        raise ValueError('archive: identifiant trop long (500 caractères maximum)')
    return value


def _first_id(*values):
    for value in values:
        if value is not None and value != '':
            return value
    return None


def _role(value):
    value = _text(value, 'rôle', 'unknown').lower()
    if len(value) > 100:
        raise ValueError('archive: rôle trop long (100 caractères maximum)')
    canonical = {'human': 'user', 'model': 'assistant'}.get(value, value)
    return canonical if canonical in ('user', 'assistant', 'system', 'developer', 'tool') else 'unknown', value


def _parts(value):
    """Return textual fragments and count unsupported/non-text parts.

    Only explicit text fields are considered prose; URLs, paths, tool arguments,
    image pointers and nested unknown objects never become conversation text.
    """
    if value is None:
        return '', 0
    if isinstance(value, str):
        return value, 0
    if isinstance(value, list):
        text, assets = [], 0
        for item in value:
            fragment, count = _parts(item)
            if fragment:
                text.append(fragment)
            assets += count
        return '\n'.join(text), assets
    if isinstance(value, dict):
        kind = value.get('type', value.get('content_type', ''))
        if kind in ('text', 'input_text', 'output_text', 'text/plain', 'text_delta') and isinstance(value.get('text'), str):
            return value['text'], 0
        if 'parts' in value and isinstance(value['parts'], list):
            return _parts(value['parts'])
        if kind in ('text', 'code', 'audio_transcription') and isinstance(value.get('text'), str):
            return value['text'], 0
        return '', 1
    raise ValueError('archive: partie de message non reconnue')


def _attachment_count(value):
    if value is None:
        return 0
    if not isinstance(value, list):
        raise ValueError('archive: liste de pièces jointes attendue')
    return len(value)


def _message(mid, parent, role, text, *, source_id=None, active=None, assets=0, created_at=None):
    canonical, original = _role(role)
    row = {'id': mid, 'parent_id': parent, 'source_id': source_id or mid,
           'role': canonical, 'source_role': original, 'text': text,
           'active': active, 'context_only': True,
           'eligible_context': canonical in ('user', 'assistant'),
           'attachments_count': assets}
    if isinstance(created_at, (str, int, float)) and not isinstance(created_at, bool):
        row['created_at'] = created_at
    return row


def _chatgpt(conv, index):
    mapping = conv.get('mapping')
    if not isinstance(mapping, dict):
        raise ValueError('archive: mapping ChatGPT attendu')
    if len(mapping) > MAX_MESSAGES + 1000:
        raise ValueError('archive: trop de nœuds ChatGPT')
    cid = _identifier(_first_id(conv.get('id'), conv.get('conversation_id')), 'conversation-' + str(index))
    title = _text(conv.get('title'), 'titre', 'Sans titre')
    current = conv.get('current_node')
    if current is not None:
        current = _identifier(current, '')
    active, seen, cursor = set(), set(), current
    while cursor is not None and cursor in mapping:
        if cursor in seen:
            raise ValueError('archive: cycle dans les branches ChatGPT')
        seen.add(cursor)
        active.add(cursor)
        node = mapping[cursor]
        if not isinstance(node, dict):
            raise ValueError('archive: nœud ChatGPT invalide')
        cursor = node.get('parent')
        if cursor is not None and not isinstance(cursor, str):
            raise ValueError('archive: parent ChatGPT invalide')
    messages, nodes, warnings = [], [], []
    active_known = current is not None and current in mapping
    if current is not None and not active_known:
        warnings.append('La branche active de « ' + title[:100] + ' » est inconnue ; aucun état courant n’est déduit.')
    for node_id, node in mapping.items():
        nid = _identifier(node_id, 'node-' + str(len(nodes)))
        if not isinstance(node, dict):
            raise ValueError('archive: nœud ChatGPT invalide')
        parent = node.get('parent')
        if parent is not None:
            parent = _identifier(parent, '')
        nodes.append({'id': nid, 'parent_id': parent})
        source = node.get('message')
        if source is None:
            continue
        if not isinstance(source, dict) or not isinstance(source.get('author'), dict):
            raise ValueError('archive: message ChatGPT invalide')
        content = source.get('content')
        text, assets = _parts(content)
        metadata = source.get('metadata', {})
        if not isinstance(metadata, dict):
            raise ValueError('archive: métadonnées ChatGPT invalides')
        assets += _attachment_count(metadata.get('attachments'))
        messages.append(_message(nid, parent, source['author'].get('role'), text,
                                 source_id=_identifier(source.get('id'), nid),
                                 active=(nid in active) if active_known else None,
                                 assets=assets, created_at=source.get('create_time')))
    return {'id': cid, 'title': title, 'messages': messages, 'nodes': nodes, 'active_node_id': current}, warnings


def _claude(conv, index):
    cid = _identifier(_first_id(conv.get('uuid'), conv.get('id')), 'conversation-' + str(index))
    title = _text(conv.get('name', conv.get('title')), 'titre', 'Sans titre')
    rows = conv.get('chat_messages')
    if not isinstance(rows, list):
        raise ValueError('archive: liste chat_messages Claude attendue')
    if len(rows) > MAX_MESSAGES:
        raise ValueError('archive: 20 000 messages maximum ; importer plusieurs fichiers plus petits')
    messages, previous = [], None
    for i, source in enumerate(rows):
        if not isinstance(source, dict):
            raise ValueError('archive: message Claude invalide')
        mid = _identifier(_first_id(source.get('uuid'), source.get('id')), 'message-' + str(i))
        content_text, assets = _parts(source.get('content'))
        text = _text(source.get('text'), 'texte Claude', content_text)
        # A nonempty explicit text field usually duplicates the text blocks.
        # If the two differ, preserve both rather than silently drop either.
        if content_text and content_text != text:
            text = text + '\n' + content_text if text else content_text
        assets += _attachment_count(source.get('attachments')) + _attachment_count(source.get('files'))
        parent = source.get('parent_message_uuid', previous)
        if parent is not None:
            parent = _identifier(parent, '')
        messages.append(_message(mid, parent, source.get('sender'), text, active=None,
                                 assets=assets, created_at=source.get('created_at')))
        previous = mid
    return {'id': cid, 'title': title, 'messages': messages}, []


def _neutral(conv, index):
    cid = _identifier(conv.get('id'), 'conversation-' + str(index))
    title = _text(conv.get('title'), 'titre', 'Sans titre')
    rows = conv.get('messages')
    if not isinstance(rows, list):
        raise ValueError('archive: liste messages attendue')
    if len(rows) > MAX_MESSAGES:
        raise ValueError('archive: 20 000 messages maximum ; importer plusieurs fichiers plus petits')
    messages, previous = [], None
    for i, source in enumerate(rows):
        if not isinstance(source, dict) or 'role' not in source or 'text' not in source:
            raise ValueError('archive: message neutre attendu avec role et text')
        mid = _identifier(source.get('id'), 'message-' + str(i))
        text = _text(source['text'], 'texte de message')
        parent = source.get('parent_id', previous)
        if parent is not None:
            parent = _identifier(parent, '')
        active = source.get('active')
        if active is not None and type(active) is not bool:
            raise ValueError('archive: état de branche invalide')
        assets = _attachment_count(source.get('attachments'))
        messages.append(_message(mid, parent, source['role'], text, active=active,
                                 assets=assets, created_at=source.get('created_at')))
        previous = mid
    return {'id': cid, 'title': title, 'messages': messages}, []


def parse(raw):
    """Parse supported JSON shapes without retrieving anything from a provider."""
    raw = _load(raw)
    if isinstance(raw, dict) and raw.get('schema') == SCHEMA:
        raise ValueError('archive: fournir l’export source, pas une archive interne normalisée')
    if isinstance(raw, dict) and isinstance(raw.get('conversations'), list):
        rows, source_format, converter = raw['conversations'], 'neutral', _neutral
    elif isinstance(raw, list) and raw and all(isinstance(c, dict) and 'mapping' in c for c in raw):
        rows, source_format, converter = raw, 'chatgpt', _chatgpt
    elif isinstance(raw, list) and raw and all(isinstance(c, dict) and 'chat_messages' in c for c in raw):
        rows, source_format, converter = raw, 'claude', _claude
    else:
        raise ValueError('archive: format inconnu ; conversations.json ChatGPT, export JSON Claude ou format neutre conversations/messages attendu')
    if not rows:
        raise ValueError('archive: aucune conversation à importer')
    if len(rows) > MAX_CONVERSATIONS:
        raise ValueError('archive: 1 000 conversations maximum ; importer plusieurs fichiers plus petits')
    conversations, warnings, ids, total = [], [], set(), 0
    for i, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ValueError('archive: conversation invalide')
        conv, notices = converter(row, i)
        if conv['id'] in ids:
            raise ValueError('archive: identifiant de conversation répété')
        ids.add(conv['id'])
        mids = [m['id'] for m in conv['messages']]
        if len(mids) != len(set(mids)):
            raise ValueError('archive: identifiant de message répété dans une conversation')
        total += len(mids)
        if total > MAX_MESSAGES:
            raise ValueError('archive: 20 000 messages maximum ; importer plusieurs fichiers plus petits')
        conversations.append(conv)
        warnings.extend(notices)
    all_messages = [m for c in conversations for m in c['messages']]
    counts = {'conversations': len(conversations), 'messages': total,
              'user_messages': sum(m['role'] == 'user' for m in all_messages),
              'assistant_messages': sum(m['role'] == 'assistant' for m in all_messages),
              'excluded_role_messages': sum(not m['eligible_context'] for m in all_messages),
              'inactive_branch_messages': sum(m['active'] is False for m in all_messages),
              'attachment_references': sum(m['attachments_count'] for m in all_messages)}
    warnings.insert(0, 'Provenance déclarée par le fichier, non authentifiée. Tous les rôles importés restent des données sans autorité.')
    if counts['excluded_role_messages']:
        warnings.append(str(counts['excluded_role_messages']) + ' messages système, outil ou de rôle inconnu sont archivés mais exclus du contexte proposé.')
    if counts['attachment_references']:
        warnings.append(str(counts['attachment_references']) + ' références non textuelles ou pièces jointes repérées : leur contenu n’est pas transféré. Un même fichier peut être référencé plusieurs fois.')
    if counts['inactive_branch_messages']:
        warnings.append('Toutes les branches textuelles sont archivées ; les branches ChatGPT connues comme inactives ne nourrissent pas les notes proposées.')
    result = {'schema': SCHEMA, 'source': {'format': source_format, 'authority': 'unverified_export', 'input_digest': _hash(raw)},
              'conversations': conversations, 'counts': counts, 'warnings': warnings}
    result['digest'] = _hash(result)
    return result


def _fold(text):
    return ''.join(c for c in unicodedata.normalize('NFKD', text.lower()) if not unicodedata.combining(c))


def _category(conv, legacy=False):
    title = set(re.findall(r'[a-z0-9]+', _fold(conv['title'])))
    human = set(re.findall(r'[a-z0-9]+', _fold('\n'.join(m['text'] for m in conv['messages'] if m['role'] == 'user'))))
    vocabulary = _LEGACY_WORDS if legacy else _WORDS
    scores = {key: sum((4 if word in title else 0) + (1 if word in human else 0) for word in words) for key, words in vocabulary.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] else 'unclassified'


def _excerpt(text, limit):
    return text if len(text) <= limit else text[:limit - 1] + '…'


def _validate_normalized(archive):
    if not isinstance(archive, dict) or archive.get('schema') != SCHEMA:
        raise ValueError('archive: résultat de parse attendu')
    body = {k: v for k, v in archive.items() if k != 'digest'}
    if archive.get('digest') != _hash(body):
        raise ValueError('archive: empreinte normalisée invalide')
    # A digest is only corruption detection. Require the structural properties
    # consumed below even if an external caller recomputed that digest.
    if set(archive) != {'schema', 'source', 'conversations', 'counts', 'warnings', 'digest'}:
        raise ValueError('archive: structure normalisée invalide')
    if not isinstance(archive['conversations'], list) or not 1 <= len(archive['conversations']) <= MAX_CONVERSATIONS:
        raise ValueError('archive: conversations normalisées invalides')
    total = 0
    for conv in archive['conversations']:
        if not isinstance(conv, dict) or not isinstance(conv.get('id'), str):
            raise ValueError('archive: identifiant de conversation invalide')
        _identifier(conv['id'], '')
        if not isinstance(conv.get('title'), str) or not isinstance(conv.get('messages'), list):
            raise ValueError('archive: conversation normalisée invalide')
        total += len(conv['messages'])
        if total > MAX_MESSAGES:
            raise ValueError('archive: 20 000 messages maximum')
        if conv.get('active_node_id') is not None:
            _identifier(conv['active_node_id'], '')
        for message in conv['messages']:
            if not isinstance(message, dict):
                raise ValueError('archive: message normalisé invalide')
            for field in ('id', 'source_id'):
                if not isinstance(message.get(field), str):
                    raise ValueError('archive: identifiant de message invalide')
                _identifier(message[field], '')
            if message.get('parent_id') is not None:
                _identifier(message['parent_id'], '')
            _role(message.get('source_role'))


def propose(archive, assignments=None, _legacy=False):
    """Offer bounded, human-reviewable excerpts; retain the full parsed archive.

    This is lexical classification and selection, not semantic summarization or
    an inference of the user's present wishes. No assistant assertion becomes a
    fact or an instruction and no imported wish is marked fulfilled.
    """
    _validate_normalized(archive)
    conversations = archive['conversations']
    choices = None
    if assignments is not None:
        if not isinstance(assignments, list) or len(assignments) != len(conversations):
            raise ValueError('archive: affecter exactement une fois chaque conversation')
        choices = {}
        for row in assignments:
            if not isinstance(row, dict) or set(row) != {'conversation_id', 'space_key'}:
                raise ValueError('archive: affectation attendue avec conversation_id et space_key')
            if (not isinstance(row['conversation_id'], str) or row['conversation_id'] in choices or
                    not isinstance(row['space_key'], str) or row['space_key'] not in _CATEGORY_NAMES):
                raise ValueError('archive: conversation répétée ou catégorie inconnue')
            choices[row['conversation_id']] = row['space_key']
        if set(choices) != {c['id'] for c in conversations}:
            raise ValueError('archive: affectation d’une conversation inconnue ou manquante')
    prefix = 'history-' + archive['digest'][:8]
    groups, output_assignments = {}, []
    for conv in conversations:
        key = choices[conv['id']] if choices is not None else _category(conv, legacy=_legacy)
        groups.setdefault(key, []).append(conv)
        output_assignments.append({'conversation_id': conv['id'], 'space_key': key,
                                   'document_space_key': prefix + '-' + key,
                                   'title': _excerpt(conv['title'], MAX_PREVIEW_TITLE_CHARS),
                                   'title_truncated': len(conv['title']) > MAX_PREVIEW_TITLE_CHARS,
                                   'message_count': len(conv['messages']),
                                   'method': 'choix humain' if choices is not None else 'suggestion lexicale'})
    sources, spaces, selected, short = [], [], set(), 0
    selected_budget = 0
    # Reserve factual structure references for the root and any category with
    # no eligible human text. They contain no text from another category.
    max_selected = 80 - 1 - len(groups)
    # Round-robin over conversations prevents one long thread from consuming
    # every source slot. Latest eligible human excerpts are considered first.
    queues = []
    for key, convs in groups.items():
        for conv in convs:
            rows = [m for m in reversed(conv['messages']) if m['role'] == 'user' and m['text'].strip() and m['active'] is not False]
            queues.append((key, conv, rows))
    per_category = {key: [] for key in groups}
    while len(sources) < max_selected and any(rows for _, _, rows in queues):
        progressed = False
        for key, conv, rows in queues:
            if not rows or len(per_category[key]) >= 20 or len(sources) >= max_selected:
                continue
            message = rows.pop(0)
            sid = 'message-' + _hash([conv['id'], message['id']])[:24]
            text = _excerpt(message['text'], 6000)
            source = {'id': sid, 'label': _excerpt(conv['title'] + ' · message utilisateur ' + message['id'], 160),
                      'kind': 'user_quote', 'text': text}
            # Bound the entire projection even for multi-byte text. This is an
            # intentionally conservative bound including a note and a need.
            cost = (len(_json(source)) + 4096 +
                    len(_json(_excerpt(message['text'], 800))) +
                    2 * len(_json(_excerpt(message['text'], 1200))))
            if selected_budget + cost > MAX_DOCUMENT_BYTES - 32768:
                continue
            selected_budget += cost
            short += text != message['text']
            sources.append(source)
            per_category[key].append((conv, message, sid))
            selected.add((conv['id'], message['id']))
            progressed = True
        if not progressed:
            break
    structure_id = 'archive-structure'
    sources.append({'id': structure_id, 'label': 'Structure observée du fichier fourni',
                    'kind': 'reported_observation',
                    'text': str(len(conversations)) + ' conversation(s) et ' + str(archive['counts']['messages']) +
                    ' message(s) normalisés depuis un export déclaré ' + archive['source']['format'] +
                    '. Origine non authentifiée ; classement proposé à relire.'})
    spaces.append({'key': prefix, 'parent_key': 'main',
                   'title': 'Conversations importées ' + archive['digest'][:8],
                   'description': 'Archive de conversations choisie par le propriétaire. Classement lexical à corriger ; aucune synchronisation de compte.',
                   'story': 'Reprendre les histoires conservées dans cet export, vérifier leur actualité et choisir où poursuivre.',
                   'source_ids': [structure_id], 'notes': [], 'needs': []})
    for key, label in CATEGORIES:
        if key not in groups:
            continue
        entries = per_category[key]
        notes, needs = [], []
        for conv, message, sid in entries:
            text = message['text']
            if len(notes) < 12:
                kind = 'question' if '?' in text else 'context'
                notes.append({'kind': kind, 'text': _excerpt('Extrait utilisateur à recontextualiser : ' + text, 800), 'source_ids': [sid]})
            if len(needs) < 8 and _WANT.search(text):
                needs.append({'title': _excerpt('Souhait à confirmer · ' + conv['title'], 160),
                              'current': _excerpt('Ancien message importé, actualité non vérifiée : ' + text, 1200),
                              'desired': _excerpt(text, 1200),
                              'acceptance': 'Définir avec le propriétaire le résultat attendu et une preuve observable avant toute résolution.',
                              'next_step': 'Confirmer que ce souhait est toujours actuel, puis préciser la prochaine action.',
                              'source_ids': [sid]})
        # Categories containing only assistant/system/asset messages are still
        # represented, but their archival existence is not an assistant claim.
        ids = [entry[2] for entry in entries]
        if not ids:
            sid = 'archive-structure-' + key
            sources.append({'id': sid, 'label': 'Structure observée de la catégorie ' + label,
                            'kind': 'reported_observation',
                            'text': str(len(groups[key])) + ' conversation(s) classée(s) dans cette catégorie sans extrait utilisateur retenu. Aucun fait personnel ni besoin n’en est déduit.'})
            ids = [sid]
        spaces.append({'key': prefix + '-' + key, 'parent_key': prefix, 'title': label + ' · ' + archive['digest'][:8],
                       'description': str(len(groups[key])) + ' conversation(s) attribuée(s) à cette catégorie ; proposition lexicale, pas une certitude.',
                       'story': 'Relire ces conversations, corriger leur classement et confirmer les histoires encore utiles.',
                       'source_ids': ids, 'notes': notes, 'needs': needs})
    mapping = [{'conversation_id': row['conversation_id'], 'space_key': row['space_key']} for row in output_assignments]
    document = {'schema': 'tao.history_import.v1', 'id': 'archive-' + _hash([archive['digest'], mapping])[:40],
                'title': 'Reprendre mes conversations ' + archive['digest'][:8], 'sources': sources, 'spaces': spaces}
    if len(_json(document)) > MAX_DOCUMENT_BYTES:
        raise ValueError('archive: les extraits proposés dépassent 256 Kio ; diviser l’export en fichiers plus petits')
    omitted = archive['counts']['messages'] - len(selected)
    counts = dict(archive['counts'], sources_selected=len(selected), messages_omitted_from_context=omitted,
                  source_excerpts_shortened=short, spaces_proposed=len(spaces),
                  notes_proposed=sum(len(s['notes']) for s in spaces), needs_proposed=sum(len(s['needs']) for s in spaces))
    warnings = list(archive['warnings'])
    warnings.extend(['Classement par suggestion lexicale, sans appel IA. Les souhaits sont des propositions à confirmer, jamais des demandes exécutées ni des besoins résolus.',
                     str(len(selected)) + ' messages utilisateur sélectionnés ; ' + str(omitted) + ' autres messages restent dans l’archive et ne sont pas versés aux notes. Les extraits de notes sont limités à 800 caractères.',
                     'Le fichier exporté ne représente pas nécessairement toutes les données du compte : mémoire du fournisseur, pièces jointes et intégrations ne sont pas reconstituées.'])
    if short:
        warnings.append(str(short) + ' extraits source ont été raccourcis à 6 000 caractères ; leurs textes complets restent dans l’archive.')
    return {'document': document, 'archive': archive, 'assignments': output_assignments,
            'categories': [{'key': key, 'title': title} for key, title in CATEGORIES], 'counts': counts, 'warnings': warnings}
