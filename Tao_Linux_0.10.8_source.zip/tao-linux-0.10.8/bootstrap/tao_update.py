"""Explicit, signed runtime updates without sending Tao's private phenotype.

The basal loop never calls this module.  A release lookup happens only after an
owner CLI or HTTP action.  The remote host supplies bytes, never authority: an
Ed25519 public key selected independently and pinned in local configuration is
required before a manifest or installer can be accepted.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request


CONFIG_SCHEMA = 'tao.update.source.v1'
REVIEW_SCHEMA = 'tao.update.review.v1'
ATTEMPT_SCHEMA = 'tao.update.attempt.v1'
RELEASE_SCHEMA = 'tao.release.v2'
MAX_MANIFEST_BYTES = 16 * 1024
MAX_METADATA_BYTES = 4 * 1024
MAX_KEY_BYTES = 16 * 1024
MAX_ARTIFACT_BYTES = 128 * 1024 * 1024
VERSION = re.compile(r'(?:0|[1-9][0-9]{0,4})\.(?:0|[1-9][0-9]{0,4})\.(?:0|[1-9][0-9]{0,4})\Z')
DIGEST = re.compile(r'[0-9a-f]{64}\Z')
PEM_PUBLIC = re.compile(br'-----BEGIN PUBLIC KEY-----\r?\n[A-Za-z0-9+/=\r\n]+-----END PUBLIC KEY-----[\r\n]*\Z')
ED25519_SPKI_PREFIX = bytes.fromhex('302a300506032b6570032100')
ACTIVE_ATTEMPTS = {'starting', 'installing'}


class UpdateError(ValueError):
    """The configured source, signed release, or update transition is invalid."""


def _now():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')


def _process_start(pid):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        return fields[19] if fields[0] != 'Z' else None
    except (OSError, IndexError, ValueError, TypeError):
        return None


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise UpdateError('Propriété JSON dupliquée dans la distribution.')
        result[key] = value
    return result


def _reject_constant(_value):
    raise UpdateError('Nombre JSON non fini dans la distribution.')


def _json(raw, maximum, label):
    if type(raw) is not bytes or not 0 < len(raw) <= maximum:
        raise UpdateError(label + ' vide ou trop grand.')
    try:
        return json.loads(raw.decode('utf-8'), object_pairs_hook=_unique_object,
                          parse_constant=_reject_constant)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise UpdateError(label + ' illisible.') from exc


def _version(value, label='Version'):
    if type(value) is not str or not VERSION.fullmatch(value):
        raise UpdateError(label + ' invalide.')
    return tuple(int(part) for part in value.split('.'))


def _release_manifest(raw):
    """Parse legacy releases for visibility and v2 releases for installation."""
    value = _json(raw, MAX_MANIFEST_BYTES, 'Manifeste de release')
    if type(value) is not dict:
        raise UpdateError('Schéma du manifeste de release invalide.')
    keys = set(value)
    legacy = keys == {'version', 'files'}
    if not legacy and keys != {'schema', 'version', 'update', 'files'}:
        raise UpdateError('Schéma du manifeste de release invalide.')
    version = value.get('version')
    _version(version, 'Version de release')
    if not legacy:
        update = value.get('update')
        if value.get('schema') != RELEASE_SCHEMA or type(update) is not dict or set(update) != {
                'minimum_runtime', 'install_mode', 'changes', 'state_migrations'}:
            raise UpdateError('Contrat de mise à jour signé invalide.')
        _version(update.get('minimum_runtime'), 'Version minimale')
        changes = update.get('changes')
        migrations = update.get('state_migrations')
        if update.get('install_mode') != 'explicit' or type(changes) is not list or not 1 <= len(changes) <= 12:
            raise UpdateError('Description de mise à jour signée invalide.')
        for change in changes:
            if (type(change) is not dict or set(change) != {'fr', 'en'} or
                    any(type(change.get(locale)) is not str or not 1 <= len(change[locale]) <= 300
                        for locale in ('fr', 'en'))):
                raise UpdateError('Description bilingue de mise à jour invalide.')
        if (type(migrations) is not list or len(migrations) > 12 or
                any(type(item) is not str or not re.fullmatch(r'[a-z0-9][a-z0-9._-]{0,79}', item)
                    for item in migrations)):
            raise UpdateError('Liste de migrations privées invalide.')
    files = value.get('files')
    expected = {f'TAO_LINUX_{version}.run', f'Tao_Linux_{version}_source.zip'}
    if type(files) is not dict or set(files) != expected:
        raise UpdateError('La release doit déclarer exactement son installateur et ses sources.')
    for name, record in files.items():
        if type(record) is not dict or set(record) != {'sha256', 'size'}:
            raise UpdateError('Description d’artefact invalide.')
        if type(record['sha256']) is not str or not DIGEST.fullmatch(record['sha256']):
            raise UpdateError('Empreinte d’artefact invalide.')
        if type(record['size']) is not int or not 0 < record['size'] <= MAX_ARTIFACT_BYTES:
            raise UpdateError('Taille d’artefact invalide.')
    return value, legacy


def _absolute(path):
    if not isinstance(path, (str, os.PathLike)) or not os.fspath(path):
        raise UpdateError('Chemin explicite requis.')
    expanded = Path(os.path.expanduser(os.fspath(path)))
    if '..' in expanded.parts:
        raise UpdateError('Traversée de dossier refusée.')
    return Path(os.path.abspath(expanded))


def _read_regular(path, maximum, *, exact=None):
    """Read an explicit regular file without following a symlink component."""
    path = _absolute(path)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    directory = os.open(path.anchor, flags)
    try:
        for part in path.parts[1:-1]:
            child = os.open(part, flags, dir_fd=directory)
            os.close(directory)
            directory = child
        descriptor = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                             dir_fd=directory)
        try:
            before = os.fstat(descriptor)
            if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or
                    before.st_size <= 0 or before.st_size > maximum or
                    (exact is not None and before.st_size != exact)):
                raise UpdateError('Fichier absent, lié ou hors limites.')
            chunks = []
            count = 0
            while True:
                chunk = os.read(descriptor, min(1024 * 1024, maximum + 1 - count))
                if not chunk:
                    break
                count += len(chunk)
                if count > maximum:
                    raise UpdateError('Fichier trop grand.')
                chunks.append(chunk)
            after = os.fstat(descriptor)
            snapshot = lambda row: (row.st_dev, row.st_ino, row.st_size, row.st_mtime_ns, row.st_ctime_ns)
            if count != before.st_size or snapshot(before) != snapshot(after):
                raise UpdateError('Fichier modifié pendant sa lecture.')
            return b''.join(chunks)
        finally:
            os.close(descriptor)
    except OSError as exc:
        raise UpdateError('Fichier absent ou inaccessible.') from exc
    finally:
        os.close(directory)


def _openssl_run(arguments, data=None):
    executable = shutil.which('openssl')
    if not executable:
        raise UpdateError('OpenSSL 3 ou plus récent est requis.')
    environment = {'PATH': os.defpath, 'LANG': 'C', 'LC_ALL': 'C', 'OPENSSL_CONF': os.devnull}
    try:
        version = subprocess.run([executable, 'version'], stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, env=environment, timeout=15, check=False)
        match = re.match(rb'OpenSSL ([0-9]+)\.', version.stdout)
        if version.returncode or not match or int(match[1]) < 3:
            raise UpdateError('OpenSSL 3 ou plus récent est requis.')
        result = subprocess.run([executable, *arguments], input=data, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, env=environment, timeout=15, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise UpdateError('OpenSSL ne répond pas.') from exc
    if result.returncode:
        raise UpdateError('La clé ou la signature de release est refusée.')
    return result.stdout


def _public_key(path):
    raw = _read_regular(path, MAX_KEY_BYTES)
    if not PEM_PUBLIC.fullmatch(raw):
        raise UpdateError('Une clé publique Ed25519 PEM explicite est requise.')
    der = _openssl_run(['pkey', '-pubin', '-pubout', '-outform', 'DER',
                        '-passin', 'pass:', '-in', '/dev/stdin'], raw)
    if len(der) != 44 or not der.startswith(ED25519_SPKI_PREFIX):
        raise UpdateError('Seules les clés publiques Ed25519 sont acceptées.')
    return der, hashlib.sha256(der).hexdigest()


def _verify_signed_manifest(raw_manifest, signature, metadata_raw, key_path, pinned_fingerprint):
    manifest, legacy = _release_manifest(raw_manifest)
    if type(signature) is not bytes or len(signature) != 64:
        raise UpdateError('Signature Ed25519 invalide.')
    der, fingerprint = _public_key(key_path)
    if fingerprint != pinned_fingerprint:
        raise UpdateError('La clé publique locale ne correspond plus à l’autorité choisie.')
    metadata = _json(metadata_raw, MAX_METADATA_BYTES, 'Métadonnées de signature')
    expected = {
        'schema': 1,
        'algorithm': 'ed25519',
        'manifest': 'release.json',
        'signature': 'release.sig',
        'manifest_sha256': hashlib.sha256(raw_manifest).hexdigest(),
        'public_key_sha256': fingerprint,
    }
    if type(metadata) is not dict or metadata != expected or type(metadata.get('schema')) is not int:
        raise UpdateError('Les métadonnées ne correspondent pas au manifeste et à la clé locale.')
    with tempfile.TemporaryDirectory(prefix='tao-update-signature-') as temporary:
        base = Path(temporary)
        manifest_path = base / 'release.json'
        signature_path = base / 'release.sig'
        manifest_path.write_bytes(raw_manifest)
        signature_path.write_bytes(signature)
        _openssl_run(['pkeyutl', '-verify', '-rawin', '-pubin', '-keyform', 'DER',
                      '-inkey', '/dev/stdin', '-in', str(manifest_path),
                      '-sigfile', str(signature_path)], der)
    return manifest, legacy, fingerprint


def _validate_url(value):
    if type(value) is not str or not 1 <= len(value) <= 2000:
        raise UpdateError('Adresse de release invalide.')
    parsed = urllib.parse.urlsplit(value)
    if (parsed.username is not None or parsed.password is not None or parsed.fragment or parsed.query or
            not parsed.hostname or parsed.path.endswith('/') is False):
        raise UpdateError('L’adresse doit désigner un dossier HTTPS et finir par / .')
    loopback = parsed.hostname in {'127.0.0.1', 'localhost', '::1'}
    if parsed.scheme != 'https' and not (parsed.scheme == 'http' and loopback):
        raise UpdateError('HTTPS est requis hors de cette machine.')
    try:
        if parsed.port is not None and not 1 <= parsed.port <= 65535:
            raise UpdateError('Port de release invalide.')
    except ValueError as exc:
        raise UpdateError('Port de release invalide.') from exc
    normalized = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, '', ''))
    if normalized != value:
        raise UpdateError('Adresse de release non canonique.')
    return value


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        previous = urllib.parse.urlsplit(req.full_url)
        parsed = urllib.parse.urlsplit(newurl)
        if (parsed.username is not None or parsed.password is not None or parsed.query or parsed.fragment or
                (previous.scheme == 'https' and parsed.scheme != 'https')):
            raise UpdateError('Redirection de release refusée.')
        if previous.scheme == 'http' and previous.hostname in {'127.0.0.1', 'localhost', '::1'}:
            if parsed.hostname not in {'127.0.0.1', 'localhost', '::1'}:
                raise UpdateError('Une source locale ne peut pas rediriger hors de cette machine.')
        if not parsed.path.endswith('/'):
            # Artifact and metadata URLs are files. Validate their origin rules
            # through their containing directory without weakening HTTPS.
            directory = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc,
                                                 parsed.path.rsplit('/', 1)[0] + '/', '', ''))
        else:
            directory = newurl
        _validate_url(directory)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _download(base_url, name, maximum, expected=None):
    if not re.fullmatch(r'[A-Za-z0-9._-]{1,160}', name):
        raise UpdateError('Nom de fichier distant invalide.')
    url = urllib.parse.urljoin(_validate_url(base_url), name)
    request = urllib.request.Request(url, headers={'User-Agent': 'Tao signed updater'})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _SafeRedirect())
    try:
        with opener.open(request, timeout=15) as response:
            final = urllib.parse.urlsplit(response.geturl())
            if final.username is not None or final.password is not None or final.query or final.fragment:
                raise UpdateError('Adresse finale de release refusée.')
            directory = urllib.parse.urlunsplit((final.scheme, final.netloc,
                                                 final.path.rsplit('/', 1)[0] + '/', '', ''))
            _validate_url(directory)
            declared = response.headers.get('Content-Length')
            if declared is not None:
                try:
                    declared_size = int(declared)
                except ValueError as exc:
                    raise UpdateError('Taille distante invalide.') from exc
                if declared_size <= 0 or declared_size > maximum or (expected is not None and declared_size != expected):
                    raise UpdateError('Taille distante hors limites.')
            data = response.read(maximum + 1)
    except UpdateError:
        raise
    except (OSError, urllib.error.URLError, urllib.error.HTTPError) as exc:
        raise UpdateError('La source de mise à jour ne répond pas.') from exc
    if not 0 < len(data) <= maximum or (expected is not None and len(data) != expected):
        raise UpdateError('Réponse distante vide, tronquée ou trop grande.')
    return data


def _folder(root, create=False):
    path = _absolute(root) / 'update'
    if path.exists() and (path.is_symlink() or not path.is_dir()):
        raise UpdateError('Le dossier local de mise à jour est invalide.')
    if create:
        path.mkdir(parents=True, exist_ok=True, mode=0o700)
        path.chmod(0o700)
    return path


def _atomic(path, data, mode=0o600):
    path = _absolute(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if path.exists():
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise UpdateError('Destination locale liée ou non régulière.')
    temporary = path.parent / ('.update-' + secrets.token_hex(12))
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _json_bytes(value):
    try:
        return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                           allow_nan=False) + '\n').encode('utf-8')
    except (TypeError, ValueError) as exc:
        raise UpdateError('État local de mise à jour invalide.') from exc


def _write_json(path, value):
    _atomic(path, _json_bytes(value))


def _read_json(path, maximum=64 * 1024):
    return _json(_read_regular(path, maximum), maximum, 'État local de mise à jour')


@contextmanager
def _locked(root):
    folder = _folder(root, create=True)
    lock_path = folder / 'update.lock'
    try:
        descriptor = os.open(lock_path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    except OSError as exc:
        raise UpdateError('Verrou local de mise à jour inaccessible.') from exc
    with os.fdopen(descriptor, 'a+') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise UpdateError('Verrou local de mise à jour lié ou non régulier.')
        os.fchmod(stream.fileno(), 0o600)
        fcntl.flock(stream, fcntl.LOCK_EX)
        yield folder


def _config(root, verify_key=False):
    value = _read_json(_folder(root) / 'source.json', 8192)
    if type(value) is not dict or set(value) != {
            'schema', 'release_url', 'trusted_public_key', 'public_key_sha256', 'automatic'}:
        raise UpdateError('Configuration locale de mise à jour invalide.')
    if value.get('schema') != CONFIG_SCHEMA or value.get('automatic') is not False:
        raise UpdateError('Configuration locale de mise à jour invalide.')
    _validate_url(value.get('release_url'))
    key_path = _absolute(value.get('trusted_public_key'))
    update_folder = _folder(root)
    if key_path == update_folder or update_folder in key_path.parents:
        raise UpdateError('La clé de confiance doit rester hors du cache de mise à jour.')
    if str(key_path) != value.get('trusted_public_key') or not DIGEST.fullmatch(value.get('public_key_sha256', '')):
        raise UpdateError('Clé de confiance locale invalide.')
    if verify_key:
        _der, fingerprint = _public_key(key_path)
        if fingerprint != value['public_key_sha256']:
            raise UpdateError('La clé publique locale ne correspond plus à l’autorité choisie.')
    return value


def configure(n, release_url, trusted_key, replace=False):
    """Pin an explicit release directory and independently obtained public key."""
    root = n.ROOT
    url = _validate_url(release_url)
    key_path = _absolute(trusted_key)
    update_folder = _folder(root)
    if key_path == update_folder or update_folder in key_path.parents:
        raise UpdateError('La clé de confiance doit rester hors du cache de mise à jour.')
    _der, fingerprint = _public_key(key_path)
    value = {'schema': CONFIG_SCHEMA, 'release_url': url,
             'trusted_public_key': str(key_path), 'public_key_sha256': fingerprint,
             'automatic': False}
    with _locked(root) as folder:
        target = folder / 'source.json'
        if target.exists():
            previous = _read_json(target, 8192)
            if previous != value and replace is not True:
                raise UpdateError('Une autre autorité est déjà configurée ; ajouter --replace pour la remplacer explicitement.')
        _write_json(target, value)
    return {'configured': True, 'automatic': False, 'source': urllib.parse.urlsplit(url).netloc,
            'public_key_sha256': fingerprint}


def _safe_local_json(path, maximum=64 * 1024):
    try:
        return _read_json(path, maximum) if path.exists() else None
    except (UpdateError, OSError):
        return {'status': 'invalid', 'error': 'État local de mise à jour illisible.'}


def _project_attempt(value):
    if not isinstance(value, dict) or value.get('status') not in ACTIVE_ATTEMPTS:
        return value
    pid, started = value.get('helper_pid'), value.get('helper_start')
    if type(pid) is int and pid > 0 and isinstance(started, str) and _process_start(pid) != started:
        projected = dict(value)
        projected.update(status='interrupted', finished_at=projected.get('finished_at') or _now(),
                         message='Le processus de mise à jour a disparu ; aucun succès n’est affirmé.')
        return projected
    return value


def _settle_interrupted(folder):
    value = _safe_local_json(folder / 'attempt.json')
    projected = _project_attempt(value)
    if (isinstance(value, dict) and isinstance(projected, dict) and
            value.get('status') in ACTIVE_ATTEMPTS and projected.get('status') == 'interrupted'):
        _attempt(folder, projected)
    return projected


def status(n):
    """Read local update state only. Never performs a network request."""
    folder = _folder(n.ROOT)
    result = {'schema': 'tao.update.status.v1', 'current_version': n.NODE_VERSION,
              'configured': False, 'automatic': False, 'network_checked': False,
              'source': None, 'public_key_sha256': None, 'review': None, 'attempt': None}
    if not folder.exists():
        return result
    try:
        configured = _config(n.ROOT)
        result.update({'configured': True,
                       'source': urllib.parse.urlsplit(configured['release_url']).netloc,
                       'public_key_sha256': configured['public_key_sha256']})
    except (UpdateError, OSError) as exc:
        result['configuration_error'] = str(exc)
    review = _safe_local_json(folder / 'review.json')
    if (isinstance(review, dict) and review.get('schema') == REVIEW_SCHEMA and
            review.get('from_version') != n.NODE_VERSION):
        result['review_stale'] = True
        review = None
    result['review'] = review
    result['attempt'] = _project_attempt(_safe_local_json(folder / 'attempt.json'))
    return result


def _review(current_version, config, raw_manifest, signature, metadata_raw):
    manifest, legacy, fingerprint = _verify_signed_manifest(
        raw_manifest, signature, metadata_raw, config['trusted_public_key'],
        config['public_key_sha256'])
    target = manifest['version']
    available = _version(target) > _version(current_version)
    digest = hashlib.sha256(
        b'tao.update.review.v1\0' + raw_manifest + b'\0' + signature + b'\0' + metadata_raw
        + b'\0' + config['release_url'].encode('utf-8')).hexdigest()
    update = manifest.get('update') if not legacy else None
    installable = False
    reason = None
    if not available:
        reason = 'Cette release n’est pas plus récente que le runtime actif.'
    elif legacy:
        reason = 'Cette ancienne release ne déclare ni compatibilité ni migration ; installation automatique refusée.'
    elif _version(current_version) < _version(update['minimum_runtime']):
        reason = 'Le runtime actif est plus ancien que la version minimale annoncée.'
    elif update['state_migrations']:
        reason = 'Cette première version de l’updater n’applique pas de migration de mémoire privée.'
    else:
        installable = True
    installer = f'TAO_LINUX_{target}.run'
    return {
        'schema': REVIEW_SCHEMA,
        'review_digest': digest,
        'checked_at': _now(),
        'from_version': current_version,
        'version': target,
        'available': available,
        'installable': installable,
        'reason': reason,
        'signature_verified': True,
        'public_key_sha256': fingerprint,
        'source': urllib.parse.urlsplit(config['release_url']).netloc,
        'changes': update['changes'] if update else [],
        'minimum_runtime': update['minimum_runtime'] if update else None,
        'state_migrations': update['state_migrations'] if update else None,
        'installer': {'name': installer, **manifest['files'][installer]},
    }, manifest


def check(n):
    """Fetch and authenticate bounded public metadata after an explicit action."""
    with _locked(n.ROOT) as folder:
        attempt = _settle_interrupted(folder)
        if isinstance(attempt, dict) and attempt.get('status') in ACTIVE_ATTEMPTS:
            raise UpdateError('Une installation est déjà en cours.')
        config = _config(n.ROOT, verify_key=True)
        raw_manifest = _download(config['release_url'], 'release.json', MAX_MANIFEST_BYTES)
        signature = _download(config['release_url'], 'release.sig', 64, expected=64)
        metadata_raw = _download(config['release_url'], 'signing.json', MAX_METADATA_BYTES)
        review, _manifest = _review(n.NODE_VERSION, config, raw_manifest, signature, metadata_raw)
        _atomic(folder / 'release.json', raw_manifest)
        _atomic(folder / 'release.sig', signature)
        _atomic(folder / 'signing.json', metadata_raw)
        _write_json(folder / 'review.json', review)
    result = status(n)
    result['network_checked'] = True
    return result


def _stored_review(root, current_version, config):
    folder = _folder(root)
    raw_manifest = _read_regular(folder / 'release.json', MAX_MANIFEST_BYTES)
    signature = _read_regular(folder / 'release.sig', 64, exact=64)
    metadata_raw = _read_regular(folder / 'signing.json', MAX_METADATA_BYTES)
    expected, manifest = _review(current_version, config, raw_manifest, signature, metadata_raw)
    stored = _read_json(folder / 'review.json')
    # checked_at is local observation time, not signed material.
    if type(stored) is not dict or set(stored) != set(expected):
        raise UpdateError('Aperçu local de mise à jour invalide ; vérifier à nouveau.')
    comparable = dict(stored, checked_at=expected['checked_at'])
    if comparable != expected:
        raise UpdateError('Aperçu local différent de la release signée ; vérifier à nouveau.')
    return stored, manifest


def _attempt(folder, value):
    if type(value) is not dict or value.get('schema') != ATTEMPT_SCHEMA:
        raise UpdateError('État d’installation invalide.')
    _write_json(folder / 'attempt.json', value)


def _child_environment(root):
    allowed = ('HOME', 'PATH', 'LANG', 'LC_ALL', 'XDG_RUNTIME_DIR', 'XDG_CONFIG_HOME',
               'DBUS_SESSION_BUS_ADDRESS')
    result = {name: os.environ[name] for name in allowed if name in os.environ}
    result.setdefault('PATH', os.defpath)
    result.setdefault('LANG', 'C.UTF-8')
    result['TAO_ROOT'] = str(_absolute(root))
    return result


def _launch_helper(command, environment):
    return subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL, start_new_session=True, close_fds=True,
                            cwd='/', env=environment)


def install(n, review_digest, confirmed=False):
    """Download a verified installer and launch the existing rollback-capable installer."""
    if confirmed is not True or type(review_digest) is not str or not DIGEST.fullmatch(review_digest):
        raise UpdateError('Confirmation exacte de la release requise.')
    with _locked(n.ROOT) as folder:
        prior = _settle_interrupted(folder)
        if isinstance(prior, dict) and prior.get('status') in ACTIVE_ATTEMPTS:
            raise UpdateError('Une installation est déjà en cours.')
        config = _config(n.ROOT, verify_key=True)
        review, _manifest = _stored_review(n.ROOT, n.NODE_VERSION, config)
        if review['review_digest'] != review_digest:
            raise UpdateError('L’aperçu relu n’est plus le courant ; vérifier à nouveau.')
        if not review['available'] or not review['installable']:
            raise UpdateError(review.get('reason') or 'Cette release ne peut pas être installée automatiquement.')
        record = review['installer']
        payload = _download(config['release_url'], record['name'], record['size'], expected=record['size'])
        if hashlib.sha256(payload).hexdigest() != record['sha256']:
            raise UpdateError('L’installateur reçu diffère du manifeste signé.')
        package = folder / 'candidate.run'
        _atomic(package, payload, mode=0o700)
        attempt_id = secrets.token_hex(16)
        row = {'schema': ATTEMPT_SCHEMA, 'id': attempt_id, 'status': 'starting',
               'from_version': n.NODE_VERSION, 'version': review['version'],
               'review_digest': review_digest, 'started_at': _now(), 'finished_at': None,
               'helper_pid': None, 'helper_start': None,
               'message': 'Installation préparée ; redémarrage local en attente.'}
        _attempt(folder, row)
        command = [sys.executable, str(Path(__file__).resolve()), '_apply',
                   '--root', str(n.ROOT), '--attempt', attempt_id]
        try:
            process = _launch_helper(command, _child_environment(n.ROOT))
            if type(getattr(process, 'pid', None)) is int:
                row['helper_pid'] = process.pid
                row['helper_start'] = _process_start(process.pid)
                _attempt(folder, row)
        except OSError as exc:
            row.update(status='failed', finished_at=_now(),
                       message='Le processus d’installation n’a pas pu démarrer ; runtime actif conservé.')
            _attempt(folder, row)
            raise UpdateError(row['message']) from exc
    return row


def _apply(root, attempt_id):
    """Detached helper: revalidate local evidence, then run the signed installer."""
    root = _absolute(root)
    try:
        with _locked(root) as folder:
            row = _read_json(folder / 'attempt.json')
            if (type(row) is not dict or row.get('schema') != ATTEMPT_SCHEMA or
                    row.get('id') != attempt_id or row.get('status') != 'starting'):
                raise UpdateError('Tentative d’installation absente ou déjà consommée.')
            if row.get('helper_pid') not in (None, os.getpid()):
                raise UpdateError('La tentative appartient à un autre processus local.')
            row['helper_pid'] = os.getpid()
            row['helper_start'] = _process_start(os.getpid())
            config = _config(root, verify_key=True)
            review, _manifest = _stored_review(root, row.get('from_version'), config)
            if (review.get('review_digest') != row.get('review_digest') or
                    review.get('version') != row.get('version') or not review.get('installable')):
                raise UpdateError('Preuve de release différente avant installation.')
            package = folder / 'candidate.run'
            payload = _read_regular(package, review['installer']['size'],
                                    exact=review['installer']['size'])
            if hashlib.sha256(payload).hexdigest() != review['installer']['sha256']:
                raise UpdateError('Installateur local différent du manifeste signé.')
            row.update(status='installing', message='Installation signée en cours ; santé et retour arrière seront vérifiés.')
            _attempt(folder, row)
            # Give the HTTP response that authorized this transition time to
            # reach the browser before the installer stops the current daemon.
            time.sleep(1)
            result = subprocess.run([sys.executable, str(package)], stdin=subprocess.DEVNULL,
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                    env=_child_environment(root), cwd='/', check=False)
            if result.returncode:
                row.update(status='failed', finished_at=_now(),
                           message='Installation refusée ou interrompue ; aucun succès n’est affirmé. Consulter les journaux locaux.')
            else:
                row.update(status='installed', finished_at=_now(),
                           message='Nouveau runtime installé et santé locale confirmée.')
            _attempt(folder, row)
            return 0 if result.returncode == 0 else 1
    except (UpdateError, OSError, subprocess.SubprocessError) as exc:
        try:
            folder = _folder(root, create=True)
            row = _safe_local_json(folder / 'attempt.json')
            if not isinstance(row, dict) or row.get('schema') != ATTEMPT_SCHEMA:
                row = {'schema': ATTEMPT_SCHEMA, 'id': attempt_id, 'from_version': None,
                       'version': None, 'review_digest': None, 'started_at': _now()}
            row.update(status='failed', finished_at=_now(),
                       message='Installation non confirmée : ' + str(exc))
            _attempt(folder, row)
        except (UpdateError, OSError):
            pass
        return 1


def add_parser(subparsers):
    parser = subparsers.add_parser('update', help='Vérifier explicitement une release signée de Tao')
    actions = parser.add_subparsers(dest='action', required=True)
    configure_parser = actions.add_parser('configure', help='Choisir un canal et une clé publique obtenue séparément')
    configure_parser.add_argument('--release-url', required=True)
    configure_parser.add_argument('--trusted-key', required=True)
    configure_parser.add_argument('--replace', action='store_true')
    actions.add_parser('status', help='Lire l’état local sans réseau')
    actions.add_parser('check', help='Contacter maintenant le canal configuré')


def command(n, args):
    if args.action == 'configure':
        return configure(n, args.release_url, args.trusted_key, args.replace)
    if args.action == 'check':
        return check(n)
    return status(n)


def main(argv=None):
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('action', choices=['_apply'])
    parser.add_argument('--root', required=True)
    parser.add_argument('--attempt', required=True)
    arguments = parser.parse_args(argv)
    return _apply(arguments.root, arguments.attempt)


if __name__ == '__main__':
    raise SystemExit(main())
