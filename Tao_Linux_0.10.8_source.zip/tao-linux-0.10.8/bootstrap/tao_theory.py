"""Versioned vocabulary, integrity checks and inert local revision proposals."""
from __future__ import annotations
import hashlib, json, unicodedata, uuid
from pathlib import Path

LEGACY_V4_1={'id':'tao.origin.v4.unified','version':'4.1.0',
             'sha256':'09b5a067eb62fd5acc7e0485335017a7ecf8226b0dd6894d64553ad605d99b6b'}
LEGACY_V4_2={'id':'tao.origin.v4.unified','version':'4.2.0',
             'sha256':'0048e7479557ced8572df859a03a7680ceab03acbcaa47e9c9ca9f6db44e8ec6'}
KNOWN_LEGACIES=(LEGACY_V4_1,LEGACY_V4_2)


def known_legacy(value):
    return next((legacy for legacy in KNOWN_LEGACIES if value==legacy),None)


def canonical_path():
    here=Path(__file__).resolve().parent
    packaged=here/'theory.canonical.json'
    if packaged.exists(): return packaged
    if here.name=='bootstrap': return here.parent/'docs/theory.json'
    raise RuntimeError('Canon complet absent du runtime ; réinstaller une version vérifiée')


def unique_object(pairs):
    value={}
    for key,item in pairs:
        if key in value: raise ValueError('Clé dupliquée dans le canon : '+key)
        value[key]=item
    return value


def validate(data):
    try:
        if not isinstance(data,dict): raise ValueError('Canon objet requis')
        statuses=data['epistemic_contract']['statuses']; dictionary=data['dictionary']
        if not isinstance(dictionary,dict) or not dictionary: raise ValueError('Dictionnaire absent')
        models=data['formal_models']
        for key,m in models.items():
            for field in ('expression','domain','units','verification','status'):
                if not isinstance(m.get(field),str) or not m[field].strip(): raise ValueError('Modèle incomplet : '+key)
        for term,row in dictionary.items():
            if not isinstance(row.get('definition'),str) or not row['definition'].strip(): raise ValueError('Définition absente : '+term)
            if row.get('status') not in statuses: raise ValueError('Statut inconnu : '+term)
            refs=row.get('model_refs',[])
            if not isinstance(refs,list) or any(not isinstance(r,str) or r not in models for r in refs):
                raise ValueError('Référence mathématique inconnue : '+term)
        for alias,target in data.get('aliases',{}).items():
            if alias in dictionary or target not in dictionary: raise ValueError('Alias invalide : '+alias)
        required={'source_buffer','term','base_digest','proposed_definition','reason','evidence','counterexample','migration','rollback'}
        if not required<=set(data['revision_protocol']['proposal_requires']): raise ValueError('Protocole de révision incomplet')
    except (KeyError,TypeError,AttributeError) as exc:
        raise ValueError('Structure du canon invalide') from exc
    return data


def load(expected):
    raw=canonical_path().read_bytes()
    if hashlib.sha256(raw).hexdigest()!=expected['sha256']:
        raise RuntimeError('Empreinte du canon différente de la version du runtime ; fichiers conservés')
    data=validate(json.loads(raw,object_pairs_hook=unique_object))
    if any(data['meta'].get(k)!=expected[k] for k in ('id','version')):
        raise RuntimeError('Identité ou version du canon incompatible')
    return data


def summary(expected):
    data=load(expected); d=data['dictionary']
    return dict(expected,ok=True,term_count=len(d),model_count=len(data['formal_models']),
        terms_with_model=sum(bool(x.get('model_refs')) for x in d.values()),
        mathematical_proofs_verified=False,scope='structure_references_and_file_integrity')


def lookup(expected,term=None):
    data=load(expected); dictionary=data['dictionary']
    if term is None: return {'theory':summary(expected),'terms':sorted(dictionary),'aliases':data.get('aliases',{})}
    name=unicodedata.normalize('NFC',term.strip().lower().replace(' ','_'))
    name=data.get('aliases',{}).get(name,name)
    if name not in dictionary: raise ValueError('Terme absent du canon : '+term)
    row=dictionary[name]
    return {'term':name,**row,'theory':expected,
            'formalization':'explicit_model' if row.get('model_refs') else 'definition_only',
            'models':{key:data['formal_models'][key] for key in row.get('model_refs',[])},
            'proof_status':'not_a_mathematical_proof'}


def proposals(n):
    return n.load_state().get('theory_proposals',[])


def propose(n,term,buffer_id,definition,reason,evidence,counterexample,migration,rollback):
    current=lookup(n.THEORY,term)
    fields={'proposed_definition':definition,'reason':reason,'evidence':evidence,
            'counterexample':counterexample,'migration':migration,'rollback':rollback}
    for key,value in fields.items():
        if not isinstance(value,str) or not value.strip() or len(value)>4000:
            raise ValueError('Champ de révision requis, 4000 caractères maximum : '+key)
    if definition.strip()==current['definition'].strip(): raise ValueError('La définition proposée est identique')
    with n.LOCK:
        s=n.load_state(); b=s['buffers'].get(buffer_id)
        if not b or b.get('status')!='open': raise ValueError('Un tampon ouvert doit justifier la révision')
        rows=s.setdefault('theory_proposals',[])
        if len(rows)>=50: raise ValueError('Cinquante propositions conservées ; revue requise')
        row={'id':'theory-proposal:'+uuid.uuid4().hex,'status':'candidate','at':n.now(),
             'source':'human_report','source_buffer':buffer_id,'term':current['term'],
             'base_version':n.THEORY['version'],'base_digest':n.THEORY['sha256'],
             'previous_definition':current['definition'],'activation':'not_applied',
             **{key:value.strip() for key,value in fields.items()}}
        rows.append(row); n.atomic_json(n.STATE,s,backup=True)
        n.event('theory_revision_proposed',{'id':row['id'],'term':row['term'],'applied':False})
        return row
