"""Capability-aware device onboarding; owner actions stay explicit and scoped."""
import html
import json
import os
from urllib.parse import quote

import tao_devices as devices
from tao_ui import DRAFT_STORE_JS


GUIDE_JS = r'''
const deviceGuides={
 browser:{name:'Téléphone ou navigateur',text:'Ouvre l’adresse HTTPS de ton Tao et connecte ton compte propriétaire. Ce navigateur permet de discuter, de relire et de piloter les appareils autorisés. Le Tao hébergé reste accessible quand ton PC est éteint.',question:'Je veux utiliser Tao depuis un téléphone ou un navigateur. Aide-moi à ouvrir la bonne adresse et à retrouver mon compte. Explique ce qui reste accessible quand mon ordinateur est éteint.'},
 linux:{name:'Ordinateur Linux',text:'Avec Tao, Python, Git et Codex installés, ce Linux peut préparer des changements dans un dépôt choisi. Connecte son moteur avec le code ci-dessous, approuve cet appareil ici, puis lance « tao device run » sur le Linux. Codex utilise le compte connecté sur ce Linux ; sa présence ne prouve pas son authentification.',question:'Je veux connecter un Linux comme moteur d’exécution de Tao. Aide-moi à vérifier les prérequis avec tao device diagnose, à choisir mon dépôt et à comprendre les commandes connect puis run. Explique chaque blocage avant de proposer une installation.'},
 windows:{name:'Ordinateur Windows',text:'Le navigateur peut déjà piloter Tao. Cette version ne fournit pas de moteur natif Windows. Un environnement Linux compatible peut être étudié avec toi ; il ne devient pas autorisé automatiquement.',question:'Je veux utiliser Tao sur Windows. Aide-moi d’abord à me connecter avec mon navigateur. Si je veux y exécuter des tâches, examinons mes moyens et les prérequis d’un environnement Linux compatible ; ne présume pas qu’un moteur Windows existe déjà.'},
 mac:{name:'Mac',text:'Le navigateur peut déjà piloter Tao. Le moteur d’exécution de cette version est prévu pour Linux ; aucun adaptateur macOS n’est qualifié ici.',question:'Je veux utiliser Tao sur mon Mac. Aide-moi à retrouver Tao dans le navigateur et à distinguer ce pilotage d’un moteur d’exécution. Si je veux exécuter des tâches ici, conservons le besoin d’un adaptateur macOS avec ses prérequis et sa preuve attendue.'},
 other:{name:'Autre appareil',text:'Un navigateur compatible avec HTTPS peut ouvrir Tao. Pour exécuter des tâches, il faudra examiner le système, les ressources, les outils et un adaptateur compatible. Aucun accès n’est créé par la simple présence d’un appareil.',question:'Je veux connecter un autre appareil à Tao. Demande-moi son système, les moyens disponibles et ce que je souhaite faire. Distingue le pilotage par navigateur d’un moteur d’exécution et aide-moi à définir le plus petit adaptateur vérifiable.'}
};
function connectionQuestion(kind,problem){const guide=deviceGuides[kind]||deviceGuides.other;return guide.question+(problem.trim()?'\n\nCe que je constate : '+problem.trim():'')+'\n\nAide-moi pas à pas, sans transmettre de code d’appairage ni de secret dans la discussion. Chaque droit d’exécution reste à approuver explicitement.'}
function keepConnectionQuestion(storage,node,world,text){
 if(typeof text!=='string'||!text.trim()||text.length>6000)throw Error('Garde une question de 1 à 6 000 caractères.');
 const store=createDraftStore(storage,node,world);
 if(store.read()['dialogue-send'])throw Error('Un brouillon de discussion existe déjà. Reprends-le dans la discussion, puis ajoute cette question sans le remplacer.');
 if(!store.put('dialogue-send',{values:{'dialogue-text':text,'dialogue-intent':'understand'},base:{'dialogue-text':'','dialogue-intent':'auto'},revision:null,extra:{selectedFocus:null}}))throw Error('Le navigateur ne peut pas garder cette question. Copie le texte avant d’ouvrir la discussion.');
}
function shellQuote(value){return "'"+String(value).replace(/'/g,"'\"'\"'")+"'"}
'''


PAGE_JS = r'''
const $=id=>document.getElementById(id);
let view={revision:null,devices:[],jobs:[]},selectedJob=null,busy=false;
const terminal=new Set(['verified','failed','interrupted','cancelled','stale']);
const statuses={pending:'À approuver',approved:'Autorisé',revoked:'Accès révoqué',queued:'En attente de cet appareil',running:'Préparation en cours',review:'Changements à relire',verify_queued:'Tests en attente de cet appareil',verifying:'Tests en cours',verified:'Tests déclarés réussis par l’appareil',failed:'Essai échoué',interrupted:'Essai interrompu, sans relance automatique',cancelled:'Essai annulé',stale:'Contexte modifié : nouvelle préparation nécessaire'};
function scoped(path){const url=new URL(path,location.origin);url.searchParams.set('world',config.world);return url.pathname+url.search}
function el(tag,text,cls){const node=document.createElement(tag);if(text!==undefined)node.textContent=String(text);if(cls)node.className=cls;return node}
function notify(text,error=false){$('message').textContent=text;$('message').classList.toggle('error',error);$('message').hidden=false}
function choice(select,value,text){const option=el('option',text);option.value=value;select.appendChild(option)}
function action(parent,title,run,secondary=true){const button=el('button',title,secondary?'secondary':'');button.type='button';button.onclick=run;parent.appendChild(button);return button}
async function request(path,data){
 const options={cache:'no-store',credentials:'same-origin'};
 if(data!==undefined){options.method='POST';options.headers={'Content-Type':'application/json','X-Tao-Token':token};options.body=JSON.stringify(data)}
 let response;try{response=await fetch(scoped(path),options)}catch(error){throw Error('Connexion interrompue : le résultat n’est pas confirmé. Actualise l’état avant tout nouvel envoi.')}
 let result;try{result=await response.json()}catch(error){throw Error('La réponse est illisible. Actualise l’état avant tout nouvel envoi.')}
 if(response.status===401){const error=Error('Ta session a expiré. Reconnecte-toi, puis vérifie l’état avant de reprendre.');notify(error.message,true);const link=el('a',' Se reconnecter');link.href=config.login;$('message').appendChild(link);error.alreadyShown=true;throw error}
 if(!response.ok)throw Error(result.error||'La demande n’a pas été acceptée. Actualise l’état et vérifie les prérequis.');
 return result;
}
async function perform(run){if(busy)return;busy=true;document.body.setAttribute('aria-busy','true');try{await run()}catch(error){if(!error.alreadyShown)notify(error.message,true)}finally{busy=false;document.body.removeAttribute('aria-busy')}}
function capabilities(device){const p=device.presence||{};if(!device.last_seen_at)return 'Le moteur n’a pas encore annoncé ses moyens. Lance « tao device run » sur cet appareil.';return [p.platform||'Système non annoncé','Python : '+(p.python?'détecté':'manquant'),'Git : '+(p.git?'détecté':'manquant'),'Codex : '+(p.codex?'détecté, compte à vérifier':'manquant'),'Dépôt : '+(p.clean?'sans modification annoncée':'à vérifier'),'Tests : '+(p.allow_tests?'permis localement':'à autoriser sur le Linux')].join(' · ')}
function ready(device){const p=device.presence||{};return device.status==='approved'&&p.git===true&&p.python===true&&p.codex===true&&typeof p.repo_head==='string'&&p.repo_head.length===40}
function renderDevices(){
 const box=$('device-list');box.replaceChildren();
 if(!view.devices.length)box.appendChild(el('p','Aucun moteur connecté dans cet espace. Tu peux déjà utiliser ce navigateur pour discuter avec Tao.','muted'));
 for(const device of view.devices){const row=el('article',undefined,'card');row.append(el('h3',device.label),el('p',statuses[device.status]||device.status),el('p',capabilities(device),'muted'));
 if(device.pairing_label!==device.label)row.appendChild(el('p','Nom prévu : '+device.pairing_label,'small'));
 if(device.last_seen_at)row.appendChild(el('p','Dernière annonce reçue : '+device.last_seen_at+'. Cela ne garantit pas que l’appareil est encore connecté.','small'));
 const p=device.presence||{};if(p.repo_head)row.appendChild(el('p','Version du dépôt annoncée : '+p.repo_head,'small mono'));
 row.appendChild(el('p','Identifiant du moteur : '+device.machine_id,'small mono'));
 if(device.status==='pending')action(row,'Approuver cet appareil pour cet espace',()=>perform(async()=>{await request('/api/devices/device',{id:device.id,action:'approve',revision:view.revision});notify('Appareil autorisé. Lance son moteur pour annoncer ses moyens.');await refresh()}),false);
 if(device.status!=='revoked')action(row,'Révoquer cet accès',()=>perform(async()=>{await request('/api/devices/device',{id:device.id,action:'revoke',revision:view.revision});notify('Accès révoqué. Une exécution déjà commencée peut se poursuivre localement ; aucun nouveau travail ne sera confié.');await refresh()}));
 box.appendChild(row)}
 const select=$('job-device'),old=select.value;select.replaceChildren();choice(select,'','Choisir le Linux qui exécutera cet essai');
 for(const device of view.devices.filter(ready))choice(select,device.id,device.label+' · dernier état connu');
 if([...select.options].some(option=>option.value===old))select.value=old;
 $('enqueue').disabled=!config.buffers.some(b=>!b.stale)||!view.devices.some(ready);preview();
}
function renderJobs(){
 const box=$('job-list');box.replaceChildren();if(!view.jobs.length)box.appendChild(el('p','Aucun essai confié à un appareil dans cet espace.','muted'));
 for(const job of [...view.jobs].reverse()){const row=el('article',undefined,'card'),device=view.devices.find(x=>x.id===job.device_id);row.append(el('h3',(config.buffers.find(x=>x.id===job.buffer_id)||{}).residual||job.buffer_id),el('p',statuses[job.status]||job.status),el('p','Lieu d’exécution : '+(device?device.label:job.device_id),'muted'));
 if(job.reason)row.appendChild(el('p',job.reason));
 action(row,'Voir cet essai',()=>perform(()=>openJob(job.id)));box.appendChild(row)}
 const b=view.budget||{};$('budget').textContent='Aujourd’hui (UTC) : '+(b.runs_reserved||0)+' / '+(b.runs_limit??'?')+' générations réservées, '+(b.seconds_reserved||0)+' / '+(b.seconds_limit??'?')+' secondes réservées. Les réservations interrompues restent imputées. Budget commun aux espaces, distinct de l’atelier local. Tokens, euros et électricité non mesurés.';
 const active=(view.pairings||[]).filter(x=>!x.device_id);$('pairings-status').textContent=active.length?active.length+' code(s) encore en attente d’utilisation. Les codes ne peuvent pas être réaffichés.':'Aucun code d’appairage en attente.';
}
async function refresh(){view=await request('/api/devices');renderDevices();renderJobs();$('refresh-time').textContent='État reçu à '+new Date().toLocaleTimeString();}
function preview(){const buffer=config.buffers.find(x=>x.id===$('job-buffer').value),box=$('job-preview');box.replaceChildren();if(!buffer)return;for(const [label,key] of [['Écart à partager','residual'],['Résultat souhaité','goal'],['Preuve attendue','acceptance']]){box.append(el('h3',label),el('p',buffer[key]));}if(buffer.source_need)box.appendChild(el('p','Issu du besoin '+buffer.source_need.id+' · version '+buffer.source_need.revision+'. Seuls les trois champs ci-dessus partent au Linux.','small'));if(buffer.stale)box.appendChild(el('p','Le besoin d’origine a changé. Relis-le et prépare un nouveau tampon de code.','muted'));}
function previewNeed(){const need=config.needs.find(x=>x.id===$('source-need').value),box=$('need-preview');box.replaceChildren();$('project-need').disabled=true;if(!need)return;box.appendChild(el('p','Interprétation à vérifier : elle ne prouve pas que les faits sont exacts. Corrige-la dans sa pièce avant d’en faire un essai de code.','muted'));for(const [label,key] of [['Situation proposée','residual'],['Résultat souhaité proposé','goal'],['Vérification proposée','acceptance']])box.append(el('h3',label),el('p',need[key]));const link=el('a','Corriger ce besoin dans ma discussion');link.href=scoped('/?view=dialogue')+'#continuity-panel';box.appendChild(link);if(!need.residual.trim()||!need.goal.trim()||!need.acceptance.trim())box.appendChild(el('p','Précise la situation, le résultat et sa vérification dans la discussion avant de préparer un essai de code.','muted'));$('project-need').disabled=!need.residual.trim()||!need.goal.trim()||!need.acceptance.trim();}
async function openJob(id){
 const job=await request('/api/devices/job?id='+encodeURIComponent(id));selectedJob=job.id;const panel=$('job-detail');panel.replaceChildren();panel.hidden=false;
 panel.append(el('h2','Examiner cet essai'),el('p',statuses[job.status]||job.status));
 for(const [label,key] of [['Écart','residual'],['Résultat souhaité','goal'],['Preuve attendue','acceptance']])panel.append(el('h3',label),el('p',job[key]||''));
 if(job.reason)panel.appendChild(el('p',job.reason));
 const result=job.verification_result||job.generation_result;if(result){panel.append(el('h3','Retour déclaré par l’appareil'),el('p',result.summary||''));if(result.tests_summary)panel.appendChild(el('pre',result.tests_summary));if(result.elapsed_seconds!==undefined)panel.appendChild(el('p','Durée déclarée : '+result.elapsed_seconds+' s.','small'))}
 if(job.patch){panel.append(el('h3','Changements proposés'),el('pre',job.patch,'patch'))}
 panel.appendChild(el('p','Ces retours viennent du moteur appairé. Ils ne prouvent pas une exécution sur le serveur. Le dépôt source et le Tao en cours ne sont pas modifiés automatiquement.','muted'));
 if(job.status==='review'){
  const device=view.devices.find(x=>x.id===job.device_id),p=device&&device.presence||{};
  const form=el('form'),label=el('label',undefined,'consent'),check=el('input');check.type='checkbox';check.required=true;check.id='confirm-candidate';label.append(check,el('span','J’ai relu ces changements et j’autorise l’exécution de ce candidat sur le Linux choisi pour le tester.'));
  form.appendChild(label);const button=el('button','Tester ce candidat');button.type='submit';button.disabled=!p.allow_tests;form.appendChild(button);
  if(!p.allow_tests)form.appendChild(el('p','Sur le Linux, arrête le moteur avec Ctrl+C, lance « tao device permissions --allow-tests », puis « tao device run ». Reviens actualiser cette page avant d’autoriser les tests.','muted'));
  form.onsubmit=event=>{event.preventDefault();if(!check.checked)return;perform(async()=>{await request('/api/devices/job',{id:job.id,action:'verify',revision:job.revision,review_digest:job.review_digest,confirmed:check.checked});check.checked=false;notify('Tests confiés à cet appareil ; ils attendent sa disponibilité.');await refresh();await openJob(job.id)})};panel.appendChild(form);
 }
 if(job.status==='verified')panel.appendChild(el('p','Le candidat est conservé sur le Linux pour la suite. Cette version ne propose pas encore son intégration à distance. Le besoin reste ouvert jusqu’à une vérification dans ton usage.'));
 if(!terminal.has(job.status))action(panel,'Annuler la suite de cet essai',()=>perform(async()=>{await request('/api/devices/job',{id:job.id,action:'cancel',revision:job.revision});notify('Suite annulée. Une exécution déjà commencée peut encore finir sur le Linux.');await refresh();await openJob(job.id)}));
 action(panel,'Fermer les détails',()=>{selectedJob=null;panel.hidden=true;panel.replaceChildren()});panel.scrollIntoView({block:'start',behavior:'smooth'});
}
function guide(){const selected=deviceGuides[$('device-kind').value]||deviceGuides.other;$('guide-text').textContent=selected.text;$('linux-setup').hidden=$('device-kind').value!=='linux'}
$('device-kind').onchange=guide;guide();
$('no-needs-link').href=scoped('/?view=dialogue')+'#continuity-panel';
$('manual-buffer-link').href=scoped('/?view=dialogue')+'#advanced';
$('prepare-question').onclick=()=>{$('connection-question').value=connectionQuestion($('device-kind').value,$('connection-problem').value);$('question-panel').hidden=false;$('connection-question').focus()};
$('open-discussion').onclick=()=>{try{keepConnectionQuestion(sessionStorage,config.node,config.world,$('connection-question').value);location.href=scoped('/')+'#dialogue-text'}catch(error){notify(error.message,true)}};
$('pair-form').onsubmit=event=>{event.preventDefault();perform(async()=>{$('pair-secret').replaceChildren();$('pair-result').hidden=true;const result=await request('/api/devices/pair',{label:$('pair-label').value,revision:view.revision});$('pair-secret').textContent=result.code;$('pair-expiry').textContent='Valable jusqu’au '+result.expires_at+' ; une seule machine peut l’utiliser.';$('pair-result').hidden=false;notify('Code créé. Saisis-le uniquement dans la demande d’appairage du Linux.');await refresh()})};
$('hide-code').onclick=()=>{$('pair-secret').replaceChildren();$('pair-result').hidden=true};
$('pair-command').textContent='tao device diagnose\ntao device connect --server '+shellQuote(location.origin)+' --repo /chemin/vers/ton/depot\ntao device run';
$('refresh').onclick=()=>perform(async()=>{await refresh();if(selectedJob)await openJob(selectedJob);notify('État actualisé. Une autorisation de test doit être cochée après chaque revue.')});
$('job-buffer').onchange=preview;
function addBufferOption(buffer){const select=$('job-buffer');choice(select,buffer.id,buffer.residual+(buffer.stale?' · besoin modifié':''));select.options[select.options.length-1].disabled=!!buffer.stale;}
for(const buffer of config.buffers)addBufferOption(buffer);
if(!config.buffers.some(b=>!b.stale))$('no-buffers').hidden=false;
$('source-need').onchange=previewNeed;
for(const need of config.needs)choice($('source-need'),need.id,need.title);
if(!config.needs.length)$('no-needs').hidden=false;
$('project-form').onsubmit=event=>{event.preventDefault();perform(async()=>{const need=config.needs.find(x=>x.id===$('source-need').value);if(!need)throw Error('Choisis un besoin de cette pièce.');const result=await request('/api/devices/project-need',{need_id:need.id,need_revision:need.revision,expected_snapshot:{residual:need.residual,goal:need.goal,acceptance:need.acceptance}});if(!config.buffers.some(b=>b.id===result.id)){config.buffers.push({id:result.id,residual:result.residual,goal:result.desired,acceptance:result.acceptance,source_need:result.source_need,stale:false});addBufferOption(config.buffers[config.buffers.length-1]);} $('no-buffers').hidden=true;$('job-buffer').value=result.id;preview();renderDevices();notify(result.already_projected?'Ce tampon existe déjà. Relis-le puis choisis le Linux.':'Tampon de code préparé. Relis-le puis choisis le Linux si tu souhaites lancer un essai.');$('job-buffer').scrollIntoView({block:'center',behavior:'smooth'})})};
$('job-form').onsubmit=event=>{event.preventDefault();perform(async()=>{const buffer=config.buffers.find(x=>x.id===$('job-buffer').value);if(!buffer||buffer.stale)throw Error('Relis un tampon de code encore valable.');const result=await request('/api/devices/jobs',{device_id:$('job-device').value,buffer_id:buffer.id,revision:view.revision,expected_snapshot:{residual:buffer.residual,goal:buffer.goal,acceptance:buffer.acceptance}});notify('Essai confié au Linux choisi. Il restera en attente tant que son moteur ne peut pas le prendre.');await refresh();await openJob(result.id)})};
perform(refresh);
setInterval(()=>{if(!document.hidden&&!busy&&!selectedJob&&view.jobs.some(job=>['queued','running','verify_queued','verifying'].includes(job.status)))perform(refresh)},20000);
'''


def page(n, s):
    """Return owner HTML; the caller applies its usual world-scoped links."""
    existing = s.get('buffers', {})
    world = n.worlds.current()
    buffers = [{'id': b['id'], 'residual': b.get('residual', ''),
                'goal': b.get('desired', ''), 'acceptance': b.get('acceptance', ''),
                'source_need': b.get('source_need'),
                'stale': not devices._source_fresh(s, b, world)}
               for b in existing.values()
               if b.get('status') == 'open' and b.get('kind') in ('user', 'code_projection')
               and 'work_task' not in b and 'dialogue_need' not in b]
    needs = [{'id': b['id'], 'title': b['dialogue_need'].get('title', ''),
              'revision': b['dialogue_need'].get('revision'),
              'residual': b['dialogue_need'].get('current') or b['dialogue_need'].get('title', ''),
              'goal': b['dialogue_need'].get('desired', ''),
              'acceptance': b['dialogue_need'].get('acceptance', '')}
             for b in s.get('buffers', {}).values()
             if b.get('status') == 'open' and b.get('kind') == 'dialogue'
             and isinstance(b.get('dialogue_need'), dict)
             and b['dialogue_need'].get('phase') != 'paused']
    config = {'node': s['id'], 'world': n.worlds.current(), 'buffers': buffers, 'needs': needs,
              'login': '/host/login' if os.environ.get('TAO_HOSTED') == '1' else '/mobile/login'}
    # JSON embedded in a script must not let a user-controlled </script> end it.
    encoded = json.dumps(config, ensure_ascii=True).replace('<', '\\u003c')
    token = json.dumps(n.TOKEN).replace('<', '\\u003c')
    version = html.escape(n.NODE_VERSION, quote=True)
    home = html.escape('/?world=' + quote(world, safe=''), quote=True)
    return '''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tao · Mes appareils</title><style>
:root{color-scheme:light;--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.6 system-ui,sans-serif}main{max-width:900px;margin:auto;padding:28px 24px 60px}nav,.actions{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}nav{border-bottom:1px solid var(--line);padding-bottom:20px}.brand{font-size:24px;letter-spacing:.13em}header{padding:30px 0 20px}h1{font-size:clamp(30px,5vw,44px);line-height:1.15;margin:10px 0}h2{font-size:22px;margin:0 0 14px}h3{font-size:17px;margin:14px 0 6px}p{margin:9px 0}a{color:var(--accent)}section{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:24px;margin-bottom:20px;min-width:0;overflow-wrap:anywhere}.muted,.small,summary{color:var(--muted)}.small{font-size:13px}.eyebrow{color:var(--accent);font-size:12px;text-transform:uppercase;letter-spacing:.12em}label{display:block;margin:15px 0 6px}input,textarea,select{width:100%;max-width:100%;font:inherit;color:var(--text);background:#fffdfa;border:1px solid #b9c7bc;border-radius:8px;padding:12px}textarea{min-height:100px;resize:vertical}button{font:inherit;min-height:44px;max-width:100%;border:0;border-radius:9px;background:var(--accent);color:#fff;padding:11px 17px;font-weight:600;cursor:pointer;margin:12px 8px 4px 0}button.secondary{color:var(--text);background:transparent;border:1px solid #b9c7bc}button:disabled{opacity:.55;cursor:not-allowed}button:focus-visible,a:focus-visible,summary:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid var(--accent);outline-offset:3px}details{margin-top:18px}summary{min-height:44px;cursor:pointer}.card{padding:15px 0;border-top:1px solid var(--line)}.card:first-child{border-top:0}.mono,pre{font-family:ui-monospace,monospace}pre{font-size:13px;white-space:pre-wrap;overflow-wrap:anywhere;max-width:100%;background:#fffdfa;padding:14px;border-radius:8px}.patch{max-height:65vh;overflow:auto;white-space:pre}.consent{display:flex;align-items:start;gap:10px}.consent input{width:auto;margin-top:6px}.secret{border:1px solid var(--accent);padding:16px;border-radius:8px;margin-top:16px}#message{position:sticky;bottom:12px;padding:14px 18px;background:var(--accent);color:#fff;border-radius:10px;box-shadow:0 8px 25px rgba(39,55,47,.12)}#message.error{background:#fff1e6}#message a{color:inherit}#job-preview p,#need-preview p{white-space:pre-wrap}body[aria-busy=true] button{cursor:progress}[hidden]{display:none!important}@media(max-width:520px){main{padding:16px 14px 36px}section{padding:17px}header{padding-top:24px}button{width:100%;margin-right:0}nav a{min-height:44px;display:flex;align-items:center}.actions{display:block}}

/* Tao · maison : surfaces, typography and interaction */
:root{--bg:#f5f3ed;--panel:#fffdfa;--text:#27372f;--muted:#596860;--line:#d9ded5;--accent:#315a47;--soft:#edf1ea;--gold:#c79d67;color-scheme:light}
body{min-height:100vh;background:radial-gradient(circle at 88% -10%,#eee3d2,transparent 38%),var(--bg)}
nav{min-height:60px}.page-nav{display:flex;align-items:center;justify-content:space-between;gap:20px;padding-bottom:18px;border-bottom:1px solid var(--line)}.eyebrow{color:var(--accent);font:700 11px/1.5 system-ui,sans-serif;letter-spacing:.15em;text-transform:uppercase}nav .brand{font:600 29px/1 ui-serif,Georgia,serif;letter-spacing:-.045em;color:var(--text);text-decoration:none}
a{color:var(--accent);text-underline-offset:3px}a:hover,summary:hover{text-decoration-color:var(--gold)}
header{margin:26px 0 28px;padding:clamp(24px,4vw,42px);border:1px solid var(--line);border-top:3px solid var(--gold);border-radius:20px;background:linear-gradient(135deg,#fffdfa,#f6f1e8);box-shadow:0 12px 30px rgba(39,55,47,.045)}
header p:last-child{max-width:68ch}h1,h2,h3{font-family:ui-serif,Georgia,serif;letter-spacing:-.025em}h1{font-weight:500}h2,h3{font-weight:600}
section,.panel{box-shadow:0 6px 22px rgba(39,55,47,.035)}
button,.button{background:var(--accent);color:#fff}button.secondary,.button.secondary{background:var(--soft);color:var(--accent);border:1px solid var(--line)}
input:not([type=checkbox]):not([type=file]),textarea,select{background:var(--panel);color:var(--text);border-color:#b9c7bc}pre{background:#f3f1eb;color:var(--text);border:1px solid var(--line)}
button:focus-visible,a:focus-visible,summary:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid var(--accent);outline-offset:3px}
#message{background:#ecf1ea;color:var(--text);border:1px solid #b7cab8;box-shadow:0 8px 25px rgba(39,55,47,.12)}#message.error{background:#fff1e6;color:#613f2d;border-color:#dfb997}
@media(max-width:540px){header{margin:18px 0 20px;padding:23px 19px;border-radius:16px}}
</style></head><body><main><nav><a class="brand" href="''' + home + '''">tao.</a><a href="''' + home + '''">Retour à ma pièce</a></nav><header><p class="eyebrow">L’atelier · moyens</p><h1>Mes appareils.</h1><p>Depuis cette pièce, choisis le Linux qui préparera un essai. Tu reliras son travail et décideras des droits accordés à chaque étape.</p></header>
<section aria-labelledby="guide-title"><h2 id="guide-title">Connecter un appareil, pas à pas</h2><label for="device-kind">Quel appareil souhaites-tu utiliser ?</label><select id="device-kind"><option value="browser">Téléphone ou navigateur</option><option value="linux">Ordinateur Linux</option><option value="windows">Ordinateur Windows</option><option value="mac">Mac</option><option value="other">Autre appareil</option></select><p id="guide-text"></p><details><summary>Me faire aider par Tao</summary><label for="connection-problem">Ce qui bloque ou ce que tu veux faire (facultatif)</label><textarea id="connection-problem" maxlength="1500" placeholder="Mon système, ce que j’ai essayé, le message affiché… Ne copie pas de secret."></textarea><button id="prepare-question" type="button">Préparer ma question</button><div id="question-panel" hidden><label for="connection-question">La question à reprendre dans ma discussion</label><textarea id="connection-question" maxlength="6000"></textarea><button id="open-discussion" type="button">Reprendre dans ma discussion</button><p class="small">Un brouillon sera proposé pour relecture dans cette discussion. Aucun message n’est envoyé, aucun logiciel installé et aucun droit accordé par ce bouton.</p></div></details>
<div id="linux-setup" hidden><h3>Autoriser un moteur Linux</h3><p>Sur le Linux, Tao et les outils doivent être disponibles. Le dépôt choisi reste local à cette machine. Crée un code, lance la commande de connexion, puis approuve l’appareil qui apparaît ci-dessous.</p><form id="pair-form"><label for="pair-label">Un nom pour reconnaître cet appareil</label><input id="pair-label" maxlength="100" required placeholder="Mon portable Linux"><button>Créer un code d’appairage</button></form><div id="pair-result" class="secret" hidden><p>Code à saisir dans la demande d’appairage du Linux :</p><pre id="pair-secret"></pre><p id="pair-expiry" class="small"></p><p class="small">Il est affiché une seule fois ici. Ne le colle pas dans la discussion ni dans une URL.</p><button id="hide-code" class="secondary" type="button">Masquer le code</button></div><pre id="pair-command"></pre><p class="small">Le code est demandé sans l’inscrire dans la commande. Le moteur contacte Tao en sortie ; aucun port entrant sur le Linux n’est ouvert. Pour permettre ensuite des tests relus, arrête le moteur avec Ctrl+C, lance « tao device permissions --allow-tests », puis « tao device run ».</p><p id="pairings-status" class="small"></p></div></section>
<section aria-labelledby="devices-title"><div class="actions"><h2 id="devices-title">Appareils de cet espace</h2><button id="refresh" class="secondary" type="button">Actualiser l’état</button></div><p id="refresh-time" class="small">Lecture de l’état…</p><p class="muted">L’approbation autorise ce moteur à recevoir les essais que tu lui confies ici. Ses moyens sont déclarés par le moteur ; aucun autre espace ni application ne lui est ouvert automatiquement.</p><div id="device-list"></div></section>
<section aria-labelledby="work-title"><h2 id="work-title">Confier un essai de code</h2><p>Choisis l’écart à traiter et le Linux qui préparera les changements. Si cet appareil est indisponible, l’essai attend ; aucun calcul payant n’est relancé ailleurs automatiquement.</p><details><summary>Partir d’un besoin discuté avec Tao</summary><p>Si une modification de Tao peut aider, relis ce besoin avant d’en faire un tampon de code. Le besoin d’origine reste ouvert ; créer ce tampon ne lance ni IA ni machine. Après une correction dans un autre onglet, recharge cette page.</p><form id="project-form"><label for="source-need">Un besoin de cette pièce</label><select id="source-need" required><option value="">Choisir un besoin</option></select><p id="no-needs" class="muted" hidden>Il n’y a pas encore de besoin discuté ici. <a id="no-needs-link" href="#">Reprendre la discussion</a>.</p><div id="need-preview"></div><button id="project-need" disabled>Préparer un tampon de code</button></form></details><form id="job-form"><label for="job-buffer">L’écart à traiter</label><select id="job-buffer" required><option value="">Choisir un tampon de code</option></select><p id="no-buffers" class="muted" hidden>Aucun tampon de code ouvert. <a id="manual-buffer-link" href="#">Décris une différence à expérimenter</a> avec son résultat souhaité et sa preuve attendue.</p><div id="job-preview"></div><label for="job-device">L’appareil qui exécutera l’essai</label><select id="job-device" required><option value="">En attente des appareils</option></select><p class="small">Seuls l’écart, le résultat souhaité et la preuve attendue sélectionnés ici sont transmis pour cet essai. La génération lance Codex sur le Linux avec son compte fournisseur ; Codex peut exécuter des commandes dans son bac à sable pendant cette préparation. Le code proposé reste dans une copie séparée. Tu le reliras avant d’autoriser la phase supplémentaire de tests du projet.</p><button id="enqueue" disabled>Confier cet essai au Linux choisi</button></form><details><summary>Comprendre le budget et les limites</summary><p id="budget"></p><p class="small">Cette limite concerne la génération de code distribuée. Elle ne mesure ni le prix de l’abonnement IA ni la facture d’hébergement. Les fichiers et applications métier ne sont pas synchronisés par ce mécanisme.</p></details></section>
<section aria-labelledby="jobs-title"><h2 id="jobs-title">Mes essais</h2><div id="job-list"></div></section><section id="job-detail" hidden aria-label="Revue de cet essai"></section><footer class="small">Tao ''' + version + ''' · Moteur d’exécution Linux ; pilotage depuis un navigateur compatible.</footer><div id="message" role="status" aria-live="polite" hidden></div></main><script>
const token=''' + token + ''';
const config=''' + encoded + ''';
''' + DRAFT_STORE_JS + GUIDE_JS + PAGE_JS + '\n</script></body></html>'
