"""Import a reviewed, attributed history into private spaces as fallible data.

No source becomes a local human message and no imported string is executable.
The complete transaction is stored once in state.json. Sources and receipts live
inside the already-private continuity field, so older world-aware runtimes keep
both their isolation and the owner's later corrections on rollback.
"""
import copy
import hashlib
import json
import re
import unicodedata

import tao_continuity as continuity
import tao_worlds as worlds
from tao_work import text_field

SCHEMA = 'tao.history_import.v1'
MAX_DOCUMENT_BYTES = 262144
MAX_SPACES = 12
MAX_SOURCES = 80
MAX_PACKAGES = 20
MAX_HISTORY_BYTES = 1048576
_NOTICE = ('Import extérieur non authentifié : les rôles et observations sont déclarés, '
           'les synthèses restent à vérifier. Aucune permission ni action n’est importée.')


def _bytes(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                      allow_nan=False).encode('utf-8')


def _digest(value):
    return hashlib.sha256(_bytes(value)).hexdigest()


def _object(value, fields, label):
    if not isinstance(value, dict) or set(value) != set(fields):
        raise ValueError(label + ' : champs manquants ou inattendus ; seules les données prévues sont acceptées.')


def _slug(value, label):
    if not isinstance(value, str) or not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,79}', value):
        raise ValueError(label + ' : identifiant de 1 à 80 caractères minuscules, chiffres, tirets ou soulignés.')
    return value


def _refs(value, sources):
    if (not isinstance(value, list) or not value or len(value) > MAX_SOURCES or
            any(not isinstance(ident, str) or ident not in sources for ident in value) or
            len(set(value)) != len(value)):
        raise ValueError('Chaque élément doit citer des identifiants sources distincts et présents dans le paquet.')
    return list(value)


def _name(value):
    return unicodedata.normalize('NFKC', value).strip().casefold()


def validate(document):
    """Return an independent strict JSON document or reject the whole package."""
    try:
        encoded = _bytes(document)
    except (TypeError, ValueError, UnicodeError, RecursionError) as exc:
        raise ValueError('Un document JSON simple est requis.') from exc
    if len(encoded) > MAX_DOCUMENT_BYTES:
        raise ValueError('Le paquet dépasse 256 Kio ; sélectionner moins de contenu.')
    _object(document, ('schema', 'id', 'title', 'sources', 'spaces'), 'Paquet')
    if document['schema'] != SCHEMA:
        raise ValueError('Version du paquet d’histoires inconnue.')
    clean = {'schema': SCHEMA, 'id': _slug(document['id'], 'Paquet'),
             'title': text_field(document['title'], 'Le titre du paquet', 120, True),
             'sources': [], 'spaces': []}
    sources = document['sources']
    if not isinstance(sources, list) or not 1 <= len(sources) <= MAX_SOURCES:
        raise ValueError('Entre une et 80 sources sont nécessaires.')
    indexed = {}
    for row in sources:
        _object(row, ('id', 'label', 'kind', 'text'), 'Source')
        ident = _slug(row['id'], 'Source')
        if ident in indexed:
            raise ValueError('Identifiant source dupliqué.')
        if not isinstance(row['kind'], str) or row['kind'] not in ('user_quote', 'reported_observation', 'assistant_summary'):
            raise ValueError('Nature de source inconnue.')
        source = {'id': ident, 'label': text_field(row['label'], 'Le libellé source', 160, True),
                  'kind': row['kind'], 'text': text_field(row['text'], 'Le texte source', 6000, True)}
        indexed[ident] = source
        clean['sources'].append(source)
    spaces = document['spaces']
    if not isinstance(spaces, list) or not 1 <= len(spaces) <= MAX_SPACES:
        raise ValueError('Entre un et douze espaces par import.')
    keys, names = set(), set()
    for row in spaces:
        _object(row, ('key', 'parent_key', 'title', 'description', 'story', 'source_ids', 'notes', 'needs'), 'Espace')
        key = _slug(row['key'], 'Espace')
        if key in keys:
            raise ValueError('Clé d’espace dupliquée.')
        keys.add(key)
        title = text_field(row['title'], 'Le titre de l’espace', 120, True)
        if _name(title) in names:
            raise ValueError('Deux espaces portent le même nom dans ce paquet.')
        names.add(_name(title))
        parent = row['parent_key']
        if key == worlds.MAIN:
            if parent is not None:
                raise ValueError('L’espace principal ne peut avoir de parent.')
        else:
            _slug(parent, 'Parent')
        space = {'key': key, 'parent_key': parent, 'title': title,
                 'description': text_field(row['description'], 'La description', 1000),
                 'story': text_field(row['story'], 'L’histoire proposée', 2000),
                 'source_ids': _refs(row['source_ids'], indexed), 'notes': [], 'needs': []}
        for collection, maximum in (('notes', 12), ('needs', 8)):
            if not isinstance(row[collection], list) or len(row[collection]) > maximum:
                raise ValueError('Douze notes et huit besoins maximum par espace.')
            for item in row[collection]:
                if collection == 'notes':
                    _object(item, ('kind', 'text', 'source_ids'), 'Note')
                    if not isinstance(item['kind'], str) or item['kind'] not in continuity.NOTE_KINDS:
                        raise ValueError('Type de note inconnu.')
                    data = {'kind': item['kind'], 'text': text_field(item['text'], 'La note', 800, True)}
                else:
                    _object(item, tuple(continuity.NEED_LIMITS) + ('source_ids',), 'Besoin')
                    data = {field: text_field(item[field], field, limit, field == 'title')
                            for field, limit in continuity.NEED_LIMITS.items()}
                data['source_ids'] = _refs(item['source_ids'], indexed)
                space[collection].append(data)
        clean['spaces'].append(space)
    by_key = {row['key']: row for row in clean['spaces']}
    for row in clean['spaces']:
        seen, key = set(), row['key']
        while key != worlds.MAIN:
            if key in seen or key not in by_key:
                raise ValueError('Parent absent du paquet ou hiérarchie cyclique.')
            seen.add(key)
            if len(seen) > worlds.MAX_DEPTH:
                raise ValueError('Six niveaux sous l’espace principal maximum.')
            key = by_key[key]['parent_key']
    used_sources = {ident for row in clean['spaces'] for ident in row['source_ids']}
    used_sources.update(ident for row in clean['spaces'] for item in row['notes'] + row['needs']
                        for ident in item['source_ids'])
    if set(indexed) != used_sources:
        raise ValueError('Une source n’est attribuée à aucun espace ; la rattacher ou la retirer avant import.')
    return clean


def _history(destination):
    memory = destination.get('continuity', {})
    if not isinstance(memory, dict):
        raise ValueError('Mémoire de continuité invalide.')
    result = copy.deepcopy(memory.get('history_imports', {'schema': SCHEMA, 'packages': {}}))
    if (not isinstance(result, dict) or set(result) != {'schema', 'packages'} or
            result.get('schema') != SCHEMA or not isinstance(result['packages'], dict)):
        raise ValueError('Historique des imports invalide.')
    if len(result['packages']) > MAX_PACKAGES or len(_bytes(result)) > MAX_HISTORY_BYTES:
        raise ValueError('Historique des imports saturé ; aucune trace supprimée.')
    return result


def _principal():
    if worlds.current() != worlds.MAIN:
        raise ValueError('Importer les histoires depuis l’espace principal du propriétaire.')


def _story_notes(space):
    # The main story lives in a separate file and is never replaced by an import.
    # Bounded ordinary notes keep every proposed word editable with existing UI.
    if (space['key'] != worlds.MAIN and space.get('story_mode') != 'append_context') or not space['story']:
        return []
    text = space['story']
    return [{'kind': 'context', 'text': text[start:start + 800],
             'source_ids': list(space['source_ids'])} for start in range(0, len(text), 800)]


def _archived(existing, ident):
    return any(existing[key].get('archived') is True for key in worlds._path(existing, ident))


def suggested_targets(raw, semantic_keys):
    """Only template identity, never a matching title, suggests a destination.

    Callers supply known semantic keys, not imported text or human names. Every
    suggestion is visible in the review and can be replaced before approval.
    """
    existing = worlds._registry(raw)['spaces']
    by_key = {}
    for ident, row in existing.items():
        key = row.get('template_key')
        if isinstance(key, str) and not _archived(existing, ident):
            by_key.setdefault(key, []).append(ident)
    return {key: by_key[semantic][0] for key, semantic in semantic_keys.items()
            if len(by_key.get(semantic, [])) == 1}


def _target_ids(raw, document, targets, previous):
    spaces = document['spaces']
    existing = worlds._registry(raw)['spaces']
    keys = {row['key'] for row in spaces}
    document_digest = _digest(document)
    generated = {row['key']: (worlds.MAIN if row['key'] == worlds.MAIN else
                 _digest([SCHEMA, document['id'], document_digest, row['key']])[:12]) for row in spaces}
    previous_ids = None
    if previous is not None:
        rows = previous['receipt'].get('spaces')
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            raise ValueError('Le reçu de cet import est incomplet ; aucune fusion automatique.')
        previous_ids = {row.get('key'): row.get('id') for row in rows}
        if set(previous_ids) != keys or len(rows) != len(keys):
            raise ValueError('Les destinations du reçu sont incomplètes ; aucune fusion automatique.')
    if targets is None:
        targets = ({key: ident for key, ident in previous_ids.items() if ident != generated[key]}
                   if previous_ids is not None else suggested_targets(raw, {key: key for key in keys}))
    if not isinstance(targets, dict) or set(targets) - keys:
        raise ValueError('Destinations attendues : une clé du paquet et un identifiant d’espace existant.')
    targets = copy.deepcopy(targets)
    for key, ident in targets.items():
        worlds._identifier(ident)
        if ident not in existing:
            raise ValueError('La destination choisie n’existe pas ; relancer la prévisualisation.')
        if key == worlds.MAIN and ident != worlds.MAIN:
            raise ValueError('Le contexte principal doit rester dans l’espace principal.')
        if previous is None and _archived(existing, ident):
            raise ValueError('La destination est archivée ; la restaurer explicitement avant d’importer.')
    ids = dict(generated, **targets)
    if len(set(ids.values())) != len(ids):
        raise ValueError('Deux parties du paquet ciblent le même espace ; choisir des destinations distinctes.')
    if previous_ids is not None and ids != previous_ids:
        raise ValueError('Les destinations de ce paquet déjà importé ont changé ; aucun déplacement ni nouvel import automatique.')
    return ids, targets


def _prepare(n, raw, document, targets=None):
    registry = worlds._registry(raw)
    main_history = _history(raw)
    document_digest = _digest(document)
    previous = main_history['packages'].get(document['id'])
    if previous is not None:
        if not isinstance(previous, dict) or previous.get('document_digest') != document_digest:
            raise ValueError('Ce nom de paquet a déjà servi pour un autre contenu ; choisir un nouvel identifiant.')
        if not isinstance(previous.get('receipt'), dict):
            raise ValueError('Le reçu de cet import est incomplet ; aucune fusion automatique.')
    ids, targets = _target_ids(raw, document, targets, previous)
    ids[worlds.MAIN] = worlds.MAIN
    existing = registry['spaces']
    plans = []
    for space in document['spaces']:
        ident = ids[space['key']]
        parent_id = ids[space['parent_key']] if space['parent_key'] is not None else None
        if ident in existing and ident != worlds.MAIN and previous is None and space['key'] not in targets:
            raise ValueError('Identifiant d’espace déjà présent ; aucune fusion silencieuse.')
        if previous is None and ident not in existing and any(_name(row['title']) == _name(space['title']) for row in existing.values()):
            raise ValueError('Un espace porte déjà le nom « ' + space['title'] + ' » ; renommer la proposition avant import.')
        if previous is not None and ident not in existing:
            raise ValueError('Un espace de cet import manque ; aucune recréation automatique.')
        local_refs = set(space['source_ids'])
        for item in space['notes'] + space['needs']:
            local_refs.update(item['source_ids'])
        proposal = dict(copy.deepcopy(space), id=ident, parent_id=parent_id,
                        existing=ident in existing,
                        sources=[copy.deepcopy(row) for row in document['sources'] if row['id'] in local_refs],
                        story_mode='append_context' if ident in existing else 'proposed_story')
        proposal['story_note_count'] = len(_story_notes(proposal))
        if ident in existing:
            proposal.update(title=existing[ident]['title'], proposed_title=space['title'],
                            description=existing[ident].get('description', ''),
                            proposed_description=space['description'],
                            parent_id=existing[ident].get('parent_id'),
                            notice='Espace déjà présent : son nom, sa description, son parent et son histoire '
                                   'sont conservés. Le récit importé est ajouté comme contexte proposé.')
        plans.append(proposal)
    new_count = sum(not row['existing'] for row in plans)
    if len(existing) + new_count > worlds.MAX_SPACES:
        raise ValueError('Cet import dépasserait vingt espaces ; rien n’a été ajouté.')
    # Include human-edited material and inventory constraints, not changing CPU,
    # timing, observations or basal-cycle counters.
    relevant = {'node_id': raw.get('id'), 'registry': registry,
                'main_continuity': raw.get('continuity'), 'main_dialogue': raw.get('dialogue'),
                'main_story': n.story(),
                'private_buffers': {ident: row for ident, row in raw.get('buffers', {}).items()
                                    if worlds._private_buffer(ident, row)},
                'shared_capacity': sorted((ident, row.get('status')) for ident, row in raw.get('buffers', {}).items()
                                          if not worlds._private_buffer(ident, row))}
    # The registry includes child private content. Only its metadata determines
    # collision and hierarchy checks; unrelated private conversations are not
    # authority for this import and do not invalidate its preview.
    relevant['registry'] = {'schema': registry['schema'], 'revision': registry['revision'],
                            'spaces': {key: worlds._metadata(row) for key, row in existing.items()}}
    # Bind only selected existing private contexts. A human correction to their
    # story, memory or needs expires approval; unrelated private work does not.
    relevant['selected_contexts'] = {ident: {field: copy.deepcopy(existing[ident].get(field))
                                           for field in ('story', 'continuity', 'dialogue', 'work_context',
                                                         'presentation', 'buffers')}
                                    for ident in targets.values() if ident != worlds.MAIN}
    review_digest = _digest({'document_digest': document_digest, 'targets': targets, 'target': relevant})
    counts = {'spaces': len(plans), 'new_spaces': new_count,
              'notes': sum(len(row['notes']) + row['story_note_count'] for row in plans),
              'needs': sum(len(row['needs']) for row in plans),
              'sources': len(document['sources'])}
    preview = {'schema': 'tao.history_import.preview.v1', 'id': document['id'], 'title': document['title'],
               'document_digest': document_digest, 'review_digest': review_digest,
               'already_imported': previous is not None, 'spaces': plans, 'counts': counts, 'notice': _NOTICE,
               'targets': targets,
               'target_options': [worlds._metadata(row) for ident, row in existing.items()
                                  if not _archived(existing, ident)]}
    return preview, previous, registry


def _quote(document, plan, refs):
    primary = next(row for row in plan['sources'] if row['id'] == refs[0])
    return {'message_id': 'external:' + _digest([document['id'], primary['id']])[:24],
            'quote': primary['text'][:600], 'quote_truncated': len(primary['text']) > 600,
            'at': None, 'reply_id': None, 'message_source': 'external_history_import',
            'source_kind': primary['kind'], 'source_label': primary['label'],
            'role_authenticated': False, 'verification': 'unverified',
            'package_id': document['id'], 'source_id': primary['id']}


def _mutate(n, raw, document, plan, registry):
    """Prepare a complete detached next state; failures never touch disk."""
    result = copy.deepcopy(raw)
    registry = copy.deepcopy(registry)
    result['worlds'] = registry
    now = n.now()
    receipt = {'schema': 'tao.history_import.receipt.v1', 'id': document['id'], 'title': document['title'],
               'document_digest': plan['document_digest'], 'review_digest': plan['review_digest'],
               'imported_at': now, 'already_imported': False, 'spaces': [], 'counts': copy.deepcopy(plan['counts']),
               'targets': copy.deepcopy(plan['targets'])}
    for space in plan['spaces']:
        ident = space['id']
        if ident == worlds.MAIN:
            destination = result
        elif space['existing']:
            destination = registry['spaces'][ident]
        else:
            destination = {'id': ident, 'title': space['title'], 'parent_id': space['parent_id'],
                           'description': space['description'], 'buffers': {}}
            registry['spaces'][ident] = destination
        destination.setdefault('buffers', {})
        memory = continuity.ensure(destination)
        history = _history(destination)
        if len(history['packages']) >= MAX_PACKAGES:
            raise ValueError('Vingt imports conservés dans cet espace ; aucune trace supprimée.')
        notes = space['notes'] + _story_notes(space)
        if (len(memory['notes']) + len(notes) > continuity.MAX_NOTES or
                len(continuity._needs(destination)) + len(space['needs']) > continuity.MAX_NEEDS or
                len(n.open_buffers(destination)) + len(space['needs']) > continuity.MAX_NEEDS or
                len(memory['events']) + len(notes) + len(space['needs']) + 1 > continuity.MAX_EVENTS):
            raise ValueError('La mémoire ou le suivi des besoins de cet espace est plein ; aucun élément importé.')
        source_refs = list(space['source_ids'])
        if ident == worlds.MAIN:
            story = n.story()
        elif space['existing']:
            story = copy.deepcopy(destination.get('story', {}))
        else:
            story = {'schema': 'tao.story.v1', 'id': 'story:' + ident, 'status': 'proposed',
                     'authority': 'context_only', 'source': 'external_history_import', 'verification': 'unverified',
                     'text': space['story'] or space['description'] or space['title'],
                     'source_quote': _quote(document, space, source_refs), 'source_ids': source_refs,
                     'execution_enabled': False}
        if ident != worlds.MAIN and not space['existing']:
            destination['story'] = story
        origin_story = {'id': story.get('id'), 'text': str(story.get('text', ''))[:1200],
                        'text_truncated': len(str(story.get('text', ''))) > 1200, 'digest': _digest(story)}
        retained = {'key': space['key'], 'id': ident, 'title': space['title'],
                    'parent_id': space['parent_id'], 'note_ids': [], 'need_ids': []}
        for collection, rows in (('notes', notes), ('needs', space['needs'])):
            for index, item in enumerate(rows):
                fingerprint = _digest([SCHEMA, plan['document_digest'], space['key'], collection, index])
                item_id = ('note:' if collection == 'notes' else 'user:dialogue:') + fingerprint[:20]
                row = {'id': item_id, 'fingerprint': fingerprint, 'at': now, 'updated_at': now,
                       'source': 'external_history_import', 'verification': 'unverified',
                       'source_quote': _quote(document, space, item['source_ids']),
                       'source_ids': list(item['source_ids']), 'import_id': document['id'],
                       'history': [], 'revision': 1, 'execution_enabled': False,
                       'origin_story_id': story.get('id'), 'origin_story': copy.deepcopy(origin_story)}
                if collection == 'notes':
                    row.update(kind=item['kind'], text=item['text'], status='proposed', authority='context_only')
                    if any(prior['id'] == item_id for prior in memory['notes']):
                        raise ValueError('Une note porte déjà cet identifiant ; aucune fusion automatique.')
                    memory['notes'].append(row)
                    retained['note_ids'].append(item_id)
                else:
                    row.update({field: item[field] for field in continuity.NEED_LIMITS})
                    row.update(schema='tao.dialogue.need.v1', phase='to_clarify', focused=False,
                               authority='description_only', task_ids=[])
                    if item_id in destination['buffers']:
                        raise ValueError('Un besoin porte déjà cet identifiant ; aucune fusion automatique.')
                    buffer = n.make_buffer(item_id, 'dialogue', item['current'] or item['title'], authority='human')
                    buffer.update(desired=item['desired'], acceptance=item['acceptance'], dialogue_need=row,
                                  story_id=story.get('id'), execution_enabled=False)
                    destination['buffers'][item_id] = buffer
                    retained['need_ids'].append(item_id)
                continuity._event(n, memory, 'note_proposed' if collection == 'notes' else 'need_proposed',
                                  item_id, 'external_history_import')
        continuity._event(n, memory, 'history_imported', document['id'], 'external_history_import')
        package = {'document_digest': plan['document_digest'], 'imported_at': now,
                   'sources': copy.deepcopy(space['sources']),
                   'story_proposal': {'text': space['story'], 'source_ids': source_refs, 'verification': 'unverified'},
                   'note_ids': retained['note_ids'], 'need_ids': retained['need_ids']}
        history['packages'][document['id']] = package
        memory['history_imports'] = history
        if len(_bytes(history)) > MAX_HISTORY_BYTES:
            raise ValueError('Historique privé des imports plein ; aucun élément importé.')
        receipt['spaces'].append(retained)
    # The root receipt contains only inventory metadata. Child quotations never
    # cross into principal continuity; each source is retained where selected.
    main_memory = continuity.ensure(result)
    main_history = _history(result)
    root_package = main_history['packages'].setdefault(document['id'], {
        'document_digest': plan['document_digest'], 'imported_at': now,
        'sources': [], 'story_proposal': None, 'note_ids': [], 'need_ids': []})
    root_package['receipt'] = copy.deepcopy(receipt)
    if len(main_history['packages']) > MAX_PACKAGES or len(_bytes(main_history)) > MAX_HISTORY_BYTES:
        raise ValueError('Historique privé des imports plein ; aucun élément importé.')
    main_memory['history_imports'] = main_history
    if plan['counts']['new_spaces']:
        registry['revision'] += 1
    worlds._registry(result)
    return result, receipt


def preview(n, document, targets=None):
    _principal()
    document = validate(document)
    with n.LOCK:
        raw = n.load_raw_state()
        plan, previous, registry = _prepare(n, raw, document, targets=targets)
        if previous is None:
            _mutate(n, raw, document, plan, registry)  # Full capacity check, without writes.
        return plan


def destinations(n, document, targets=None):
    """Offer metadata for correcting a blocked preview; this authorizes nothing."""
    _principal()
    document = validate(document)
    with n.LOCK:
        raw = n.load_raw_state()
        existing = worlds._registry(raw)['spaces']
        if targets is None:
            targets = suggested_targets(raw, {row['key']: row['key'] for row in document['spaces']})
        return {'targets': copy.deepcopy(targets), 'already_imported': False,
                'spaces': [{key: row[key] for key in ('key', 'title')} for row in document['spaces']],
                'target_options': [worlds._metadata(row) for ident, row in existing.items()
                                   if not _archived(existing, ident)],
                'notice': 'Choisir les destinations, puis préparer un aperçu complet avant toute confirmation.'}


def apply(n, document, review_digest, confirmed=False, _attach=None, targets=None):
    """Apply data once; _attach is a trusted Python hook, never a JSON field.

    Archive import may attach private per-space descriptors to the detached
    result before its single commit. The hook is not rerun for a prior receipt.
    """
    _principal()
    document = validate(document)
    if _attach is not None and not callable(_attach):
        raise ValueError('Extension interne d’import invalide.')
    if confirmed is not True:
        raise ValueError('Confirmer l’import des espaces, notes et besoins prévisualisés.')
    if not isinstance(review_digest, str) or not re.fullmatch(r'[a-f0-9]{64}', review_digest):
        raise ValueError('Prévisualiser ce paquet avant de confirmer son import.')
    with n.LOCK:
        raw = n.load_raw_state()
        plan, previous, registry = _prepare(n, raw, document, targets=targets)
        if previous is not None:
            return dict(copy.deepcopy(previous['receipt']), already_imported=True)
        if plan['review_digest'] != review_digest:
            raise ValueError('Le contenu ou les espaces ont changé depuis la prévisualisation ; la relancer.')
        result, receipt = _mutate(n, raw, document, plan, registry)
        if _attach is not None:
            _attach(n, result, {row['key']: row['id'] for row in receipt['spaces']})
        n.atomic_json(n.STATE, result, backup=True)
        n.WAKE.set()
        return receipt
