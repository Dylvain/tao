"""Owner entry points for private history imports and read-only local inventory."""
import base64
import binascii
import io
import json
import stat
import sys
import zipfile
import zlib
from urllib.parse import parse_qs, urlsplit

import tao_onboarding as onboarding
import tao_history_store as history

MAX_JSON_BYTES = 16 * 1024 * 1024
MAX_ZIP_BYTES = 16 * 1024 * 1024
MAX_ZIP_ENTRIES = 10000
# A 16 MiB ZIP grows to about 21.4 MiB when carried as base64 in JSON.
MAX_BODY = 24 * 1024 * 1024


def _zip_history(value):
    """Read one conversations.json from an in-memory ZIP without extracting files."""
    maximum_encoded = 4 * ((MAX_ZIP_BYTES + 2) // 3)
    if not isinstance(value, str) or not value or len(value) > maximum_encoded:
        raise ValueError('Archive ZIP absente ou trop grande ; la limite est de 16 Mio.')
    try:
        raw = base64.b64decode(value.encode('ascii'), validate=True)
    except (UnicodeEncodeError, binascii.Error, ValueError) as exc:
        raise ValueError('Archive ZIP illisible.') from exc
    if not raw or len(raw) > MAX_ZIP_BYTES:
        raise ValueError('Archive ZIP absente ou trop grande ; la limite est de 16 Mio.')
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            entries = archive.infolist()
            if len(entries) > MAX_ZIP_ENTRIES:
                raise ValueError('Archive ZIP trop complexe.')
            candidates = []
            names = set()
            for entry in entries:
                name = entry.orig_filename
                path = name[:-1] if name.endswith('/') else name
                parts = path.split('/')
                if (not path or '\x00' in name or '\\' in name or name.startswith('/') or
                        any(part in ('', '.', '..') for part in parts) or name in names):
                    raise ValueError('Archive ZIP ambiguë ou chemin interne non sûr.')
                names.add(name)
                if not entry.is_dir() and parts[-1] == 'conversations.json':
                    candidates.append(entry)
            if len(candidates) != 1:
                raise ValueError('Le ZIP doit contenir exactement un fichier conversations.json.')
            entry = candidates[0]
            mode = entry.external_attr >> 16
            kind = stat.S_IFMT(mode)
            if (entry.flag_bits & 1 or kind not in (0, stat.S_IFREG) or
                    entry.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED)):
                raise ValueError('Le fichier conversations.json du ZIP est chiffré ou non pris en charge.')
            if entry.file_size > MAX_JSON_BYTES:
                raise ValueError('Le fichier conversations.json dépasse 16 Mio.')
            with archive.open(entry) as stream:
                document = stream.read(MAX_JSON_BYTES + 1)
    except ValueError:
        raise
    except (zipfile.BadZipFile, RuntimeError, NotImplementedError, OSError,
            EOFError, UnicodeError, zlib.error) as exc:
        raise ValueError('Archive ZIP illisible.') from exc
    if len(document) > MAX_JSON_BYTES:
        raise ValueError('Le fichier conversations.json dépasse 16 Mio.')
    try:
        return json.loads(document.decode('utf-8-sig'), object_pairs_hook=unique_object,
                          parse_constant=_invalid_json_constant)
    except (UnicodeError, RecursionError, json.JSONDecodeError) as exc:
        raise ValueError('Le fichier conversations.json du ZIP est illisible.') from exc


def _invalid_json_constant(value):
    raise ValueError('Valeur JSON non standard dans conversations.json.')


def _history_input(obj):
    plain = 'archive' in obj
    zipped = 'archive_zip' in obj
    if plain == zipped:
        raise ValueError('Fournir soit un export JSON, soit un ZIP, mais pas les deux.')
    return obj['archive'] if plain else _zip_history(obj['archive_zip'])


def owns(path):
    return path.startswith(('/api/onboarding/', '/api/history/'))


def environment(n):
    """Detect fixed executable names without running them or reading credentials."""
    env = n.observe_environment()
    tools = []
    for name in ('git', 'codex', 'claude', 'ollama', 'python3', 'node', 'npm', 'docker', 'podman'):
        tools.append({'name': name, 'present': n.adaptation.executable(n, name) is not None,
                      'authenticated': None,
                      'adapter': 'Dialogue et atelier Tao' if name == 'codex' else
                                 'Sources de l’atelier' if name == 'git' else 'Connexion non vérifiée'})
    return {'observed_at': n.now(), 'authority': 'observation_only', 'execution_enabled': False,
            'host': {'system': env.get('os'), 'release': env.get('release'),
                     'machine': env.get('machine'), 'python': env.get('python')},
            'tools': tools,
            'resources': {key: env.get(key) for key in ('memory_total', 'memory_available',
                                                       'disk_total', 'disk_free', 'cpu_count')},
            'limitations': ['Ce relevé concerne la machine qui héberge Tao, pas nécessairement ce navigateur.',
                            'La détection porte sur des exécutables dans le chemin connu de Tao ; ce n’est pas un inventaire complet des applications.',
                            'Aucun programme détecté n’a été lancé. Les comptes, quotas et accès métier ne sont pas vérifiés.',
                            'Un récit importé ne constitue jamais une observation actuelle ni une autorisation d’agir.']}


def get(n, path):
    parsed = urlsplit(path)
    params = parse_qs(parsed.query, keep_blank_values=True)
    if parsed.path == '/api/onboarding/environment' and not params:
        return environment(n)
    if parsed.path == '/api/history/archives' and not params:
        return history.list_archives(n)
    if parsed.path == '/api/history/search' and set(params) == {'q'} and len(params['q']) == 1:
        return history.search(n, params['q'][0])
    if parsed.path == '/api/history/archive' and set(params) == {'id'} and len(params['id']) == 1:
        return history.read_archive(n, params['id'][0])
    raise ValueError('Consultation de reprise inconnue.')


def post(n, path, obj):
    allowed = {'document'} if path == '/api/onboarding/destinations' else (
        {'archive', 'archive_zip', 'assignments'} if path == '/api/history/destinations' else (
        {'document', 'targets'} if path == '/api/onboarding/preview' else (
        {'document', 'targets', 'review_digest', 'confirmed'} if path == '/api/onboarding/apply' else (
        {'archive', 'archive_zip', 'assignments', 'targets'} if path == '/api/history/preview' else (
        {'archive', 'archive_zip', 'assignments', 'targets', 'review_digest', 'confirmed'} if path == '/api/history/apply' else None)))))
    if allowed is None or not isinstance(obj, dict) or set(obj) - allowed:
        raise ValueError('Champs ou action de reprise inconnus.')
    if path == '/api/onboarding/destinations':
        return onboarding.destinations(n, obj.get('document'))
    if path == '/api/history/destinations':
        return history.destinations(n, _history_input(obj), assignments=obj.get('assignments'))
    if path == '/api/onboarding/preview':
        return onboarding.preview(n, obj.get('document'), targets=obj.get('targets'))
    if path == '/api/onboarding/apply':
        return onboarding.apply(n, obj.get('document'), obj.get('review_digest'),
                                confirmed=obj.get('confirmed', False), targets=obj.get('targets'))
    if path == '/api/history/preview':
        return history.preview(n, _history_input(obj), assignments=obj.get('assignments'), targets=obj.get('targets'))
    return history.apply(n, _history_input(obj), obj.get('review_digest'),
                         confirmed=obj.get('confirmed', False), assignments=obj.get('assignments'),
                         targets=obj.get('targets'))


def add_parser(sub):
    actions = sub.add_parser('onboarding', help='Reprendre des conversations privées dans des espaces').add_subparsers(dest='action', required=True)
    actions.add_parser('environment')
    for action in ('preview', 'apply'):
        parser = actions.add_parser(action)
        parser.add_argument('file')
        parser.add_argument('--targets', help='JSON explicite : clés du paquet vers identifiants d’espaces existants')
        if action == 'apply':
            parser.add_argument('--review-digest', required=True)
            parser.add_argument('--confirm', action='store_true')


def command(n, args):
    if args.action == 'environment':
        return environment(n)
    if args.file == '-':
        raw = sys.stdin.buffer.read(MAX_JSON_BYTES + 1)
    else:
        with open(args.file, 'rb') as stream:
            raw = stream.read(MAX_JSON_BYTES + 1)
    if len(raw) > MAX_JSON_BYTES:
        raise ValueError('Fichier trop grand ; importer un export de conversations plus petit.')
    # Both parsers validate their own bounds and reject ambiguous JSON keys.
    try:
        value = json.loads(raw, object_pairs_hook=unique_object)
    except (UnicodeError, RecursionError, json.JSONDecodeError) as exc:
        raise ValueError('Fichier JSON illisible.') from exc
    prepared = isinstance(value, dict) and value.get('schema') == 'tao.history_import.v1'
    module = onboarding if prepared else history
    try:
        targets = json.loads(args.targets, object_pairs_hook=unique_object) if getattr(args, 'targets', None) else None
    except (UnicodeError, RecursionError, json.JSONDecodeError) as exc:
        raise ValueError('Destinations JSON illisibles.') from exc
    if args.action == 'preview':
        return module.preview(n, value, targets=targets)
    return module.apply(n, value, args.review_digest, confirmed=args.confirm, targets=targets)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Champ JSON répété ; document ambigu.')
        result[key] = value
    return result
