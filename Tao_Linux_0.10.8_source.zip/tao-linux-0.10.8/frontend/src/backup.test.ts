import assert from 'node:assert/strict';
import { webcrypto } from 'node:crypto';
import test from 'node:test';

import {
  decryptPortableText,
  encryptPortableBundle,
  ENCRYPTED_BACKUP_SCHEMA,
  PBKDF2_ITERATIONS,
} from './backup.ts';

if (!globalThis.crypto) Object.defineProperty(globalThis, 'crypto', { value: webcrypto });

const phrase = 'une phrase secrète longue et locale';
const bundle = {
  schema: 'tao.portable.core.v1',
  state: { centers: ['C₀', 'travail'], private: '<script>inerte</script>' },
};

test('round trip keeps unicode and uses the fixed authenticated format', async () => {
  const encrypted = await encryptPortableBundle(bundle, phrase);
  const envelope = JSON.parse(encrypted);
  assert.equal(envelope.schema, ENCRYPTED_BACKUP_SCHEMA);
  assert.deepEqual(envelope.kdf, {
    name: 'PBKDF2', hash: 'SHA-256', iterations: PBKDF2_ITERATIONS,
    salt: envelope.kdf.salt,
  });
  assert.equal(envelope.cipher.name, 'AES-GCM');
  assert.equal(envelope.cipher.tagLength, 128);
  assert.notDeepEqual(envelope.ciphertext, JSON.stringify(bundle));
  assert.deepEqual(await decryptPortableText(encrypted, phrase), bundle);
});

test('wrong phrase and authenticated-ciphertext tampering disclose no plaintext', async () => {
  const encrypted = await encryptPortableBundle(bundle, phrase);
  await assert.rejects(decryptPortableText(encrypted, 'une autre phrase vraiment longue'),
    /incorrecte ou sauvegarde altérée/);
  const envelope = JSON.parse(encrypted);
  const index = Math.floor(envelope.ciphertext.length / 2);
  envelope.ciphertext = envelope.ciphertext.slice(0, index)
    + (envelope.ciphertext[index] === 'A' ? 'B' : 'A')
    + envelope.ciphertext.slice(index + 1);
  await assert.rejects(decryptPortableText(JSON.stringify(envelope), phrase),
    /incorrecte ou sauvegarde altérée/);
});

test('weak phrases and ambiguous envelopes fail before decryption', async () => {
  await assert.rejects(encryptPortableBundle(bundle, 'trop court'), /12 à 256/);
  const encrypted = JSON.parse(await encryptPortableBundle(bundle, phrase));
  encrypted.extra = true;
  await assert.rejects(decryptPortableText(JSON.stringify(encrypted), phrase), /ambiguë/);
});
