export type Locale = 'fr' | 'en';
export type CenterStatus = 'candidate' | 'active' | 'paused' | 'retired';

export interface Definition {
  title: string;
  purpose: string;
  input: string;
  process: string[];
  output: string;
  benefit: string;
  acceptance: string;
  boundaries: string;
}

export interface ContractSource {
  publisher: string;
  center_title: string;
  node_version: string;
  exported_at: string;
}

export interface CenterContractDocument {
  schema: 'tao.center.contract.v1';
  version: 1;
  id: string;
  source: ContractSource;
  definition: Definition;
  authority: 'external_unverified_contract';
  permissions: 'none';
  automatic_execution: false;
  sha256: string;
}

export interface ContractReview {
  schema: 'tao.center.contract.review.v1';
  contract_id: string;
  contract_sha256: string;
  operation: 'creation' | 'revision';
  center_id: string | null;
  center_revision: number | null;
  registry_revision: number;
  definition: Definition;
  changed_fields: string[];
  review_digest: string;
  source: ContractSource;
  already_current: boolean;
  authority: 'external_unverified_contract';
  permissions: 'none';
  automatic_execution: false;
  warnings: string[];
}

export interface Trial {
  id: string;
  status: 'review' | 'reported';
  input: string;
  expected: string;
  output: string;
  process: string[];
  benefit: string;
  residual: string;
  origin: 'ai' | 'human';
  outcome?: 'success' | 'partial' | 'failure' | 'counterexample';
  observed?: string;
  evidence?: string;
}

export type OrganRole = 'input' | 'output' | 'tool' | 'bridge';

export interface PreparedOrgan {
  schema: 'tao.center.organ.v1';
  legacy: boolean;
  name: string;
  role: OrganRole;
  interface: string;
  operation: string;
  input: string;
  output: string;
  translation: string;
  requested_effects: string[];
  requirements: string[];
  purpose: string;
  acceptance: string;
  boundaries: string;
  center_id: string;
  center_revision: number;
  origin_reply_id: string;
  digest: string;
  build: {
    status: 'not_started' | 'task_saved' | 'adaptation_started';
    task_id: string;
    adaptation_id: string | null;
  };
  current_contract: boolean;
  execution_enabled: false;
}

export interface Center {
  id: string;
  revision: number;
  status: CenterStatus;
  parent_id: string | null;
  provenance: string;
  definition: Definition;
  trials: Trial[];
  history: Array<{ revision: number; definition: Definition }>;
  readiness: {
    reported: number;
    successes: number;
    counterexamples: number;
    ready: boolean;
  };
  qualification?: { review_digest: string } | null;
  prepared_adapters: PreparedOrgan[];
  execution_enabled: false;
}

export interface CenterLink {
  id: string;
  source_id: string;
  target_id: string;
  translation: string;
  purpose: string;
}

export type CenterInputReference =
  | { kind: 'landmark'; id: string; revision: number }
  | { kind: 'center_receipt'; id: string; link_id: string };

export interface Capture {
  status: 'none' | 'review' | 'accepted' | 'rejected_by_owner' | 'rejected' | 'deferred'
    | 'checking' | 'executing' | 'succeeded' | 'tool_error' | 'failed' | 'blocked'
    | 'unknown' | 'dismissed';
  warnings?: string[];
  definition?: Definition;
  source_title?: string;
  target_title?: string;
  organ_schema?: 'tao.center.organ.v1';
  name?: string;
  role?: OrganRole;
  interface?: string;
  operation?: string;
  input?: string;
  output?: string;
  requested_effects?: string[];
  requirements?: string[];
  translation?: string;
  purpose?: string;
  // Former provider-specific captures remain readable during the additive
  // migration but are no longer emitted by the conversation contract.
  provider?: string;
  capability?: string;
  source?: string;
  selection?: string;
  mapping?: string;
  acceptance?: string;
  boundaries?: string;
  kind?: 'action';
  center_id?: string;
  center_revision?: number;
  connector_id?: string;
  connector_label?: string;
  tool?: string;
  request_id?: string;
  review_digest?: string;
  connector_revision?: number;
  descriptor_digest?: string;
  arguments?: Record<string, unknown>;
  expected?: string;
  risk?: string;
  rollback?: string;
  automatic_execution?: false;
  call_dispatched?: boolean;
  receipt?: {
    status: string;
    call_dispatched: boolean;
    result_authority: 'external_untrusted_data';
    automatic_retry: false;
    reason?: string;
    elapsed_seconds?: number;
    finished_at?: string;
    result?: unknown;
    result_omitted?: boolean;
    result_bytes?: number;
  };
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  job_id?: string;
  model?: string | null;
  input_context?: {
    context?: { title?: string; concept_id?: string };
  };
  center_capture?: {
    proposal?: Capture;
    revision?: Capture;
    link?: Capture;
    organ?: Capture;
    adapter?: Capture;
    action?: Capture;
    output?: Capture;
    warnings?: string[];
  };
}

export interface CenterInput {
  id: string;
  revision: number;
  kind: 'landmark' | 'center_receipt';
  reference: CenterInputReference;
  concept_id: string;
  concept_label: string;
  title: string;
  text: string;
  text_truncated: boolean;
  status: string;
}

export interface DialogueJob {
  id: string;
  status: 'queued' | 'running' | 'answered' | 'blocked' | 'interrupted' | 'cancelled';
  message?: string;
  partial_text?: string;
  retryable?: boolean;
  dialogue_revision?: number;
  failure_reason?: string | null;
}

export interface UpdateChange {
  fr: string;
  en: string;
}

export interface UpdateReview {
  schema: 'tao.update.review.v1';
  review_digest: string;
  checked_at: string;
  from_version: string;
  version: string;
  available: boolean;
  installable: boolean;
  reason: string | null;
  signature_verified: true;
  public_key_sha256: string;
  source: string;
  changes: UpdateChange[];
  minimum_runtime: string | null;
  state_migrations: string[] | null;
  installer: { name: string; sha256: string; size: number };
}

export interface UpdateAttempt {
  schema: 'tao.update.attempt.v1';
  id: string;
  status: 'starting' | 'installing' | 'installed' | 'failed' | 'interrupted' | 'invalid';
  from_version: string | null;
  version: string | null;
  review_digest: string | null;
  started_at: string;
  finished_at: string | null;
  helper_pid?: number | null;
  helper_start?: string | null;
  message: string;
}

export interface UpdateStatus {
  schema: 'tao.update.status.v1';
  current_version: string;
  configured: boolean;
  automatic: false;
  network_checked: boolean;
  source: string | null;
  public_key_sha256: string | null;
  configuration_error?: string;
  review_stale?: boolean;
  review: UpdateReview | { status: 'invalid'; error: string } | null;
  attempt: UpdateAttempt | { status: 'invalid'; error: string } | null;
}

export interface TaoBootstrap {
  schema: 'tao.center.interface.v1';
  world: string;
  worldTitle: string;
  locale: Locale;
  token: string;
  registryRevision: number;
  dialogueRevision: number;
  selectedCenterId: string | null;
  focus: { kind: 'center' | 'center_factory'; id: string; revision: number };
  centers: Center[];
  links: CenterLink[];
  messages: Message[];
  centerInputs: CenterInput[];
  initialJob: DialogueJob | null;
  update: UpdateStatus;
  product: {
    billingEnabled: false;
    centerLimit: null;
  };
}
