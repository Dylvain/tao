export const ENCRYPTED_BACKUP_SCHEMA = 'tao.encrypted-backup.v1' as const;
export const PBKDF2_ITERATIONS = 600_000;

const MAX_PLAINTEXT_BYTES = 18 * 1024 * 1024;
const MAX_ENCRYPTED_TEXT = 25 * 1024 * 1024;
const AAD = new TextEncoder().encode('TAO\0tao.encrypted-backup.v1');

interface EncryptedEnvelope {
  schema: typeof ENCRYPTED_BACKUP_SCHEMA;
  kdf: {
    name: 'PBKDF2';
    hash: 'SHA-256';
    iterations: typeof PBKDF2_ITERATIONS;
    salt: string;
  };
  cipher: {
    name: 'AES-GCM';
    iv: string;
    tagLength: 128;
  };
  ciphertext: string;
}

function cryptoApi() {
  if (!globalThis.crypto?.subtle || !globalThis.crypto.getRandomValues) {
    throw new Error('Le chiffrement local nécessite un navigateur récent et une connexion sécurisée.');
  }
  return globalThis.crypto;
}

function passphrase(value: string) {
  if (typeof value !== 'string' || value.length < 12 || value.length > 256) {
    throw new Error('Choisis une phrase secrète de 12 à 256 caractères.');
  }
  return value;
}

function exactObject(value: unknown, keys: string[]): value is Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const actual = Object.keys(value as Record<string, unknown>).sort();
  return actual.length === keys.length && actual.every((key, index) => key === [...keys].sort()[index]);
}

function toBase64(value: Uint8Array) {
  let binary = '';
  for (let offset = 0; offset < value.length; offset += 0x8000) {
    binary += String.fromCharCode(...value.subarray(offset, offset + 0x8000));
  }
  return btoa(binary);
}

function fromBase64(value: unknown, maximum: number) {
  if (typeof value !== 'string' || value.length === 0 || value.length > Math.ceil(maximum / 3) * 4 + 4
      || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) {
    throw new Error('Sauvegarde chiffrée invalide.');
  }
  let binary: string;
  try { binary = atob(value); } catch { throw new Error('Sauvegarde chiffrée invalide.'); }
  if (binary.length > maximum) throw new Error('Sauvegarde chiffrée trop grande.');
  const result = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) result[index] = binary.charCodeAt(index);
  return result;
}

async function keyFor(password: string, salt: Uint8Array<ArrayBuffer>) {
  const api = cryptoApi();
  const bytes = new TextEncoder().encode(passphrase(password));
  try {
    const material = await api.subtle.importKey('raw', bytes, 'PBKDF2', false, ['deriveKey']);
    return await api.subtle.deriveKey({
      name: 'PBKDF2', hash: 'SHA-256', salt, iterations: PBKDF2_ITERATIONS,
    }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  } finally {
    bytes.fill(0);
  }
}

export async function encryptPortableBundle(bundle: unknown, password: string) {
  const api = cryptoApi();
  const serialized = JSON.stringify(bundle);
  if (typeof serialized !== 'string') throw new Error('Le cœur de Tao ne peut pas être sérialisé.');
  const plaintext = new TextEncoder().encode(serialized);
  if (plaintext.length === 0 || plaintext.length > MAX_PLAINTEXT_BYTES) {
    plaintext.fill(0);
    throw new Error('Le cœur de Tao est trop grand pour cette première sauvegarde.');
  }
  const salt = api.getRandomValues(new Uint8Array(16));
  const iv = api.getRandomValues(new Uint8Array(12));
  try {
    const key = await keyFor(password, salt);
    const encrypted = new Uint8Array(await api.subtle.encrypt({
      name: 'AES-GCM', iv, tagLength: 128, additionalData: AAD,
    }, key, plaintext));
    const envelope: EncryptedEnvelope = {
      schema: ENCRYPTED_BACKUP_SCHEMA,
      kdf: { name: 'PBKDF2', hash: 'SHA-256', iterations: PBKDF2_ITERATIONS, salt: toBase64(salt) },
      cipher: { name: 'AES-GCM', iv: toBase64(iv), tagLength: 128 },
      ciphertext: toBase64(encrypted),
    };
    encrypted.fill(0);
    return JSON.stringify(envelope);
  } finally {
    plaintext.fill(0);
  }
}

function envelopeFrom(text: string): EncryptedEnvelope {
  if (typeof text !== 'string' || text.length === 0 || text.length > MAX_ENCRYPTED_TEXT) {
    throw new Error('Sauvegarde chiffrée vide ou trop grande.');
  }
  let parsed: unknown;
  try { parsed = JSON.parse(text); } catch { throw new Error('Sauvegarde chiffrée illisible.'); }
  if (!exactObject(parsed, ['schema', 'kdf', 'cipher', 'ciphertext'])) {
    throw new Error('Sauvegarde chiffrée ambiguë.');
  }
  const value = parsed as Record<string, unknown>;
  if (value.schema !== ENCRYPTED_BACKUP_SCHEMA
      || !exactObject(value.kdf, ['name', 'hash', 'iterations', 'salt'])
      || !exactObject(value.cipher, ['name', 'iv', 'tagLength'])) {
    throw new Error('Format de sauvegarde chiffrée non pris en charge.');
  }
  const kdf = value.kdf as Record<string, unknown>;
  const cipher = value.cipher as Record<string, unknown>;
  if (kdf.name !== 'PBKDF2' || kdf.hash !== 'SHA-256' || kdf.iterations !== PBKDF2_ITERATIONS
      || cipher.name !== 'AES-GCM' || cipher.tagLength !== 128) {
    throw new Error('Paramètres de chiffrement non pris en charge.');
  }
  return parsed as unknown as EncryptedEnvelope;
}

export async function decryptPortableText(text: string, password: string): Promise<unknown> {
  const api = cryptoApi();
  const envelope = envelopeFrom(text);
  const salt = fromBase64(envelope.kdf.salt, 16);
  const iv = fromBase64(envelope.cipher.iv, 12);
  if (salt.length !== 16 || iv.length !== 12) throw new Error('Paramètres de chiffrement invalides.');
  const ciphertext = fromBase64(envelope.ciphertext, MAX_PLAINTEXT_BYTES + 16);
  let clear: Uint8Array | null = null;
  try {
    const key = await keyFor(password, salt);
    try {
      clear = new Uint8Array(await api.subtle.decrypt({
        name: 'AES-GCM', iv, tagLength: 128, additionalData: AAD,
      }, key, ciphertext));
    } catch {
      throw new Error('Phrase secrète incorrecte ou sauvegarde altérée.');
    }
    if (clear.length === 0 || clear.length > MAX_PLAINTEXT_BYTES) {
      throw new Error('Contenu de sauvegarde vide ou trop grand.');
    }
    let decoded: string;
    try { decoded = new TextDecoder('utf-8', { fatal: true }).decode(clear); }
    catch { throw new Error('Contenu de sauvegarde illisible.'); }
    try { return JSON.parse(decoded) as unknown; }
    catch { throw new Error('Contenu de sauvegarde invalide.'); }
  } finally {
    ciphertext.fill(0);
    clear?.fill(0);
  }
}

export async function decryptPortableFile(file: File, password: string) {
  if (!(file instanceof File) || file.size === 0 || file.size > MAX_ENCRYPTED_TEXT) {
    throw new Error('Choisis une sauvegarde Tao chiffrée de moins de 25 Mio.');
  }
  return decryptPortableText(await file.text(), password);
}
