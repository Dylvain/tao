import { FormEvent, useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { copyFor, type Copy } from './copy';
import { decryptPortableFile, encryptPortableBundle } from './backup';
import { Icon } from './icons';
import { buildCenterTopology } from './topology';
import type {
  Capture,
  Center,
  CenterContractDocument,
  CenterInput,
  CenterInputReference,
  CenterStatus,
  ContractReview,
  DialogueJob,
  Message,
  PreparedOrgan,
  TaoBootstrap,
  Trial,
  UpdateReview,
  UpdateAttempt,
  UpdateStatus,
} from './types';
import './styles.css';

const captureKinds = ['proposal', 'revision', 'link', 'organ', 'adapter'] as const;
type CaptureKind = (typeof captureKinds)[number];

function bootstrap(): TaoBootstrap {
  const node = document.getElementById('tao-bootstrap');
  if (!node?.textContent) throw new Error('Configuration Tao absente.');
  const value = JSON.parse(node.textContent) as TaoBootstrap;
  if (value.schema !== 'tao.center.interface.v1') throw new Error('Interface Tao incompatible.');
  return value;
}

const config = bootstrap();
const words = copyFor(config.locale);
const topology = buildCenterTopology(config.centers, config.links);

function query(values: Record<string, string | null | undefined>) {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) if (value) params.set(key, value);
  return params.toString();
}

function scoped(path: string) {
  const url = new URL(path, window.location.origin);
  url.searchParams.set('world', config.world);
  return `${url.pathname}?${url.searchParams.toString()}`;
}

async function post<T = Record<string, unknown>>(path: string, data: unknown): Promise<T> {
  const response = await fetch(scoped(path), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Tao-Token': config.token },
    body: JSON.stringify(data),
  });
  let value: Record<string, unknown> = {};
  try { value = await response.json() as Record<string, unknown>; } catch { /* surfaced below */ }
  if (!response.ok) throw new Error(typeof value.error === 'string' ? value.error : words.error);
  return value as T;
}

function centerHref(centerId: string | null) {
  const path = centerId ? '/centers' : '/';
  return `${path}?${query({ world: config.world, lang: config.locale, center: centerId })}`;
}

function centerInputStorageKey(centerId: string) {
  return `tao.center.draft.${config.world}.${centerId}.input`;
}

function sameInputReference(left: CenterInputReference, right: CenterInputReference | null) {
  if (!right || left.kind !== right.kind || left.id !== right.id) return false;
  if (left.kind === 'landmark' && right.kind === 'landmark') return left.revision === right.revision;
  return left.kind === 'center_receipt' && right.kind === 'center_receipt'
    && left.link_id === right.link_id;
}

function workshopHref() {
  return `/?${query({ world: config.world, lang: config.locale, view: 'dialogue' })}#work-progress`;
}

function statusLabel(status: CenterStatus, copy: Copy) {
  return copy[status];
}

function organRoleLabel(role?: string) {
  if (role === 'input') return words.roleInput;
  if (role === 'output') return words.roleOutput;
  if (role === 'tool') return words.roleTool;
  if (role === 'bridge') return words.roleBridge;
  return role;
}

function effectLabel(effect: string) {
  if (effect === 'read') return words.effectRead;
  if (effect === 'write') return words.effectWrite;
  if (effect === 'execute') return words.effectExecute;
  if (effect === 'network') return words.effectNetwork;
  if (effect === 'interactive_ui') return words.effectInteractiveUi;
  return effect;
}

function proposalCount(message: Message) {
  const captures = message.center_capture;
  if (!captures) return 0;
  return captureKinds.filter((kind) => captures[kind]?.status === 'review').length
    + (captures.action?.status === 'review' ? 1 : 0)
    + (captures.output?.status === 'review' ? 1 : 0);
}

interface StructuralDecision {
  kind: CaptureKind;
  capture: Capture;
  replyId: string;
}

function structuralDecisions(messages: Message[]): StructuralDecision[] {
  const result: StructuralDecision[] = [];
  for (const message of messages) {
    if (message.role !== 'assistant' || !message.center_capture) continue;
    for (const kind of captureKinds) {
      const capture = message.center_capture[kind];
      if (capture?.status === 'review') result.push({ kind, capture, replyId: message.id });
    }
  }
  return result;
}

interface ActionDecision {
  capture: Capture;
  replyId: string;
}

function actionDecisions(messages: Message[]): ActionDecision[] {
  return messages.flatMap((message) => message.role === 'assistant'
    && message.center_capture?.action?.status === 'review'
    ? [{ capture: message.center_capture.action, replyId: message.id }] : []);
}

function actionReceipts(messages: Message[]): ActionDecision[] {
  return messages.flatMap((message) => message.role === 'assistant'
    && message.center_capture?.action?.kind === 'action'
    && message.center_capture.action.status !== 'review'
    && message.center_capture.action.status !== 'none'
    && message.center_capture.action.status !== 'rejected'
    && message.center_capture.action.status !== 'deferred'
    ? [{ capture: message.center_capture.action, replyId: message.id }] : []).slice(-3).reverse();
}

function actionStatusLabel(status?: string) {
  if (status === 'succeeded') return words.actionSucceeded;
  if (status === 'dismissed') return words.actionDismissed;
  if (status === 'tool_error') return words.actionToolError;
  if (status === 'failed') return words.actionFailed;
  if (status === 'blocked') return words.actionBlocked;
  return words.actionUnknown;
}

function Sidebar({ selected, open, close, openBackup, openUpdate }: {
  selected: Center | null;
  open: boolean;
  close: () => void;
  openBackup: () => void;
  openUpdate: () => void;
}) {
  const renderBranch = (parent: string | null, depth = 0): React.ReactNode =>
    topology.childrenOf(parent).map((center) => {
      const waiting = center.trials.filter((trial) => trial.status === 'review').length;
      const branch = topology.childrenOf(center.id);
      return <div className="center-tree-node" key={center.id}>
        <a className={`center-nav-item ${depth > 0 ? 'is-child' : ''} ${selected?.id === center.id ? 'is-active' : ''}`}
          style={{ '--depth': Math.min(depth, 4), '--branch-left': `${1 + Math.min(depth, 4) * 12}px` } as React.CSSProperties}
          href={centerHref(center.id)} onClick={close}
          aria-current={selected?.id === center.id ? 'page' : undefined}>
          <span className="center-nav-mark">ƒ</span>
          <span className="center-nav-copy">
            <strong>{center.definition.title}</strong>
            <small>{statusLabel(center.status, words)}{waiting ? ` · ${waiting}` : ''}</small>
          </span>
          {waiting > 0 && <span className="nav-count">{waiting}</span>}
        </a>
        {branch.length > 0 && <div className="center-tree-children">{renderBranch(center.id, depth + 1)}</div>}
      </div>;
    });

  return <>
    <aside className={`sidebar ${open ? 'is-open' : ''}`} aria-label={words.centers}>
      <div className="brand-row">
        <a className="brand" href={centerHref(null)} aria-label="Tao">tao<span>.</span></a>
        <button className="icon-button sidebar-close" type="button" onClick={close} aria-label={words.close}>
          <Icon name="close" />
        </button>
      </div>
      <div className="brand-tag">{words.brandTag}</div>
      <nav className="center-navigation">
        <div className="nav-section-label">{words.centers}</div>
        <a className={`center-nav-item root ${selected === null ? 'is-active' : ''}`}
          href={centerHref(null)} onClick={close} aria-current={selected === null ? 'page' : undefined}>
          <span className="center-nav-mark">C₀</span>
          <span className="center-nav-copy"><strong>{words.rootShort}</strong><small>{words.root}</small></span>
        </a>
        <div className="center-tree">{renderBranch(null)}</div>
      </nav>
      <div className="sidebar-bottom">
        <a className="new-center-link" href={`${centerHref(null)}#chat`} onClick={close}>
          <Icon name="plus" /> <span>{words.newCenter}</span>
        </a>
        <div className="sidebar-meta">
          {config.world === 'main' && <div className="sidebar-tools">
            <button className="sidebar-tool" type="button" onClick={() => { close(); openUpdate(); }}>
              <Icon name="update" /><span>{words.update}</span>
            </button>
            <button className="sidebar-tool" type="button" onClick={() => { close(); openBackup(); }}>
              <Icon name="backup" /><span>{words.backup}</span>
            </button>
          </div>}
          <span className="world-pill"><i />{config.world}</span>
        </div>
      </div>
    </aside>
    {open && <button className="sidebar-backdrop" type="button" onClick={close} aria-label={words.close} />}
  </>;
}

function CenterPath({ center }: { center: Center | null }) {
  if (!center) return <span className="workspace-kicker">C₀</span>;
  return <nav className="center-path" aria-label={words.hierarchy}>
    <a href={centerHref(null)}>C₀</a>
    {topology.pathTo(center.id).map((row) => <span className="center-path-step" key={row.id}>
      <Icon name="chevron" />
      {row.id === center.id
        ? <strong aria-current="page">{row.definition.title}</strong>
        : <a href={centerHref(row.id)}>{row.definition.title}</a>}
    </span>)}
  </nav>;
}

function FunctionBar({ center }: { center: Center | null }) {
  const input = center?.definition.input ?? (config.locale === 'fr'
    ? 'Une demande encore mêlée' : 'A request not yet oriented');
  const output = center?.definition.output ?? (config.locale === 'fr'
    ? 'Une orientation à relire' : 'An orientation to review');
  return <div className="function-bar" aria-label={words.function}>
    <span className="function-token"><b>x</b><span>{input}</span></span>
    <span className="function-arrow"><Icon name="arrow" /></span>
    <span className="function-token"><b>f(x)</b><span>{output}</span></span>
  </div>;
}

function ProposalCard({ decision }: { decision: StructuralDecision }) {
  const [pending, setPending] = useState<'accept' | 'reject' | null>(null);
  const [error, setError] = useState('');
  const { capture, kind } = decision;
  const definition = capture.definition;
  const titles: Record<CaptureKind, string> = {
    proposal: words.draftStructure,
    revision: words.draftRevision,
    link: words.draftLink,
    organ: words.draftOrgan,
    adapter: words.draftAdapter,
  };

  async function decide(value: 'accept' | 'reject') {
    setPending(value); setError('');
    try {
      const result = await post<{ center_id?: string }>('/api/centers/proposal', {
        reply_id: decision.replyId,
        kind,
        decision: value,
        dialogue_revision: config.dialogueRevision,
      });
      if (value === 'accept' && kind === 'proposal' && result.center_id) {
        window.location.assign(centerHref(result.center_id));
      } else window.location.reload();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error);
      setPending(null);
    }
  }

  return <article className="review-card proposal-review">
    <div className="review-card-head">
      <span className="draft-pill"><Icon name="spark" />{words.inert}</span>
      <span className="review-origin">{words.originAi}</span>
    </div>
    <h3>{titles[kind]}</h3>
    {definition && <>
      <strong className="proposal-name">{definition.title}</strong>
      <p className="proposal-purpose">{definition.purpose}</p>
      <div className="mini-flow">
        <div><small>{words.input} x</small><span>{definition.input}</span></div>
        <Icon name="arrow" />
        <div><small>{words.output} f(x)</small><span>{definition.output}</span></div>
      </div>
      <details className="card-details">
        <summary>{words.details}</summary>
        <div className="card-details-body">
          <Detail label={words.process} value={definition.process} />
          <Detail label={words.benefit} value={definition.benefit} />
          <Detail label={words.proof} value={definition.acceptance} />
          <Detail label={words.boundaries} value={definition.boundaries} />
        </div>
      </details>
    </>}
    {kind === 'link' && <>
      <div className="mini-flow names">
        <div><small>{words.from}</small><span>{capture.source_title}</span></div>
        <Icon name="arrow" />
        <div><small>{words.to}</small><span>{capture.target_title}</span></div>
      </div>
      <Detail label={words.translation} value={capture.translation} />
      <Detail label={words.purpose} value={capture.purpose} />
    </>}
    {(kind === 'organ' || kind === 'adapter') && <>
      <div className="adapter-title">
        <span>{capture.name ?? capture.provider}</span>
        <b>{capture.operation ?? capture.capability}</b>
      </div>
      <div className="mini-flow">
        <div><small>{words.input}</small><span>{capture.input ?? capture.source}</span></div>
        <Icon name="arrow" />
        <div><small>{words.output}</small><span>{capture.output ?? capture.mapping}</span></div>
      </div>
      <Detail label={words.translation} value={capture.translation ?? capture.mapping} />
      <details className="card-details"><summary>{words.details}</summary><div className="card-details-body">
        <Detail label={words.organRole} value={organRoleLabel(capture.role ?? (kind === 'adapter' ? 'input' : undefined))} />
        <Detail label={words.organInterface} value={capture.interface ?? capture.provider} />
        <Detail label={words.organEffects} value={capture.requested_effects ?? (kind === 'adapter' ? ['read'] : [])} />
        <Detail label={words.organRequirements} value={capture.requirements ?? (capture.selection ? [capture.selection] : [])} />
        <Detail label={words.purpose} value={capture.purpose} />
        <Detail label={words.proof} value={capture.acceptance} />
        <Detail label={words.boundaries} value={capture.boundaries} />
      </div></details>
    </>}
    <div className="decision-actions">
      <button className="primary-button" type="button" disabled={pending !== null} onClick={() => decide('accept')}>
        <Icon name="check" />{words.accept}
      </button>
      <button className="quiet-button" type="button" disabled={pending !== null} onClick={() => decide('reject')}>
        {words.reject}
      </button>
    </div>
    {error && <p className="inline-error" role="alert">{error}</p>}
  </article>;
}

function Detail({ label, value }: { label: string; value?: string | string[] | null }) {
  if (!value || (Array.isArray(value) && value.length === 0)) return null;
  return <div className="detail-row"><small>{label}</small>{Array.isArray(value)
    ? <ol>{value.map((item, index) => <li key={`${index}-${item}`}>{item}</li>)}</ol>
    : <p>{value}</p>}</div>;
}

function ActionCard({ decision }: { decision: ActionDecision }) {
  const [pending, setPending] = useState<'execute' | 'dismiss' | null>(null);
  const [error, setError] = useState('');
  const { capture } = decision;
  const exact = Boolean(capture.request_id && capture.review_digest
    && typeof capture.connector_revision === 'number');

  async function decide(value: 'execute' | 'dismiss') {
    if (!exact) return;
    if (value === 'execute' && !window.confirm(words.confirmAction)) return;
    setPending(value); setError('');
    try {
      await post('/api/centers/tool', {
        reply_id: decision.replyId,
        decision: value,
        request_id: capture.request_id,
        review_digest: capture.review_digest,
        connector_revision: capture.connector_revision,
        confirmed: value === 'execute',
      });
      window.location.reload();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error);
      setPending(null);
    }
  }

  return <article className="review-card action-review">
    <div className="review-card-head">
      <span className="draft-pill"><Icon name="spark" />{words.exactReview}</span>
      <span className="review-origin">{words.noRecurringMandate}</span>
    </div>
    <h3>{words.draftAction}</h3>
    <div className="adapter-title"><span>{capture.connector_label}</span><b>{capture.tool}</b></div>
    <Detail label={words.purpose} value={capture.purpose} />
    <div className="action-arguments"><small>{words.arguments}</small>
      <pre>{JSON.stringify(capture.arguments ?? {}, null, 2)}</pre>
    </div>
    <details className="card-details"><summary>{words.details}</summary><div className="card-details-body">
      <Detail label={words.expected} value={capture.expected} />
      <Detail label={words.risk} value={capture.risk} />
      <Detail label={words.rollback} value={capture.rollback} />
    </div></details>
    <div className="decision-actions">
      <button className="primary-button" type="button" disabled={pending !== null || !exact}
        onClick={() => decide('execute')}><Icon name="check" />{words.executeAction}</button>
      <button className="quiet-button" type="button" disabled={pending !== null || !exact}
        onClick={() => decide('dismiss')}>{words.dismissAction}</button>
    </div>
    {error && <p className="inline-error" role="alert">{error}</p>}
  </article>;
}

function ActionReceiptCard({ decision }: { decision: ActionDecision }) {
  const { capture } = decision;
  const receipt = capture.receipt;
  const [error, setError] = useState('');
  const transferable = ['succeeded', 'tool_error', 'failed', 'blocked', 'unknown'].includes(capture.status);
  const targets = transferable && capture.request_id && capture.center_id
    ? config.links.flatMap((link) => {
      if (link.source_id !== capture.center_id) return [];
      const center = config.centers.find((item) => item.id === link.target_id && item.status !== 'retired');
      return center ? [{ link, center }] : [];
    }) : [];

  function prepare(targetId: string, linkId: string) {
    if (!capture.request_id) return;
    const reference: CenterInputReference = {
      kind: 'center_receipt', id: capture.request_id, link_id: linkId,
    };
    try {
      sessionStorage.setItem(centerInputStorageKey(targetId), JSON.stringify(reference));
      window.location.assign(`${centerHref(targetId)}#chat`);
    } catch {
      setError(words.prepareInputFailed);
    }
  }
  return <article className={`action-receipt receipt-${capture.status}`}>
    <div className="action-receipt-head">
      <div><span>{capture.connector_label}</span><strong>{capture.tool}</strong></div>
      <b>{actionStatusLabel(capture.status)}</b>
    </div>
    {receipt?.reason && <p className="receipt-reason">{receipt.reason}</p>}
    {(receipt?.result !== undefined || receipt?.result_omitted) && <details>
      <summary>{words.externalResult}</summary>
      <small>{words.externalResultNote}</small>
      {receipt.result_omitted
        ? <p className="receipt-reason">{words.resultOmitted}</p>
        : <pre>{JSON.stringify(receipt.result, null, 2)}</pre>}
    </details>}
    {targets.length > 0 && <div className="receipt-routes">
      {targets.map(({ link, center }) => <button className="quiet-button" type="button" key={link.id}
        title={link.translation} onClick={() => prepare(center.id, link.id)}>
        <Icon name="chevron" />{words.useInCenter} {center.definition.title}
      </button>)}
    </div>}
    {error && <p className="inline-error" role="alert">{error}</p>}
  </article>;
}

function TrialCard({ trial, center }: { trial: Trial; center: Center }) {
  const [reviewing, setReviewing] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setPending(true); setError('');
    const fields = new FormData(event.currentTarget);
    try {
      await post('/api/centers/review', {
        id: center.id,
        trial_id: trial.id,
        outcome: fields.get('outcome'),
        observed: fields.get('observed'),
        evidence: fields.get('evidence'),
        residual: fields.get('residual'),
        revision: config.registryRevision,
      });
      window.location.reload();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error);
      setPending(false);
    }
  }

  return <article className="review-card output-review">
    <div className="review-card-head">
      <span className="draft-pill"><Icon name="spark" />{words.inert}</span>
      <span className="review-origin">{words.originAi}</span>
    </div>
    <h3>{words.draftOutput}</h3>
    <div className="output-copy">{trial.output}</div>
    <div className="source-input"><small>{words.input} x</small><p>{trial.input}</p></div>
    <details className="card-details">
      <summary>{words.details}</summary>
      <div className="card-details-body">
        <Detail label={words.process} value={trial.process} />
        <Detail label={words.proof} value={trial.expected} />
        <Detail label={words.benefit} value={trial.benefit} />
        <Detail label={words.residual} value={trial.residual} />
      </div>
    </details>
    {!reviewing ? <div className="decision-actions">
      <button className="primary-button" type="button" onClick={() => setReviewing(true)}>
        <Icon name="check" />{words.review}
      </button>
    </div> : <form className="review-form" onSubmit={submit}>
      <label>{words.outcome}<select name="outcome" defaultValue="success">
        <option value="success">{words.success}</option>
        <option value="partial">{words.partial}</option>
        <option value="failure">{words.failure}</option>
        <option value="counterexample">{words.counterexample}</option>
      </select></label>
      <label>{words.observation}<textarea name="observed" maxLength={3000} required /></label>
      <label>{words.evidence}<textarea name="evidence" maxLength={3000} required /></label>
      <label>{words.residual}<textarea name="residual" maxLength={2000} defaultValue={trial.residual} /></label>
      <div className="decision-actions">
        <button className="primary-button" type="submit" disabled={pending}>{words.keepReview}</button>
        <button className="quiet-button" type="button" disabled={pending} onClick={() => setReviewing(false)}>{words.cancel}</button>
      </div>
      {error && <p className="inline-error" role="alert">{error}</p>}
    </form>}
  </article>;
}

function Workspace({ center, onDetails }: { center: Center | null; onDetails: () => void }) {
  const structural = structuralDecisions(config.messages);
  const actions = actionDecisions(config.messages);
  const receipts = actionReceipts(config.messages);
  const trials = center?.trials.filter((trial) => trial.status === 'review') ?? [];
  const decisionCount = structural.length + actions.length + trials.length;
  const focusChat = () => document.getElementById('tao-message')?.focus();

  return <main className="workspace">
    <div className="workspace-inner">
      <header className="workspace-header">
        <div>
          <CenterPath center={center} />
          <h1>{center?.definition.title ?? words.root}</h1>
          <p>{center?.definition.purpose ?? words.rootPurpose}</p>
        </div>
        <div className="workspace-actions">
          {center && <span className={`status-pill status-${center.status}`}><i />{statusLabel(center.status, words)}</span>}
          <span className="supervised-pill">{words.noAutomation}</span>
          <button className="icon-button" type="button" onClick={onDetails} aria-label={words.details} title={words.details}>
            <Icon name="details" />
          </button>
        </div>
      </header>
      <FunctionBar center={center} />
      <section className="work-queue" aria-labelledby="work-title">
        {decisionCount > 0 ? <>
          <div className="queue-title">
            <div><span>{words.reviewTitle}</span><h2 id="work-title">{decisionCount} {decisionCount === 1 ? words.reviewOne : words.reviewMany}</h2></div>
            <strong>{decisionCount}</strong>
          </div>
          <div className="review-stack">
            {structural.map((decision) => <ProposalCard key={`${decision.replyId}-${decision.kind}`} decision={decision} />)}
            {actions.map((decision) => <ActionCard key={`${decision.replyId}-action`} decision={decision} />)}
            {center && trials.map((trial) => <TrialCard key={trial.id} trial={trial} center={center} />)}
          </div>
        </> : <div className="empty-work">
          <span className="empty-symbol"><Icon name={center ? 'check' : 'spark'} /></span>
          <h2 id="work-title">{center ? words.allClear : words.rootQuestion}</h2>
          <p>{center ? words.allClearNote : words.rootQuestionNote}</p>
          <button className="primary-button" type="button" onClick={focusChat}>
            <Icon name="message" />{words.talk}
          </button>
        </div>}
        {receipts.length > 0 && <div className="recent-actions">
          <h3>{words.recentActions}</h3>
          {receipts.map((decision) => <ActionReceiptCard key={`${decision.replyId}-receipt`} decision={decision} />)}
        </div>}
      </section>
    </div>
  </main>;
}

function ContractControls({ center }: { center: Center | null }) {
  const [publisher, setPublisher] = useState(config.worldTitle);
  const [documentJson, setDocumentJson] = useState('');
  const [review, setReview] = useState<ContractReview | null>(null);
  const [pending, setPending] = useState<'export' | 'preview' | 'import' | null>(null);
  const [error, setError] = useState('');

  async function exportCurrent() {
    if (!center || !publisher.trim()) return;
    setPending('export'); setError('');
    try {
      const result = await post<{ document: CenterContractDocument; filename: string }>(
        '/api/centers/contract/export', {
          id: center.id, center_revision: center.revision, publisher: publisher.trim(),
        });
      downloadText(JSON.stringify(result.document, null, 2), result.filename);
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error);
    } finally {
      setPending(null);
    }
  }

  async function selectFile(file: File | null) {
    setReview(null); setDocumentJson(''); setError('');
    if (!file) return;
    setPending('preview');
    try {
      const raw = await file.text();
      const result = await post<ContractReview>('/api/centers/contract/preview', {
        center_id: center?.id ?? null,
        center_revision: center?.revision ?? null,
        registry_revision: config.registryRevision,
        document_json: raw,
      });
      setDocumentJson(raw); setReview(result);
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error);
    } finally {
      setPending(null);
    }
  }

  async function importReviewed() {
    if (!review || !documentJson || review.already_current) return;
    setPending('import'); setError('');
    try {
      const result = await post<{ center_id: string }>('/api/centers/contract/import', {
        center_id: center?.id ?? null,
        center_revision: center?.revision ?? null,
        registry_revision: config.registryRevision,
        document_json: documentJson,
        review_digest: review.review_digest,
        confirmed: true,
      });
      window.location.assign(centerHref(result.center_id));
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error);
      setPending(null);
    }
  }

  return <details className="drawer-section drawer-disclosure contract-section">
    <summary><span>{center ? words.shareFunction : words.sharedContracts}</span>
      <small>{words.shareFunctionNote}</small></summary>
    <div className="drawer-disclosure-body">
    {center && <>
      <p className="contract-provenance">{center.provenance}</p>
      <label className="contract-publisher">{words.publisher}
        <input value={publisher} maxLength={160} disabled={pending !== null}
          onChange={(event) => setPublisher(event.target.value)} />
      </label>
      <button className="quiet-button contract-export" type="button"
        disabled={pending !== null || !publisher.trim()} onClick={exportCurrent}>
        <Icon name="download" />{words.exportContract}
      </button>
    </>}
    <label className="contract-file">{words.importContract}
      <input type="file" accept=".json,application/json" disabled={pending !== null}
        onChange={(event) => {
          const file = event.target.files?.[0] ?? null;
          event.currentTarget.value = '';
          void selectFile(file);
        }} />
    </label>
    {pending === 'preview' && <p className="drawer-muted">{words.reviewingContract}</p>}
    {review && <div className="contract-review">
      <span className="draft-pill"><Icon name="check" />{words.contractChecked}</span>
      <small>{words.contractSource}</small>
      <strong>{review.source.publisher}</strong>
      <p>{review.definition.title}</p>
      <div className="contract-mini-flow">
        <span><b>x</b>{review.definition.input}</span>
        <Icon name="arrow" />
        <span><b>f(x)</b>{review.definition.output}</span>
      </div>
      <details><summary>{words.details}</summary><div className="card-details-body">
        <Detail label={words.purpose} value={review.definition.purpose} />
        <Detail label={words.process} value={review.definition.process} />
        <Detail label={words.benefit} value={review.definition.benefit} />
        <Detail label={words.proof} value={review.definition.acceptance} />
        <Detail label={words.boundaries} value={review.definition.boundaries} />
      </div></details>
      <p className="contract-impact">{review.operation === 'creation'
        ? words.contractCreatesCenter
        : words.contractRevisesCenter.replace('{count}', String(review.changed_fields.length))}</p>
      {review.warnings.map((warning) => <p className="contract-warning" key={warning}>{warning}</p>)}
      {review.already_current
        ? <p className="contract-current"><Icon name="check" />{words.contractAlreadyCurrent}</p>
        : <button className="primary-button" type="button" disabled={pending !== null}
          onClick={importReviewed}><Icon name="check" />{words.applyContract}</button>}
    </div>}
    {error && <p className="inline-error" role="alert">{error}</p>}
    </div>
  </details>;
}

function HierarchySection({ center }: { center: Center | null }) {
  const parent = center?.parent_id ? topology.byId.get(center.parent_id) ?? null : null;
  const children = topology.childrenOf(center?.id ?? null);
  return <section className="drawer-section hierarchy-section">
    <h3>{words.hierarchy}</h3>
    {center && <div className="hierarchy-parent">
      <small>{words.containedIn}</small>
      <a href={parent ? centerHref(parent.id) : centerHref(null)}>
        <span className="center-nav-mark">{parent ? 'ƒ' : 'C₀'}</span>
        <strong>{parent?.definition.title ?? words.root}</strong>
        <Icon name="chevron" />
      </a>
    </div>}
    <small className="hierarchy-label">{center ? words.subcenters : words.branches}</small>
    {children.length === 0 ? <p className="drawer-muted">{words.noSubcenters}</p>
      : <div className="hierarchy-children">{children.map((child) => <a href={centerHref(child.id)} key={child.id}>
        <span className="center-nav-mark">ƒ</span>
        <span><strong>{child.definition.title}</strong><small>{statusLabel(child.status, words)}</small></span>
        <Icon name="chevron" />
      </a>)}</div>}
  </section>;
}

function CenterControls({ center }: { center: Center }) {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const controls: Array<{ action: string; label: string; danger?: boolean }> = [];
  if (center.readiness.ready && !center.qualification && center.status !== 'retired') controls.push({ action: 'qualify', label: words.qualify });
  if (center.qualification && center.status !== 'active' && center.status !== 'retired') controls.push({ action: 'activate', label: words.activate });
  if (center.status === 'active') controls.push({ action: 'pause', label: words.pause });
  if (center.status === 'retired') controls.push({ action: 'restore', label: words.restore });
  else controls.push({ action: 'retire', label: words.retire, danger: true });

  async function run(action: string) {
    if (action === 'activate' && !window.confirm(words.confirmActivate)) return;
    if (action === 'retire' && !window.confirm(words.confirmRetire)) return;
    setPending(true); setError('');
    try {
      if (action === 'qualify') await post('/api/centers/qualify', { id: center.id, revision: config.registryRevision });
      else await post('/api/centers/action', {
        id: center.id, action, revision: config.registryRevision,
        review_digest: action === 'activate' ? center.qualification?.review_digest ?? null : null,
        confirmed: action === 'activate',
      });
      window.location.reload();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error); setPending(false);
    }
  }

  return <div className="drawer-controls">
    {controls.map((control) => <button key={control.action}
      className={control.danger ? 'danger-button' : 'quiet-button'} type="button"
      disabled={pending} onClick={() => run(control.action)}>{control.label}</button>)}
    {error && <p className="inline-error" role="alert">{error}</p>}
  </div>;
}

function OrganBuild({ center, organ }: { center: Center; organ: PreparedOrgan }) {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  if (organ.legacy) return <p className="organ-build-note">{words.legacyOrganBuild}</p>;
  if (!organ.current_contract) return <p className="organ-build-note">{words.staleOrganBuild}</p>;
  if (organ.build.status !== 'not_started') return <div className="organ-build-action">
    {organ.build.status === 'task_saved' && <span>{words.organTaskSaved}</span>}
    <a className="quiet-button" href={workshopHref()}>{words.openWorkshop}</a>
  </div>;

  async function build() {
    setPending(true); setError('');
    try {
      await post('/api/centers/organ/build', {
        center_id: center.id,
        center_revision: center.revision,
        reply_id: organ.origin_reply_id,
        digest: organ.digest,
      });
      window.location.assign(workshopHref());
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error);
      setPending(false);
    }
  }

  return <div className="organ-build-action">
    <button className="primary-button" type="button" disabled={pending} onClick={build}>
      <Icon name="spark" />{words.buildOrgan}
    </button>
    {error && <p className="inline-error" role="alert">{error}</p>}
  </div>;
}

function EquipmentSection({ center }: { center: Center }) {
  const means = center.prepared_adapters;
  return <section className="drawer-section equipment-section">
    <h3>{words.equipmentRules}</h3>
    <div className="equipment-overview">
      <span><small>{words.agent}</small><strong>{words.conversationAgent}</strong><em>{words.proposalOnly}</em></span>
      <span><small>{words.means}</small><strong>{means.length}</strong><em>{words.plannedMeans}</em></span>
      <span><small>{words.authority}</small><strong>{words.ownerAuthority}</strong><em>{words.beforeEachEffect}</em></span>
    </div>
    <details className="equipment-disclosure">
      <summary>{words.inspectEquipment}<Icon name="chevron" /></summary>
      <div className="equipment-body">
        <div className="equipment-agent">
          <span className="equipment-mark">t.</span>
          <div><strong>{words.conversationAgent}</strong><small>{words.proposalOnly}</small>
            <p>{words.centerAgentNote}</p></div>
        </div>
        <div className="equipment-subhead"><strong>{words.adapters}</strong><span>{means.length}</span></div>
        {means.length === 0 ? <p className="drawer-muted">{words.noAdapters}</p> : means.map((organ, index) => <div className="adapter-row" key={`${organ.name}-${index}`}>
          <div><strong>{organ.name}</strong><span>{organRoleLabel(organ.role)} · {organ.current_contract ? words.currentContract : words.staleContract}</span></div>
          <p>{organ.translation}</p>
          <small>{organ.interface} · {organ.operation} · {words.preparedOnly}</small>
          <div className="effect-list">
            {organ.requested_effects.map((effect) => <span key={effect}>{effectLabel(effect)}</span>)}
            <em>{words.requestedNotGranted}</em>
          </div>
          <details className="organ-details"><summary>{words.details}</summary><div className="card-details-body">
            <Detail label={words.organRequirements} value={organ.requirements} />
            <Detail label={words.input} value={organ.input} />
            <Detail label={words.output} value={organ.output} />
            <Detail label={words.proof} value={organ.acceptance} />
            <Detail label={words.boundaries} value={organ.boundaries} />
          </div></details>
          <OrganBuild center={center} organ={organ} />
        </div>)}
        <div className="authority-card"><div><Icon name="check" /><strong>{words.noImplicitRights}</strong></div>
          <p>{words.noImplicitRightsNote}</p></div>
      </div>
    </details>
  </section>;
}

function DetailsDrawer({ center, open, close }: { center: Center | null; open: boolean; close: () => void }) {
  const relatedLinks = center
    ? [...topology.incomingTo(center.id), ...topology.outgoingFrom(center.id)] : [];
  return <>
    {open && <button className="drawer-backdrop" type="button" onClick={close} aria-label={words.close} />}
    <aside className={`details-drawer ${open ? 'is-open' : ''}`} aria-hidden={!open} aria-label={words.details}>
      <header className="drawer-head"><div><span>{words.details}</span><h2>{center?.definition.title ?? words.root}</h2></div>
        <button className="icon-button" type="button" onClick={close} aria-label={words.close}><Icon name="close" /></button>
      </header>
      <div className="drawer-body">
        {center ? <>
          <HierarchySection center={center} />
          <section className="drawer-section"><h3>{words.centerContract}</h3>
            <Detail label={words.purpose} value={center.definition.purpose} />
            <Detail label={`${words.input} x`} value={center.definition.input} />
            <Detail label={words.process} value={center.definition.process} />
            <Detail label={`${words.output} f(x)`} value={center.definition.output} />
            <Detail label={words.benefit} value={center.definition.benefit} />
            <Detail label={words.proof} value={center.definition.acceptance} />
            <Detail label={words.boundaries} value={center.definition.boundaries} />
          </section>
          <EquipmentSection center={center} />
          <section className="drawer-section"><h3>{words.history}</h3>
            <div className="metric-row"><span><b>{center.readiness.reported}</b>{words.cases}</span><span><b>{center.readiness.counterexamples}</b>{words.counterexamples}</span><span><b>{center.history.length}</b>{words.versions}</span></div>
          </section>
          <section className="drawer-section"><h3>{words.links}</h3>
            {relatedLinks.length === 0 ? <p className="drawer-muted">{words.noLinks}</p> : relatedLinks.map((link) => {
              const outgoing = link.source_id === center.id;
              const other = topology.byId.get(outgoing ? link.target_id : link.source_id);
              return <a className="connection-row" href={other ? centerHref(other.id) : undefined} key={link.id}>
                <Icon name="link" /><div><span>{outgoing ? words.sendsTo : words.receivesFrom}</span>
                  <strong>{other?.definition.title ?? '—'}</strong><p>{link.translation}</p><small>{link.purpose}</small></div>
                <Icon name="chevron" />
              </a>;
            })}
          </section>
          <ContractControls center={center} />
          <CenterControls center={center} />
        </> : <><HierarchySection center={null} /><ContractControls center={null} /><ResourceLinks /></>}
      </div>
    </aside>
  </>;
}

function ResourceLinks() {
  const rows = [
    [words.landmarks, `/explore?${query({ world: config.world, lang: config.locale })}`],
    [words.imports, `/onboarding?${query({ world: config.world })}`],
    [words.tools, `/tools?${query({ world: config.world })}`],
    [words.devices, `/devices?${query({ world: config.world })}`],
    [words.aiConnection, `/connect?${query({ world: config.world, lang: config.locale })}`],
    [words.guide, `/guide?${query({ world: config.world, lang: config.locale })}`],
  ];
  return <section className="drawer-section resource-section"><h3>{words.resources}</h3>
    {rows.map(([label, href]) => <a href={href} key={href}><span>{label}</span><Icon name="chevron" /></a>)}
  </section>;
}

interface BackupExport {
  bundle: unknown;
  filename: string;
}

interface BackupPreview {
  review_digest: string;
  expected_current_digest: string;
  created_at: string;
  state_bytes: number;
  summary: { spaces: number; centers: number; active_messages: number };
}

function downloadText(value: string, filename: string) {
  const url = URL.createObjectURL(new Blob([value], { type: 'application/json' }));
  const link = document.createElement('a');
  link.href = url; link.download = filename; link.hidden = true;
  document.body.append(link); link.click(); link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function BackupModal({ open, close }: { open: boolean; close: () => void }) {
  const [mode, setMode] = useState<'export' | 'restore'>('export');
  const [secret, setSecret] = useState('');
  const [repeat, setRepeat] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [bundle, setBundle] = useState<unknown>(null);
  const [preview, setPreview] = useState<BackupPreview | null>(null);
  const [afterDigest, setAfterDigest] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  function reset(next: 'export' | 'restore') {
    setMode(next); setSecret(''); setRepeat(''); setFile(null); setBundle(null);
    setPreview(null); setAfterDigest(''); setNotice(''); setError('');
  }

  function dismiss() {
    if (busy) return;
    reset('export');
    close();
  }

  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setNotice('');
    if (secret !== repeat) { setError(words.phrasesDiffer); return; }
    setBusy(true);
    try {
      const result = await post<BackupExport>('/api/backup/export', { scope: 'core' });
      const encrypted = await encryptPortableBundle(result.bundle, secret);
      downloadText(encrypted, result.filename);
      setSecret(''); setRepeat(''); setNotice(words.backupCreated);
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error);
    } finally { setBusy(false); }
  }

  async function inspect(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setNotice(''); setPreview(null); setBundle(null); setAfterDigest('');
    if (!file) { setError(words.fileRequired); return; }
    setBusy(true);
    try {
      const clear = await decryptPortableFile(file, secret);
      const result = await post<BackupPreview>('/api/backup/inspect', { bundle: clear });
      setBundle(clear); setPreview(result); setSecret('');
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error);
    } finally { setBusy(false); }
  }

  async function restore() {
    if (!preview || !bundle || !window.confirm(words.confirmRestore)) return;
    setBusy(true); setError(''); setNotice('');
    try {
      const fresh = await post<BackupPreview>('/api/backup/inspect', { bundle });
      if (fresh.review_digest !== preview.review_digest) throw new Error(words.error);
      const result = await post<{ after_digest: string }>('/api/backup/restore', {
        bundle, review_digest: fresh.review_digest,
        expected_current_digest: fresh.expected_current_digest, confirmed: true,
      });
      setAfterDigest(result.after_digest); setBundle(null); setPreview(null); setNotice(words.restoreDone);
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error);
    } finally { setBusy(false); }
  }

  async function rollback() {
    if (!afterDigest) return;
    setBusy(true); setError('');
    try {
      await post('/api/backup/rollback', { after_digest: afterDigest, confirmed: true });
      window.location.reload();
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error); setBusy(false);
    }
  }

  if (!open) return null;
  return <div className="backup-modal" role="dialog" aria-modal="true" aria-labelledby="backup-title">
    <button className="modal-backdrop" type="button" onClick={dismiss} aria-label={words.close} />
    <section className="backup-panel">
      <header className="backup-head"><div><span>{words.backup}</span><h2 id="backup-title">{words.backupTitle}</h2></div>
        <button className="icon-button" type="button" disabled={busy} onClick={dismiss} aria-label={words.close}><Icon name="close" /></button>
      </header>
      <div className="backup-tabs" role="tablist">
        <button type="button" className={mode === 'export' ? 'is-active' : ''} onClick={() => reset('export')}>{words.createBackup}</button>
        <button type="button" className={mode === 'restore' ? 'is-active' : ''} onClick={() => reset('restore')}>{words.restoreBackup}</button>
      </div>
      <div className="backup-body">
        <p className="backup-intro">{words.backupIntro}</p>
        <div className="backup-scope"><Icon name="backup" /><div><strong>{words.backupCore}</strong><p>{words.backupExcluded}</p></div></div>
        {mode === 'export' ? <form className="backup-form" onSubmit={create}>
          <label>{words.secretPhrase}<input type="password" autoComplete="new-password" minLength={12} maxLength={256} required value={secret} onChange={(event) => setSecret(event.target.value)} /></label>
          <label>{words.repeatSecret}<input type="password" autoComplete="new-password" minLength={12} maxLength={256} required value={repeat} onChange={(event) => setRepeat(event.target.value)} /></label>
          <small>{words.noRecovery}</small>
          <button className="primary-button" type="submit" disabled={busy}>{words.createBackup}</button>
        </form> : <>
          {!afterDigest && !preview && <form className="backup-form" onSubmit={inspect}>
            <label>{words.chooseBackup}<input type="file" accept=".tao-backup,application/json" required onChange={(event) => setFile(event.target.files?.[0] ?? null)} /></label>
            <label>{words.secretPhrase}<input type="password" autoComplete="current-password" minLength={12} maxLength={256} required value={secret} onChange={(event) => setSecret(event.target.value)} /></label>
            <button className="primary-button" type="submit" disabled={busy}>{words.inspectBackup}</button>
          </form>}
          {preview && <div className="backup-preview">
            <span className="verified-mark"><Icon name="check" />{words.backupPreview}</span>
            <strong>{new Date(preview.created_at).toLocaleString(config.locale)}</strong>
            <p>{preview.summary.spaces} · {preview.summary.centers} · {preview.summary.active_messages}<small>{words.backupCounts}</small></p>
            <button className="danger-button" type="button" disabled={busy} onClick={restore}>{words.replaceLocal}</button>
          </div>}
        </>}
        {notice && <div className="backup-success" role="status"><Icon name="check" /><p>{notice}</p>
          {afterDigest && <div><button className="quiet-button" type="button" disabled={busy} onClick={() => window.location.reload()}>{words.reload}</button>
            <button className="danger-link" type="button" disabled={busy} onClick={rollback}>{words.undoRestore}</button></div>}
        </div>}
        {error && <p className="inline-error" role="alert">{error}</p>}
      </div>
    </section>
  </div>;
}

function validReview(value: UpdateStatus['review']): value is UpdateReview {
  return Boolean(value && 'schema' in value && value.schema === 'tao.update.review.v1');
}

function validAttempt(value: UpdateStatus['attempt']): value is UpdateAttempt {
  return Boolean(value && 'schema' in value && value.schema === 'tao.update.attempt.v1');
}

function UpdateModal({ open, close }: { open: boolean; close: () => void }) {
  const [state, setState] = useState<UpdateStatus>(config.update);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const review = validReview(state.review) ? state.review : null;
  const priorAttempt = validAttempt(state.attempt) ? state.attempt : null;
  const localStateError = (!review && state.review && 'error' in state.review ? state.review.error : '')
    || (!priorAttempt && state.attempt && 'error' in state.attempt ? state.attempt.error : '');
  const fingerprint = state.public_key_sha256 ? `${state.public_key_sha256.slice(0, 12)}…` : '—';

  async function readStatus(): Promise<UpdateStatus> {
    const response = await fetch(scoped('/api/update/status'), { cache: 'no-store' });
    let value: Record<string, unknown> = {};
    try { value = await response.json() as Record<string, unknown>; } catch { /* handled below */ }
    if (!response.ok) throw new Error(typeof value.error === 'string' ? value.error : words.error);
    return value as unknown as UpdateStatus;
  }

  async function checkUpdate() {
    setBusy(true); setError(''); setNotice(words.updateChecking);
    try {
      const result = await post<UpdateStatus>('/api/update/check', {});
      setState(result); setNotice('');
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error); setNotice('');
    } finally { setBusy(false); }
  }

  async function watchInstall(version: string) {
    for (let count = 0; count < 600; count += 1) {
      await new Promise((resolve) => window.setTimeout(resolve, 1000));
      try {
        const current = await readStatus();
        setState(current);
        const attempt = current.attempt;
        if (attempt && 'schema' in attempt && attempt.schema === 'tao.update.attempt.v1') {
          if (attempt.status === 'failed') {
            setError(attempt.message); setNotice(''); setBusy(false); return;
          }
          if (attempt.status === 'installed' && current.current_version === version) {
            setNotice(words.updateInstalled);
            window.setTimeout(() => window.location.reload(), 700);
            return;
          }
        }
      } catch { /* A local restart is expected; keep polling the same address. */ }
    }
    setError(words.error); setNotice(''); setBusy(false);
  }

  async function installUpdate() {
    if (!review || !window.confirm(words.updateConfirm)) return;
    setBusy(true); setError(''); setNotice(words.updateStarting);
    try {
      await post('/api/update/install', { review_digest: review.review_digest, confirmed: true });
      await watchInstall(review.version);
    } catch (exception) {
      setError(exception instanceof Error ? exception.message : words.error);
      setNotice(''); setBusy(false);
    }
  }

  if (!open) return null;
  return <div className="backup-modal" role="dialog" aria-modal="true" aria-labelledby="update-title">
    <button className="modal-backdrop" type="button" disabled={busy} onClick={close} aria-label={words.close} />
    <section className="backup-panel update-panel">
      <header className="backup-head"><div><span>{words.update}</span><h2 id="update-title">{words.updateTitle}</h2></div>
        <button className="icon-button" type="button" disabled={busy} onClick={close} aria-label={words.close}><Icon name="close" /></button>
      </header>
      <div className="backup-body update-body">
        <div className="update-current"><span>{words.updateCurrent}</span><strong>{state.current_version}</strong></div>
        <p className="backup-intro">{words.updateManual}</p>
        {!state.configured ? <div className="update-unconfigured">
          <Icon name="update" /><div><strong>{words.updateUnconfigured}</strong><p>{state.configuration_error ?? words.updateConfigure}</p>
            <code>tao update configure --release-url https://…/ --trusted-key /chemin/cle-publique.pem</code></div>
        </div> : <>
          <div className="update-trust">
            <span><small>{words.updateSource}</small><strong>{state.source}</strong></span>
            <span><small>{words.updateTrust}</small><strong>{fingerprint}</strong></span>
          </div>
          <button className="quiet-button update-check" type="button" disabled={busy} onClick={checkUpdate}>
            <Icon name="update" />{words.updateCheck}
          </button>
          {review && <div className={`update-review ${review.available ? 'is-available' : ''}`}>
            <span className="verified-mark"><Icon name="check" />{words.updateVerified}</span>
            <h3>{review.available ? `${words.updateAvailable} · ${review.version}` : words.updateCurrentEnough}</h3>
            {review.changes.length > 0 && <div className="update-list"><small>{words.updateChanges}</small><ul>
              {review.changes.map((change, index) => <li key={`${index}-${change.fr}`}>{change[config.locale]}</li>)}
            </ul></div>}
            <div className="update-memory"><small>{words.updateMigrations}</small>
              <p>{review.state_migrations?.length ? review.state_migrations.join(' · ') : words.updateNoMigration}</p>
            </div>
            {review.available && review.installable && <button className="primary-button" type="button" disabled={busy} onClick={installUpdate}>
              <Icon name="update" />{words.updateInstall}
            </button>}
            {review.available && !review.installable && <div className="update-blocked"><strong>{words.updateBlocked}</strong><p>{review.reason}</p></div>}
          </div>}
        </>}
        {notice && <div className="backup-success" role="status"><Icon name="update" /><p>{notice}</p></div>}
        {!notice && priorAttempt?.status === 'installed' && priorAttempt.version === state.current_version
          && <div className="backup-success" role="status"><Icon name="check" /><p>{priorAttempt.message}</p></div>}
        {!notice && (priorAttempt?.status === 'failed' || priorAttempt?.status === 'interrupted')
          && <p className="inline-error" role="alert">{priorAttempt.message}</p>}
        {localStateError && <p className="inline-error" role="alert">{localStateError}</p>}
        {error && <p className="inline-error" role="alert">{error}</p>}
      </div>
    </section>
  </div>;
}

function Chat({ center }: { center: Center | null }) {
  const initialBusy = Boolean(config.initialJob && ['queued', 'running'].includes(config.initialJob.status));
  const initialFailed = Boolean(config.initialJob && ['blocked', 'interrupted', 'cancelled'].includes(config.initialJob.status));
  const [messages, setMessages] = useState<Message[]>(config.messages);
  const [draft, setDraft] = useState('');
  const [model, setModel] = useState('');
  const [attached, setAttached] = useState<CenterInputReference | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [busy, setBusy] = useState(initialBusy);
  const [jobId, setJobId] = useState(config.initialJob?.id ?? null);
  const [streamText, setStreamText] = useState(config.initialJob?.partial_text ?? '');
  const [notice, setNotice] = useState(config.initialJob?.message ?? (initialBusy ? words.thinking : ''));
  const [error, setError] = useState(initialFailed);
  const [canRetry, setCanRetry] = useState(Boolean(config.initialJob?.retryable));
  const [revision, setRevision] = useState(config.initialJob?.dialogue_revision ?? config.dialogueRevision);
  const log = useRef<HTMLDivElement>(null);
  const textarea = useRef<HTMLTextAreaElement>(null);
  const initialWatch = useRef(false);
  const storageKey = `tao.center.draft.${config.world}.${center?.id ?? 'root'}`;
  const inputKey = center ? centerInputStorageKey(center.id) : `${storageKey}.input`;
  const attachedRow = config.centerInputs.find((row) => sameInputReference(row.reference, attached)) ?? null;

  useEffect(() => {
    try {
      setDraft(sessionStorage.getItem(storageKey) ?? '');
      setModel(localStorage.getItem('tao.dialogue.model') ?? '');
      const prior = JSON.parse(sessionStorage.getItem(inputKey) ?? 'null') as CenterInputReference | null;
      if (prior && config.centerInputs.some((row) => sameInputReference(row.reference, prior))) setAttached(prior);
    } catch { /* storage is optional */ }
  }, [storageKey, inputKey]);

  useEffect(() => {
    log.current?.scrollTo({ top: log.current.scrollHeight });
  }, [messages, streamText, busy]);

  useEffect(() => {
    if (window.location.hash === '#chat') textarea.current?.focus();
  }, []);

  async function readJob(id: string): Promise<DialogueJob> {
    const response = await fetch(scoped(`/api/dialogue?id=${encodeURIComponent(id)}`), { cache: 'no-store' });
    let value: Record<string, unknown> = {};
    try { value = await response.json() as Record<string, unknown>; } catch { /* handled below */ }
    if (!response.ok) throw new Error(typeof value.error === 'string' ? value.error : words.error);
    return value as unknown as DialogueJob;
  }

  async function watch(start: DialogueJob) {
    const running = ['queued', 'running'].includes(start.status);
    setBusy(running); setJobId(start.id); setNotice(running ? words.thinking : (start.message || words.error));
    setError(false); setCanRetry(false);
    if (start.partial_text) setStreamText(start.partial_text);
    if (typeof start.dialogue_revision === 'number') setRevision(start.dialogue_revision);
    try {
      let state = start;
      for (let count = 0; count < 3600 && ['queued', 'running'].includes(state.status); count += 1) {
        await new Promise((resolve) => window.setTimeout(resolve, 500));
        state = await readJob(start.id);
        if (typeof state.partial_text === 'string') setStreamText(state.partial_text);
        if (typeof state.dialogue_revision === 'number') setRevision(state.dialogue_revision);
      }
      if (state.status === 'answered') {
        setNotice(words.loading);
        window.setTimeout(() => window.location.reload(), 180);
        return;
      }
      setNotice(state.message || words.error);
      setError(true); setBusy(false); setCanRetry(Boolean(state.retryable));
      setJobId(state.retryable ? state.id : null);
    } catch (exception) {
      setNotice(exception instanceof Error ? exception.message : words.error);
      setError(true); setBusy(false); setCanRetry(false); setJobId(null);
    }
  }

  useEffect(() => {
    if (config.initialJob && !initialWatch.current) {
      initialWatch.current = true;
      void watch(config.initialJob);
    } else if (!config.initialJob) textarea.current?.focus();
  }, []);

  function saveDraft(value: string) {
    setDraft(value);
    try { sessionStorage.setItem(storageKey, value); } catch { /* optional */ }
  }

  function chooseInput(row: CenterInput) {
    const reference = row.reference;
    setAttached(reference); setPickerOpen(false);
    try { sessionStorage.setItem(inputKey, JSON.stringify(reference)); } catch { /* optional */ }
    textarea.current?.focus();
  }

  function removeInput() {
    setAttached(null);
    try { sessionStorage.removeItem(inputKey); } catch { /* optional */ }
  }

  async function send(event: FormEvent) {
    event.preventDefault();
    const text = draft.trim();
    if (!text || busy) return;
    setBusy(true); setError(false); setCanRetry(false); setNotice(words.thinking); setStreamText('');
    try {
      const nonce = globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
      const job = await post<DialogueJob>('/api/dialogue/send', {
        text,
        revision,
        nonce,
        focus: config.focus,
        intent: 'auto',
        model: model.trim() || null,
        input_reference: attached,
      });
      const optimistic: Message = {
        id: `optimistic-${nonce}`, role: 'user', text, job_id: job.id, model: model.trim() || null,
        input_context: attachedRow ? { context: { title: attachedRow.title, concept_id: attachedRow.concept_id } } : undefined,
      };
      if (typeof job.dialogue_revision === 'number') setRevision(job.dialogue_revision);
      setMessages((current) => [...current, optimistic]);
      saveDraft(''); removeInput();
      try { sessionStorage.removeItem(storageKey); } catch { /* optional */ }
      await watch(job);
    } catch (exception) {
      setNotice(exception instanceof Error ? exception.message : words.error);
      setError(true); setBusy(false); setJobId(null);
    }
  }

  async function retry() {
    if (!jobId || busy || !canRetry) return;
    setBusy(true); setError(false); setCanRetry(false); setNotice(words.thinking); setStreamText('');
    try {
      const job = await post<DialogueJob>('/api/dialogue/retry', { id: jobId, revision });
      if (typeof job.dialogue_revision === 'number') setRevision(job.dialogue_revision);
      await watch(job);
    } catch (exception) {
      setNotice(exception instanceof Error ? exception.message : words.error);
      setError(true); setBusy(false);
    }
  }

  async function stop() {
    if (!jobId) return;
    try { await post('/api/dialogue/cancel', { id: jobId }); setNotice(`${words.stop}…`); }
    catch (exception) { setNotice(exception instanceof Error ? exception.message : words.error); setError(true); }
  }

  const title = center?.definition.title ?? words.root;
  return <aside className="chat" id="chat" aria-label={`${words.conversation} ${words.inCenter} ${title}`}>
    <header className="chat-header">
      <span className="chat-avatar">t.</span>
      <div><strong>{words.conversation} <span>{words.inCenter} {title}</span></strong><small><i />{words.noAutomation}</small></div>
      <a className="chat-device-link" href={scoped('/devices')} title={words.devices} aria-label={words.devices}>
        <Icon name="device" /><span>{words.devices}</span>
      </a>
    </header>
    <div className="chat-log" ref={log} aria-live="polite">
      {messages.length === 0 && !busy && <div className="empty-chat"><Icon name="message" /><p>{words.emptyChat}</p></div>}
      {messages.map((message) => <MessageBubble key={message.id} message={message} />)}
      {busy && <article className="chat-message assistant streaming-message">
        <div className="message-author">Tao</div>
        <div className="message-bubble">{streamText || <span className="typing"><i /><i /><i /></span>}</div>
      </article>}
      {!busy && error && streamText && <article className="chat-message assistant interrupted-message">
        <div className="message-author">Tao</div>
        <div className="message-bubble">{streamText}</div>
        <small className="partial-label">{words.partialReply}</small>
      </article>}
    </div>
    <div className="composer-shell">
      {pickerOpen && <InputPicker rows={config.centerInputs} onChoose={chooseInput} onClose={() => setPickerOpen(false)} />}
      <form className="composer" onSubmit={send}>
        {attachedRow && <div className="attached-input"><span>x</span><div><strong>{attachedRow.title}</strong><small>{attachedRow.concept_label}</small></div><button type="button" onClick={removeInput}>{words.remove}</button></div>}
        <textarea id="tao-message" ref={textarea} value={draft} disabled={busy} maxLength={6000} rows={1}
          placeholder={center ? words.placeholderCenter : words.placeholderRoot}
          onChange={(event) => saveDraft(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) {
              event.preventDefault(); event.currentTarget.form?.requestSubmit();
            }
          }} />
        <div className="composer-bar">
          <div className="composer-left">
            <input className="model-input" list="tao-models" value={model} disabled={busy}
              aria-label={words.model} placeholder={words.modelAuto}
              onChange={(event) => { setModel(event.target.value); try { localStorage.setItem('tao.dialogue.model', event.target.value.trim()); } catch { /* optional */ } }} />
            <datalist id="tao-models"><option value="gpt-6-astra" /><option value="gpt-5.6-sol" /><option value="gpt-5.6-terra" /><option value="gpt-5.6-luna" /></datalist>
            {center && <button className="composer-tool" type="button" disabled={busy} onClick={() => setPickerOpen((value) => !value)} aria-label={words.attach} title={words.attach}><Icon name="attach" /><span>x</span></button>}
          </div>
          {busy ? <button className="send-button stop" type="button" onClick={stop} aria-label={words.stop}><Icon name="stop" /></button>
            : <button className="send-button" type="submit" disabled={!draft.trim()} aria-label={words.send}><Icon name="send" /></button>}
        </div>
      </form>
      <div className="chat-status">
        <p className={`chat-notice ${error ? 'is-error' : ''}`}>{notice}</p>
        {canRetry && <button className="retry-button" type="button" disabled={busy} onClick={retry}>{words.retry}</button>}
      </div>
    </div>
  </aside>;
}

function MessageBubble({ message }: { message: Message }) {
  const human = message.role === 'user';
  const count = proposalCount(message);
  const attachedTitle = message.input_context?.context?.title;
  const warnings = [
    ...(message.center_capture?.warnings ?? []),
    ...captureKinds.flatMap((kind) => message.center_capture?.[kind]?.warnings ?? []),
    ...(message.center_capture?.action?.warnings ?? []),
    ...(message.center_capture?.output?.warnings ?? []),
  ];
  return <article className={`chat-message ${human ? 'human' : 'assistant'}`}>
    <div className="message-author">{human ? words.you : 'Tao'}{message.model ? <span> · {message.model}</span> : null}</div>
    {attachedTitle && <div className="message-attachment"><b>x</b><span>{attachedTitle}</span></div>}
    <div className="message-bubble">{message.text}</div>
    {count > 0 && <span className="message-proposal"><Icon name="spark" />{count} {count === 1 ? words.reviewOne : words.reviewMany} · {words.reviewTitle.toLowerCase()}</span>}
    {warnings.map((warning) => <p className="message-warning" key={warning}>{warning}</p>)}
  </article>;
}

function InputPicker({ rows, onChoose, onClose }: { rows: CenterInput[]; onChoose: (row: CenterInput) => void; onClose: () => void }) {
  return <div className="input-picker-popover">
    <header><strong>{words.chooseInput}</strong><button className="icon-button" type="button" onClick={onClose} aria-label={words.close}><Icon name="close" /></button></header>
    <div className="input-picker-list">{rows.length === 0 ? <p>{words.noInputs}</p> : rows.map((row) => <button type="button" key={row.id} onClick={() => onChoose(row)}>
      <span>x</span><div><strong>{row.title}</strong><small>{row.concept_label}</small><p>{row.text}</p></div><Icon name="chevron" />
    </button>)}</div>
  </div>;
}

function App() {
  const selected = config.selectedCenterId
    ? config.centers.find((center) => center.id === config.selectedCenterId) ?? null
    : null;
  const [menuOpen, setMenuOpen] = useState(false);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [backupOpen, setBackupOpen] = useState(false);
  const [updateOpen, setUpdateOpen] = useState(false);
  return <div className="tao-app">
    <button className="mobile-menu-button icon-button" type="button" onClick={() => setMenuOpen(true)} aria-label={words.menu}><Icon name="menu" /></button>
    <Sidebar selected={selected} open={menuOpen} close={() => setMenuOpen(false)}
      openBackup={() => setBackupOpen(true)} openUpdate={() => setUpdateOpen(true)} />
    <Workspace center={selected} onDetails={() => setDetailsOpen(true)} />
    <Chat center={selected} />
    <DetailsDrawer center={selected} open={detailsOpen} close={() => setDetailsOpen(false)} />
    <BackupModal open={backupOpen} close={() => setBackupOpen(false)} />
    <UpdateModal open={updateOpen} close={() => setUpdateOpen(false)} />
  </div>;
}

const root = document.getElementById('tao-root');
if (!root) throw new Error('Racine Tao absente.');
createRoot(root).render(<App />);
