# Tao — architecture et exploitation

Ce document est la référence humaine unique du runtime Tao. Le `README` couvre
le démarrage ; `docs/VALIDATION.md` conserve la preuve courante ;
`docs/theory.json` est un contrat machine, pas un guide produit.

## 1. Produit et invariants

Tao est un poste de travail local centré sur une transformation :

```text
entrée x → centre Cᵢ → sortie proposée f(x) → revue → effet autorisé → preuve
```

Un centre est défini par son contrat, son état, sa mémoire, son processus, son
rythme, ses limites et ses résidus. Une fonction sans état propre peut rester une
capacité d’un centre. Un sous-centre n’est utile que lorsqu’une transformation
distincte gagne réellement à avoir sa propre mémoire et son propre cycle.

`C₀` reçoit les entrées qui ne justifient pas encore un centre spécialisé. La
naissance ne crée donc aucun ensemble prédéfini de centres. Les spécialisations
sont proposées depuis des histoires et des écarts observables, puis conservées
seulement si leur bénéfice dépasse leur coût de complexité.

Le noyau conserve ce qu’un modèle de langage ne doit pas posséder seul :

- identité et état durable ;
- provenance et version des entrées ;
- permissions et décisions du propriétaire ;
- preuves, échecs et cas non intégrés ;
- sauvegarde, compatibilité et retour arrière.

Une réponse plausible, une exécution technique et une résolution observée sont
trois faits différents.

## 2. Interface

L’interface de travail possède trois zones :

1. la hiérarchie empirique des centres ;
2. le centre courant, ses entrées et ses sorties à relire ;
3. la conversation IA située dans ce centre.

Les tâches, histoires, missions, rôles, ressources et preuves sont des objets du
travail, pas des destinations principales. `/explore` les conserve comme
projections secondaires. `/classic` et l’ancien accueil restent des alias de
compatibilité ; ils ne constituent pas d’autres produits.

Une proposition produite par la conversation est inerte. La création ou la
révision d’un centre, l’acceptation d’un lien, la construction d’un organe, les
tests, l’installation et l’action métier sont des décisions séparées.

## 3. Modèle seed et héritage

Le seed exécutable se résume à :

```text
persist → observe → compare → residual → vary → test → retain / rollback
```

Le runtime fournit des invariants lents à changer : écritures atomiques,
autorité explicite, budgets, conservation des résidus et réversibilité. Un
descendant reçoit une identité neuve, le runtime et uniquement le patrimoine
inerte sélectionné. Il ne reçoit ni mémoire privée, ni compte, ni permission.

Un patrimoine distant reste une proposition à relire. Il n’est jamais exécuté
directement. Une pratique répétée peut devenir une recette locale seulement
après cas positifs, contre-exemple, qualification et activation explicite.

## 4. Composition du runtime

`bootstrap/tao_runtime.py` est l’inventaire ordonné unique des modules installés
et hérités :

| Groupe | Responsabilités |
| --- | --- |
| kernel | persistance, théorie, mondes, centres, sauvegarde, ressources |
| intelligence | dialogue, routage descriptif, mémoire de retours |
| evolution | atelier Git, qualification, installation et rollback |
| capabilities | recettes, outils externes, ponts, appareils et accès facultatifs |
| projections | API HTTP et interfaces de lecture |

Les invariants vivent côté serveur. Le front-end React/TypeScript consomme des
projections bornées et ne devient pas la source de vérité.

Le runtime standard utilise uniquement la bibliothèque Python. Node est requis
pour reconstruire le front-end, pas pour exécuter Tao. Aucun fournisseur métier,
IDE, stockage cloud ou serveur MCP n’est intégré d’office.

## 5. État, fichiers et concurrence

Les sources, le runtime installé et les données privées sont distincts. Une
installation standard utilise :

```text
sources choisies/                 code relu
~/.tao/genesis/releases/          runtimes immuables
~/.tao/genesis/runtime            lien vers le runtime actif
~/.tao/genesis/runtime.previous   lien de retour arrière
~/.tao/genesis/state.json         cœur privé atomique
~/.tao/genesis/state.prev.json    dernier état précédent
```

Les écritures privées passent par un verrou interprocessus, une validation de
schéma et un remplacement atomique. Les opérations sensibles utilisent une
révision ou une empreinte attendue afin qu’un onglet ancien n’écrase pas une
décision plus récente.

Certains volumes sont séparés du cœur : archives d’import, travaux d’atelier,
registres d’outils, journaux et caches publics. Leur présence doit rester visible
dans les sauvegardes et les diagnostics ; ils ne sont pas implicitement appelés
« mémoire complète ».

## 6. IA et mémoire de conversation

Le dialogue appelle un fournisseur uniquement après un envoi explicite. Le
contexte est borné au centre, aux extraits choisis, aux contrats nécessaires et
à une mémoire locale sélectionnée. Les textes importés et les réponses IA
gardent leur provenance et ne deviennent ni faits ni permissions.

Codex CLI est actuellement le premier adaptateur. La détection d’un exécutable
ne prouve pas que le compte est connecté, que le quota suffit ou que le modèle
peut agir sur une application. Une erreur réelle reste affichée avec le brouillon
de l’utilisateur ; elle n’est pas remplacée par un succès artificiel.

Le flux progressif utilise un travail identifié, des événements bornés et une
reprise après interruption. Le daemon basal n’appelle aucun modèle, n’analyse
aucun compte et ne déclenche aucun polling métier.

## 7. Organes, outils et appareils

Un organe est une capacité bornée dont le centre peut avoir besoin : interface,
traduction, service local ou adaptateur externe. Son plan déclare au minimum son
rôle, ses entrées/sorties, ses effets, ses permissions, sa preuve et son retour
arrière. Décrire un accès réseau ou une écriture ne crée pas cet accès.

Trois chemins existent :

- les recettes déclaratives exécutent hors IA des transformations locales
  qualifiées (`csv.audit`, `records.audit`, `text.template`) ;
- le client MCP sortant lance un serveur local déjà installé et explicitement
  choisi, puis sépare aperçu et appel ;
- Tao Bridge expose à un client local un espace et un ensemble d’outils bornés
  par un mandat révocable.

Pour le client MCP sortant, un centre sélectionné reçoit seulement un catalogue
borné d’outils déjà inspectés : identifiants, description, schéma d’entrée et
empreinte. La conversation peut en tirer une demande exacte, mais cette demande
reste au statut `review`. Le propriétaire voit le connecteur, l’outil, les
arguments, le résultat attendu, le risque et le retour arrière avant un clic
distinct. L’appel utilise ensuite l’empreinte et la révision relues, ne peut pas
être rejoué et conserve un reçu. Un résultat est affiché comme donnée externe
non vérifiée ; son affichage ne déclenche pas un nouvel appel IA.

Un reçu terminal (`succeeded`, `tool_error`, `failed`, `blocked` ou `unknown`)
peut servir d’entrée au centre suivant seulement si un lien dirigé relie le
centre qui a proposé l’appel à cette destination. Le navigateur ne conserve que
les identifiants du reçu et du lien. Au prochain envoi humain, le runtime résout
la proposition et le reçu dans ses propres registres, contrôle la direction,
borne le résultat externe et fige la provenance. Le clic **Utiliser dans…** est
donc une préparation locale : il ne lance ni outil, ni IA, ni transfert. Un reçu
en attente, écarté, falsifié ou présenté au mauvais centre est refusé.

Ce parcours constitue le premier degré d’autonomie opérationnelle : revue
humaine pour chaque action. Les mandats récurrents, budgets d’action, échéances
et règles d’escalade ne sont pas encore accordés aux centres. Ils ne pourront
être envisagés qu’à partir de reçus répétés et de limites révocables, sans
modifier les outils ou processus externes eux-mêmes.

Ces mécanismes ne sont pas des bacs à sable du compte Linux. Le programme choisi
garde les droits du processus qui le lance. Une action interrompue dont l’effet
est inconnu n’est jamais relancée automatiquement.

Un appareil appairé peut préparer une expérience sur le Linux choisi. La
génération, la revue, les tests, l’intégration et le redémarrage restent des
étapes distinctes. Aucun appareil n’hérite automatiquement des secrets ou des
sessions d’un autre.

## 8. Import et sauvegarde

L’onboarding accepte des JSON ou ZIP reconnus de ChatGPT et Claude, ainsi qu’un
format Tao borné. Chaque source est prévisualisée puis confirmée séparément. Le
runtime ne se connecte pas au compte fournisseur, n’extrait pas les pièces
jointes et ne rejoue pas les anciennes demandes.

Un format inconnu ou modifié par un fournisseur est refusé jusqu’à l’existence
d’un exemple reproductible. Ajouter Gemini ou un autre service signifie écrire
un adaptateur vérifiable, pas annoncer un import universel.

La sauvegarde `tao.encrypted-backup.v1` chiffre dans le navigateur un paquet
`tao.portable.core.v1` avec AES-256-GCM et une clé dérivée de la phrase secrète.
La phrase ne quitte pas le navigateur. La restauration vérifie le format, le
canon, l’état aperçu et la concurrence avant un remplacement atomique, puis
conserve `portable-restore.prev.json` pour annulation.

La version actuelle couvre `state.json`, pas les archives externes, les sources,
les secrets, les travaux en cours ni tous les journaux. Un fichier altéré,
incompatible ou déchiffré avec une mauvaise phrase ne modifie pas l’état courant.

## 9. Installation et mises à jour

`bootstrap/install.py` qualifie le runtime dans un état jetable, installe ses
octets sous un dossier immuable, conserve le pointeur précédent, démarre le
service et attend sa santé. Un échec remet le runtime précédent sans réécrire la
mémoire privée.

Les mises à jour sont manuelles :

```bash
tao update configure --release-url URL --trusted-key CLE_PUBLIQUE
tao update status
tao update check
```

La source de téléchargement et la source de confiance sont distinctes. Le
manifeste `tao.release.v2`, sa signature Ed25519, la taille et l’empreinte de
l’installateur sont vérifiés avant une seconde confirmation. La clé initiale doit
être obtenue par un canal indépendant.

Le premier updater intégré refuse toute release qui annonce une migration de
mémoire privée. Il n’existe ni vérification silencieuse, ni mise à jour en
arrière-plan. Un changement de format exceptionnel doit fournir sa migration,
sa preuve et son rollback dans un parcours séparé.

Le pointeur du contrat machine est une petite métadonnée privée. Les pointeurs
connus des versions 4.1 et 4.2 migrent vers 4.3 avec un reçu ; un pointeur inconnu
est préservé et signalé. Le retour arrière normal consiste à réactiver le runtime
précédent, qui garde son propre contrat canonique.

## 10. Portail, hébergement et téléphone

Le dossier `gaia/` construit un portail public statique : présentation,
catalogue inerte et artefacts de release. Il ne contient pas la mémoire d’un Tao,
n’appelle pas de modèle et ne sonde pas la machine du visiteur.

Le cockpit privé est une application web progressive : la même interface peut
s’ouvrir dans un onglet ou dans une fenêtre autonome installée par un navigateur
compatible. Le manifeste ne donne aucun droit système et aucun service worker ne
met en cache la mémoire privée. Sans runtime joignable, l’enveloppe installée ne
prétend pas pouvoir travailler.

Sur Debian et Ubuntu, l’enveloppe de bureau est un paquet `all`
très mince : une entrée dans le menu, l’icône, un lanceur Python sans dépendance
tierce et l’archive source vérifiée. Le paquet système ne crée aucune mémoire en
tant que root. Au premier lancement utilisateur, le lanceur installe le runtime
normal dans le compte, vérifie `doctor --require-running`, puis ouvre seulement
l’adresse loopback confirmée. Cette frontière réduit l’entretien lié aux mises à
jour de bureau ; Python 3.9+ et le contrat HTTP local restent les seules bases
système de cette expérience.

La version embarquée est un plancher, pas une version à imposer. Le lanceur
accepte un runtime sain de version numérique égale ou supérieure ; une version
ancienne, ambiguë ou non conforme ne passe pas cette comparaison. Une mise à
jour explicite du runtime ne peut donc pas être annulée par un ancien raccourci.

Dans le navigateur seul, Tao peut utiliser les capacités web et les services
explicitement reliés. Pour Git, les fichiers, un IDE ou un processus local, un
moteur appairé contacte Tao en sortie, annonce des moyens bornés puis reçoit une
opération relue ; la page web ne reçoit jamais un accès général au système.

Un profil hébergé est une installation Tao privée séparée, avec son propre
volume, son compte et ses coûts. Ce n’est ni le portail public ni une
synchronisation automatique du nœud local. Le transfert de mémoire est une
opération explicite.

L’accès mobile vise un Tao existant via HTTPS et un réseau privé. Chaque
navigateur est appairé et révocable. Le téléphone n’héberge pas le moteur Linux
et ne reçoit pas un droit général sur la machine.

## 11. Construction et publication

Construire localement :

```bash
bash scripts/verify.sh
python3 scripts/build_release.py
python3 scripts/build_linux_desktop.py
python3 scripts/build_gaia.py
```

`RELEASE_FILES.json` est l’autorisation exacte de lecture et de distribution.
Le constructeur refuse les chemins ambigus et les liens symboliques. Le mode
`--strict-git` exige que les octets distribués correspondent au commit et à
l’index.

Une somme SHA-256 placée à côté d’un fichier ne prouve pas son origine. La
publication exécutable demande une paire de clés fournie par le propriétaire :

```bash
python3 scripts/release_signing.py sign \
  --release-dir dist --private-key CLE_PRIVEE --public-key CLE_PUBLIQUE
python3 scripts/release_signing.py verify \
  --release-dir dist --trusted-key CLE_PUBLIQUE
python3 scripts/release_signing.py sign-desktop \
  --release-dir dist --private-key CLE_PRIVEE --public-key CLE_PUBLIQUE
python3 scripts/release_signing.py verify-desktop \
  --release-dir dist --trusted-key CLE_PUBLIQUE
python3 scripts/build_gaia.py \
  --release-dir dist --trusted-key CLE_PUBLIQUE
```

La clé privée reste hors du dépôt, des images et de `dist/`. Construire ou
signer ne publie rien. Le site de qualification, le domaine et le déploiement
restent des opérations distinctes.

Le manifeste principal reste `tao.release.v2` avec exactement le `.run` et
l’archive source, afin que le runtime 0.10.6 puisse encore lire la release. Le
paquet `.deb` utilise l’enveloppe additive `tao.desktop.release.v1` : elle nomme
le paquet, fixe sa taille et son empreinte, et contient l’empreinte exacte du
manifeste principal. Une seconde signature avec la même clé de confiance lie
cette enveloppe sans muter le schéma de mise à jour ni la mémoire privée.

Le retour arrière retire la publication du paquet et revient au tag public
précédent ; une installation locale conserve en plus `runtime.previous`. La
désinstallation du paquet système n’efface pas l’état privé du compte.

## 12. Faire évoluer Tao

Toute modification part d’un cas reproductible lié à une histoire :

1. écrire le résultat souhaité ;
2. borner les données, l’autorité et les effets ;
3. définir la preuve attendue et un contre-exemple ;
4. estimer le coût de complexité ;
5. tenter la plus petite expérience réversible ;
6. exécuter `bash scripts/verify.sh` avant de retenir le changement ;
7. conserver les échecs et les cas non intégrés.

Une mutation de schéma fournit une migration et un retour arrière. Une évolution
ordinaire préfère un champ optionnel, une enveloppe versionnée ou une projection
reconstructible. La compatibilité ne signifie pas que les formats ne changeront
jamais ; elle signifie qu’aucun changement n’efface ou ne réinterprète
silencieusement la mémoire.

## 13. Limites actuelles

- Codex est le seul adaptateur de conversation effectivement pris en charge.
- Les connecteurs métier et IDE sont construits au cas par cas ; aucun accès
  GitLab, mail ou navigateur n’est fourni par défaut.
- Un centre peut préparer un appel vers un outil MCP déjà installé, mais chaque
  appel exige encore une revue humaine exacte ; aucun mandat récurrent n’est
  implémenté.
- Les imports ne couvrent pas tous les fournisseurs ni leurs pièces jointes.
- Le paquet graphique actuel couvre Debian/Ubuntu ; les autres distributions,
  Windows et macOS n’ont pas encore d’artefact natif qualifié.
- La sauvegarde portable ne couvre pas encore tous les volumes privés.
- L’hébergement personnel, le téléphone, un vrai compte fournisseur et les
  outils du propriétaire exigent une qualification sur leur environnement.
- Les tests vérifient les contrats logiciels, pas la justesse universelle d’un
  modèle mathématique ni la qualité d’une réponse IA réelle.

Ces limites sont des résidus conservés. Elles ne sont ni masquées par un
indicateur positif ni transformées en fonctionnalités promises.
