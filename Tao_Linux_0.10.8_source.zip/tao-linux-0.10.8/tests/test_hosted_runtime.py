import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.request
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('tao_hosted_runtime_tests', ROOT / 'deployment' / 'hosted.py')
hosted = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hosted)


class HostedRuntimeTests(unittest.TestCase):
    def fixture(self, base):
        data = base / 'data'
        hosted.prepare_volume(data, os.geteuid(), os.getegid())
        env = hosted.process_env(data)
        return data, env

    def test_origin_is_https_explicit_or_railway_domain_only(self):
        self.assertEqual(hosted.origin_from_env({'TAO_HOST_ORIGIN': 'https://tao.example:8443'}), 'https://tao.example:8443')
        self.assertEqual(hosted.origin_from_env({'RAILWAY_PUBLIC_DOMAIN': 'tao.up.railway.app'}), 'https://tao.up.railway.app')
        for value in ('http://tao.example', 'https://tao.example/', 'https://tao.example?x=1',
                      'https://owner@tao.example', 'https://tao.example\\evil', 'https://tao.example:0'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                hosted.origin_from_env({'TAO_HOST_ORIGIN': value})
        for value in ('example.com', 'tao.up.railway.app/evil', 'tao.up.railway.app@evil', ''):
            with self.subTest(value=value), self.assertRaises(ValueError):
                hosted.origin_from_env({'RAILWAY_PUBLIC_DOMAIN': value})

    def test_process_environment_uses_persistent_account_and_hosted_interface(self):
        with tempfile.TemporaryDirectory() as td:
            data, env = self.fixture(Path(td))
            self.assertEqual(env['TAO_HOSTED'], '1')
            self.assertEqual(env['TAO_ROOT'], str(data / 'node'))
            self.assertEqual(env['HOME'], str(data / 'home'))
            self.assertEqual(env['CODEX_HOME'], str(data / 'codex'))
            self.assertTrue(env['PATH'].startswith(str(data / 'home' / '.local' / 'bin') + ':'))

    def test_volume_is_repeatable_but_does_not_take_existing_data_or_links(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            data, _env = self.fixture(base)
            note = data / 'node' / 'memory.txt'
            note.write_text('retained')
            hosted.prepare_volume(data, os.geteuid(), os.getegid())
            self.assertEqual(note.read_text(), 'retained')
            self.assertEqual((data.stat().st_mode & 0o777), 0o700)
            other = base / 'other'
            other.mkdir()
            (other / 'existing.txt').write_text('not ours')
            with self.assertRaisesRegex(ValueError, 'vide'):
                hosted.prepare_volume(other, os.geteuid(), os.getegid())
            (base / 'linked').symlink_to(other, target_is_directory=True)
            with self.assertRaises(ValueError):
                hosted.prepare_volume(base / 'linked', os.geteuid(), os.getegid())
            (data / 'home').rmdir()
            (data / 'home').symlink_to(other, target_is_directory=True)
            with self.assertRaises(ValueError):
                hosted.prepare_volume(data, os.geteuid(), os.getegid())
            self.assertEqual((other / 'existing.txt').read_text(), 'not ours')

    def test_boot_requires_a_mounted_volume_before_creating_state(self):
        with tempfile.TemporaryDirectory() as td:
            data = Path(td) / 'data'
            with self.assertRaisesRegex(ValueError, 'volume persistant'):
                hosted.require_mount(data)
            self.assertFalse(data.exists())
            with mock.patch.object(hosted.os.path, 'ismount', return_value=True):
                hosted.require_mount(data)

    def test_privilege_drop_clears_groups_before_uid_and_refuses_other_user(self):
        calls = []
        with mock.patch.object(hosted.os, 'geteuid', side_effect=[0, 1000]), mock.patch.object(hosted.os, 'getegid', return_value=1000), \
             mock.patch.object(hosted.os, 'setgroups', side_effect=lambda v: calls.append(('groups', v))), \
             mock.patch.object(hosted.os, 'setgid', side_effect=lambda v: calls.append(('gid', v))), \
             mock.patch.object(hosted.os, 'setuid', side_effect=lambda v: calls.append(('uid', v))):
            hosted.drop_privileges()
        self.assertEqual(calls, [('groups', []), ('gid', 1000), ('uid', 1000)])
        with mock.patch.object(hosted.os, 'geteuid', return_value=1001), self.assertRaises(ValueError):
            hosted.drop_privileges()

    def test_seed_is_independent_git_and_never_overwrites_changes_on_reboot(self):
        with tempfile.TemporaryDirectory() as td:
            data, env = self.fixture(Path(td))
            image = Path(td) / 'image'
            image.mkdir()
            (image / 'readme.txt').write_text('seed')
            (image / '.env').write_text('do not copy')
            (image / 'dist').mkdir()
            (image / 'dist' / 'ignored').write_text('archive')
            source = hosted.ensure_source(data, image, env)
            self.assertTrue((source / '.git').is_dir())
            self.assertEqual(hosted.git(source, 'status', '--porcelain', env=env), '')
            self.assertFalse((source / '.env').exists())
            self.assertFalse((source / 'dist').exists())
            self.assertEqual(hosted.git(source, 'remote', env=env), '')
            (source / 'readme.txt').write_text('human changes')
            (image / 'readme.txt').write_text('new image')
            self.assertEqual(hosted.ensure_source(data, image, env), source)
            self.assertEqual((source / 'readme.txt').read_text(), 'human changes')
            self.assertIn('readme.txt', hosted.git(source, 'status', '--porcelain', env=env))

    def test_existing_runtime_is_validated_and_never_reinstalled_implicitly(self):
        with tempfile.TemporaryDirectory() as td:
            data, env = self.fixture(Path(td))
            root = data / 'node'
            release = root / 'releases' / 'accepted'
            release.mkdir(parents=True)
            (release / 'tao_node.py').write_text('retained')
            (root / 'runtime').symlink_to('releases/accepted')
            (root / 'source.json').write_text(json.dumps({'path': str(data / 'source')}))
            with mock.patch.object(hosted.subprocess, 'run') as run:
                hosted.ensure_runtime(root, data / 'source', env)
                run.assert_not_called()
            (root / 'runtime').unlink()
            (root / 'runtime').symlink_to(data / 'home')
            with self.assertRaises(ValueError):
                hosted.ensure_runtime(root, data / 'source', env)

    def test_supervisor_obeys_installer_and_adopts_replacement_singleton(self):
        with tempfile.TemporaryDirectory() as td:
            data, env = self.fixture(Path(td))
            supervisor = hosted.Supervisor(data / 'node', env)
            with hosted.lock_file(data / 'node' / 'install.lock') as held:
                self.assertTrue(held)
                with mock.patch.object(hosted.subprocess, 'Popen') as popen:
                    self.assertEqual(supervisor.tick(), 'installing')
                    popen.assert_not_called()
            with hosted.lock_file(data / 'node' / 'daemon.lock') as held:
                self.assertTrue(held)
                with mock.patch.object(hosted.subprocess, 'Popen') as popen:
                    self.assertEqual(supervisor.tick(), 'adopted')
                    popen.assert_not_called()

    def test_real_install_daemon_installer_restart_and_persistence(self):
        with tempfile.TemporaryDirectory() as td:
            data, env = self.fixture(Path(td))
            source = hosted.ensure_source(data, ROOT, env)
            root = data / 'node'
            with socket.socket() as sock:
                sock.bind(('127.0.0.1', 0))
                port = sock.getsockname()[1]
            (root / 'policy.json').write_text(json.dumps({'http_port': port}))
            hosted.ensure_runtime(root, source, env)
            supervisor = hosted.Supervisor(root, env)
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

            def health():
                with opener.open(f'http://127.0.0.1:{port}/health', timeout=.3) as response:
                    return json.load(response)

            def await_health(previous=None):
                deadline = time.monotonic() + 12
                while time.monotonic() < deadline:
                    try:
                        row = health()
                        if row.get('ok') and row.get('session') != previous:
                            return row
                    except (OSError, ValueError):
                        pass
                    time.sleep(.05)
                self.fail('Hosted daemon did not become healthy')

            class NodeStop:
                def stop_daemon(self):
                    subprocess.run([sys.executable, str(root / 'runtime' / 'tao_node.py'), 'stop'],
                                   env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10, check=True)

            try:
                self.assertEqual(supervisor.tick(), 'started')
                first = await_health()
                subprocess.run([sys.executable, str(root / 'runtime' / 'tao_node.py'), 'story', 'set', 'Mémoire persistante'],
                               env=env, check=True, stdout=subprocess.DEVNULL, timeout=10)
                # An atelier installation owns the stop/start, creating a daemon
                # that is not the supervisor's original Popen child.
                installer = subprocess.Popen([sys.executable, str(source / 'bootstrap' / 'install.py')], env=env,
                                             stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
                statuses = []
                deadline = time.monotonic() + 30
                supervisor.next_start = 0
                try:
                    while installer.poll() is None and time.monotonic() < deadline:
                        statuses.append(supervisor.tick())
                        time.sleep(.01)
                    _out, error = installer.communicate(timeout=2)
                    self.assertEqual(installer.returncode, 0, error.decode())
                    self.assertNotIn('started', statuses)
                finally:
                    if installer.poll() is None:
                        installer.kill()
                        installer.wait(timeout=5)
                    installer.stderr.close()
                second = await_health(first['session'])
                supervisor.next_start = 0
                self.assertEqual(supervisor.tick(), 'adopted')
                self.assertEqual(health()['session'], second['session'])
                supervisor.close(NodeStop())
                supervisor.next_start = 0
                self.assertEqual(supervisor.tick(), 'started')
                await_health(second['session'])
                self.assertEqual(json.loads((root / 'story.json').read_text())['text'], 'Mémoire persistante')
                self.assertEqual(json.loads((root / 'source.json').read_text())['path'], str(source))
            finally:
                supervisor.close(NodeStop())


if __name__ == '__main__':
    unittest.main()
