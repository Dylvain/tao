import copy
import json
import socket
from unittest.mock import patch

from test_node import NodeHarness
import tao_reuse as reuse
import tao_worlds as worlds


class ReuseTests(NodeHarness):
    def active(self, name='records.audit', payload=None, origin='human'):
        row = reuse.propose(self.n, payload or reuse.template(name), origin=origin)
        row = reuse.qualify(self.n, row['id'], row['revision'])
        self.assertTrue(row['qualification']['ok'], row['qualification'])
        return reuse.activate(self.n, row['id'], row['revision'], row['qualification']['review_digest'])

    def read_sidecar(self):
        return json.loads((self.root / 'reuse' / 'main.json').read_text())

    def rewrite_sidecar(self, value):
        # Recompute the storage checksum to exercise the deeper definition guard.
        value.pop('_integrity', None)
        value['_integrity'] = reuse._digest(value)
        self.n.atomic_json(self.root / 'reuse' / 'main.json', value)

    def test_all_templates_qualify_but_never_activate_or_call_a_model(self):
        before = self.n.STATE.read_bytes()
        with patch.object(self.n.subprocess, 'run', side_effect=AssertionError('process forbidden')), \
                patch.object(socket, 'socket', side_effect=AssertionError('network forbidden')):
            for name in reuse.OPERATIONS:
                proposal = reuse.propose(self.n, reuse.template(name), origin='ai')
                self.assertEqual(proposal['status'], 'candidate')
                with self.assertRaisesRegex(ValueError, 'inactive'):
                    reuse.run(self.n, proposal['id'], proposal['definition']['cases'][0]['input'])
                qualified = reuse.qualify(self.n, proposal['id'], 0)
                self.assertTrue(qualified['qualification']['ok'])
                self.assertEqual(qualified['status'], 'qualified')
                with self.assertRaisesRegex(ValueError, 'inactive'):
                    reuse.run(self.n, qualified['id'], qualified['definition']['cases'][0]['input'])
                active = reuse.activate(self.n, qualified['id'], qualified['revision'], qualified['qualification']['review_digest'])
                receipt = reuse.run(self.n, active['id'], active['definition']['cases'][0]['input'])
                self.assertEqual(receipt['model_calls'], 0)
                self.assertEqual(receipt['output'], active['definition']['cases'][0]['expected'])
                self.assertIsNone(receipt['euros'])
                self.assertIsNone(receipt['joules'])
                self.assertGreaterEqual(receipt['duration_seconds'], 0)
        self.assertEqual(before, self.n.STATE.read_bytes())
        result = reuse.catalog(self.n)
        self.assertEqual(result['metrics']['completed_no_model_runs'], 3)
        self.assertEqual(result['metrics']['human_useful'], 0)
        self.assertNotIn('saved_ai_calls', result['metrics'])
        self.assertEqual((self.root / 'reuse' / 'main.json').stat().st_mode & 0o777, 0o600)

    def test_csv_audit_reports_missing_and_duplicate_without_reading_urls(self):
        row = self.active('csv.audit')
        values = {'csv': 'id,title,url\n7,Page,https://invalid.example/private\n7, ,../../secret\n8,Autre,/x\n'}
        with patch.object(self.n.urllib.request, 'urlopen', side_effect=AssertionError('no fetch')):
            result = reuse.run(self.n, row['id'], values)
        self.assertEqual(result['output'], {'row_count': 3, 'issues': [
            {'kind': 'duplicate', 'row': 2, 'column': 'id', 'first_row': 1},
            {'kind': 'missing', 'row': 2, 'column': 'title'}], 'issue_count': 2, 'valid': False})
        self.assertNotIn('invalid.example', json.dumps(reuse.catalog(self.n)))
        # Only the input hash is retained, not the supplied private records.
        self.assertEqual(result['input_digest'], reuse._digest(values))

    def test_every_call_validates_domain_and_unknown_fields(self):
        row = self.active('records.audit')
        bad = [
            {'records': [{'id': '1', 'title': 'x', 'url': '/', 'execute': 'ls'}]},
            {'records': [{'id': ['nested']}]},
            {'records': [{'id': 2 ** 129}]},
            {'records': [{'id': float('inf')}]},
            {'records': [], 'path': '/etc/passwd'},
            {'records': [{}] * 501},
            {'records': 'not-a-list'}]
        for values in bad:
            before = (self.root / 'reuse' / 'main.json').read_bytes()
            with self.assertRaises(ValueError):
                reuse.run(self.n, row['id'], values)
            self.assertEqual(before, (self.root / 'reuse' / 'main.json').read_bytes())
        csvrow = self.active('csv.audit')
        for value in ('id,title\n1,X\n', 'id,id,url\n1,2,/\n', 'id,title,url\n1,X,/,extra\n',
                      'id,title,url\n"unterminated', 'id,title,url\n1,\x00,/\n'):
            with self.assertRaises(reuse.DomainError):
                reuse.run(self.n, csvrow['id'], {'csv': value})
        self.assertEqual(reuse.catalog(self.n)['metrics']['completed_no_model_runs'], 0)

    def test_templates_are_one_pass_literal_and_attribute_access_is_rejected(self):
        row = self.active('text.template')
        literal = '{{next_step}} ${HOME} <script>alert(1)</script> ../../secret'
        result = reuse.run(self.n, row['id'], {'values': {'name': literal, 'next_step': '__import__("os").system("id")'}})
        self.assertEqual(result['output']['text'], 'Bonjour ' + literal + ',\nProchaine étape : __import__("os").system("id").')
        for dangerous in ('{{name.__class__}}', '{{name[0]}}', '{{__import__("os")}}', '{{name}} {{unknown}}'):
            payload = reuse.template('text.template')
            payload['config']['template'] = dangerous
            with self.assertRaises(ValueError):
                reuse.propose(self.n, payload)
        for values in ({'name': 'Alexis'}, {'name': 'Alexis', 'next_step': []},
                       {'name': 'x' * 501, 'next_step': 'x'},
                       {'name': 'Alexis', 'next_step': 'x', 'admin': True}):
            with self.assertRaises(reuse.DomainError):
                reuse.run(self.n, row['id'], {'values': values})

    def test_two_distinct_positive_cases_and_meaningful_negative_are_required(self):
        payload = reuse.template('records.audit')
        payload['cases'][1]['input'] = copy.deepcopy(payload['cases'][0]['input'])
        payload['cases'][1]['expected'] = copy.deepcopy(payload['cases'][0]['expected'])
        row = reuse.propose(self.n, payload)
        row = reuse.qualify(self.n, row['id'], 0)
        self.assertFalse(row['qualification']['ok'])
        self.assertEqual(row['qualification']['positive_cases'], 1)
        with self.assertRaises(ValueError):
            reuse.activate(self.n, row['id'], row['revision'], row['qualification']['review_digest'])
        payload = reuse.template('records.audit')
        payload['cases'][2] = {'label': 'Faux contre-exemple',
                               'input': {'records': [{'id': '77', 'title': 'Correct', 'url': '/ok'}]},
                               'expected': {'row_count': 1, 'issues': [], 'issue_count': 0, 'valid': True}}
        row = reuse.propose(self.n, payload)
        row = reuse.qualify(self.n, row['id'], 0)
        self.assertFalse(row['qualification']['ok'])
        self.assertEqual(row['qualification']['negative_cases'], 0)
        payload = reuse.template('records.audit')
        payload['cases'][0]['input'] = {'records': []}
        payload['cases'][0]['expected'] = {'row_count': 0, 'issues': [], 'issue_count': 0, 'valid': True}
        row = reuse.propose(self.n, payload)
        row = reuse.qualify(self.n, row['id'], 0)
        self.assertFalse(row['qualification']['ok'])
        self.assertEqual(row['qualification']['positive_cases'], 1)
        payload = reuse.template('records.audit')
        payload['cases'][2]['expected']['issue_count'] = 123
        row = reuse.propose(self.n, payload)
        row = reuse.qualify(self.n, row['id'], 0)
        self.assertFalse(row['qualification']['ok'])
        self.assertFalse(row['qualification']['cases'][2]['passed'])

    def test_semantically_duplicate_csv_examples_do_not_count_twice(self):
        payload = reuse.template('csv.audit')
        payload['cases'][1] = {'label': 'Même cas avec autres fins de ligne',
                               'input': {'csv': payload['cases'][0]['input']['csv'].replace('\n', '\r\n')},
                               'expected': payload['cases'][0]['expected']}
        row = reuse.propose(self.n, payload)
        row = reuse.qualify(self.n, row['id'], 0)
        self.assertEqual(row['qualification']['positive_cases'], 1)
        self.assertFalse(row['qualification']['ok'])

    def test_stale_revision_wrong_review_tampering_and_revocation_fail_closed(self):
        row = reuse.propose(self.n, reuse.template('records.audit'))
        qualified = reuse.qualify(self.n, row['id'], row['revision'])
        with self.assertRaises(ValueError):
            reuse.activate(self.n, row['id'], 0, qualified['qualification']['review_digest'])
        with self.assertRaises(ValueError):
            reuse.activate(self.n, row['id'], qualified['revision'], '0' * 64)
        active = reuse.activate(self.n, row['id'], qualified['revision'], qualified['qualification']['review_digest'])
        values = active['definition']['cases'][0]['input']
        with self.assertRaises(ValueError):
            reuse.run(self.n, row['id'], values, revision=0)
        reuse.run(self.n, row['id'], values, request_id='first')
        retired = reuse.retire(self.n, row['id'], active['revision'])
        with self.assertRaises(ValueError):
            reuse.run(self.n, row['id'], values, request_id='first')
        with self.assertRaises(ValueError):
            reuse.qualify(self.n, row['id'], retired['revision'])
        data = self.read_sidecar()
        data['recipes'][0]['definition']['config']['max_rows'] = 20
        self.rewrite_sidecar(data)
        with self.assertRaisesRegex(ValueError, 'revue'):
            reuse.catalog(self.n)

    def test_raw_storage_corruption_is_not_overwritten(self):
        self.active()
        path = self.root / 'reuse' / 'main.json'
        for content in ('{broken', path.read_text().replace('tao.reuse.v1', 'tao.reuse.v2')):
            path.write_text(content)
            with self.assertRaises(ValueError):
                reuse.propose(self.n, reuse.template('records.audit'))
            self.assertEqual(path.read_text(), content)

    def test_successor_preserves_history_but_requires_its_own_activation(self):
        previous = self.active()
        receipt = reuse.run(self.n, previous['id'], previous['definition']['cases'][0]['input'])
        payload = reuse.template('records.audit')
        payload.update(replaces_id=previous['id'], replaces_revision=previous['revision'])
        payload['description'] += ' Nouvelle explication.'
        candidate = reuse.propose(self.n, payload, origin='external')
        self.assertEqual(candidate['version'], 2)
        self.assertEqual(candidate['lineage_id'], previous['lineage_id'])
        reuse.run(self.n, previous['id'], previous['definition']['cases'][0]['input'])
        with self.assertRaises(ValueError):
            reuse.run(self.n, candidate['id'], candidate['definition']['cases'][0]['input'])
        candidate = reuse.qualify(self.n, candidate['id'], 0)
        candidate = reuse.activate(self.n, candidate['id'], candidate['revision'], candidate['qualification']['review_digest'])
        rows = reuse.catalog(self.n)['recipes']
        self.assertEqual(rows[0]['status'], 'retired')
        self.assertEqual(rows[0]['receipts'][0], receipt)
        self.assertEqual(rows[1]['status'], 'active')
        with self.assertRaises(ValueError):
            reuse.run(self.n, previous['id'], previous['definition']['cases'][0]['input'])

    def test_world_separation_unknown_world_and_symlink_rejection(self):
        main = self.active()
        child = worlds.create(self.n, 'Travail')
        with worlds.using(child['id']):
            self.assertEqual(reuse.catalog(self.n)['recipes'], [])
            with self.assertRaises(ValueError):
                reuse.run(self.n, main['id'], main['definition']['cases'][0]['input'])
            own = self.active()
            self.assertNotEqual(own['id'], main['id'])
        self.assertEqual(len(reuse.catalog(self.n)['recipes']), 1)
        with worlds.using('aaaaaaaaaaaa'):
            with self.assertRaises(ValueError):
                reuse.catalog(self.n)
        self.assertFalse((self.root / 'reuse' / 'aaaaaaaaaaaa.json').exists())
        with self.assertRaises(ValueError):
            with worlds.using('../../bad'):
                reuse.catalog(self.n)
        path = self.root / 'reuse' / 'main.json'
        other = self.base / 'other.json'
        path.rename(other)
        path.symlink_to(other)
        with self.assertRaises(ValueError):
            reuse.catalog(self.n)

    def test_idempotency_is_exact_and_cross_recipe_collisions_are_rejected(self):
        row = self.active()
        values = row['definition']['cases'][0]['input']
        first = reuse.run(self.n, row['id'], values, origin='external', request_id='source:42')
        second = reuse.run(self.n, row['id'], values, origin='external', request_id='source:42')
        self.assertEqual(first, second)
        self.assertEqual(reuse.catalog(self.n)['metrics']['completed_no_model_runs'], 1)
        with self.assertRaises(ValueError):
            reuse.run(self.n, row['id'], row['definition']['cases'][1]['input'], origin='external', request_id='source:42')
        other = self.active()
        with self.assertRaises(ValueError):
            reuse.run(self.n, other['id'], values, origin='external', request_id='source:42')
        with self.assertRaises(ValueError):
            reuse.run(self.n, row['id'], values, request_id='../escape')

    def test_human_usefulness_is_separate_correctable_and_adverse_report_retires(self):
        row = self.active()
        receipt = reuse.run(self.n, row['id'], row['definition']['cases'][0]['input'])
        row = reuse.report(self.n, row['id'], receipt['id'], True, 'Comparé manuellement au fichier source.', row['revision'])
        self.assertEqual(reuse.catalog(self.n)['metrics']['human_useful'], 1)
        row = reuse.report(self.n, row['id'], receipt['id'], False, 'Une règle métier manque au contrôle.', row['revision'])
        self.assertEqual(row['status'], 'retired')
        metrics = reuse.catalog(self.n)['metrics']
        self.assertEqual(metrics['human_useful'], 0)
        self.assertEqual(metrics['human_not_useful'], 1)
        self.assertEqual(metrics['completed_no_model_runs'], 1)
        self.assertEqual(len(row['reports']), 2)
        self.assertFalse(row['reports'][0]['verified_automatically'])
        with self.assertRaises(ValueError):
            reuse.run(self.n, row['id'], row['definition']['cases'][0]['input'])
        for useful, note in ((1, 'Invalid boolean'), (True, '')):
            with self.assertRaises(ValueError):
                reuse.report(self.n, row['id'], receipt['id'], useful, note, row['revision'])

    def test_capacity_errors_never_erase_or_count_rejected_work(self):
        row = self.active()
        values = row['definition']['cases'][0]['input']
        reuse.run(self.n, row['id'], values)
        path = self.root / 'reuse' / 'main.json'
        before = path.read_bytes()
        with patch.object(reuse, 'MAX_RECEIPTS', 1):
            with self.assertRaises(ValueError):
                reuse.run(self.n, row['id'], values)
        with patch.object(reuse, 'MAX_RECIPES', 1):
            with self.assertRaises(ValueError):
                reuse.propose(self.n, reuse.template('text.template'))
        with patch.object(reuse, 'MAX_STORE_BYTES', len(before) + 10):
            with self.assertRaises(ValueError):
                reuse.run(self.n, row['id'], values)
        self.assertEqual(before, path.read_bytes())
        with self.assertRaises(ValueError):
            reuse.run(self.n, row['id'], {'records': [{'title': 'x' * reuse.MAX_IO_BYTES}]})
        self.assertEqual(before, path.read_bytes())

    def test_lexical_suggestion_is_neither_dispatch_nor_authority(self):
        row = reuse.propose(self.n, reuse.template('records.audit'), origin='external')
        suggestions = reuse.suggest(self.n, 'export contenus')
        self.assertEqual(suggestions[0]['id'], row['id'])
        self.assertTrue(suggestions[0]['proposal_only'])
        self.assertEqual(suggestions[0]['status'], 'candidate')
        self.assertEqual(reuse.catalog(self.n)['metrics']['completed_no_model_runs'], 0)
        with self.assertRaises(ValueError):
            reuse.propose(self.n, dict(reuse.template('records.audit'), shell='ls'))
        with self.assertRaises(ValueError):
            reuse.propose(self.n, reuse.template('records.audit'), origin='owner_by_ai_claim')
