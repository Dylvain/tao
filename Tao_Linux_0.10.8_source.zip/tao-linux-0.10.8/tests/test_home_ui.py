"""The empty scaffold never invents or executes; edits keep exact review scope."""
import html
import http.client
import json
import os
import re
import shutil
import subprocess
import threading
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from test_node import NodeHarness
from test_mobile_ui import Page
import tao_foundations as foundations
import tao_home_ui as ui
import tao_landmarks as landmarks
import tao_navigation_ui as navigation
import tao_dialogue as dialogue
import tao_onboarding as onboarding
import tao_ui as dialogue_ui
import tao_worlds as worlds


DOM = r'''
const assert=require('assert'),crypto=require('crypto');
class Element {
 constructor(tag){this.tagName=tag;this.children=[];this.value='';this.textContent='';this.checked=false;this.disabled=false;this.hidden=false;this.listeners={};this.attributes={};this.classList={toggle(){}}}
 append(...items){for(const item of items)this.appendChild(item)}
 appendChild(item){item.parent=this;this.children.push(item);return item}
 replaceChildren(...items){this.children=[];this.textContent='';this.append(...items)}
 setAttribute(name,value){this.attributes[name]=value}
 get childElementCount(){return this.children.length}
 addEventListener(name,fn){this.listeners[name]=fn}
 querySelectorAll(selector){const types=selector.split(',');return all(this).filter(node=>types.includes(node.tagName))}
 querySelector(selector){return this.querySelectorAll(selector)[0]||null}
 focus(){} scrollIntoView(){}
 remove(){if(this.parent)this.parent.children=this.parent.children.filter(item=>item!==this)}
 closest(selector){return this.tagName===selector?this:this.parent?.closest(selector)||null}
 set innerHTML(value){throw Error('Unsafe markup insertion: '+value)}
}
function all(node){return [node,...node.children.flatMap(all)]}
const nodes=new Map(),document={body:new Element('body'),createElement:tag=>new Element(tag),getElementById:id=>{const existing=[...nodes.values()].flatMap(all).find(item=>item.id===id);if(existing)return existing;if(!nodes.has(id))nodes.set(id,new Element('div'));return nodes.get(id)},addEventListener(){},querySelectorAll:selector=>[...nodes.values()].flatMap(node=>node.querySelectorAll(selector))};
const window={addEventListener(){}},location={origin:'https://tao.example.test',href:'',reloads:0,reload(){this.reloads++}},token='csrf-owner',config={world:'012345abcdef',node:'private-node',locale:'fr'};
const foundation={initialized:true,revision:7,areas:[{key:'work',label:'Travail',description:'Rôles et tâches',world_id:config.world,status:'active'}],spaces:[{id:'main',title:'Principal',display_title:'Principal'},{id:config.world,title:'Mon travail',display_title:'Mon travail',description:'',parent_id:'main',template_key:'work',archived:false,effective_archived:false}],concepts:[{id:'tao.concept.task',label:'Tâche',definition:'Une contribution bornée'}]};
const landmarks={revision:4,world_id:config.world,slots:[{concept_id:'tao.concept.task',active_count:0,proposed_count:2,archived_count:0}],items:[{id:'112233aabbcc',concept_id:'tao.concept.task',title:'<img onerror=bad()>',text:'Ne pas exécuter <script>bad()</script>',status:'proposed',revision:3,origin:'ai',provenance:[{source_id:'message:x',quote:'javascript:evil()',role:'user',authority:'reported'}],history:[]},{id:'112233aabbdd',concept_id:'tao.concept.task',title:'Même situation',text:'Mon complément',status:'proposed',revision:2,origin:'human',provenance:[],history:[]}]};
const saved=new Map(),sessionStorage={getItem:key=>saved.get(key)||null,setItem:(key,value)=>saved.set(key,value),removeItem:key=>saved.delete(key)};
let handler=null;const calls=[];
const fetch=async(path,options)=>{const call={path,options,data:options.body?JSON.parse(options.body):undefined};calls.push(call);return handler?handler(call):{ok:true,status:200,json:async()=>({ok:true})}};
const confirm=()=>true,turn=()=>new Promise(setImmediate);
function rendered(node){return all(node).map(item=>item.textContent).join('\n')}
function clickText(root,text){const node=all(root).find(item=>item.tagName==='button'&&item.textContent===text);assert(node,'Missing '+text);return node.onclick()}
'''


class HomeUITests(NodeHarness):
    def run_js(self, text, syntax=False):
        node = os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node:
            self.skipTest('JavaScript runtime optional')
        path = self.base / 'home-ui.js'
        path.write_text(text)
        result = subprocess.run([node, *(['--check'] if syntax else []), str(path)],
                                capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        return result.stdout

    def script(self, tail='', setup=''):
        return DOM + 'const words=' + json.dumps(ui.WORDS['fr']) + ';\n' + setup + ui.DRAFT_JS + ui.PAGE_JS + tail

    def test_render_is_read_only_and_keeps_scoped_records_inert(self):
        state = foundations.initialize(self.n, revision=0)
        work = next(row['world_id'] for row in state['areas'] if row['key'] == 'work')
        personal = next(row['world_id'] for row in state['areas'] if row['key'] == 'personal')
        with worlds.using(work):
            landmarks.create(self.n, 'tao.concept.task', '</script><img src=x>', 'WORK_ONLY_SOURCE')
        with worlds.using(personal):
            landmarks.create(self.n, 'tao.concept.story', 'Histoire privée', 'PERSONAL_ONLY_SOURCE')
        before = self.n.STATE.read_bytes()
        with worlds.using(work), patch.object(self.n, 'TOKEN', '</script><img src=x>'):
            page = ui.render(self.n, self.n.load_state())
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertEqual(page.count('</script>'), 1)
        self.assertNotIn('<img src=x>', page)
        self.assertIn(r'\u003c/script>', page)
        self.assertIn('WORK_ONLY_SOURCE', page)
        self.assertNotIn('PERSONAL_ONLY_SOURCE', page)
        self.assertIn('view=dialogue', page)
        self.assertIn('width=device-width,initial-scale=1', page)
        parsed = Page(page)
        self.assertEqual(len(parsed.ids), len(set(parsed.ids)))
        self.run_js(page.split('<script>', 1)[1].split('</script>', 1)[0], syntax=True)

    def test_new_locale_translates_scaffold_without_translating_user_data(self):
        foundations.initialize(self.n, revision=0)
        landmarks.create(self.n, 'tao.concept.question', 'Ma question en français', 'Ce texte doit rester le mien.')
        page = ui.render(self.n, self.n.load_state(), locale='en')
        self.assertIn('<html lang="en">', page)
        self.assertIn('Your home is ready.', page)
        self.assertIn('Connecting a model enables discussion.', page)
        self.assertIn('The existing discussion and tools remain in French.', page)
        self.assertIn('Ma question en fran', page)
        self.assertIn('Ce texte doit rester le mien.', page)
        self.assertIn('Your home is ready.', ui.render(self.n, locale='en'))
        self.assertIn('<html lang="fr">', ui.render(self.n, locale='<script>'))
        for locale, account, model in [('fr', 'Mon accès', 'Connexion du modèle'),
                                       ('en', 'My access', 'Model connection')]:
            with patch.dict(os.environ, {'TAO_HOSTED': '1'}):
                hosted_page = ui.render(self.n, locale=locale)
            self.assertIn('href="/host/account"', hosted_page)
            self.assertIn('>' + account + '</a>', hosted_page)
            self.assertIn('href="/host/ai"', hosted_page)
            self.assertIn('>' + model + '</a>', hosted_page)
            with patch.dict(os.environ, {'TAO_HOSTED': '0'}):
                local_page = ui.render(self.n, locale=locale)
            self.assertNotIn('href="/host/account"', local_page)
            self.assertNotIn('href="/host/ai"', local_page)

    def test_one_sidebar_partitions_every_landmark_type_once(self):
        catalogue = foundations.initialize(self.n, revision=0)
        work = next(row['world_id'] for row in catalogue['areas'] if row['key'] == 'work')
        with worlds.using(work):
            page = navigation.render(self.n, self.n.load_state(), current='mission',
                                     world=work, overview=foundations.overview(self.n))
        types = re.findall(r'data-tao-type="([a-z]+)"', page)
        self.assertEqual(len(types), len(foundations.CONCEPTS))
        self.assertEqual(set(types), set(foundations.CONCEPTS))
        self.assertEqual(len(types), len(set(types)))
        self.assertEqual(page.count('aria-current="page"'), 1)
        self.assertIn('data-tao-key="mission"', page)
        self.assertIn('Travail', page)
        self.assertIn('Atlas Tao', page)
        self.assertIn('<details class="tao-reference-zone" open>', page)
        self.assertLess(page.index('tao-work-block'), page.index('tao-reference-zone'))

    def test_core_pages_share_the_sidebar_without_the_old_top_menu(self):
        explorer = ui.render(self.n, self.n.load_state())
        discussion = self.n.dashboard(self.n.load_state())
        for page in (explorer, discussion):
            self.assertEqual(page.count('data-tao-sidebar'), 1)
            self.assertIn('class="tao-has-sidebar"', page)
            self.assertNotIn('class="house-navigation"', page)
        self.assertIn('id="house-map"', explorer)
        self.assertIn('id="workshop-link"', discussion)
        self.assertIn('href="#work-progress"', discussion)

    def test_imported_memory_is_visible_without_fabricating_landmarks_or_neighbor_counts(self):
        from test_onboarding import document
        packet = document()
        packet['spaces'][2]['notes'] *= 3
        packet['spaces'][2]['needs'] *= 2
        preview = onboarding.preview(self.n, packet)
        result = onboarding.apply(self.n, packet, preview['review_digest'], confirmed=True)
        work = next(row['id'] for row in result['spaces'] if row['key'] == 'work')
        with worlds.using(work):
            state = self.n.load_state()
            summary = ui.history_summary(state, work)
            self.assertEqual(summary, {'present': True, 'imported_notes': 2, 'imported_needs': 1,
                                      'sources': 1, 'archives': 0, 'conversations': 0})
            self.assertEqual(landmarks.view(self.n)['items'], [])
            page = ui.render(self.n, state)
            self.assertIn('Ce qui est déjà ici', page)
            self.assertIn('2 notes importées conservées', page)
            self.assertIn('/?world=' + work + '&amp;view=dialogue#continuity-panel', page)
            self.assertIn('/history?world=' + work, page)
            self.assertNotIn('FAMILY_ONLY', page)
            self.assertNotIn('WORK_ONLY', page)  # Only counts; sources are in their existing views.
            self.assertNotIn('3 notes importées conservées', page)
        with worlds.using(work):
            with self.assertRaises(ValueError):
                ui.history_summary(self.n.load_state(), 'main')

    def test_archive_summary_counts_only_its_registered_world(self):
        state = self.n.load_state()
        state.setdefault('continuity', {})['external_archives'] = [{
            'id': 'a' * 64, 'digest': 'a' * 64, 'world_id': 'main', 'messages': 4,
            'conversations': 2, 'bytes': 100, 'archive_digest': 'b' * 64}]
        result = ui.history_summary(state, 'main')
        self.assertTrue(result['present'])
        self.assertEqual(result['archives'], 1)
        self.assertEqual(result['conversations'], 2)
        state['continuity']['external_archives'][0]['world_id'] = '112233aabbcc'
        with self.assertRaises(ValueError): ui.history_summary(state, 'main')

    def test_home_token_uses_proxy_replacement_contract(self):
        with patch.object(self.n, 'TOKEN', 'private-owner-fixture-token'):
            page = ui.render(self.n)
        expected = 'const token=' + json.dumps('private-owner-fixture-token') + ';'
        self.assertEqual(page.count(expected), 1)
        redacted = page.replace(expected, 'const token="browser-scoped-token";')
        self.assertNotIn('private-owner-fixture-token', redacted)

    def test_accepted_large_records_fit_gateway_with_unicode_and_escape_expansion(self):
        for character, length, count in [('🌱', 1100, 350), ('<', 4000, 350)]:
            with self.subTest(character=character):
                registry = {'schema': landmarks.SCHEMA, 'revision': count, 'items': []}
                content = character * length
                for index in range(count):
                    row = landmarks._new(self.n, 'tao.concept.story', 'Source ' + str(index), content,
                        'human', [{'source_id': 'entry:synthetic:' + str(index), 'quote': content,
                        'role': 'user', 'world_id': 'main', 'authority': 'human_report_unverified'}])
                    registry['items'].append(row)
                state = self.n.load_state()
                landmarks._save(self.n, state, registry)
                added = landmarks.create(self.n, 'question', 'Unicode exact',
                                         '</script><script>alert(1)</script> 🌱\u2028\u2029', count)
                complete = landmarks.view(self.n)
                self.assertEqual(len(complete['items']), count + 1)
                self.assertLess(len(self.n.json_bytes(complete)), 8 * 1024 * 1024)
                before = self.n.STATE.read_bytes()
                page = ui.render(self.n)
                self.assertLess(len(page.encode('utf-8')), 8 * 1024 * 1024)
                self.assertEqual(page.count('</script>'), 1)
                self.assertNotIn('<script>alert(1)</script>', page)
                self.assertNotIn('\u2028', page)
                self.assertNotIn('\u2029', page)
                self.assertEqual(self.n.STATE.read_bytes(), before)
                self.assertEqual(landmarks.view(self.n)['items'][-1]['text'], added['text'])
                if character == '<':
                    self.assertTrue(ui._initial_records(complete)['items'][0]['preview'])
                    self.assertEqual(ui._initial_records(complete)['items'][0]['text'], '<' * 600)

    def test_abbreviated_records_require_full_read_before_review_edit_and_merge(self):
        self.run_js(self.script(r'''
(async()=>{
 assert(!all(nodes.get('cards')).some(item=>item.textContent===words.accept));
 const full={...landmarks,items:landmarks.items.map(item=>({...item,text:'Texte complet '+item.id+' FIN_IMPORTANTE',preview:undefined,history:[{title:'Avant',text:'Historique complet'}],provenance:[{quote:'Source entière',role:'assistant'}]}))};
 handler=()=>({ok:true,status:200,json:async()=>full});
 await editCard(landmarks.items[0]);assert.equal(calls.length,1);assert.equal(calls[0].options.method,undefined);assert.equal(calls[0].path,'/api/landmarks?world=012345abcdef');
 let form=document.getElementById('landmark-112233aabbcc').querySelector('form');assert(form.querySelector('textarea').value.endsWith('FIN_IMPORTANTE'));
 assert(all(nodes.get('cards')).some(item=>item.textContent===words.accept));
 selected.add('112233aabbcc');selected.add('112233aabbdd');await openMerge();
 form=nodes.get('merge-form').querySelector('form');assert(form.querySelector('textarea').value.includes('Texte complet 112233aabbdd FIN_IMPORTANTE'));assert.equal(calls.length,2);assert(!calls.some(call=>call.options.method==='POST'));
})().catch(error=>{console.error(error);process.exitCode=1});
''', setup="for(const item of landmarks.items){item.preview=true;item.source_count=1;item.history_count=1;}\n"))

    def test_classifying_imports_only_prepares_a_scoped_question(self):
        self.run_js(self.script(r'''
assert(rendered(nodes.get('cards')).includes(words.empty_after_import));assert.equal(calls.length,0);
nodes.get('classify-history').onclick();assert.equal(calls.length,0);
const value=JSON.parse(saved.get('tao-explorer-draft:private-node:012345abcdef'));
assert.equal(value.text,words.classify_draft);assert.deepEqual(value.focus,{kind:'space',id:'012345abcdef',revision:7});
assert(!value.text.includes('WORK_ONLY'));assert(location.href.includes('view=dialogue'));
''', setup="config.history={present:true};landmarks.items=[];\n"))

    def test_retired_entrance_question_remains_recoverable_in_a_room(self):
        self.run_js(self.script(r'''
assert.equal(nodes.get('question-pending').hidden,false);
const link=all(nodes.get('spaces')).find(item=>item.tagName==='a'&&rendered(item).includes('Mon travail'));
assert(link);let prevented=false;link.listeners.click({preventDefault(){prevented=true}});
assert(prevented);assert.equal(saved.get('tao-steward-question:private-node'),null);
const draft=JSON.parse(saved.get('tao-explorer-draft:private-node:012345abcdef'));
assert.equal(draft.text,'Question conservée avant la réduction');
assert.equal(location.href,'/?view=dialogue&world=012345abcdef#dialogue');
assert.equal(calls.length,0);
''', setup=r'''
saved.set('tao-steward-question:private-node','Question conservée avant la réduction');
const originalQueryAll=document.querySelectorAll;
document.querySelectorAll=selector=>selector==='#spaces a.space-link'
 ?all(nodes.get('spaces')).filter(item=>item.tagName==='a'):originalQueryAll(selector);
'''))

    def test_generated_urls_reach_real_owner_routes_and_legacy_import(self):
        catalogue = foundations.initialize(self.n, revision=0)
        child = next(row['world_id'] for row in catalogue['areas'] if row['key'] == 'work')
        paths = json.loads(self.run_js(self.script(
            "console.log(JSON.stringify([scoped('/api/landmarks'),scoped('/api/foundations/update'),scoped('/explore'),talkUrl()]));",
            setup='config.world=' + json.dumps(child) + ';\n')))
        with worlds.using(child):
            page = ui.render(self.n, self.n.load_state(), locale='en')
        import_url = next(html.unescape(value) for value in re.findall('href="([^"]+)"', page)
                          if value.startswith('/onboarding?'))
        self.assertNotIn('lang=', import_url)
        self.assertEqual(import_url, '/onboarding?world=main')
        self.n.TOKEN = 'home-ui-owner-fixture'
        server = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        server.daemon_threads = True
        thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
        thread.start()
        def request(path, body=None):
            connection = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=5)
            try:
                connection.request('POST' if body is not None else 'GET', path,
                                   json.dumps(body) if body is not None else None,
                                   {'Content-Type': 'application/json', 'X-Tao-Token': self.n.TOKEN})
                response = connection.getresponse()
                result = response.read().decode()
                self.assertEqual(response.status, 200, result)
                return result
            finally:
                connection.close()
        try:
            self.assertIn('history-file', request(import_url))
            self.assertIn('Mes pièces', request(paths[2]))
            filtered = request('/explore?world=' + child + '&lang=en&type=resource')
            self.assertIn('"selected_type": "resource"', filtered)
            self.assertIn('/explore?world=' + child + '&amp;lang=fr&amp;type=resource', filtered)
            self.assertIn('dialogue-send', request(paths[3].split('#')[0]))
            row = json.loads(request(paths[0], {'action': 'create', 'concept_id': 'tao.concept.task',
                'title': 'Mon titre', 'text': 'Ma situation réelle', 'revision': 0}))
            self.assertEqual(row['world_id'], child)
            request(paths[1], {'world_id': child, 'revision': catalogue['revision'], 'title': 'Travail renommé'})
            self.assertIn('Travail renommé', request(paths[2]))
        finally:
            server.shutdown(); thread.join(timeout=3); server.server_close()

    def test_loading_and_challenging_never_call_ai_or_accept_proposals(self):
        self.run_js(self.script(r'''
assert.equal(calls.length,0);assert.equal(location.reloads,0);
assert(rendered(nodes.get('cards')).includes('<img onerror=bad()>'));
assert(rendered(nodes.get('cards')).includes('javascript:evil()'));
assert(![...nodes.values()].flatMap(all).some(item=>item.href==='javascript:evil()'));
clickText(nodes.get('cards'),words.challenge);
assert.equal(calls.length,0);assert(location.href.includes('world=012345abcdef'));assert(location.href.includes('view=dialogue'));
const draft=JSON.parse(saved.get('tao-explorer-draft:private-node:012345abcdef'));
assert(!draft.text.includes('Ne pas exécuter'));assert(!draft.text.includes('<img'));assert.equal(draft.text,words.challenge_draft);assert.deepEqual(draft.focus,{kind:'landmark',id:'112233aabbcc',revision:3});
const previous=location.href;location.href='';nodes.get('complete').onclick();assert.equal(location.href,'');assert(rendered(nodes.get('message')).includes(words.draft_conflict));
assert.deepEqual(JSON.parse(saved.get('tao-explorer-draft:private-node:012345abcdef')),draft);
'''))

    def test_dialogue_recovers_prepared_question_without_replacing_existing_draft(self):
        self.run_js(DOM + r'''
const dialogueForm={dataset:{node:config.node,pendingDraft:'true'}},worldId=config.world;
let selectedFocus=null;const showFocus=()=>{},keepFormDraft=()=>true,message=()=>{};
document.querySelector=selector=>document.getElementById(selector.slice(1));
document.getElementById('dialogue-text').value='Ma saisie précédente';
document.getElementById('dialogue-text').dispatchEvent=()=>{};
saved.set('tao-explorer-draft:private-node:012345abcdef',JSON.stringify({text:'Ma question préparée',focus:{kind:'landmark',id:'112233aabbcc',revision:3}}));
''' + dialogue_ui.EXPLORER_DRAFT_JS + r'''
assert.equal(document.getElementById('dialogue-text').value,'Ma saisie précédente');assert.equal(calls.length,0);
const list=document.getElementById('drafts-list');clickText(list,'Ajouter à ma discussion');assert.equal(document.getElementById('dialogue-text').value,'Ma saisie précédente');assert.equal(saved.size,1);
delete dialogueForm.dataset.pendingDraft;clickText(list,'Ajouter à ma discussion');
assert.equal(document.getElementById('dialogue-text').value,'Ma saisie précédente\n\nMa question préparée');assert.equal(saved.size,0);assert.equal(calls.length,0);
assert.deepEqual(selectedFocus.focus,{kind:'landmark',id:'112233aabbcc',revision:3});
''')

    def test_challenge_keeps_imported_ai_quote_out_of_new_human_message(self):
        quote = 'ANCIENNE_HYPOTHESE_IA : une dépense de 100000 XPF reste à vérifier.'
        payload = {'world': {'id': 'main'}, 'messages': [], 'imported_history': {'excerpts': [{
            'archive_id': 'old', 'conversation_id': 'chat', 'message_id': 'reply',
            'offset': 0, 'role': 'assistant', 'source_role': 'assistant', 'text': quote}]}}
        sources = landmarks.sources(payload)
        state = self.n.load_state()
        captured = landmarks.assimilate(self.n, state, [{'concept_id': 'tao.concept.expense',
            'source_id': sources[0]['source_id'], 'quote': quote}], sources, 'current-reply')
        row = next(item for item in landmarks.view(self.n, state)['items'] if item['id'] == captured['ids'][0])
        prepared = json.loads(self.run_js(DOM + 'const words=' + json.dumps(ui.WORDS['fr']) + ';\n' +
            ui.DRAFT_JS + 'const row=' + json.dumps(row) + r''';
saveExplorerDraft(sessionStorage,'this-node','main',discussionDraft('challenge',row.title,row),{kind:'landmark',id:row.id,revision:row.revision});
console.log(saved.get('tao-explorer-draft:this-node:main'));
'''))
        self.assertNotIn('ANCIENNE_HYPOTHESE_IA', prepared['text'])
        focus = dialogue.resolve_focus(self.n, state, prepared['focus'])
        self.assertEqual(focus['context']['text'], quote)
        self.assertEqual(focus['context']['provenance'][0]['role'], 'assistant')
        self.assertFalse(focus['execution_enabled'])

    def test_review_exact_revision_and_duplicate_click_blocked(self):
        self.run_js(self.script(r'''
(async()=>{
 let release;handler=()=>new Promise(resolve=>release=()=>resolve({ok:true,status:200,json:async()=>({ok:true})}));
 const first=clickText(nodes.get('cards'),words.accept);const second=clickText(nodes.get('cards'),words.accept);
 assert.equal(calls.length,1);assert.deepEqual(calls[0].data,{action:'review',id:'112233aabbcc',revision:3});
 assert.equal(calls[0].path,'/api/landmarks?world=012345abcdef');assert.equal(calls[0].options.headers['X-Tao-Token'],'csrf-owner');
 release();await first;await second;assert.equal(location.reloads,1);
})().catch(error=>{console.error(error);process.exitCode=1});
'''))

    def test_merge_uses_the_reviewed_selection_and_keeps_sources(self):
        self.run_js(self.script(r'''
(async()=>{
 selected.add('112233aabbcc');selected.add('112233aabbdd');await openMerge();
 const form=nodes.get('merge-form').querySelector('form');assert(form);
 assert(form.querySelector('textarea').value.includes('Ne pas exécuter'));assert(form.querySelector('textarea').value.includes('Mon complément'));
 selected.clear();form.onsubmit({preventDefault(){}});await turn();
 assert.deepEqual(calls[0].data.ids,['112233aabbcc','112233aabbdd']);assert.equal(calls[0].data.revision,4);assert.equal(calls[0].data.action,'merge');
 assert.equal(landmarks.items.length,2);assert.equal(landmarks.items[0].status,'proposed');
})().catch(error=>{console.error(error);process.exitCode=1});
'''))

    def test_unknown_post_result_keeps_entry_and_requires_manual_next_step(self):
        self.run_js(self.script(r'''
(async()=>{
 nodes.get('new-landmark').onclick();const form=nodes.get('new-card').querySelector('form');form.querySelector('input').value='Mon vrai titre';form.querySelector('textarea').value='Mon vrai contenu';
 form.listeners.input();handler=()=>{throw Error('network down')};form.onsubmit({preventDefault(){}});await turn();
 assert.equal(calls.length,1);assert.equal(location.reloads,0);assert.equal(form.querySelector('input').value,'Mon vrai titre');assert(dirtyForms.has(form));
 assert(rendered(nodes.get('message')).includes(words.network));
 const old=selectedType;chooseType('tao.concept.task');assert.equal(selectedType,old);
 await clickText(nodes.get('cards'),words.accept);assert.equal(calls.length,1);
})().catch(error=>{console.error(error);process.exitCode=1});
'''))

    def test_archived_space_is_read_only_and_restoration_explicit(self):
        self.run_js(self.script(r'''
(async()=>{
 assert(nodes.get('complete').hidden);assert(nodes.get('new-landmark').hidden);
 assert(!all(nodes.get('cards')).some(item=>item.tagName==='button'));
 assert.equal(calls.length,0);assert(!nodes.get('restore-space').hidden);
 nodes.get('restore-space').onclick();await turn();assert.equal(calls[0].path,'/api/foundations/restore?world=012345abcdef');
 assert.deepEqual(calls[0].data,{world_id:'012345abcdef',revision:7});
})().catch(error=>{console.error(error);process.exitCode=1});
''', setup="foundation.spaces[1].archived=true;foundation.spaces[1].effective_archived=true;\n"))

    def test_room_families_filter_existing_records_and_keep_shareable_view(self):
        setup = r'''
const history={entries:[],replaceState(state,title,url){this.entries.push(url)}};
config.selected_type='resource';
for(const [key,label] of [['resource','Ressource'],['method','Méthode']]){
 const id='tao.concept.'+key;
 foundation.concepts.push({id,label,definition:'Fiche descriptive'});
 landmarks.slots.push({concept_id:id,active_count:1,proposed_count:0,archived_count:0});
 landmarks.items.push({id:key==='resource'?'aabbccddeeff':'ffeeddccbbaa',concept_id:id,
  title:key==='resource'?'Outil décrit Client':'Processus décrit Écriture',text:'Description sans exécution',
  status:'active',revision:1,origin:'human',provenance:[],history:[]});
}
'''
        self.run_js(self.script(r'''
assert(rendered(nodes.get('cards')).includes('Outil décrit Client'));
assert(!rendered(nodes.get('cards')).includes('Processus décrit Écriture'));
assert.equal(nodes.get('room-tools').href,'/tools?world=012345abcdef');
assert.equal(nodes.get('room-contents').open,true);
clickText(nodes.get('room-families'),words.room_methods+' · 1');
assert.equal(history.entries.at(-1),'/explore?world=012345abcdef&lang=fr&type=method');
assert(!rendered(nodes.get('cards')).includes('Outil décrit Client'));
assert(rendered(nodes.get('cards')).includes('Processus décrit Écriture'));
clickText(nodes.get('room-families'),words.all);
assert.equal(history.entries.at(-1),'/explore?world=012345abcdef&lang=fr');
assert.equal(calls.length,0);
''', setup=setup))

    def test_room_creation_uses_current_parent_and_opens_new_room(self):
        self.run_js(self.script(r'''
(async()=>{
 assert.equal(nodes.get('create-room-parent').value,'012345abcdef');
 const form=nodes.get('create-room-form');
 document.getElementById('create-room-name').value='Mon roman';
 document.getElementById('create-room-description').value='Écrire et relire mes chapitres';
 handler=()=>({ok:true,status:200,json:async()=>({world_id:'abcdef123456'})});
 form.onsubmit({preventDefault(){}});await turn();await turn();
 assert.deepEqual(calls[0].data,{title:'Mon roman',description:'Écrire et relire mes chapitres',parent_id:'012345abcdef',revision:7});
 assert.equal(calls[0].path,'/api/worlds/create?world=012345abcdef');
 assert.equal(location.href,'/explore?world=abcdef123456&lang=fr');
 assert.equal(location.reloads,0);
 assert.equal(calls[0].options.headers['X-Tao-Token'],'csrf-owner');
})().catch(error=>{console.error(error);process.exitCode=1});
'''))
