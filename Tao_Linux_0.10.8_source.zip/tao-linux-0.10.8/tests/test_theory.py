import copy, json, tempfile
from pathlib import Path
from unittest.mock import patch
from test_node import NodeHarness, PROJECT
import tao_theory as theory
from tao_ui import render_lexicon


class TheoryTests(NodeHarness):
    def test_published_catalog_is_technical_and_matches_manifests(self):
        data=theory.load(self.n.THEORY)
        self.assertEqual(data['meta']['version'],'4.3.0')
        self.assertEqual(len(data['dictionary']),233)
        self.assertEqual(data['migration_from_v4_2']['parent_file_sha256'],
                         theory.LEGACY_V4_2['sha256'])
        retired_statuses={'historical_reference','historical_inspiration',
                          'historical_mapping','derived_structure'}
        self.assertFalse(retired_statuses & {row['status'] for row in data['dictionary'].values()})
        self.assertEqual(data['migration_from_v4_2']['removed_historical_term_count'],18)
        self.assertEqual(json.loads((PROJECT/'VERSION.json').read_text())['theory'],self.n.THEORY)
        report=theory.summary(self.n.THEORY)
        self.assertEqual(report['terms_with_model'],37)
        self.assertFalse(report['mathematical_proofs_verified'])

    def test_corrupted_content_cannot_pass_integrity(self):
        with tempfile.TemporaryDirectory() as td:
            target=Path(td)/'theory.json'; target.write_bytes(theory.canonical_path().read_bytes()+b' ')
            with patch.object(theory,'canonical_path',return_value=target):
                with self.assertRaises(RuntimeError): self.n.doctor()
        self.assertTrue(self.n.STATE.exists())

    def test_broken_references_unknown_status_and_duplicate_keys_are_rejected(self):
        base=theory.load(self.n.THEORY)
        broken=[]
        data=copy.deepcopy(base); data['dictionary']['centre']['model_refs']=['absent']; broken.append(data)
        data=copy.deepcopy(base); data['dictionary']['centre']['status']='proven_consciousness'; broken.append(data)
        data=copy.deepcopy(base); data['aliases']['absent']='missing'; broken.append(data)
        for data in broken:
            with self.assertRaises(ValueError): theory.validate(data)
        with self.assertRaises(ValueError): json.loads('{"centre":1,"centre":2}',object_pairs_hook=theory.unique_object)

    def test_term_lookup_respects_alias_and_uncertainty(self):
        self.assertEqual(theory.lookup(self.n.THEORY,'génome')['term'],'genome')
        self.assertEqual(theory.lookup(self.n.THEORY,'centre')['formalization'],'explicit_model')
        self.assertEqual(theory.lookup(self.n.THEORY,'subjectivité')['formalization'],'definition_only')
        self.assertEqual(json.loads(self.cli('lexicon','espèce').stdout)['status'],'design_hypothesis')
        with self.assertRaises(ValueError): theory.lookup(self.n.THEORY,'invented')

    def test_revision_is_attributed_inert_and_preserves_open_residual(self):
        b=self.n.add_buffer('Le sens de rythme est insuffisant','Définition précise','Comparer deux tempos')
        path=theory.canonical_path(); before=path.read_bytes(); ptr=self.n.THEORY_PTR.read_bytes()
        row=theory.propose(self.n,'rythme',b['id'],'Une nouvelle proposition à étudier',
            'Deux cas non distingués','Observation A','Observation B contredit la généralisation',
            'Conserver les anciens enregistrements avec version','Revenir au terme et à la version précédents')
        self.assertEqual(row['status'],'candidate'); self.assertEqual(row['activation'],'not_applied')
        self.assertEqual(row['base_digest'],self.n.THEORY['sha256'])
        self.assertEqual(path.read_bytes(),before); self.assertEqual(self.n.THEORY_PTR.read_bytes(),ptr)
        self.assertEqual(self.n.load_state()['buffers'][b['id']]['status'],'open')
        self.assertEqual(theory.proposals(self.n)[0]['source'],'human_report')

    def test_revision_requires_evidence_and_existing_unresolved_need(self):
        b=self.n.add_buffer('Résidu','But','Test')
        args=['Nouveau sens','Justification','Observations','Contre-exemple','Migration','Retour']
        with self.assertRaises(ValueError): theory.propose(self.n,'centre','missing',*args)
        missing=list(args); missing[2]=''
        with self.assertRaises(ValueError): theory.propose(self.n,'centre',b['id'],*missing)
        self.n.close_buffer(b['id'],'Vérification humaine')
        with self.assertRaises(ValueError): theory.propose(self.n,'centre',b['id'],*args)
        self.assertEqual(theory.proposals(self.n),[])

    def test_known_legacy_pointers_migrate_but_unknown_pointer_stays_visible(self):
        original=self.n.load_state()['id']
        for legacy in theory.KNOWN_LEGACIES:
            with self.subTest(version=legacy['version']):
                s=self.n.load_state(); s['theory']=legacy
                self.n.atomic_json(self.n.STATE,s,backup=True); self.n.atomic_json(self.n.THEORY_PTR,legacy)
                migrated=self.n.cycle()
                self.assertEqual(migrated['id'],original); self.assertEqual(migrated['theory'],self.n.THEORY)
                receipt=self.n.load_json(self.root/'theory-migration-4.3.json')
                self.assertEqual(receipt['previous'],legacy)
                self.assertEqual(receipt['current'],self.n.THEORY)
        unknown=dict(self.n.THEORY,version='unreviewed')
        self.n.atomic_json(self.n.THEORY_PTR,unknown)
        self.assertFalse(self.n.doctor()['ok'])
        self.assertEqual(self.n.load_json(self.n.THEORY_PTR),unknown)
        self.assertEqual(self.n.cycle()['buffers']['theory.local']['status'],'open')

    def test_lexicon_renders_without_executing_definition_text(self):
        data=theory.load(self.n.THEORY)
        data['dictionary']['centre']['definition']='<script>alert(1)</script>'
        page=render_lexicon(data)
        self.assertNotIn('<script>alert(1)</script>',page)
        self.assertIn('&lt;script&gt;alert(1)&lt;/script&gt;',page)
        self.assertIn('Définition seule',page)
