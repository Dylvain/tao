"""Reviewed imports fill chosen private spaces without replacing their owner data."""
import copy
import json
import os
import shutil
import subprocess
from unittest.mock import patch

from test_node import NodeHarness
from test_onboarding import document
from test_history_store import archive, ASSIGNMENTS
from test_onboarding_ui import DOM
import tao_continuity as continuity
import tao_dialogue as dialogue
import tao_history_store as history
import tao_history_archive as adapter
import tao_onboarding as onboarding
import tao_onboarding_routes as routes
import tao_onboarding_ui as ui
import tao_worlds as worlds
import tao_foundations as foundations


class ImportTargetTests(NodeHarness):
    def setUp(self):
        super().setUp()
        # Explicitly exercise migration from the prior one-space installation;
        # a separate test below covers the new populated navigation skeleton.
        raw = self.n.load_raw_state()
        raw.pop('worlds', None)
        self.n.atomic_json(self.n.STATE, raw, backup=True)

    def space(self, title='Espace choisi', template_key=None):
        row = worlds.create(self.n, title, revision=worlds.describe(self.n)['revision'])
        if template_key:
            raw = self.n.load_raw_state()
            raw['worlds']['spaces'][row['id']]['template_key'] = template_key
            self.n.atomic_json(self.n.STATE, raw, backup=True)
        return row['id']

    def test_selected_existing_context_is_additive_and_preserves_story_metadata_and_preferences(self):
        ident = self.space()
        raw = self.n.load_raw_state()
        local = raw['worlds']['spaces'][ident]
        local.update(description='Mon descriptif actuel', story={'id': 'story:human', 'text': 'Mon histoire réelle'},
                     custom_local_data={'untouched': True})
        dialogue.ensure(local)['memory'] = 'Contexte humain conservé'
        local['dialogue']['include_archives'] = False
        continuity.ensure(local)['notes'].append({'id': 'manual-note', 'kind': 'context',
                                                'text': 'Note antérieure', 'status': 'active'})
        original = copy.deepcopy(local)
        self.n.atomic_json(self.n.STATE, raw, backup=True)
        policy = self.n.POLICY.read_bytes()
        plan = onboarding.preview(self.n, document(), targets={'work': ident})
        part = next(row for row in plan['spaces'] if row['key'] == 'work')
        self.assertEqual(part['title'], original['title'])
        self.assertEqual(part['parent_id'], original['parent_id'])
        self.assertEqual(part['proposed_title'], 'Travail')
        self.assertEqual(part['story_mode'], 'append_context')
        self.assertEqual(plan['counts']['new_spaces'], 1)
        receipt = onboarding.apply(self.n, document(), plan['review_digest'], confirmed=True, targets=plan['targets'])
        local = self.n.load_raw_state()['worlds']['spaces'][ident]
        for field in ('id', 'title', 'parent_id', 'description', 'story', 'dialogue', 'custom_local_data'):
            self.assertEqual(local[field], original[field])
        self.assertEqual(local['continuity']['notes'][0], original['continuity']['notes'][0])
        self.assertEqual(len(local['continuity']['notes']), 3)
        self.assertEqual(len(local['buffers']), 1)
        self.assertEqual(receipt['targets'], {'work': ident})
        self.assertEqual(self.n.POLICY.read_bytes(), policy)
        self.assertNotIn('WORK_ONLY', json.dumps(self.n.load_state()['continuity']))
        with worlds.using(ident):
            self.assertIn('WORK_ONLY', json.dumps(self.n.load_state()))
            self.assertNotIn('FAMILY_ONLY', json.dumps(self.n.load_state()))

    def test_mapping_and_selected_human_context_changes_invalidate_review(self):
        one, two = self.space('Premier'), self.space('Deuxième')
        target = {'work': one}
        plan = onboarding.preview(self.n, document(), targets=target)
        before = self.n.STATE.read_bytes()
        with self.assertRaisesRegex(ValueError, 'changé'):
            onboarding.apply(self.n, document(), plan['review_digest'], confirmed=True, targets={'work': two})
        self.assertEqual(self.n.STATE.read_bytes(), before)
        raw = self.n.load_raw_state()
        dialogue.ensure(raw['worlds']['spaces'][two])['memory'] = 'Autre espace privé'
        self.n.atomic_json(self.n.STATE, raw, backup=True)
        self.assertEqual(onboarding.preview(self.n, document(), targets=target)['review_digest'], plan['review_digest'])
        raw = self.n.load_raw_state()
        dialogue.ensure(raw['worlds']['spaces'][one])['memory'] = 'Correction dans la destination'
        self.n.atomic_json(self.n.STATE, raw, backup=True)
        with self.assertRaisesRegex(ValueError, 'changé'):
            onboarding.apply(self.n, document(), plan['review_digest'], confirmed=True, targets=target)
        fresh = onboarding.preview(self.n, document(), targets=target)
        with self.assertRaisesRegex(ValueError, 'Confirmer'):
            onboarding.apply(self.n, document(), fresh['review_digest'], confirmed=1, targets=target)

    def test_duplicate_unknown_archived_and_main_redirect_targets_are_rejected(self):
        ident = self.space()
        before = self.n.STATE.read_bytes()
        for targets in ({'work': ident, 'family': ident}, {'work': 'main'}, {'main': ident},
                        {'absent': ident}, {'work': 'abcdef012345'}, {'work': '../escape'}, [], {'work': None}):
            with self.subTest(targets=targets), self.assertRaises(ValueError):
                onboarding.preview(self.n, document(), targets=targets)
        self.assertEqual(self.n.STATE.read_bytes(), before)
        raw = self.n.load_raw_state()
        raw['worlds']['spaces'][ident]['archived'] = True
        self.n.atomic_json(self.n.STATE, raw, backup=True)
        with self.assertRaisesRegex(ValueError, 'archivée'):
            onboarding.preview(self.n, document(), targets={'work': ident})
        self.assertNotIn(ident, [row['id'] for row in onboarding.preview(self.n, document(), targets={})['target_options']])

    def test_archived_ancestor_disables_destination(self):
        parent, child = self.space('Parent'), self.space('Enfant')
        raw = self.n.load_raw_state()
        raw['worlds']['spaces'][parent]['archived'] = True
        raw['worlds']['spaces'][child]['parent_id'] = parent
        self.n.atomic_json(self.n.STATE, raw, backup=True)
        with self.assertRaisesRegex(ValueError, 'archivée'):
            onboarding.preview(self.n, document(), targets={'work': child})

    def test_exact_reimport_uses_recorded_targets_and_never_resets_human_changes(self):
        ident, other = self.space('Destination'), self.space('Autre')
        plan = onboarding.preview(self.n, document(), targets={'work': ident})
        receipt = onboarding.apply(self.n, document(), plan['review_digest'], confirmed=True, targets=plan['targets'])
        imported = next(row for row in receipt['spaces'] if row['key'] == 'work')
        with worlds.using(ident):
            revision = self.n.load_state()['continuity']['revision']
            continuity.edit_note(self.n, imported['note_ids'][0], 'Correction humaine', 'rejected', revision)
            revision = self.n.load_state()['continuity']['revision']
            continuity.need_action(self.n, imported['need_ids'][0], 'withdraw', revision)
        raw = self.n.load_raw_state()
        raw['worlds']['spaces'][ident].update(archived=True, title='Nom actuel')
        self.n.atomic_json(self.n.STATE, raw, backup=True)
        before = self.n.STATE.read_bytes()
        with patch.object(self.n, 'atomic_json', wraps=self.n.atomic_json) as atomic:
            repeated = onboarding.apply(self.n, document(), plan['review_digest'], confirmed=True)
            self.assertEqual(atomic.call_count, 0)
        self.assertTrue(repeated['already_imported'])
        self.assertEqual(self.n.STATE.read_bytes(), before)
        for targets in ({}, {'work': other}):
            with self.assertRaisesRegex(ValueError, 'déjà importé'):
                onboarding.preview(self.n, document(), targets=targets)

    def test_legacy_receipt_without_targets_stays_idempotent_after_templates_are_added(self):
        plan = onboarding.preview(self.n, document())
        receipt = onboarding.apply(self.n, document(), plan['review_digest'], confirmed=True)
        raw = self.n.load_raw_state()
        raw['continuity']['history_imports']['packages'][document()['id']]['receipt'].pop('targets')
        self.n.atomic_json(self.n.STATE, raw, backup=True)
        self.space('Nouveau modèle du travail', template_key='work')
        before = self.n.STATE.read_bytes()
        repeated = onboarding.apply(self.n, document(), plan['review_digest'], confirmed=True)
        self.assertEqual(repeated['spaces'], receipt['spaces'])
        self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_only_semantic_template_identity_suggests_existing_space_never_its_name(self):
        ident = self.space('Mon vocabulaire préféré', template_key='work')
        plan = onboarding.preview(self.n, document())
        self.assertEqual(plan['targets'], {'work': ident})
        self.assertEqual(next(row for row in plan['spaces'] if row['key'] == 'work')['title'], 'Mon vocabulaire préféré')
        # Explicit empty selection means new spaces; a matching title alone must
        # remain a visible conflict, never a silent import into that private space.
        self.space('Famille')
        with self.assertRaisesRegex(ValueError, 'porte déjà le nom'):
            onboarding.preview(self.n, document(), targets={})

    def test_archive_template_targets_keep_private_content_local_and_preserve_checkbox(self):
        work, personal = self.space('Mon travail', 'work'), self.space('Personnel', 'personal')
        raw = self.n.load_raw_state()
        for ident in (work, personal):
            dialogue.ensure(raw['worlds']['spaces'][ident])['include_archives'] = False
        self.n.atomic_json(self.n.STATE, raw, backup=True)
        plan = history.preview(self.n, archive(), assignments=ASSIGNMENTS)
        self.assertEqual(plan['counts']['new_spaces'], 0)
        self.assertEqual(set(plan['targets'].values()), {'main', work, personal})
        receipt = history.apply(self.n, archive(), plan['review_digest'], confirmed=True,
                                assignments=ASSIGNMENTS, targets=plan['targets'])
        self.assertEqual(history.list_archives(self.n)['archives'], [])
        self.assertEqual(history.search(self.n, 'PRIVATE')['excerpts'], [])
        self.assertNotIn('WORK_PRIVATE', json.dumps(self.n.load_state()['continuity']))
        for ident, present, absent in ((work, 'WORK_PRIVATE', 'FAMILY_PRIVATE'),
                                      (personal, 'FAMILY_PRIVATE', 'WORK_PRIVATE')):
            with worlds.using(ident):
                self.assertFalse(self.n.load_state()['dialogue']['include_archives'])
                self.assertTrue(history.search(self.n, present)['excerpts'])
                self.assertNotIn(absent, json.dumps(history.search(self.n, absent)['excerpts']))
        before = self.n.STATE.read_bytes()
        again = history.apply(self.n, archive(), plan['review_digest'], confirmed=True, assignments=ASSIGNMENTS)
        self.assertTrue(again['already_imported'])
        self.assertEqual(again['spaces'], receipt['spaces'])
        self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_fresh_empty_foundation_spaces_receive_archive_without_new_spaces(self):
        raw = foundations.seed(self.n.load_raw_state())
        self.n.atomic_json(self.n.STATE, raw, backup=True)
        original = copy.deepcopy(raw['worlds']['spaces'])
        self.assertEqual(len(original), 9)
        self.assertTrue(all(not row.get('story') and not row.get('dialogue') for row in original.values()))
        plan = history.preview(self.n, archive(), assignments=ASSIGNMENTS)
        self.assertEqual(plan['counts']['new_spaces'], 0)
        result = history.apply(self.n, archive(), plan['review_digest'], confirmed=True,
                               assignments=ASSIGNMENTS, targets=plan['targets'])
        after = self.n.load_raw_state()['worlds']['spaces']
        self.assertEqual(set(after), set(original))
        for ident, row in original.items():
            for field in ('title', 'description', 'parent_id', 'template_key'):
                self.assertEqual(after[ident].get(field), row.get(field))
        self.assertEqual(set(result['targets'].values()),
                         {'main'} | {ident for ident, row in original.items()
                                     if row.get('template_key') in ('work', 'personal')})

    def test_money_and_relationships_categories_fill_empty_templates_as_unverified_context(self):
        self.n.atomic_json(self.n.STATE, foundations.seed(self.n.load_raw_state()), backup=True)
        value = {'conversations': [
            {'id': 'budget', 'title': 'Mon budget mensuel et mes dépenses',
             'messages': [{'id': 'b', 'role': 'user', 'text': 'Je veux comprendre mon salaire et mes dépenses en XPF.'}]},
            {'id': 'family', 'title': 'Ma famille et mes amis',
             'messages': [{'id': 'f', 'role': 'user', 'text': 'Comment passer plus de temps avec ma famille ?'}]}]}
        plan = history.preview(self.n, value)
        self.assertEqual([row['space_key'] for row in plan['assignments']], ['money', 'relationships'])
        self.assertEqual(plan['counts']['new_spaces'], 0)
        self.assertTrue(all(row['method'] == 'suggestion lexicale' for row in plan['assignments']))
        self.assertEqual({row['key'] for row in plan['categories']} & {'money', 'relationships'}, {'money', 'relationships'})

    def test_expanded_classifier_preserves_exact_legacy_archive_receipt(self):
        parsed = adapter.parse(archive())
        legacy = adapter.propose(parsed, _legacy=True)
        assignments = [{'conversation_id': row['conversation_id'], 'space_key': row['space_key']}
                       for row in legacy['assignments']]
        plan = history.preview(self.n, archive(), assignments=assignments)
        first = history.apply(self.n, archive(), plan['review_digest'], confirmed=True, assignments=assignments)
        self.assertNotEqual(adapter.propose(parsed)['document']['id'], legacy['document']['id'])
        before = self.n.STATE.read_bytes()
        repeated_plan = history.preview(self.n, archive())
        self.assertTrue(repeated_plan['already_imported'])
        repeated = history.apply(self.n, archive(), repeated_plan['review_digest'], confirmed=True)
        self.assertEqual(repeated['spaces'], first['spaces'])
        self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_routes_and_cli_forward_targets_without_importing_permissions(self):
        ident = self.space()
        payload = {'document': document(), 'targets': {'work': ident}}
        plan = routes.post(self.n, '/api/onboarding/preview', payload)
        self.assertEqual(plan['targets'], payload['targets'])
        path = self.base / 'packet.json'
        path.write_text(json.dumps(document()))
        cli = json.loads(self.cli('onboarding', 'preview', str(path), '--targets', json.dumps(payload['targets'])).stdout)
        self.assertEqual(cli['review_digest'], plan['review_digest'])
        result = routes.post(self.n, '/api/onboarding/apply', dict(payload, review_digest=plan['review_digest'], confirmed=True))
        self.assertEqual(result['targets'], payload['targets'])

    def test_name_conflict_has_metadata_only_destination_recovery_without_approval(self):
        ident = self.space('Travail')
        before = self.n.STATE.read_bytes()
        with self.assertRaisesRegex(ValueError, 'porte déjà le nom'):
            onboarding.preview(self.n, document())
        choices = routes.post(self.n, '/api/onboarding/destinations', {'document': document()})
        self.assertIn(ident, [row['id'] for row in choices['target_options']])
        self.assertNotIn('WORK_ONLY', json.dumps(choices))
        self.assertNotIn('review_digest', choices)
        self.assertEqual(self.n.STATE.read_bytes(), before)
        preview = onboarding.preview(self.n, document(), targets={'work': ident})
        self.assertEqual(preview['targets'], {'work': ident})
        with worlds.using(ident), self.assertRaisesRegex(ValueError, 'principal'):
            onboarding.destinations(self.n, document())

    def test_browser_target_edit_requires_fresh_review_and_sends_reviewed_mapping(self):
        node = os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node:
            self.skipTest('Node optional: browser controller check')
        source = DOM + r'''
const destinations=[{id:'111111111111',title:'Travail actuel'},{id:'222222222222',title:'Autre espace'}];
let firstConflict=true;
handler=call=>{
 if(call.path.includes('/destinations'))return {ok:true,status:200,json:async()=>({...plan,targets:{work:'111111111111'},target_options:destinations})};
 if(call.path.includes('/preview')){if(firstConflict){firstConflict=false;return {ok:false,status:400,json:async()=>({error:'Un espace porte déjà le nom choisi.'})}}return {ok:true,status:200,json:async()=>({...plan,targets:call.data.targets||{work:'111111111111'},target_options:destinations,review_digest:call.data.targets?'changed-review':'first-review'})}}
 return null;
};
''' + ui.PAGE_JS + r'''
(async()=>{
 await turn();await selectFileValue(file(prepared));assert(nodes.get('review').hidden);assert(!nodes.get('target-placement').hidden);assert(nodes.get('apply-import').disabled);
 const select=all(nodes.get('target-assignments')).find(node=>node.tagName==='select');assert.equal(select.value,'111111111111');
 nodes.get('confirm-import').checked=true;select.value='222222222222';select.onchange();
 assert(nodes.get('review').hidden);assert(nodes.get('apply-import').disabled);await submit();assert(!calls.some(call=>call.path.includes('/apply')));
 await nodes.get('preview-again').onclick();const latest=calls.filter(call=>call.path.includes('/preview')).at(-1);assert.deepEqual(latest.data.targets,{work:'222222222222'});
 assert(!nodes.get('confirm-import').checked);nodes.get('confirm-import').checked=true;await submit();
 const applied=calls.find(call=>call.path.includes('/apply'));assert.deepEqual(applied.data.targets,{work:'222222222222'});assert.equal(applied.data.review_digest,'changed-review');
})().catch(error=>{console.error(error);process.exitCode=1});
'''
        path = self.base / 'target-ui.js'
        path.write_text(source)
        result = subprocess.run([node, str(path)], capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
