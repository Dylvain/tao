import json
import os
from pathlib import Path
from unittest.mock import patch

from test_node import NodeHarness
import tao_adaptation as adaptation
import tao_workshop as workshop
import tao_worlds as worlds


class WorkshopRetentionTests(NodeHarness):
    def repository(self):
        repo=self.base/'repo';repo.mkdir();(repo/'scripts').mkdir()
        (repo/'value.txt').write_text('before\n')
        (repo/'scripts/verify.sh').write_text('set -eu\ntest "$(cat value.txt)" = after\n')
        workshop.git(repo,'init');workshop.git(repo,'add','.')
        workshop.git(repo,*workshop.identity_args(),'commit','-m','Fictional retention baseline')
        return repo

    def test_archive_keeps_candidate_diff_proofs_references_and_requires_restore_before_mutation(self):
        repo=self.repository();w=workshop.Workshop(self.n)
        b=self.n.add_buffer('Un écart fictif','Une modification vérifiée','Le test du candidat réussit')
        e=w.prepare(repo,b['id']);ident=e['id'];candidate=Path(e['candidate'])
        (candidate/'value.txt').write_text('after\n')
        e=w.verify(ident,True);self.assertEqual(e['status'],'verified')
        diff=w.diff(ident);commit=workshop.git(candidate,'rev-parse','HEAD')
        proof=(candidate.parent/'tests.log').read_bytes();prompt=(candidate.parent/'prompt.txt').read_bytes()
        archived=w.archive(ident)
        self.assertTrue(archived['archived']);self.assertEqual(archived['status'],'verified')
        self.assertEqual(w.archive(ident),archived)
        self.assertEqual(w.list(),[]);self.assertEqual(w.list(True)[0]['id'],ident)
        self.assertEqual(w.diff(ident),diff)
        self.assertEqual(workshop.git(candidate,'rev-parse','HEAD'),commit)
        self.assertEqual((candidate.parent/'tests.log').read_bytes(),proof)
        self.assertEqual((candidate.parent/'prompt.txt').read_bytes(),prompt)
        self.assertEqual(w.load(ident)['verification'],e['verification'])
        for operation in (w.run,w.accept,w.rollback):
            with self.assertRaisesRegex(ValueError,'archivée'):operation(ident)
        with self.assertRaisesRegex(ValueError,'archivée'):w.verify(ident,True)
        self.assertEqual((repo/'value.txt').read_text(),'before\n')
        restored=w.restore(ident);self.assertFalse(restored['archived'])
        self.assertEqual(restored['retention_revision'],2)
        accepted=w.accept(ident);self.assertEqual((repo/'value.txt').read_text(),'after\n')
        w.archive(ident)
        self.assertEqual(w.load(ident)['accepted_commit'],accepted['accepted_commit'])
        with self.assertRaisesRegex(ValueError,'archivée'):w.rollback(ident)
        w.restore(ident);rolled_back=w.rollback(ident)
        self.assertEqual(rolled_back['status'],'rolled_back')
        self.assertEqual((repo/'value.txt').read_text(),'before\n')
        self.assertEqual(self.n.load_state()['buffers'][b['id']]['status'],'open')

    def test_capacity_counts_active_globally_and_restore_never_deletes_any_record(self):
        repo=self.repository();w=workshop.Workshop(self.n)
        other=worlds.create(self.n,'Autre espace',revision=0)['id']
        for i in range(100):
            self.n.atomic_json(w._file(f'{i:012x}'),{'id':f'{i:012x}','status':'prepared'})
        with worlds.using(other):
            b=self.n.add_buffer('Un autre écart','Un résultat','Une preuve')
            with self.assertRaisesRegex(ValueError,'100 expériences'):w.prepare(repo,b['id'])
            with self.assertRaises(ValueError):w.archive('000000000000')
            with self.assertRaises(ValueError):w.restore('000000000000')
            self.assertEqual(w.list(True),[])
        w.archive('000000000000')
        self.assertEqual(w.active_count(),99)
        with worlds.using(other):e=w.prepare(repo,b['id'])
        self.assertEqual(w.active_count(),100)
        with self.assertRaisesRegex(ValueError,'100 expériences'):w.restore('000000000000')
        self.assertTrue(w.load('000000000000')['archived'])
        with worlds.using(other):w.archive(e['id'])
        w.restore('000000000000')
        self.assertEqual(w.active_count(),100)
        self.assertEqual(len(list(w.root.glob('*/experiment.json'))),101)
        with worlds.using(other):
            self.assertTrue(Path(w.load(e['id'])['candidate']).is_dir())
            self.assertEqual(w.list(),[]);self.assertEqual(len(w.list(True)),1)

    def test_live_related_adaptation_blocks_retention_but_interrupted_job_does_not(self):
        w=workshop.Workshop(self.n);ident='012345abcdef';jobid='112345abcdef'
        w.save({'id':ident,'status':'review'})
        row={'id':jobid,'experiment_id':ident,'world_id':'main','status':'running',
             'pid':os.getpid(),'process_start':self.n.proc_start(os.getpid()),'operation':'generate'}
        adaptation.save(self.n,row)
        with self.assertRaisesRegex(ValueError,'encore active'):w.archive(ident)
        self.assertNotIn('archived',w.load(ident))
        row.update(pid=99999999,process_start='missing');adaptation.save(self.n,row)
        self.assertTrue(w.archive(ident)['archived'])
        row.update(status='queued',pid=None,started_epoch=self.n.epoch());adaptation.save(self.n,row)
        with self.assertRaisesRegex(ValueError,'encore active'):w.restore(ident)
        row['started_epoch']=self.n.epoch()-100;adaptation.save(self.n,row)
        self.assertFalse(w.restore(ident)['archived'])

    def test_unknown_or_running_experiment_is_not_archived_and_watch_keeps_old_attempts(self):
        w=workshop.Workshop(self.n)
        for i,status in enumerate(('running','testing','unexpected')):
            ident=f'{i:012x}';w.save({'id':ident,'status':status,'buffer_id':'fixture:'+ident})
            with self.assertRaisesRegex(ValueError,'en cours'):w.archive(ident)
        b=self.n.add_buffer('Un besoin déjà essayé','Un résultat','Une preuve')
        ident='012345abcdef';w.save({'id':ident,'status':'agent_failed','buffer_id':b['id']})
        w.archive(ident)
        # Archiving keeps the old attempt visible to the watch scheduler, so it
        # cannot silently spend another AI call on the same unresolved buffer.
        with patch.object(workshop.time,'monotonic',side_effect=[0,0,4000,4000]),patch.object(workshop.time,'sleep'),patch.object(w,'prepare') as prepare:
            result=w.watch(self.base,max_runs=1,hours=1)
        prepare.assert_not_called();self.assertEqual(result['experiments'],[])

    def test_interrupted_related_worker_allows_archiving_without_forging_a_terminal_status(self):
        w=workshop.Workshop(self.n)
        for i,status in enumerate(('running','testing')):
            ident=f'{i:012x}';jobid=f'{i+10:012x}'
            w.save({'id':ident,'status':status,'attempts':1,'runs':[{'ok':False,'reason':'prior_failure'}]})
            with self.assertRaisesRegex(ValueError,'en cours'):w.archive(ident)
            row={'id':jobid,'experiment_id':ident,'world_id':'main','status':status,
                 'pid':99999999,'process_start':'missing','operation':'generate'}
            adaptation.save(self.n,row)
            before=w.load(ident)
            archived=w.archive(ident)
            self.assertTrue(archived['archived']);self.assertEqual(archived['status'],status)
            self.assertEqual(archived['runs'],before['runs']);self.assertEqual(archived['attempts'],1)
            self.assertEqual(w.restore(ident)['status'],status)
            self.assertEqual(adaptation.load(self.n,jobid)['status'],status)
