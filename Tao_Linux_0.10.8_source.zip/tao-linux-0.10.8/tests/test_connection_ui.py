"""Connection and trend presentation neither forge state nor retry writes."""
import html
import json
import os
import re
import shutil
import subprocess
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from test_node import NodeHarness
import tao_connection_ui as connection
import tao_trends_ui as trends


class ConnectionUITests(NodeHarness):
    def test_preparation_panel_escapes_source_path_without_starting_processes(self):
        source = self.base / 'source-<img onerror="fixture">'
        source.mkdir()
        self.n.atomic_json(self.n.ROOT / 'source.json', {'path': str(source)})
        with patch('subprocess.Popen', side_effect=AssertionError('No process on page read')):
            for locale in ('fr', 'en'):
                page = connection.render(self.n, locale)
                self.assertIn(html.escape(str(source), quote=True), page)
                self.assertNotIn(str(source), page)
                self.assertIn(connection.WORDS[locale]['source_found'], page)
                self.assertIn(connection.WORDS[locale]['source_limits'], page)

    def test_local_login_uses_saved_interpreter_path_without_inheriting_secrets(self):
        saved_bin = self.base / 'saved-bin'
        saved_bin.mkdir()
        (saved_bin / 'tao-fixture-python').symlink_to(sys.executable)
        executable = self.base / 'fixture-codex'
        executable.write_text('''#!/usr/bin/env tao-fixture-python
import json, os, sys
from pathlib import Path
Path('fixture-login-call.json').write_text(json.dumps({
    'args': sys.argv[1:], 'path': os.environ.get('PATH'),
    'keys': sorted(os.environ)}))
assert sys.argv[1:] == ['login', 'status']
''')
        executable.chmod(0o700)
        self.n.atomic_json(self.n.ROOT / 'source.json', {
            'executables': {'codex': str(executable)}, 'path_env': str(saved_bin)})
        server = SimpleNamespace()
        call = self.n.ROOT / 'fixture-login-call.json'
        with patch.dict(os.environ, {
            'PATH': str(self.base / 'daemon-path-without-interpreter'),
            'HOME': str(self.base), 'CODEX_HOME': str(self.base / 'fixture-codex-home'),
            'OPENAI_API_KEY': 'fixture-not-for-login',
            'RAILWAY_TOKEN': 'fixture-not-for-login'}):
            self.addCleanup(connection.manager(self.n, server).close)
            snapshot = connection.status(self.n, server)
            self.assertTrue(snapshot['cli_available'])
            self.assertEqual(snapshot['state'], 'idle')
            self.assertFalse(call.exists())
            result = connection.post(self.n, server, '/api/connection/check', {})
        self.assertTrue(result['connected'])
        self.assertEqual(result['state'], 'connected')
        recorded = json.loads(call.read_text())
        self.assertEqual(recorded['args'], ['login', 'status'])
        self.assertEqual(recorded['path'], str(saved_bin))
        self.assertNotIn('OPENAI_API_KEY', recorded['keys'])
        self.assertNotIn('RAILWAY_TOKEN', recorded['keys'])

    def test_pages_escape_session_values_and_distinguish_history_from_login(self):
        self.n.TOKEN = '</script><script>throw Error(1)</script>'
        for locale in ('fr', 'en'):
            page = connection.render(self.n, locale)
            self.assertNotIn(self.n.TOKEN, page)
            self.assertIn('/onboarding?world=main', page)
            self.assertIn('view=dialogue', page)
            self.assertIn('device', page)
        self.assertIn('historique ChatGPT', connection.render(self.n))
        with patch.dict('os.environ', {'TAO_HOSTED':'1'}):
            page = connection.render(self.n)
            self.assertIn('href="/host/ai"', page)
            self.assertNotIn('<button id="start"', page)

    def test_scripts_parse_and_days_are_compared_without_float_unit_conversion(self):
        node = shutil.which('node')
        if not node:
            self.skipTest('Node absent')
        for module in (connection, trends):
            script = re.search(r'<script>(.*?)</script>', module.render(self.n), re.S).group(1)
            result = subprocess.run([node, '--check'], input=script, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
        harness = r'''
const vm=require('vm'),assert=require('assert');
const values={quantity:'Test',unit:'XPF',samples:'0 ; 0.2\n1 ; 0.3',min:'',max:'',rate:'0.1',acceleration:'',reference:''};
const nodes={};for(const [key,value] of Object.entries(values))nodes[key]={value};nodes['trend-form']={};
const ctx={config:{words:{invalid:'invalid'}},document:{getElementById:id=>nodes[id]}};vm.createContext(ctx);
vm.runInContext(SCRIPT,ctx);const p=vm.runInContext('payload()',ctx);
assert.equal(p.time_unit,'day');assert.equal(p.samples[1].t,1);assert.equal(p.bounds.trend.max_abs,0.1);
nodes.samples.value='0 ; ';
assert.throws(()=>vm.runInContext('payload()',ctx));
'''.replace('SCRIPT', json.dumps(trends.JS))
        result = subprocess.run([node, '-e', harness], text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_connection_js_never_posts_on_load_and_clears_failed_auth_codes(self):
        node = shutil.which('node')
        if not node:
            self.skipTest('Node absent')
        harness = r'''
const vm=require('vm'),assert=require('assert');const nodes={},pending=[];
const ctx={config:{world:'main',token:'fixture',hosted:false,words:{idle:'idle',unconfirmed:'unknown',error:'error'}},
location:{origin:'http://127.0.0.1:8790'},URL,
document:{getElementById:id=>nodes[id]||(nodes[id]={disabled:false,hidden:false,textContent:''})},
setTimeout:()=>1,clearTimeout:()=>{},fetch:(url,opts)=>new Promise((resolve,reject)=>pending.push({url,opts,resolve,reject}))};
vm.createContext(ctx);vm.runInContext(SCRIPT,ctx);assert.equal(pending.length,1);assert.equal(pending[0].opts.method,'GET');
(async()=>{pending[0].resolve({ok:true,json:async()=>({state:'idle',cli_available:true,connected:false,login_in_progress:false})});
await new Promise(r=>setImmediate(r));assert(!nodes.start.disabled);nodes.start.onclick();assert.equal(pending[1].opts.method,'POST');
assert.equal(pending[1].opts.headers['X-Tao-Token'],'fixture');pending[1].reject(Error('lost'));
await new Promise(r=>setImmediate(r));assert(nodes.pairing.hidden);assert.equal(nodes.code.textContent,'');assert.equal(pending.length,2);assert(!nodes.check.disabled);
nodes.check.onclick();pending[2].resolve({ok:true,json:async()=>({state:'awaiting_authorization',cli_available:true,connected:false,login_in_progress:true,user_code:'ABC-1234',verification_url:'https://auth.openai.com/codex/device'})});
await new Promise(r=>setImmediate(r));assert(!nodes.cancel.hidden);assert(!nodes.cancel.disabled);
nodes.cancel.onclick();assert.equal(pending[3].opts.method,'POST');assert(pending[3].url.includes('/cancel'));
pending[3].resolve({ok:true,json:async()=>({state:'cancelled',cli_available:true,connected:false,login_in_progress:false})});
await new Promise(r=>setImmediate(r));assert(nodes.cancel.hidden);assert(nodes.pairing.hidden);
})().catch(e=>{console.error(e);process.exitCode=1});
'''.replace('SCRIPT', json.dumps(connection.JS))
        result = subprocess.run([node, '-e', harness], text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
