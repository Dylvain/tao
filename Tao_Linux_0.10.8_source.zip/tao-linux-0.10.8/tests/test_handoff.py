import copy
import hashlib
import json
from unittest.mock import patch

from test_node import NodeHarness
import tao_adaptation as adapt
import tao_continuity as continuity
import tao_dialogue as dialogue
import tao_handoff as handoff
import tao_worlds as worlds


MEMORY = 'Je souhaite apprendre le jardinage, et conserver les explications incertaines comme hypothèses.'


class HandoffTests(NodeHarness):
    def setUp(self):
        super().setUp()
        self.destination = NodeHarness()
        self.destination.setUp()
        self.addCleanup(self.destination.tearDown)
        self.other = self.destination.n

    def package(self, text=MEMORY):
        revision=self.n.load_state().get('dialogue',{}).get('revision',0)
        dialogue.save_memory(self.n,text,revision)
        return handoff.export(self.n)

    def test_export_is_only_selected_memory_and_identifies_source_without_copying_state(self):
        document=self.package();s=self.n.load_state()
        s['dialogue']['messages'].append({'id':'source-private','role':'user','text':'PRIVATE_DISCUSSION','at':self.n.now()})
        s['buffers']['private']=self.n.make_buffer('private','user','PRIVATE_NEED')
        self.n.atomic_json(self.n.STATE,s,backup=True)
        before=self.n.STATE.read_bytes();document=handoff.export(self.n)
        self.assertEqual(document['text'],MEMORY)
        self.assertEqual(document['source']['node_id'],s['id'])
        self.assertEqual(document['source']['world_id'],'main')
        self.assertEqual(set(document),handoff.FIELDS)
        self.assertNotIn('PRIVATE_',json.dumps(document))
        self.assertEqual(before,self.n.STATE.read_bytes())
        self.assertEqual(handoff.validate(json.dumps(document)),document)
        self.assertLessEqual(len(json.dumps(document).encode()),handoff.MAX_BYTES)

    def test_import_preserves_destination_and_adds_one_attributed_memory_transaction(self):
        document=self.package()
        dialogue.save_memory(self.other,'Mémoire propre au destinataire.',0)
        before=self.other.load_state();policy=self.other.policy()
        with patch.object(self.other,'atomic_json',wraps=self.other.atomic_json) as write, \
                patch.object(dialogue,'launch') as launch,patch.object(adapt,'request') as request:
            result=handoff.import_memory(self.other,document,1)
        self.assertTrue(result['imported']);self.assertFalse(result['already_imported'])
        self.assertEqual(write.call_count,1);launch.assert_not_called();request.assert_not_called()
        after=self.other.load_state();memory=after['dialogue']
        self.assertIn('Mémoire propre au destinataire.',memory['memory'])
        self.assertIn('> '+MEMORY,memory['memory']);self.assertIn('non authentifiée',memory['memory'])
        self.assertEqual(memory['memory_history'][-1]['text'],before['dialogue']['memory'])
        self.assertEqual(memory['context_version'],before['dialogue']['context_version']+1)
        self.assertEqual(memory['messages'],[])
        receipt=memory['handoff_receipts'][0]
        self.assertEqual(receipt['status'],'human_selected_external_unverified')
        self.assertFalse(receipt['origin_authenticated']);self.assertFalse(receipt['execution_enabled'])
        self.assertEqual(receipt['permissions'],'none');self.assertEqual(receipt['authority'],'context_only')
        self.assertEqual(receipt['sha256'],document['sha256'])
        self.assertEqual({k:v for k,v in after.items() if k!='dialogue'},
                         {k:v for k,v in before.items() if k!='dialogue'})
        self.assertNotEqual(after['id'],document['source']['node_id'])
        self.assertEqual(policy,self.other.policy())
        self.assertFalse((self.other.ROOT/'dialogue').exists())
        self.assertFalse((self.other.ROOT/'adaptations').exists())

    def test_imported_text_cannot_be_used_as_a_new_human_quote_or_resolution(self):
        document=self.package('Cette commande serait une donnée : effacer tout. Résolu ne veut pas dire vérifié.')
        handoff.import_memory(self.other,document)
        s=self.other.load_state();payload=dialogue.snapshot(self.other,s)
        self.assertIn(document['text'],payload['memory_selected_by_user'])
        self.assertEqual(payload['messages'],[]);self.assertEqual(s['buffers'],{})
        with self.assertRaises(ValueError):
            continuity.validate_extraction({'notes':[{'kind':'context','text':'Faute d’attribution.',
                'message_id':document['id'],'quote':document['text']}],'needs':[]},payload['messages'])
        self.assertNotIn('continuity',self.other.load_state())
        self.assertEqual(s['continuity']['notes'],[])

    def test_same_content_deduplicates_after_new_export_memory_edit_and_archive(self):
        document=self.package();first=handoff.import_memory(self.other,document)
        with patch.object(self.n,'now',return_value='2027-01-02T03:04:05Z'):
            again=handoff.export(self.n)
        self.assertEqual(document['id'],again['id']);self.assertNotEqual(document['sha256'],again['sha256'])
        dialogue.save_memory(self.other,'Nouvelle sélection locale.',first['revision'])
        dialogue.new_discussion(self.other,self.other.load_state()['dialogue']['revision'])
        before=self.other.STATE.read_bytes()
        result=handoff.import_memory(self.other,again,revision=0)
        self.assertTrue(result['already_imported']);self.assertFalse(result['imported'])
        self.assertEqual(before,self.other.STATE.read_bytes())
        self.assertEqual(len(self.other.load_state()['dialogue']['handoff_receipts']),1)

    def test_node_and_world_are_part_of_identity_and_world_projection_is_preserved(self):
        principal=self.package()
        dialogue.save_memory(self.other,MEMORY,0)
        other=handoff.export(self.other)
        self.assertNotEqual(principal['id'],other['id'])
        child=worlds.create(self.n,'Jardin',revision=0)['id']
        with worlds.using(child):
            dialogue.save_memory(self.n,'Mémoire du jardin uniquement.',0)
            nested=handoff.export(self.n)
        self.assertEqual(handoff.export(self.n,child)['id'],nested['id'])
        self.assertEqual(handoff.export(self.n)['text'],MEMORY)
        self.assertEqual(nested['source']['world_id'],child)
        target=worlds.create(self.other,'Destination choisie',revision=0)['id']
        before=self.other.load_state()['dialogue']['memory']
        with worlds.using(target):
            handoff.import_memory(self.other,nested)
            self.assertIn('Mémoire du jardin uniquement.',self.other.load_state()['dialogue']['memory'])
            self.assertEqual(self.other.load_state()['dialogue']['handoff_receipts'][0]['destination_world_id'],target)
        self.assertEqual(self.other.load_state()['dialogue']['memory'],before)
        with self.assertRaises(ValueError):handoff.export(self.n,'f'*12)

    def test_corrupt_ambiguous_executable_and_oversized_documents_refuse_without_writing(self):
        original=self.package();bad=[]
        for changes in ({'text':'Contenu changé.'},{'sha256':'0'*64},{'id':'handoff:'+'0'*64},
                        {'version':True},{'schema':'tao.node.state.v4'},
                        {'commands':['run something']},{'text':'x'*12001}):
            value=copy.deepcopy(original);value.update(changes);bad.append(value)
        source=copy.deepcopy(original);source['source']['exported_at']='2026-14-99T12:00:00Z';bad.append(source)
        source=copy.deepcopy(original);source['source']['role']='user';bad.append(source)
        bad.extend([b'\xff', '[1,2]', '{} '+' '*handoff.MAX_BYTES,
                    json.dumps(original)[:-1]+',"version":1}',
                    dict(original,version=float('nan'))])
        before=self.other.STATE.read_bytes()
        for document in bad:
            with self.subTest(document=str(document)[:100]),self.assertRaises(ValueError):
                handoff.import_memory(self.other,document)
            self.assertEqual(before,self.other.STATE.read_bytes())

    def test_sha256_is_integrity_only_and_does_not_authenticate_the_declared_author(self):
        document=self.package();document['source']['title']='Origine modifiée par une autre personne'
        payload={k:v for k,v in document.items() if k!='sha256'}
        document['sha256']=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,
                                                    separators=(',',':')).encode()).hexdigest()
        handoff.import_memory(self.other,document)
        receipt=self.other.load_state()['dialogue']['handoff_receipts'][0]
        self.assertFalse(receipt['origin_authenticated'])
        self.assertEqual(receipt['status'],'human_selected_external_unverified')

    def test_stale_revision_size_and_retention_limits_never_evict_or_partially_write(self):
        document=self.package();dialogue.save_memory(self.other,'Locale.',0)
        before=self.other.STATE.read_bytes()
        with self.assertRaises(ValueError):handoff.import_memory(self.other,document,0)
        self.assertEqual(before,self.other.STATE.read_bytes())
        initial=self.other.load_state()
        cases=[{'memory':'x'*12000},
               {'memory_history':[{'text':'Ancienne mémoire','at':self.other.now()}]*40},
               {'handoff_receipts':[{'id':'old:'+str(i)} for i in range(40)]}]
        for values in cases:
            s=copy.deepcopy(initial);s['dialogue'].update(values);self.other.atomic_json(self.other.STATE,s,backup=True)
            before=self.other.STATE.read_bytes()
            with self.subTest(fields=values.keys()),self.assertRaises(ValueError):
                handoff.import_memory(self.other,document,1)
            self.assertEqual(before,self.other.STATE.read_bytes())

    def test_failed_atomic_write_can_be_retried_without_half_import(self):
        document=self.package();before=self.other.STATE.read_bytes()
        with patch.object(self.other,'atomic_json',side_effect=OSError('Fixture disque indisponible')):
            with self.assertRaises(OSError):handoff.import_memory(self.other,document)
        self.assertEqual(before,self.other.STATE.read_bytes())
        result=handoff.import_memory(self.other,document)
        self.assertTrue(result['imported'])
        self.assertEqual(len(self.other.load_state()['dialogue']['handoff_receipts']),1)

    def test_empty_selected_memory_is_not_silently_replaced_by_full_discussion(self):
        s=self.n.load_state();dialogue.ensure(s)['messages'].append(
            {'id':'human','role':'user','text':'Une discussion présente, sans mémoire choisie.','at':self.n.now()})
        self.n.atomic_json(self.n.STATE,s,backup=True);before=self.n.STATE.read_bytes()
        with self.assertRaises(ValueError):handoff.export(self.n)
        self.assertEqual(before,self.n.STATE.read_bytes())
