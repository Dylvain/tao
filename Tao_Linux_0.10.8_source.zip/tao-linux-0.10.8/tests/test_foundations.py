import copy
import json
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'bootstrap'))
import tao_foundations as foundations
import tao_worlds as worlds


def fresh():
    return {'schema': 'tao.node.state.v4', 'id': 'node:empty-test', 'cycles': 0,
            'buffers': {}, 'policy': {'external_ai_auto': False, 'self_modify_code': False}}


class FoundationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.raw = foundations.seed(fresh())
        self.writes = 0
        self.n = SimpleNamespace(ROOT=Path(self.tmp.name), STATE=Path(self.tmp.name) / 'state.json',
            LOCK=threading.RLock(), load_raw_state=lambda: copy.deepcopy(self.raw), atomic_json=self.persist)

    def tearDown(self):
        self.tmp.cleanup()

    def persist(self, path, value, backup=False):
        self.assertEqual(path, self.n.STATE)
        self.assertTrue(backup)
        self.raw = copy.deepcopy(value)
        self.writes += 1

    def revision(self):
        return self.raw['worlds']['revision']

    def ident(self, key):
        return next(ident for ident, row in self.raw['worlds']['spaces'].items() if row.get('template_key') == key)

    def test_fresh_inheritance_is_only_empty_metadata_with_no_permissions(self):
        source = fresh(); before = copy.deepcopy(source)
        seeded = foundations.seed(source)
        self.assertEqual(source, before)
        self.assertEqual(seeded['id'], source['id'])
        self.assertEqual(seeded['policy'], source['policy'])
        self.assertEqual(len(seeded['worlds']['spaces']), 9)
        self.assertEqual(seeded['worlds']['revision'], 0)
        self.assertEqual(foundations.seed(seeded), seeded)
        for ident, row in seeded['worlds']['spaces'].items():
            self.assertFalse(set(worlds.PRIVATE_FIELDS) & set(row))
            if ident != worlds.MAIN:
                self.assertEqual(row['buffers'], {})
                self.assertEqual(row['parent_id'], worlds.MAIN)
        self.assertEqual(set(foundations._template_map(seeded['worlds'])), set(foundations.AREAS))

    def test_seed_refuses_to_treat_an_existing_history_as_a_newborn(self):
        for changes in ({'cycles': 1}, {'dialogue': {}}, {'continuity': {}},
                        {'buffers': {'user:need': {'text': 'keep me'}}},
                        {'landmarks': {}}, {'story': {'text': 'keep me'}}):
            raw = dict(fresh(), **changes)
            self.assertEqual(foundations.seed(raw), raw)
        legacy = fresh(); legacy['worlds'] = worlds._registry(legacy)
        self.assertEqual(foundations.seed(legacy), legacy)

    def test_concept_ids_and_relationships_are_language_independent(self):
        fr, en = foundations.catalog('fr-FR'), foundations.catalog('en_NZ')
        self.assertEqual([x['id'] for x in fr['concepts']], [x['id'] for x in en['concepts']])
        self.assertNotEqual(fr['concepts'][0]['label'], en['concepts'][0]['label'])
        valid = {row['id'] for row in fr['concepts']}
        for row in fr['concepts']:
            self.assertTrue(row['definition'])
            for relation in row['relations']:
                self.assertIn(relation['predicate'], foundations.RELATIONS)
                self.assertTrue(set(relation['target_types']) <= valid)
        self.assertEqual(foundations.get_concept('income')['id'], 'tao.concept.income')
        self.assertEqual(foundations.get_concept('tao.concept.income', 'en')['label'], 'Income')
        for invalid in ('system_prompt', 'tao.concept.unknown', [], None):
            with self.assertRaises(ValueError):
                foundations.get_concept(invalid)
        with self.assertRaises(ValueError):
            foundations.catalog('de')
        fr['concepts'][0]['relations'].clear()
        self.assertTrue(foundations.get_concept('story')['relations'])

    def test_overview_and_child_projection_expose_metadata_not_other_histories(self):
        work, personal = self.ident('work'), self.ident('personal')
        self.raw['dialogue'] = {'memory': 'MAIN_PRIVATE'}
        self.raw['continuity'] = {'landmarks': {'objects': [{'title': 'MAIN_SECRET'}]}}
        self.raw['worlds']['spaces'][personal]['dialogue'] = {'memory': 'OTHER_PRIVATE'}
        self.raw['worlds']['spaces'][personal]['continuity'] = {'landmarks': {'objects': [{'title': 'OTHER_SECRET'}]}}
        self.raw['worlds']['spaces'][work]['continuity'] = {'landmarks': {'objects': [{'title': 'WORK_PRIVATE'}]}}
        with worlds.using(work):
            view = worlds.project(self.raw)
            overview = foundations.overview(self.n, view, 'en')
        self.assertEqual(view['continuity']['landmarks']['objects'][0]['title'], 'WORK_PRIVATE')
        for private in ('MAIN_PRIVATE', 'MAIN_SECRET', 'OTHER_PRIVATE', 'OTHER_SECRET'):
            self.assertNotIn(private, json.dumps(view))
        for private in ('MAIN_PRIVATE', 'MAIN_SECRET', 'OTHER_PRIVATE', 'OTHER_SECRET', 'WORK_PRIVATE'):
            self.assertNotIn(private, json.dumps(overview))
        self.assertTrue(overview['initialized'])
        self.assertEqual(next(row for row in overview['spaces'] if row['id'] == work)['display_title'], 'Work')
        self.assertEqual(self.writes, 0)

    def test_explicit_legacy_initialize_preserves_names_data_and_is_idempotent(self):
        self.raw = fresh(); self.raw['cycles'] = 300
        self.raw['dialogue'] = {'memory': 'Existing story'}
        self.raw['worlds'] = worlds._registry(self.raw)
        old = 'aaaaaaaaaaaa'
        self.raw['worlds']['spaces'][old] = {'id': old, 'title': 'Travail', 'parent_id': worlds.MAIN,
                                            'dialogue': {'memory': 'Existing work'}, 'buffers': {}}
        previous = copy.deepcopy(self.raw)
        result = foundations.initialize(self.n, 0, 'en')
        self.assertEqual(self.raw['dialogue'], previous['dialogue'])
        self.assertEqual(self.raw['worlds']['spaces'][old], previous['worlds']['spaces'][old])
        self.assertNotEqual(self.ident('work'), old)
        self.assertEqual(len(self.raw['worlds']['spaces']), 10)
        self.assertTrue(result['initialized'])
        again = foundations.initialize(self.n, self.revision(), 'fr')
        self.assertEqual(self.writes, 1)
        self.assertEqual(again['revision'], result['revision'])
        self.assertEqual(next(r for r in again['spaces'] if r['id'] == old)['display_title'], 'Travail')

    def test_initialization_capacity_failure_is_atomic(self):
        self.raw = fresh(); self.raw['worlds'] = worlds._registry(self.raw)
        before = copy.deepcopy(self.raw)
        with patch.object(worlds, 'MAX_SPACES', 8), self.assertRaises(ValueError):
            foundations.initialize(self.n, 0)
        self.assertEqual(self.raw, before)
        self.assertEqual(self.writes, 0)

    def test_revision_checks_cover_every_mutation(self):
        work = self.ident('work'); before = copy.deepcopy(self.raw)
        stale = self.revision() - 1
        for operation in (
            lambda: foundations.initialize(self.n, stale),
            lambda: foundations.update(self.n, work, stale, title='Changed'),
            lambda: foundations.archive(self.n, work, stale),
            lambda: foundations.restore(self.n, work, stale),
            lambda: foundations.remove_empty(self.n, work, stale, confirm=True),
        ):
            with self.assertRaises(ValueError):
                operation()
            self.assertEqual(self.raw, before)
        self.assertEqual(self.writes, 0)

    def test_renaming_and_reparenting_do_not_merge_or_translate_user_words(self):
        work, personal = self.ident('work'), self.ident('personal')
        self.raw['worlds']['spaces'][work]['dialogue'] = {'memory': 'Work remains work'}
        self.raw['worlds']['spaces'][personal]['dialogue'] = {'memory': 'Personal remains personal'}
        foundations.update(self.n, work, self.revision(), title='Mon atelier', description='À ma manière', parent_id=personal)
        row = self.raw['worlds']['spaces'][work]
        self.assertEqual(row['template_key'], 'work')
        self.assertEqual(row['parent_id'], personal)
        overview = foundations.overview(self.n, locale='en')
        meta = next(item for item in overview['spaces'] if item['id'] == work)
        self.assertEqual(meta['display_title'], 'Mon atelier')
        self.assertEqual(meta['display_description'], 'À ma manière')
        with worlds.using(personal):
            projected = worlds.project(self.raw)
        self.assertNotIn('Work remains work', json.dumps(projected))
        self.assertEqual(projected['dialogue']['memory'], 'Personal remains personal')

    def test_reparent_rejects_cycles_and_descendant_depth_without_any_write(self):
        work, personal = self.ident('work'), self.ident('personal')
        foundations.update(self.n, personal, self.revision(), parent_id=work)
        before = copy.deepcopy(self.raw)
        with self.assertRaises(ValueError):
            foundations.update(self.n, work, self.revision(), parent_id=personal)
        self.assertEqual(self.raw, before)
        with patch.object(worlds, 'MAX_DEPTH', 1), self.assertRaises(ValueError):
            foundations.update(self.n, work, self.revision(), title='Still invalid')
        self.assertEqual(self.raw, before)

    def test_archival_is_reversible_and_does_not_broaden_private_context(self):
        work, personal = self.ident('work'), self.ident('personal')
        self.raw['worlds']['spaces'][work]['continuity'] = {'landmarks': {'items': ['work secret']}}
        foundations.update(self.n, work, self.revision(), parent_id=personal)
        foundations.archive(self.n, personal, self.revision())
        overview = foundations.overview(self.n)
        child = next(row for row in overview['spaces'] if row['id'] == work)
        self.assertTrue(child['effective_archived'])
        self.assertFalse(child['archived'])
        with self.assertRaises(ValueError):
            foundations.restore(self.n, work, self.revision())
        with worlds.using(work):
            self.assertEqual(worlds.project(self.raw)['continuity']['landmarks']['items'], ['work secret'])
        with worlds.using(personal):
            self.assertNotIn('work secret', json.dumps(worlds.project(self.raw)))
        foundations.restore(self.n, personal, self.revision())
        self.assertFalse(next(row for row in foundations.overview(self.n)['spaces'] if row['id'] == work)['effective_archived'])
        with self.assertRaises(ValueError):
            foundations.archive(self.n, worlds.MAIN, self.revision())

    def test_empty_deletion_requires_confirmation_and_never_silently_respawns(self):
        work = self.ident('work'); before = copy.deepcopy(self.raw)
        for confirmation in (False, 'true', 1):
            with self.assertRaises(ValueError):
                foundations.remove_empty(self.n, work, self.revision(), confirmation)
        self.assertEqual(self.raw, before)
        removed = foundations.remove_empty(self.n, work, self.revision(), True)
        self.assertEqual(next(row for row in removed['areas'] if row['key'] == 'work')['status'], 'removed')
        self.assertNotIn(work, self.raw['worlds']['spaces'])
        foundations.initialize(self.n, self.revision())
        self.assertEqual(len(self.raw['worlds']['spaces']), 8)
        self.assertEqual(foundations.seed(self.raw), self.raw)
        with worlds.using(worlds.MAIN):
            view = worlds.project(self.raw)
            merged = worlds.merge(self.raw, view)
        self.assertIn('work', merged['worlds']['foundations']['removed_templates'])
        with worlds.using(work), self.assertRaises(ValueError):
            worlds.project(self.raw)

    def test_deletion_refuses_private_data_children_and_external_archives(self):
        work = self.ident('work'); pristine = copy.deepcopy(self.raw)
        for field, value in (('dialogue', {}), ('landmarks', {'items': []}),
                             ('custom_private_data', {}), ('buffers', {'user:x': {'text': 'keep'}})):
            self.raw = copy.deepcopy(pristine)
            self.raw['worlds']['spaces'][work][field] = value
            before = copy.deepcopy(self.raw)
            with self.assertRaises(ValueError):
                foundations.remove_empty(self.n, work, self.revision(), True)
            self.assertEqual(self.raw, before)
        self.raw = copy.deepcopy(pristine)
        child = self.ident('personal')
        self.raw['worlds']['spaces'][child]['parent_id'] = work
        with self.assertRaises(ValueError):
            foundations.remove_empty(self.n, work, self.revision(), True)
        self.raw = copy.deepcopy(pristine)
        archive = self.n.ROOT / 'history-archives' / work
        archive.mkdir(parents=True)
        (archive / 'test.json').write_text('{"private":"keep"}')
        with self.assertRaises(ValueError):
            foundations.remove_empty(self.n, work, self.revision(), True)
        self.assertTrue((archive / 'test.json').exists())

    def test_broken_template_metadata_fails_closed_without_leaking_marker_fields(self):
        self.raw['worlds']['foundations']['secret'] = 'PRIVATE_MARKER'
        with worlds.using(self.ident('work')):
            view = worlds.project(self.raw)
        self.assertNotIn('PRIVATE_MARKER', json.dumps(view))
        self.raw['worlds']['foundations']['removed_templates'] = ['not_a_template']
        before = copy.deepcopy(self.raw)
        work = self.ident('work')
        for operation in (
            lambda: foundations.initialize(self.n, self.revision()),
            lambda: foundations.update(self.n, work, self.revision(), title='Never written'),
            lambda: foundations.archive(self.n, work, self.revision()),
            lambda: foundations.remove_empty(self.n, work, self.revision(), True),
        ):
            with self.assertRaises(ValueError):
                operation()
            self.assertEqual(self.raw, before)
        self.assertEqual(self.writes, 0)

    def test_sidecar_only_capabilities_cannot_be_orphaned_by_empty_deletion(self):
        work = self.ident('work'); pristine = copy.deepcopy(self.raw)
        for relative in ('reuse/' + work + '.json', 'connectors/' + work + '.json',
                         'bridge/' + work + '/state-v1.json'):
            with self.subTest(relative=relative):
                path = self.n.ROOT / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text('{"private_receipt":"keep"}')
                with self.assertRaises(ValueError):
                    foundations.remove_empty(self.n, work, self.revision(), True)
                self.assertEqual(self.raw, pristine)
                self.assertEqual(path.read_text(), '{"private_receipt":"keep"}')
                path.unlink()
                if relative.startswith('bridge/'):
                    path.parent.rmdir()
        self.assertEqual(self.writes, 0)

    def test_device_references_and_unreadable_registry_block_empty_deletion(self):
        import tao_devices as devices
        work = self.ident('work'); pristine = copy.deepcopy(self.raw)
        path = self.n.ROOT / 'devices' / 'registry.json'
        path.parent.mkdir()
        registry = {'schema': devices.SCHEMA, 'node_id': self.raw['id'], 'revision': 0,
                    'devices': {}, 'pairings': {}, 'jobs': {}}
        ident = '1' * 32
        registry['pairings'][ident] = {'id': ident, 'world_id': work,
                                      'code_hash': 'a' * 64, 'expires_epoch': 1}
        path.write_text(json.dumps(registry))
        original = path.read_bytes()
        with self.assertRaises(ValueError):
            foundations.remove_empty(self.n, work, self.revision(), True)
        self.assertEqual(self.raw, pristine)
        self.assertEqual(path.read_bytes(), original)
        path.write_text('{broken registry')
        with self.assertRaises(ValueError):
            foundations.remove_empty(self.n, work, self.revision(), True)
        self.assertEqual(self.raw, pristine)
        self.assertEqual(path.read_text(), '{broken registry')
        # A valid device registry concerning another world need not prevent an
        # unrelated pristine leaf from being removed.
        registry['pairings'][ident]['world_id'] = self.ident('personal')
        path.write_text(json.dumps(registry))
        foundations.remove_empty(self.n, work, self.revision(), True)
        self.assertNotIn(work, self.raw['worlds']['spaces'])
        self.assertEqual(json.loads(path.read_text()), registry)


if __name__ == '__main__':
    unittest.main()
