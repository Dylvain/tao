import copy
import json
from unittest.mock import patch

from test_node import NodeHarness
from test_ecology import HEALTHY
import tao_adaptation as adapt
import tao_dialogue as talk
import tao_worlds as worlds


TEXT='Je souhaite apprendre à comprendre ce jardin avant de déléguer son entretien.'


class DialogueRoutingTests(NodeHarness):
    def send(self, text=TEXT, intent='learn', nonce='routing-fixture-001', available=True, focus=None):
        revision=self.n.load_state().get('dialogue',{}).get('revision',0)
        with patch.object(adapt,'executable',return_value='/fixture/codex' if available else None),patch.object(talk,'launch'):
            return talk.send(self.n,text,revision,nonce,focus,intent)

    def payload(self, row):
        return self.n.load_json(talk.file(self.n,row['id']).parent/'context.json')

    def answer(self, row, invalid_route=False, with_proposal=False, malformed=False):
        def run(node,exe,job_row,cwd,prompt,timeout,cancelled):
            self.assertEqual(exe,'/fixture/codex')
            payload=self.n.load_json(cwd/'context.json')
            source=next(m for m in reversed(payload['messages']) if m['role']=='user')
            if malformed:
                (cwd/'response.json').write_text('{broken');return {'ok':True}
            raw={'reply':'On peut apprendre sur un cas concret sans agir à ta place.',
                'memory_suggestion':'','situation_map':None,
                'proposal':{'title':'Aide fictive','situation':'Un cas','expected':'Une aide relue','boundaries':'Aucun envoi'} if with_proposal else None,
                'continuity':{'notes':[{'kind':'preference','text':'Apprendre avant de déléguer.',
                                      'message_id':source['id'],'quote':source['text']}],'needs':[]},
                'routing':{'intent':'Comprendre et apprendre avant de déléguer.',
                           'contributions':[{'function_id':'imaginary_action' if invalid_route else 'explain',
                                             'reason':'La personne souhaite apprendre.','expected':'Un exemple et ses limites.',
                                             'source_ids':[source['id']]}]}}
            (cwd/'response.json').write_text(json.dumps(raw))
            return {'ok':True}
        with patch.object(adapt,'executable',return_value='/fixture/codex'), \
                patch.object(talk,'run_provider',side_effect=run) as provider, \
                patch.object(self.n,'observe_environment',return_value=HEALTHY):
            result=talk.worker(self.n,row['id'])
        self.assertEqual(provider.call_count,1)
        return result

    def test_human_intent_is_explicit_in_context_and_nonce_cannot_change_it(self):
        before=self.n.policy(); row=self.send()
        self.assertEqual(self.payload(row)['routing']['human_intent'],'learn')
        self.assertEqual(self.n.load_state()['dialogue']['messages'][-1]['intent'],'learn')
        again=self.send();self.assertEqual(again['id'],row['id'])
        raw=self.n.STATE.read_bytes()
        for intent in ('execute',None,True,{},'delegate'):
            with self.subTest(intent=intent),self.assertRaises(ValueError):self.send(intent=intent)
            self.assertEqual(raw,self.n.STATE.read_bytes())
        self.assertEqual(before,self.n.policy())

    def test_single_response_records_inert_route_measured_turn_cost_and_memory(self):
        row=self.answer(self.send());s=self.n.load_state();m=s['dialogue']['messages'][-1]
        self.assertEqual(row['status'],'answered')
        trace=m['routing_trace'];function=trace['route']['contributions'][0]
        self.assertEqual(function['function_id'],'explain');self.assertEqual(function['status'],'proposed')
        self.assertFalse(function['execution_enabled']);self.assertEqual(trace['human_intent'],'learn')
        self.assertEqual(trace['source_message_id'],s['dialogue']['messages'][0]['id'])
        self.assertEqual(trace['world_id'],'main');self.assertEqual(trace['result'],'reply_unverified')
        self.assertEqual(trace['permissions'],'none');self.assertFalse(trace['execution_enabled'])
        costs=trace['costs'];self.assertEqual(costs['scope'],'whole_dialogue_turn')
        self.assertEqual(costs['cli_attempts'],1);self.assertGreaterEqual(costs['measured_wall_seconds'],0)
        self.assertIsNone(costs['tokens']);self.assertIsNone(costs['money']);self.assertIsNone(costs['electricity_joules'])
        self.assertEqual(s['metabolism']['dialogue_attempts'],1)
        self.assertEqual(len(s['continuity']['notes']),1)
        self.assertEqual(s['buffers'],{})
        self.assertIn('tao.routing.trace.v1',talk.export(s))

    def test_invalid_route_preserves_reply_raw_output_and_valid_memory(self):
        row=self.answer(self.send(),invalid_route=True);s=self.n.load_state();m=s['dialogue']['messages'][-1]
        self.assertEqual(row['status'],'answered')
        self.assertIn('On peut apprendre',m['text']);self.assertIsNone(m['routing_trace']['route'])
        self.assertTrue(m['routing_trace']['warnings']);self.assertEqual(len(s['continuity']['notes']),1)
        self.assertIn('imaginary_action',(talk.file(self.n,row['id']).parent/'response.json').read_text())
        self.assertEqual(s['metabolism']['dialogue_attempts'],1)

    def test_legacy_answers_without_optional_routing_still_validate(self):
        value={'reply':'Une réponse ancienne.','memory_suggestion':'','situation_map':None,'proposal':None}
        clean=talk.validated_reply(json.dumps(value))
        self.assertIsNone(clean['routing']);self.assertEqual(clean['reply'],value['reply'])
        self.assertNotIn('routing_warnings',clean)

    def test_inventory_lists_only_final_bounded_sources_and_previous_traces_are_bounded(self):
        row=self.answer(self.send());s=self.n.load_state();d=s['dialogue'];trace=d['messages'][-1]['routing_trace']
        for i in range(10):
            d['messages'].append({'id':'past-'+str(i),'role':'assistant','text':'Autre sujet é'+str(i)+'é'*5990,
                                  'at':self.n.now(),'routing_trace':copy.deepcopy(trace)})
        d['messages'].append({'id':'last','role':'user','text':'Une contribution finale nouvelle.','intent':'understand','at':self.n.now()})
        payload=talk.snapshot(self.n,s)
        available={row['id'] for row in talk.routing_sources(payload)}
        self.assertEqual({row['id'] for row in payload['routing_sources']},available)
        self.assertLessEqual(len(self.n.json_bytes(payload)),talk.MAX_CONTEXT)
        self.assertLessEqual(len(payload['previous_routing']),3)
        self.assertEqual(payload['omitted_routing_traces']+len(payload['previous_routing']),11)
        self.assertEqual(payload['routing']['human_intent'],'understand')
        self.assertEqual(len(d['messages']),13)

    def test_retry_missing_provider_is_explicit_idempotent_and_does_not_repeat_human_words(self):
        blocked=self.send(available=False);s=self.n.load_state();original=s['dialogue']['messages'][0]
        talk.save_memory(self.n,'Nouvelle contrainte fournie.',s['dialogue']['revision'])
        revision=self.n.load_state()['dialogue']['revision']
        with patch.object(adapt,'executable',return_value='/fixture/codex'),patch.object(talk,'launch') as launch:
            retry=talk.retry(self.n,blocked['id'],revision)
            duplicate=talk.retry(self.n,blocked['id'],revision)
            launch.assert_called_once()
        self.assertEqual(retry['id'],duplicate['id']);self.assertNotEqual(retry['id'],blocked['id'])
        s=self.n.load_state();d=s['dialogue'];self.assertEqual(len(d['messages']),1)
        self.assertEqual(d['messages'][0]['id'],original['id']);self.assertEqual(d['messages'][0]['text'],TEXT)
        self.assertEqual(d['messages'][0]['retry_jobs'],[blocked['id']])
        self.assertEqual(talk.load(self.n,blocked['id'])['retried_as'],retry['id'])
        self.assertEqual(self.payload(retry)['memory_selected_by_user'],'Nouvelle contrainte fournie.')
        self.assertEqual(self.payload(retry)['routing']['human_intent'],'learn')
        self.assertNotIn('dialogue_attempts',s['metabolism'])
        self.assertEqual(self.answer(retry)['status'],'answered')
        self.assertEqual(len(self.n.load_state()['dialogue']['messages']),2)

    def test_retry_after_failed_model_keeps_attempt_accounting_and_succeeds_once(self):
        failed=self.answer(self.send(),malformed=True)
        self.assertEqual(failed['status'],'blocked')
        self.assertEqual(self.n.load_state()['metabolism']['dialogue_attempts'],1)
        with patch.object(adapt,'executable',return_value='/fixture/codex'),patch.object(talk,'launch'):
            retry=talk.retry(self.n,failed['id'],self.n.load_state()['dialogue']['revision'])
        self.answer(retry)
        s=self.n.load_state();self.assertEqual(s['metabolism']['dialogue_attempts'],2)
        self.assertEqual(len([m for m in s['dialogue']['messages'] if m['role']=='user']),1)
        self.assertTrue((talk.file(self.n,failed['id']).parent/'response.json').is_file())

    def test_retry_rejects_other_world_previous_question_and_stale_revision(self):
        blocked=self.send(available=False);revision=self.n.load_state()['dialogue']['revision']
        before=self.n.STATE.read_bytes()
        with self.assertRaises(ValueError):talk.retry(self.n,blocked['id'],revision-1)
        self.assertEqual(self.n.STATE.read_bytes(),before)
        child=worlds.create(self.n,'Autre espace',revision=0)['id']
        with worlds.using(child),self.assertRaises(ValueError):talk.retry(self.n,blocked['id'],0)
        newer=self.send(text='Une question plus récente.',nonce='routing-fixture-002',available=False)
        with self.assertRaises(ValueError):talk.retry(self.n,blocked['id'],self.n.load_state()['dialogue']['revision'])
        self.assertEqual(self.n.load_state()['dialogue']['messages'][-1]['job_id'],newer['id'])

    def test_retry_limit_retains_all_attempts_and_refuses_without_call(self):
        current=self.send(available=False)
        for _ in range(10):
            with patch.object(adapt,'executable',return_value=None):
                current=talk.retry(self.n,current['id'],self.n.load_state()['dialogue']['revision'])
        before=self.n.STATE.read_bytes()
        with patch.object(talk,'launch') as launch,self.assertRaises(ValueError):
            talk.retry(self.n,current['id'],self.n.load_state()['dialogue']['revision'])
        launch.assert_not_called();self.assertEqual(before,self.n.STATE.read_bytes())
        self.assertEqual(len(list((self.root/'dialogue').glob('*/job.json'))),11)
        self.assertEqual(len(self.n.load_state()['dialogue']['messages']),1)

    def test_retry_rejects_stale_focus_and_active_work_in_another_world(self):
        focus={'kind':'space','id':'main','revision':0}
        blocked=self.send(available=False,focus=focus)
        child=worlds.create(self.n,'Autre activité',revision=0)['id']
        before=self.n.STATE.read_bytes()
        with patch.object(talk,'launch') as launch,self.assertRaises(ValueError):
            talk.retry(self.n,blocked['id'],self.n.load_state()['dialogue']['revision'])
        launch.assert_not_called();self.assertEqual(self.n.STATE.read_bytes(),before)
        # A fresh contribution clears the stale selection, while another world's
        # running request still occupies the shared provider budget/worker.
        blocked=self.send(available=False,nonce='routing-unfocused-002')
        with worlds.using(child):self.send(nonce='routing-child-001')
        before=self.n.STATE.read_bytes()
        with patch.object(talk,'launch') as launch,self.assertRaises(ValueError):
            talk.retry(self.n,blocked['id'],self.n.load_state()['dialogue']['revision'])
        launch.assert_not_called();self.assertEqual(self.n.STATE.read_bytes(),before)

    def test_delayed_worker_reloads_after_lock_and_does_not_overwrite_a_retry(self):
        original_flock=talk.fcntl.flock
        for lock_busy in (False,True):
            with self.subTest(lock_busy=lock_busy):
                queued=self.send(nonce='routing-race-'+str(lock_busy))
                old=talk.load(self.n,queued['id']);old['started_epoch']=self.n.epoch()-30;talk.save(self.n,old)
                replacement=[]
                def race(lock,operation):
                    if str(getattr(lock,'name','')).endswith('/workshop.lock'):
                        replacement.append(talk.retry(self.n,queued['id'],self.n.load_state()['dialogue']['revision']))
                        if lock_busy:raise BlockingIOError('Fixture atelier occupé')
                    return original_flock(lock,operation)
                with patch.object(talk.fcntl,'flock',side_effect=race), \
                        patch.object(adapt,'executable',return_value=None), \
                        patch.object(talk,'run_provider') as provider, \
                        patch.object(talk.ecology,'reserve') as reserve:
                    if lock_busy:talk.worker(self.n,queued['id'])
                    else:
                        with self.assertRaises(ValueError):talk.worker(self.n,queued['id'])
                provider.assert_not_called();reserve.assert_not_called()
                self.assertEqual(len(replacement),1)
                stored=talk.load(self.n,queued['id'])
                self.assertEqual(stored['retried_as'],replacement[0]['id'])
                self.assertEqual(stored['status'],'interrupted')
                self.assertEqual(self.n.load_state()['dialogue']['messages'][-1]['job_id'],replacement[0]['id'])
                self.assertNotIn('dialogue_attempts',self.n.load_state()['metabolism'])

    def test_expired_queued_job_requires_explicit_retry_even_if_raw_status_is_queued(self):
        queued=self.send();old=talk.load(self.n,queued['id'])
        old['started_epoch']=self.n.epoch()-30;talk.save(self.n,old)
        before=self.n.STATE.read_bytes()
        with patch.object(talk,'run_provider') as provider, \
                patch.object(talk.ecology,'reserve') as reserve,self.assertRaises(ValueError):
            talk.worker(self.n,queued['id'])
        provider.assert_not_called();reserve.assert_not_called()
        self.assertEqual(before,self.n.STATE.read_bytes())
        self.assertEqual(talk.load(self.n,queued['id'])['status'],'queued')

    def test_preparing_without_capability_keeps_exact_task_and_never_calls_model(self):
        row=self.answer(self.send(intent='improve'),with_proposal=True)
        diagnostic={'ready':False,'blockers':[{'code':'codex_missing','message':'Codex absent.','next':'Le connecter.'}],
                    'source':None,'codex_detected':False}
        with patch.object(adapt,'diagnose',return_value=diagnostic),patch.object(adapt,'request') as request:
            result=talk.prepare(self.n,row['reply_id']);again=talk.prepare(self.n,row['reply_id'])
            request.assert_not_called()
        self.assertFalse(result['prepared']);self.assertEqual(result['blockers'],diagnostic['blockers'])
        self.assertEqual(again['task_id'],result['task_id'])
        task=self.n.load_state()['buffers'][result['task_id']]
        self.assertEqual(task['status'],'open');self.assertFalse(task['work_task']['execution_enabled'])
        self.assertEqual(task['work_task']['example']['expected'],'Une aide relue')
