import concurrent.futures
import copy
import hashlib
import json
import os
import secrets
import stat
import subprocess
import sys
from unittest.mock import patch

from test_node import NodeHarness, BOOT
import tao_devices as devices
import tao_worlds as worlds
import tao_continuity as continuity


TOKEN = 'fixture_device_token_with_at_least_32_characters'
MACHINE = '1' * 32
HEAD = 'a' * 40
PATCH = 'diff --git a/example.txt b/example.txt\n--- a/example.txt\n+++ b/example.txt\n@@ -1 +1 @@\n-old\n+new\n'


class DeviceTests(NodeHarness):
    def revision(self):
        return devices.owner_view(self.n)['revision']

    def pair(self, token=TOKEN, machine=MACHINE, approve=True):
        pairing = devices.create_pairing(self.n, 'Mon PC', self.revision())
        payload = {'code': pairing['code'], 'token': token, 'label': 'Portable', 'machine_id': machine}
        row = devices.worker(self.n, 'enrol', payload)
        if approve:
            devices.owner_device(self.n, row['device_id'], 'approve', self.revision())
        return row['device_id'], pairing, payload

    def poll(self, token=TOKEN, machine=MACHINE, **changes):
        payload = {'machine_id': machine, 'repo_head': HEAD, 'clean': True,
                   'git': True, 'codex': True, 'python': True, 'allow_tests': False,
                   'platform': 'linux', 'request_id': secrets.token_hex(16)}
        payload.update(changes)
        return devices.worker(self.n, 'poll', payload, token=token)

    def setup_job(self, suffix=''):
        ident, _, _ = self.pair()
        self.poll()
        buffer = self.n.add_buffer('Une sortie manque' + suffix, 'Afficher une sortie', 'La sortie est présente')
        job = devices.enqueue(self.n, ident, buffer['id'], self.revision())
        return ident, buffer, job

    def report(self, work, status='review', token=TOKEN, patch_text=PATCH, **values):
        result = {'ok': status in ('review', 'verified'), 'status': status,
                  'patch': patch_text, 'patch_sha256': hashlib.sha256(patch_text.encode()).hexdigest(),
                  'summary': 'Compte rendu non vérifié de cette machine.', 'elapsed_seconds': 2.0}
        result.update(values)
        payload = {'id': work['id'], 'phase': work['phase'], 'lease_id': work['lease_id'], 'result': result}
        return devices.worker(self.n, 'report', payload, token=token), payload

    def dialogue_need(self):
        s = self.n.load_state()
        ident = 'user:dialogue:source-for-code'
        need = {'id': ident, 'revision': 1, 'title': 'Améliorer l’accueil',
                'current': 'Le bouton manque.', 'desired': 'Afficher un bouton utile.',
                'acceptance': 'Le bouton est visible.', 'next_step': 'Examiner un exemple.',
                'phase': 'to_clarify', 'focused': False, 'history': []}
        b = self.n.make_buffer(ident, 'dialogue', need['current'], authority='human')
        b.update(desired=need['desired'], acceptance=need['acceptance'],
                 dialogue_need=need, story_id='story:fixture')
        s['buffers'][ident] = b
        self.n.atomic_json(self.n.STATE, s, backup=True)
        return ident, {'residual': need['current'], 'goal': need['desired'],
                       'acceptance': need['acceptance']}

    def project_dialogue_need(self):
        ident, snapshot = self.dialogue_need()
        return ident, snapshot, devices.project_need(self.n, ident, 1, snapshot)

    def test_pairing_is_pending_single_use_idempotent_and_hash_only(self):
        ident, pairing, payload = self.pair(approve=False)
        before = (self.n.ROOT / 'devices/registry.json').read_bytes()
        again = devices.worker(self.n, 'enrol', payload)
        self.assertEqual(again['device_id'], ident)
        self.assertEqual((self.n.ROOT / 'devices/registry.json').read_bytes(), before)
        self.assertNotIn(TOKEN, before.decode())
        self.assertNotIn(pairing['code'], before.decode())
        self.assertEqual(self.poll()['status'], 'pending')
        self.assertIsNone(self.poll()['work'])
        altered = dict(payload, token='other_token_which_also_has_32_characters')
        with self.assertRaises(PermissionError):
            devices.worker(self.n, 'enrol', altered)
        altered = dict(payload, machine_id='2' * 32)
        with self.assertRaises(PermissionError):
            devices.worker(self.n, 'enrol', altered)
        public = json.dumps(devices.owner_view(self.n))
        self.assertNotIn('token_hash', public)
        self.assertNotIn('code_hash', public)
        self.assertEqual(stat.S_IMODE((self.n.ROOT / 'devices').stat().st_mode), 0o700)
        self.assertEqual(stat.S_IMODE((self.n.ROOT / 'devices/registry.json').stat().st_mode), 0o600)

    def test_expired_and_malformed_pairing_never_grant_access(self):
        with patch.object(devices.time, 'time', return_value=1000):
            pairing = devices.create_pairing(self.n, 'PC')
        payload = {'code': pairing['code'], 'token': TOKEN, 'label': 'Portable', 'machine_id': MACHINE}
        with patch.object(devices.time, 'time', return_value=1601), self.assertRaises(PermissionError):
            devices.worker(self.n, 'enrol', payload)
        for changes in ({'token': 'short'}, {'machine_id': '../escape'}, {'unknown': 'field'}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                devices.worker(self.n, 'enrol', dict(payload, **changes))
        self.assertEqual(devices.owner_view(self.n)['devices'], [])

    def test_consumed_pairing_recovers_same_machine_after_timeout_without_granting_authority(self):
        with patch.object(devices.time, 'time', return_value=1000):
            ident, _, payload = self.pair(approve=False)
        with patch.object(devices.time, 'time', return_value=2000):
            devices.create_pairing(self.n, 'Une autre machine', self.revision())
            before = (self.n.ROOT / 'devices/registry.json').read_bytes()
            recovered = devices.worker(self.n, 'enrol', payload)
            self.assertEqual(recovered['device_id'], ident)
            self.assertEqual(recovered['status'], 'pending')
            self.assertEqual((self.n.ROOT / 'devices/registry.json').read_bytes(), before)
            with self.assertRaises(PermissionError):
                devices.worker(self.n, 'enrol', dict(payload, token='a' * 43))

    def test_pending_machine_cannot_receive_job_and_owner_revision_required(self):
        ident, _, _ = self.pair(approve=False)
        self.poll()
        buffer = self.n.add_buffer('Manque', 'But', 'Preuve')
        with self.assertRaises(ValueError):
            devices.enqueue(self.n, ident, buffer['id'], self.revision())
        with self.assertRaises(ValueError):
            devices.owner_device(self.n, ident, 'approve', 0)
        devices.owner_device(self.n, ident, 'approve', self.revision())
        revision = self.revision()
        self.poll()
        self.assertEqual(self.revision(), revision, 'Presence must not invalidate owner forms')
        devices.enqueue(self.n, ident, buffer['id'], revision)

    def test_token_machine_identity_and_strict_payloads_are_checked(self):
        self.pair()
        for token in ('wrong_token_with_at_least_32_characters', None, ''):
            with self.subTest(token=token), self.assertRaises(PermissionError):
                self.poll(token=token)
        with self.assertRaises(PermissionError):
            self.poll(machine='2' * 32)
        for values in ({'clean': 1}, {'repo_head': 'main'}, {'request_id': '../bad'},
                       {'world_id': 'main'}, {'platform': 'x' * 101}):
            with self.subTest(values=values), self.assertRaises(ValueError):
                self.poll(**values)

    def test_world_scoped_devices_jobs_and_selected_snapshot_exclude_memory(self):
        ident, buffer, job = self.setup_job()
        state = self.n.load_state()
        state['dialogue'] = {'memory': 'PRIVATE_SECRET_CONTEXT', 'messages': []}
        self.n.atomic_json(self.n.STATE, state, backup=True)
        child = worlds.create(self.n, 'Travail', revision=0)['id']
        with worlds.using(child):
            view = devices.owner_view(self.n)
            self.assertEqual(view['devices'], [])
            self.assertEqual(view['jobs'], [])
            with self.assertRaises(ValueError):
                devices.job_view(self.n, job['id'])
            with self.assertRaises(ValueError):
                devices.owner_device(self.n, ident, 'revoke', view['revision'])
            with self.assertRaises(ValueError):
                devices.enqueue(self.n, ident, buffer['id'], view['revision'])
        # Worker bearer selects its bound world, even if HTTP context differs.
        with worlds.using(child):
            work = self.poll()['work']
        self.assertEqual(work['world_id'], 'main')
        self.assertEqual(set(work), {'id', 'phase', 'lease_id', 'base_commit', 'world_id',
                                     'residual', 'goal', 'acceptance', 'timeout_seconds'})
        self.assertNotIn('PRIVATE_SECRET_CONTEXT', json.dumps(work))
        self.assertNotIn('PRIVATE_SECRET_CONTEXT', (self.n.ROOT / 'devices/registry.json').read_text())

    def test_only_open_code_buffers_not_work_or_dialogue_can_be_enqueued(self):
        ident, _, _ = self.pair()
        self.poll()
        buffer = self.n.add_buffer('Manque', 'But', 'Preuve')
        original = self.n.load_state()
        for field, value in [('work_task', {}), ('dialogue_need', {}), ('status', 'resolved'), ('kind', 'work')]:
            state = copy.deepcopy(original)
            state['buffers'][buffer['id']][field] = value
            self.n.atomic_json(self.n.STATE, state, backup=True)
            with self.subTest(field=field), self.assertRaises(ValueError):
                devices.enqueue(self.n, ident, buffer['id'], self.revision())
        self.assertEqual(devices.owner_view(self.n)['jobs'], [])

    def test_reviewed_dialogue_need_projects_separate_inert_code_buffer(self):
        ident, snapshot, projected = self.project_dialogue_need()
        s = self.n.load_state()
        original = s['buffers'][ident]
        self.assertEqual(original['status'], 'open')
        self.assertEqual(original['kind'], 'dialogue')
        self.assertNotEqual(projected['id'], ident)
        self.assertEqual(projected['kind'], 'code_projection')
        self.assertFalse(projected['kind'] == 'user', 'An older broker must not accept this projection on rollback')
        self.assertFalse(projected['execution_enabled'])
        self.assertFalse(projected['already_projected'])
        self.assertEqual(projected['source_need'], {'id': ident, 'revision': 1, 'world_id': 'main'})
        self.assertEqual({key: projected[field] for key, field in
                          (('residual', 'residual'), ('goal', 'desired'), ('acceptance', 'acceptance'))}, snapshot)
        self.assertNotIn('dialogue_need', projected)
        self.assertEqual(devices.owner_view(self.n)['jobs'], [])
        machine, _, _ = self.pair()
        self.poll()
        job = devices.enqueue(self.n, machine, projected['id'], self.revision(), expected_snapshot=snapshot)
        self.assertEqual(job['status'], 'queued')
        self.assertNotIn('source_need', self.poll()['work'], 'The Linux receives only reviewed code fields')

    def test_code_projection_without_valid_source_link_cannot_be_enqueued(self):
        machine, _, _ = self.pair()
        self.poll()
        s = self.n.load_state()
        orphan = self.n.make_buffer('user:code:dialogue:orphan', 'code_projection',
                                    'Une aide manque.', authority='human')
        orphan.update(desired='Afficher une aide.', acceptance='Aide visible.',
                      execution_enabled=False)
        s['buffers'][orphan['id']] = orphan
        self.n.atomic_json(self.n.STATE, s, backup=True)
        with self.assertRaises(ValueError):
            devices.enqueue(self.n, machine, orphan['id'], self.revision())
        self.assertEqual(devices.owner_view(self.n)['jobs'], [])

    def test_old_user_kind_with_projection_link_is_not_accepted_by_current_broker(self):
        ident, snapshot, projected = self.project_dialogue_need()
        machine, _, _ = self.pair()
        self.poll()
        s = self.n.load_state()
        s['buffers'][projected['id']]['kind'] = 'user'
        self.n.atomic_json(self.n.STATE, s, backup=True)
        with self.assertRaises(ValueError):
            devices.enqueue(self.n, machine, projected['id'], self.revision(),
                            expected_snapshot=snapshot)
        self.assertEqual(self.n.load_state()['buffers'][ident]['status'], 'open')

    def test_projection_retry_is_idempotent_and_old_projection_is_not_reused(self):
        ident, snapshot, projected = self.project_dialogue_need()
        before = self.n.STATE.read_bytes()
        again = devices.project_need(self.n, ident, 1, snapshot)
        self.assertTrue(again['already_projected'])
        self.assertEqual(again['id'], projected['id'])
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertEqual(again['seen'], 1)
        continuity.need_action(self.n, ident, 'revise', 0, values={'title': 'Autre besoin'})
        changed = self.n.STATE.read_bytes()
        with self.assertRaisesRegex(ValueError, projected['id']):
            devices.project_need(self.n, ident, 1, snapshot)
        self.assertEqual(self.n.STATE.read_bytes(), changed)
        fresh = devices.project_need(self.n, ident, 2, snapshot)
        self.assertNotEqual(fresh['id'], projected['id'])
        self.assertEqual(fresh['source_need']['revision'], 2)
        self.n.close_buffer(projected['id'], 'Le besoin de code a été traité séparément.')
        closed = self.n.STATE.read_bytes()
        with self.assertRaisesRegex(ValueError, projected['id']):
            devices.project_need(self.n, ident, 1, snapshot)
        self.assertEqual(self.n.STATE.read_bytes(), closed, 'A retry must never reopen a resolved projection')
        with self.assertRaises(ValueError):
            devices.project_need(self.n, ident, 2, {'residual': snapshot['residual'],
                                                     'goal': 'But périmé', 'acceptance': snapshot['acceptance']})
        self.assertEqual(self.n.STATE.read_bytes(), closed)

    def test_projection_requires_current_exact_source_and_same_world(self):
        ident, snapshot = self.dialogue_need()
        state = self.n.STATE.read_bytes()
        for revision, displayed in ((0, snapshot), (2, snapshot),
                                    (1, dict(snapshot, goal='Un ancien objectif'))):
            with self.subTest(revision=revision, displayed=displayed), self.assertRaises(ValueError):
                devices.project_need(self.n, ident, revision, displayed)
            self.assertEqual(self.n.STATE.read_bytes(), state)
        child = worlds.create(self.n, 'Travail', revision=0)['id']
        with worlds.using(child), self.assertRaises(ValueError):
            devices.project_need(self.n, ident, 1, snapshot)
        with worlds.using(child):
            child_need, child_snapshot = self.dialogue_need()
            child_projection = devices.project_need(self.n, child_need, 1, child_snapshot)
            self.assertEqual(child_projection['source_need']['world_id'], child)
        main_projection = devices.project_need(self.n, ident, 1, snapshot)
        self.assertNotEqual(main_projection['id'], child_projection['id'])
        self.assertEqual(main_projection['source_need']['world_id'], 'main')

    def test_paused_need_cannot_be_projected_and_pausing_invalidates_queued_job(self):
        ident, snapshot = self.dialogue_need()
        continuity.need_action(self.n, ident, 'pause', 0)
        with self.assertRaises(ValueError):
            devices.project_need(self.n, ident, 2, snapshot)
        continuity.need_action(self.n, ident, 'resume', 1)
        projected = devices.project_need(self.n, ident, 3, snapshot)
        machine, _, _ = self.pair()
        self.poll()
        job = devices.enqueue(self.n, machine, projected['id'], self.revision(),
                              expected_snapshot=snapshot)
        continuity.need_action(self.n, ident, 'pause', 2)
        self.assertIsNone(self.poll()['work'])
        self.assertEqual(devices.job_view(self.n, job['id'])['status'], 'stale')

    def test_source_change_without_revision_cannot_pass_freshness(self):
        ident, snapshot, projected = self.project_dialogue_need()
        machine, _, _ = self.pair()
        self.poll()
        job = devices.enqueue(self.n, machine, projected['id'], self.revision(),
                              expected_snapshot=snapshot)
        state = self.n.load_state()
        state['buffers'][ident]['dialogue_need']['next_step'] = 'Une contrainte changée sans révision.'
        self.n.atomic_json(self.n.STATE, state, backup=True)
        self.assertIsNone(self.poll()['work'])
        self.assertEqual(devices.job_view(self.n, job['id'])['status'], 'stale')

    def test_projection_source_revision_or_resolution_invalidates_device_job(self):
        for stage, action in (('enqueue', 'revise'), ('poll', 'revise'),
                              ('report', 'resolve'), ('verify', 'revise')):
            with self.subTest(stage=stage):
                other = NodeHarness()
                other.setUp()
                prior = self.n
                self.n = other.n
                try:
                    ident, snapshot, projected = self.project_dialogue_need()
                    machine, _, _ = self.pair()
                    self.poll()
                    job = None
                    if stage != 'enqueue':
                        job = devices.enqueue(self.n, machine, projected['id'], self.revision(),
                                              expected_snapshot=snapshot)
                    if stage in ('report', 'verify'):
                        work = self.poll()['work']
                    if stage == 'verify':
                        self.report(work)
                    if action == 'resolve':
                        continuity.need_action(self.n, ident, 'resolve', 0,
                                               evidence='Résultat vérifié dans l’usage.')
                    else:
                        continuity.need_action(self.n, ident, 'revise', 0,
                                               values={'title': 'Une nouvelle formulation'})
                    if stage == 'enqueue':
                        with self.assertRaises(ValueError):
                            devices.enqueue(self.n, machine, projected['id'], self.revision(),
                                            expected_snapshot=snapshot)
                    elif stage == 'poll':
                        self.assertIsNone(self.poll()['work'])
                    elif stage == 'report':
                        with self.assertRaises(ValueError):
                            self.report(work)
                    else:
                        with self.assertRaises(ValueError):
                            devices.owner_job(self.n, job['id'], 'verify', self.revision(),
                                              hashlib.sha256(PATCH.encode()).hexdigest(), True)
                    if job is not None:
                        self.assertEqual(devices.job_view(self.n, job['id'])['status'], 'stale')
                    self.assertEqual(self.n.load_state()['buffers'][ident]['status'],
                                     'resolved' if action == 'resolve' else 'open')
                finally:
                    self.n = prior
                    other.tearDown()

    def test_lost_claim_response_replays_same_lease_without_second_reservation(self):
        _, _, job = self.setup_job()
        request_id = '3' * 32
        first = self.poll(request_id=request_id)['work']
        replay = self.poll(request_id=request_id)['work']
        self.assertEqual(first, replay)
        self.assertEqual(first['id'], job['id'])
        self.assertIsNone(self.poll(request_id='4' * 32)['work'])
        self.assertEqual(devices.owner_view(self.n)['budget']['runs_reserved'], 1)
        self.assertEqual(devices.owner_view(self.n)['budget']['seconds_reserved'], 600)
        self.report(first)
        self.assertIsNone(self.poll(request_id=request_id)['work'])

    def test_real_process_lock_allows_only_one_distinct_claim(self):
        self.setup_job()
        script = ("import json,sys;sys.path.insert(0,sys.argv[1]);import tao_node as n;"
                  "import tao_devices as d;print(json.dumps(d.worker(n,'poll',json.loads(sys.argv[2]),sys.argv[3])))")
        def claim(index):
            presence = {'machine_id': MACHINE, 'repo_head': HEAD, 'clean': True, 'git': True,
                        'codex': True, 'python': True, 'allow_tests': False, 'platform': 'linux',
                        'request_id': ('%032x' % (index + 1))}
            process = subprocess.run([sys.executable, '-c', script, str(BOOT), json.dumps(presence), TOKEN],
                                     env=self.env, capture_output=True, text=True, timeout=20)
            self.assertEqual(process.returncode, 0, process.stderr)
            return json.loads(process.stdout)
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            results = list(pool.map(claim, range(4)))
        self.assertEqual(sum(row['work'] is not None for row in results), 1)
        self.assertEqual(devices.owner_view(self.n)['budget']['runs_reserved'], 1)

    def test_generation_report_duplicate_is_idempotent_and_changed_report_refused(self):
        self.setup_job()
        work = self.poll()['work']
        response, payload = self.report(work)
        before = (self.n.ROOT / 'devices/registry.json').read_bytes()
        again = devices.worker(self.n, 'report', payload, TOKEN)
        self.assertEqual(response['status'], 'review')
        self.assertTrue(again['duplicate'])
        self.assertEqual((self.n.ROOT / 'devices/registry.json').read_bytes(), before)
        altered = copy.deepcopy(payload)
        altered['result']['summary'] = 'Changed receipt'
        with self.assertRaises(ValueError):
            devices.worker(self.n, 'report', altered, TOKEN)
        view = devices.job_view(self.n, work['id'])
        self.assertEqual(view['patch'], PATCH)
        self.assertFalse(view['automatic_apply'])
        self.assertFalse(view['automatic_deploy'])
        self.assertNotIn('lease_id', view)

    def test_verify_requires_exact_review_and_local_permission_and_same_candidate(self):
        _, buffer, job = self.setup_job()
        generated = self.poll()['work']
        self.report(generated)
        digest = hashlib.sha256(PATCH.encode()).hexdigest()
        for kwargs in ({'review_digest': digest}, {'review_digest': '0' * 64, 'confirmed': True}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                devices.owner_job(self.n, job['id'], 'verify', self.revision(), **kwargs)
        devices.owner_job(self.n, job['id'], 'verify', self.revision(), digest, True)
        self.assertIsNone(self.poll()['work'])
        work = self.poll(allow_tests=True)['work']
        self.assertEqual(work['phase'], 'verify')
        self.assertEqual(work['timeout_seconds'], 300)
        self.assertEqual(work['review_digest'], digest)
        with self.assertRaises(ValueError):
            self.report(work, 'verified', patch_text=PATCH + '\nother')
        self.report(work, 'verified')
        view = devices.job_view(self.n, job['id'])
        self.assertEqual(view['status'], 'verified')
        self.assertEqual(view['report_authority'], 'paired_machine_report_not_local_execution_proof')
        self.assertEqual(self.n.load_state()['buffers'][buffer['id']]['status'], 'open')
        self.assertEqual(devices.owner_view(self.n)['budget']['runs_reserved'], 1)

    def test_cancel_and_revoke_never_accept_late_work_or_restore_permissions(self):
        ident, _, job = self.setup_job()
        work = self.poll()['work']
        devices.owner_job(self.n, job['id'], 'cancel', self.revision())
        with self.assertRaises(ValueError):
            self.report(work)
        self.assertEqual(devices.job_view(self.n, job['id'])['status'], 'cancelled')
        devices.owner_device(self.n, ident, 'revoke', self.revision())
        with self.assertRaises(PermissionError):
            self.poll()
        with self.assertRaises(PermissionError):
            self.report(work)
        with self.assertRaises(ValueError):
            devices.owner_device(self.n, ident, 'approve', self.revision())
        self.assertEqual(devices.owner_view(self.n)['budget']['runs_reserved'], 1)

    def test_interrupted_verification_can_report_without_recovered_patch(self):
        _, _, job = self.setup_job()
        generated = self.poll()['work']
        self.report(generated)
        digest = hashlib.sha256(PATCH.encode()).hexdigest()
        devices.owner_job(self.n, job['id'], 'verify', self.revision(), digest, True)
        work = self.poll(allow_tests=True)['work']
        self.report(work, 'interrupted', patch_text='')
        view = devices.job_view(self.n, job['id'])
        self.assertEqual(view['status'], 'interrupted')
        self.assertEqual(view['patch'], PATCH, 'Original reviewed candidate remains available')
        self.assertFalse(view['verification_result']['ok'])

    def test_revocation_cancels_queued_running_and_review_without_deleting(self):
        ident, _, job = self.setup_job()
        work = self.poll()['work']
        self.report(work)
        devices.owner_device(self.n, ident, 'revoke', self.revision())
        view = devices.job_view(self.n, job['id'])
        self.assertEqual(view['status'], 'cancelled')
        self.assertEqual(view['patch'], PATCH)
        self.assertEqual(len(devices.owner_view(self.n)['jobs']), 1)

    def test_expiry_is_interrupted_no_redispatch_and_budget_retained(self):
        self.setup_job()
        with patch.object(devices.time, 'time', return_value=2000):
            work = self.poll(request_id='2' * 32)['work']
        with patch.object(devices.time, 'time', return_value=2901):
            self.assertIsNone(self.poll(request_id='2' * 32)['work'])
            with self.assertRaises(ValueError):
                self.report(work)
            view = devices.owner_view(self.n)
        self.assertEqual(view['jobs'][0]['status'], 'interrupted')
        self.assertEqual(view['budget']['runs_reserved'], 1)

    def test_buffer_change_before_claim_or_report_or_review_is_stale(self):
        for stage in ('claim', 'report', 'verify'):
            with self.subTest(stage=stage):
                # Separate harness per case avoids retained machine/token state.
                other = NodeHarness()
                other.setUp()
                old = self.n
                self.n = other.n
                try:
                    _, buffer, job = self.setup_job(stage)
                    if stage != 'claim':
                        work = self.poll()['work']
                    if stage == 'verify':
                        self.report(work)
                    state = self.n.load_state()
                    state['buffers'][buffer['id']]['desired'] = 'Nouvelle direction'
                    self.n.atomic_json(self.n.STATE, state, backup=True)
                    if stage == 'claim':
                        self.assertIsNone(self.poll()['work'])
                    elif stage == 'report':
                        with self.assertRaises(ValueError): self.report(work)
                    else:
                        with self.assertRaises(ValueError):
                            devices.owner_job(self.n, job['id'], 'verify', self.revision(),
                                              hashlib.sha256(PATCH.encode()).hexdigest(), True)
                    self.assertEqual(devices.job_view(self.n, job['id'])['status'], 'stale')
                finally:
                    self.n = old
                    other.tearDown()

    def test_dirty_offline_machine_waits_but_changed_head_is_stale(self):
        _, _, job = self.setup_job()
        self.assertEqual(devices.job_view(self.n, job['id'])['status'], 'queued')
        self.assertIsNone(self.poll(clean=False)['work'])
        self.assertIsNone(self.poll(repo_head=None, git=False)['work'])
        self.assertEqual(devices.job_view(self.n, job['id'])['status'], 'queued')
        self.assertIsNone(self.poll(repo_head='b' * 40)['work'])
        self.assertEqual(devices.job_view(self.n, job['id'])['status'], 'stale')

    def test_generation_budget_counts_failures_and_is_separate_and_node_global(self):
        ident, _, first = self.setup_job()
        for index in range(3):
            if index:
                buffer = self.n.add_buffer('Manque %s' % index, 'But', 'Preuve')
                devices.enqueue(self.n, ident, buffer['id'], self.revision())
            work = self.poll()['work']
            self.assertIsNotNone(work)
            self.report(work, 'failed', patch_text='')
        buffer = self.n.add_buffer('Quatrième essai', 'But', 'Preuve')
        last = devices.enqueue(self.n, ident, buffer['id'], self.revision())
        response = self.poll()
        self.assertIsNone(response['work'])
        self.assertIn('Budget', response['waiting_reason'])
        budget = devices.owner_view(self.n)['budget']
        self.assertEqual(budget['runs_reserved'], 3)
        self.assertEqual(budget['seconds_reserved'], 1800)
        self.assertFalse(budget['money_measured'])
        self.assertTrue(budget['separate_from_local_adaptation_budget'])
        self.assertEqual(devices.job_view(self.n, last['id'])['status'], 'queued')

    def test_policy_can_tighten_but_not_expand_distributed_budget(self):
        self.setup_job()
        self.n.atomic_json(self.n.POLICY, {'adaptation_runs_per_day': 0})
        self.assertIsNone(self.poll()['work'])
        self.n.atomic_json(self.n.POLICY, {'adaptation_runs_per_day': 20, 'adaptation_seconds_per_day': 14400})
        budget = devices.owner_view(self.n)['budget']
        self.assertEqual((budget['runs_limit'], budget['seconds_limit']), (3, 1800))

    def test_payload_result_integrity_size_and_status_refuse_without_partial_result(self):
        self.setup_job()
        work = self.poll()['work']
        bad = [dict(ok=False), dict(status='verified'), dict(patch_sha256='0' * 64),
               dict(patch='x' * (devices.MAX_PATCH_BYTES + 1)), dict(elapsed_seconds=float('nan')),
               dict(elapsed_seconds=True), dict(unknown='field')]
        for values in bad:
            with self.subTest(values=str(values)[:70]), self.assertRaises(ValueError):
                self.report(work, **values)
        self.assertEqual(devices.job_view(self.n, work['id'])['status'], 'running')

    def test_registry_bounds_corruption_and_node_binding_preserve_records(self):
        ident, _, payload = self.pair()
        path = self.n.ROOT / 'devices/registry.json'
        original = path.read_text()
        for modified in ('{broken', original.replace('tao.devices.v1', 'unknown')):
            path.write_text(modified)
            with self.assertRaises(ValueError):
                devices.owner_view(self.n)
            self.assertEqual(path.read_text(), modified)
        path.write_text(original)
        data = json.loads(original)
        data['node_id'] = 'another-node'
        path.write_text(json.dumps(data))
        with self.assertRaises(ValueError): devices.owner_view(self.n)
        path.write_text(original)
        with patch.object(devices, 'MAX_DEVICES', 1):
            with self.assertRaises(ValueError): devices.create_pairing(self.n, 'Encore', self.revision())
        self.assertEqual(path.read_text(), original)
        self.assertEqual(devices.owner_view(self.n)['devices'][0]['id'], ident)

    def test_failed_claim_write_never_returns_work_and_retry_can_claim(self):
        self.setup_job()
        with patch.object(self.n, 'atomic_json', side_effect=OSError('Disque indisponible')):
            with self.assertRaises(OSError): self.poll()
        self.assertEqual(devices.owner_view(self.n)['jobs'][0]['status'], 'queued')
        self.assertIsNotNone(self.poll()['work'])

    def test_completed_request_nonce_cannot_claim_next_job(self):
        ident, _, _ = self.setup_job()
        nonce = '5' * 32
        work = self.poll(request_id=nonce)['work']
        self.report(work, 'failed', patch_text='')
        buffer = self.n.add_buffer('Un autre manque', 'But', 'Preuve')
        devices.enqueue(self.n, ident, buffer['id'], self.revision())
        self.assertIsNone(self.poll(request_id=nonce)['work'])
        self.assertIsNotNone(self.poll()['work'])

    def test_enqueue_compares_displayed_snapshot_without_relying_on_registry_revision(self):
        ident, _, _ = self.pair()
        self.poll()
        buffer = self.n.add_buffer('Manque affiché', 'But affiché', 'Preuve affichée')
        snapshot = {'residual': buffer['residual'], 'goal': buffer['desired'], 'acceptance': buffer['acceptance']}
        revision = self.revision()
        state = self.n.load_state()
        state['buffers'][buffer['id']]['desired'] = 'But modifié dans une autre vue'
        self.n.atomic_json(self.n.STATE, state, backup=True)
        self.assertEqual(self.revision(), revision)
        with self.assertRaises(ValueError):
            devices.enqueue(self.n, ident, buffer['id'], revision, expected_snapshot=snapshot)
        self.assertEqual(devices.owner_view(self.n)['jobs'], [])
        snapshot['goal'] = 'But modifié dans une autre vue'
        self.assertEqual(devices.enqueue(self.n, ident, buffer['id'], revision,
                                         expected_snapshot=snapshot)['goal'], snapshot['goal'])
