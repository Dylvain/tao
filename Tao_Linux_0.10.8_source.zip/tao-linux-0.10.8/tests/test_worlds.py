import concurrent.futures
import copy
import hashlib
import json
import os
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from test_node import NodeHarness

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'bootstrap'))
import tao_worlds as worlds


WORK = '111111111111'
FAMILY = '222222222222'


def fixture():
    return {'schema': 'tao.node.state.v4', 'id': 'node:fixture', 'cycles': 4,
            'metabolism': {'dialogue_attempts': 2},
            'dialogue': {'memory': 'MAIN_PRIVATE', 'messages': [], 'revision': 0, 'context_version': 0},
            'continuity': {'completed_needs': {'user:main:resolved': {'kind': 'dialogue'}}},
            'work_context': {'description': 'MAIN_WORK_PRIVATE'},
            'learning': {'reports': ['MAIN_LEARNING_PRIVATE']},
            'story': {'text': 'MAIN_STORY_PRIVATE'},
            'buffers': {'user:main': {'kind': 'user', 'residual': 'MAIN_NEED_PRIVATE'},
                        'user:legacy': {'residual': 'MAIN_LEGACY_PRIVATE'},
                        'ram.low': {'kind': 'resource', 'residual': 'Available memory'}},
            'worlds': {'schema': worlds.SCHEMA, 'revision': 2, 'spaces': {
                'main': {'id': 'main', 'title': 'Principal', 'parent_id': None},
                WORK: {'id': WORK, 'title': 'Travail', 'parent_id': 'main',
                       'description': 'Le travail', 'dialogue': {'memory': 'WORK_PRIVATE', 'messages': [], 'revision': 0, 'context_version': 0},
                       'continuity': {'completed_needs': {'user:work:resolved': {'kind': 'dialogue'}}},
                       'buffers': {'user:work': {'kind': 'work', 'residual': 'WORK_NEED_PRIVATE'}}},
                FAMILY: {'id': FAMILY, 'title': 'Famille', 'parent_id': 'main',
                         'dialogue': {'memory': 'FAMILY_PRIVATE', 'messages': [], 'revision': 0, 'context_version': 0},
                         'learning': {'reports': ['FAMILY_LEARNING_PRIVATE']},
                         'buffers': {'user:family': {'kind': 'dialogue', 'residual': 'FAMILY_NEED_PRIVATE'}}}}}}


class WorldsTests(unittest.TestCase):
    def test_projections_hide_other_private_contexts_but_keep_global_observations(self):
        raw = fixture(); before = copy.deepcopy(raw)
        with worlds.using(WORK):
            view = worlds.project(raw)
        self.assertEqual(view['dialogue']['memory'], 'WORK_PRIVATE')
        self.assertEqual(set(view['buffers']), {'ram.low', 'user:work'})
        self.assertNotIn('story', view); self.assertNotIn('learning', view)
        self.assertNotIn('work_context', view)
        self.assertEqual(view['metabolism'], raw['metabolism'])
        rendered = json.dumps(view)
        for secret in ('MAIN_PRIVATE', 'MAIN_LEGACY_PRIVATE', 'MAIN_LEARNING_PRIVATE', 'FAMILY_PRIVATE', 'FAMILY_LEARNING_PRIVATE'):
            self.assertNotIn(secret, rendered)
        view['dialogue']['memory'] = 'changed'; view['worlds']['spaces'][FAMILY]['title'] = 'changed'
        self.assertEqual(raw, before)
        with worlds.using('main'):
            main = worlds.project(raw)
        self.assertEqual(set(main['buffers']), {'ram.low', 'user:main', 'user:legacy'})
        self.assertNotIn('"WORK_PRIVATE"', json.dumps(main)); self.assertNotIn('"FAMILY_PRIVATE"', json.dumps(main))

    def test_scoped_merge_preserves_every_other_space_and_updates_shared_budget(self):
        raw = fixture(); before = copy.deepcopy(raw)
        with worlds.using(WORK):
            view = worlds.project(raw)
            view['dialogue']['memory'] = 'Work revised'
            view['learning'] = {'reports': ['Work report']}
            view['buffers']['user:new'] = {'kind': 'dialogue', 'residual': 'New work need'}
            view['buffers']['ram.low']['residual'] = 'Updated resource'
            view['metabolism']['dialogue_attempts'] += 1
            view['worlds']['spaces'][FAMILY]['dialogue'] = {'memory': 'forged'}
            result = worlds.merge(raw, view)
        self.assertEqual(raw, before)
        self.assertEqual(result['dialogue'], raw['dialogue'])
        self.assertEqual(result['worlds']['spaces'][FAMILY], raw['worlds']['spaces'][FAMILY])
        self.assertEqual(result['worlds']['spaces'][WORK]['dialogue']['memory'], 'Work revised')
        self.assertEqual(result['worlds']['spaces'][WORK]['learning']['reports'], ['Work report'])
        self.assertIn('user:new', result['worlds']['spaces'][WORK]['buffers'])
        self.assertNotIn('user:new', result['buffers'])
        self.assertEqual(result['buffers']['ram.low']['residual'], 'Updated resource')
        self.assertEqual(result['buffers']['user:main'], raw['buffers']['user:main'])
        self.assertEqual(result['metabolism']['dialogue_attempts'], 3)
        self.assertNotIn('_world_view', result)
        result['worlds']['spaces'][WORK]['dialogue']['memory'] = 'Again'
        self.assertEqual(view['dialogue']['memory'], 'Work revised')

    def test_principal_merge_keeps_legacy_storage_and_cannot_edit_children(self):
        raw = fixture()
        with worlds.using('main'):
            view = worlds.project(raw)
            view['dialogue']['memory'] = 'New principal memory'
            view['buffers'].pop('user:main')
            view['worlds']['spaces'].pop(FAMILY)
            result = worlds.merge(raw, view)
        self.assertEqual(result['dialogue']['memory'], 'New principal memory')
        self.assertNotIn('user:main', result['buffers'])
        self.assertEqual(result['worlds'], raw['worlds'])

    def test_legacy_state_projects_and_round_trips_without_losing_content(self):
        raw = fixture(); raw.pop('worlds')
        with worlds.using('main'):
            view = worlds.project(raw); result = worlds.merge(raw, view)
        result.pop('worlds')
        self.assertEqual(result, raw)
        with worlds.using(WORK), self.assertRaises(ValueError):
            worlds.project(raw)

    def test_wrong_context_and_missing_markers_never_merge(self):
        raw = fixture()
        with worlds.using(WORK):
            view = worlds.project(raw)
        with worlds.using(FAMILY), self.assertRaises(ValueError):
            worlds.merge(raw, view)
        with worlds.using('main'), self.assertRaises(ValueError):
            worlds.merge(raw, raw)
        raw['worlds']['spaces'].pop(WORK)
        with worlds.using(WORK), self.assertRaises(ValueError):
            worlds.merge(raw, view)

    def test_contexts_are_nested_exception_safe_and_thread_local(self):
        with patch.dict(os.environ, {'TAO_WORLD': FAMILY}):
            self.assertEqual(worlds.current(), FAMILY)
            with worlds.using(WORK):
                self.assertEqual(worlds.current(), WORK)
                with self.assertRaises(RuntimeError):
                    with worlds.using('main'):
                        raise RuntimeError('Restore outer context')
                self.assertEqual(worlds.current(), WORK)
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    self.assertEqual(pool.submit(worlds.current).result(), FAMILY)
            self.assertEqual(worlds.current(), FAMILY)
        for invalid in ('../main', '', 'unknown', [], None):
            with self.assertRaises(ValueError):
                with worlds.using(invalid):
                    pass

    def test_hierarchy_validation_rejects_cycles_and_buffer_collision(self):
        raw = fixture(); raw['worlds']['spaces'][WORK]['parent_id'] = FAMILY
        raw['worlds']['spaces'][FAMILY]['parent_id'] = WORK
        with worlds.using('main'), self.assertRaises(ValueError):
            worlds.project(raw)
        raw = fixture(); raw['worlds']['spaces'][WORK]['buffers']['ram.low'] = {'kind': 'dialogue'}
        with worlds.using(WORK), self.assertRaises(ValueError):
            worlds.project(raw)


class WorldsMutationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.root = Path(self.tmp.name)
        self.raw = fixture()
        self.n = SimpleNamespace(ROOT=self.root, STATE=self.root/'state.json', LOCK=threading.RLock(),
            load_raw_state=lambda: copy.deepcopy(self.raw), atomic_json=self.persist,
            now=lambda: '2026-09-28T00:00:00Z',
            json_bytes=lambda value: json.dumps(value, sort_keys=True).encode(),
            digest_bytes=lambda value: hashlib.sha256(value).hexdigest())
    def tearDown(self):
        self.tmp.cleanup()
    def persist(self, path, value, backup=False):
        self.assertEqual(path, self.n.STATE); self.assertTrue(backup)
        self.raw = copy.deepcopy(value)

    def test_create_is_empty_and_metadata_exposes_no_content(self):
        with worlds.using(WORK):
            row = worlds.create(self.n, 'Une tâche', description='Un résultat attendu', revision=2)
            description = worlds.describe(self.n)
        self.assertEqual(row['parent_id'], WORK)
        self.assertEqual(row['revision'], 3)
        child = self.raw['worlds']['spaces'][row['id']]
        for key in worlds.PRIVATE_FIELDS:
            self.assertNotIn(key, child)
        self.assertEqual(child['buffers'], {})
        self.assertNotIn('PRIVATE', json.dumps(description))
        self.assertEqual([r['id'] for r in description['path']], ['main', WORK])
        self.assertEqual(description['parent']['id'], 'main')
        with worlds.using(row['id']):
            view = worlds.project(self.raw)
        self.assertNotIn('dialogue', view)
        self.assertEqual(set(view['buffers']), {'ram.low'})

    def test_create_rejects_stale_revision_depth_and_capacity_without_data_loss(self):
        before = copy.deepcopy(self.raw)
        with worlds.using('main'):
            with self.assertRaises(ValueError): worlds.create(self.n, 'Périmé', revision=0)
            self.assertEqual(self.raw, before)
            parent = 'main'
            for i in range(worlds.MAX_DEPTH):
                row = worlds.create(self.n, 'Niveau '+str(i), parent, revision=self.raw['worlds']['revision'])
                parent = row['id']
            before = copy.deepcopy(self.raw)
            with self.assertRaises(ValueError):
                worlds.create(self.n, 'Trop profond', parent, revision=self.raw['worlds']['revision'])
            self.assertEqual(self.raw, before)
            with patch.object(worlds, 'MAX_SPACES', len(self.raw['worlds']['spaces'])):
                with self.assertRaises(ValueError):
                    worlds.create(self.n, 'Trop nombreux', revision=self.raw['worlds']['revision'])
            self.assertEqual(self.raw, before)

    def source(self, role='assistant'):
        self.raw['dialogue']['messages'] = [
            {'id': 'source-message', 'role': role, 'text': 'Un passage exact et quelques détails privés.', 'at': self.n.now()}]

    def test_selected_transfer_is_attributed_idempotent_and_does_not_call_ai(self):
        import tao_dialogue as dialogue
        self.source()
        with worlds.using('main'), patch.object(dialogue, 'launch') as launch:
            result = worlds.transfer(self.n, WORK, 'Cette piste reste à vérifier.', 'Un passage exact', 'source-message', 2)
            again = worlds.transfer(self.n, WORK, 'Cette piste reste à vérifier.', 'Un passage exact', 'source-message', 2)
            launch.assert_not_called()
        self.assertEqual(result['message_id'], again['message_id']); self.assertTrue(again['already_transferred'])
        self.assertEqual(self.raw['worlds']['revision'], 3)
        target = self.raw['worlds']['spaces'][WORK]['dialogue']
        self.assertEqual(target['memory'], 'WORK_PRIVATE'); self.assertEqual(len(target['messages']), 1)
        message = target['messages'][0]
        self.assertEqual(message['original_role'], 'assistant')
        self.assertEqual(message['origin']['world_id'], 'main')
        self.assertEqual(message['origin']['quote'], 'Un passage exact')
        self.assertIn('contenu non vérifié', message['text'])
        self.assertNotIn('quelques détails privés', message['text'])
        self.assertFalse(message['execution_enabled'])
        self.assertEqual(self.raw['worlds']['spaces'][FAMILY]['dialogue']['memory'], 'FAMILY_PRIVATE')

    def test_transfer_rejects_unrelated_quotes_and_preserves_original_ai_role_on_retransfer(self):
        self.source()
        before = copy.deepcopy(self.raw)
        with worlds.using('main'):
            with self.assertRaises(ValueError):
                worlds.transfer(self.n, WORK, 'Inventé', 'Phrase qui n’est pas dans la source', 'source-message', 2)
            self.assertEqual(self.raw, before)
            first = worlds.transfer(self.n, WORK, 'À étudier', 'Un passage exact', 'source-message', 2)
        with worlds.using(WORK):
            second = worlds.transfer(self.n, FAMILY, 'À étudier ailleurs', 'Un passage exact', first['message_id'], 3)
        message = self.raw['worlds']['spaces'][FAMILY]['dialogue']['messages'][0]
        self.assertEqual(message['id'], second['message_id'])
        self.assertEqual(message['original_role'], 'assistant')
        self.assertEqual(message['source_world_id'], WORK)
        self.assertEqual(message['origin']['world_id'], 'main')
        self.assertEqual(message['origin']['message_id'], 'source-message')

    def test_transfer_back_to_principal_preserves_human_provenance_and_checks_busy_target(self):
        import tao_dialogue as dialogue
        self.raw['worlds']['spaces'][WORK]['dialogue']['messages'] = [
            {'id': 'work-message', 'role': 'user', 'text': 'Je veux comprendre ce résultat précis.', 'at': self.n.now()}]
        before = copy.deepcopy(self.raw)
        with worlds.using(WORK):
            with patch.object(dialogue, 'active', return_value={'status': 'running'}), self.assertRaises(ValueError):
                worlds.transfer(self.n, 'main', 'À relier à mes objectifs', 'comprendre ce résultat', 'work-message', 2)
            self.assertEqual(self.raw, before)
            result = worlds.transfer(self.n, 'main', 'À relier à mes objectifs', 'comprendre ce résultat', 'work-message', 2)
        row = self.raw['dialogue']['messages'][-1]
        self.assertEqual(row['id'], result['message_id'])
        self.assertEqual(row['original_role'], 'user')
        self.assertEqual(row['origin']['role'], 'user')
        self.assertEqual(self.raw['dialogue']['memory'], 'MAIN_PRIVATE')
        self.assertEqual(self.raw['worlds']['spaces'][WORK]['dialogue'], before['worlds']['spaces'][WORK]['dialogue'])

    def test_completed_needs_restoration_stays_inside_its_space(self):
        import tao_continuity as continuity
        # Fully shaped records are unnecessary for ensure's restoration contract.
        with worlds.using(WORK):
            view = worlds.project(self.raw)
            continuity.ensure(view)
            self.assertIn('user:work:resolved', view['buffers'])
            self.assertNotIn('user:main:resolved', view['buffers'])
            self.raw = worlds.merge(self.raw, view)
        self.assertNotIn('user:work:resolved', self.raw['buffers'])
        with worlds.using('main'):
            view = worlds.project(self.raw)
            continuity.ensure(view)
        self.assertIn('user:main:resolved', view['buffers'])
        self.assertNotIn('user:work:resolved', view['buffers'])


class WorldsNodeIntegrationTests(NodeHarness):
    def test_actual_atomic_state_preserves_independent_memories_across_basal_cycle(self):
        import tao_dialogue as dialogue
        with worlds.using('main'):
            dialogue.save_memory(self.n, 'PRINCIPAL_ONLY', 0)
            space = worlds.create(self.n, 'Travail fictif', revision=0)
            principal_buffer = self.n.add_buffer('Même besoin', 'Même but', 'Même vérification')
        with worlds.using(space['id']):
            dialogue.save_memory(self.n, 'WORK_ONLY', 0)
            self.n.work.save_context(self.n, 'WORK_CONTEXT_ONLY')
            child_buffer = self.n.add_buffer('Même besoin', 'Même but', 'Même vérification')
            # The same local residual may have the same key: the spaces remain distinct.
            self.assertEqual(principal_buffer['id'], child_buffer['id'])
            view = self.n.load_state()
            view['buffers'][child_buffer['id']]['residual'] = 'WORK_RESIDUAL_ONLY'
            self.n.atomic_json(self.n.STATE, view, backup=True)
        with worlds.using('main'):
            self.n.cycle()
            main = self.n.load_state()
            self.assertEqual(main['dialogue']['memory'], 'PRINCIPAL_ONLY')
            self.assertEqual(main['buffers'][principal_buffer['id']]['residual'], 'Même besoin')
            self.assertNotIn('WORK_ONLY', json.dumps(main))
            self.assertNotIn('WORK_CONTEXT_ONLY', json.dumps(main))
        with worlds.using(space['id']):
            child = self.n.load_state()
            self.assertEqual(child['dialogue']['memory'], 'WORK_ONLY')
            self.assertEqual(child['buffers'][child_buffer['id']]['residual'], 'WORK_RESIDUAL_ONLY')
            self.assertNotIn('PRINCIPAL_ONLY', json.dumps(child))
            self.assertEqual(child['cycles'], 1)
        persisted = self.n.checked_state(self.n.STATE)
        self.assertNotIn('_world_view', persisted)
        self.assertEqual(persisted['dialogue']['memory'], 'PRINCIPAL_ONLY')
        self.assertEqual(persisted['worlds']['spaces'][space['id']]['dialogue']['memory'], 'WORK_ONLY')

    def test_parallel_space_writes_keep_all_private_buffers(self):
        with worlds.using('main'):
            first = worlds.create(self.n, 'Premier espace', revision=0)['id']
            second = worlds.create(self.n, 'Deuxième espace', revision=1)['id']
        def write(ident):
            with worlds.using(ident):
                for i in range(8):
                    self.n.add_buffer(ident + ' besoin ' + str(i), 'Un résultat', 'Une observation')
                return len(self.n.load_state()['buffers'])
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            counts = list(pool.map(write, [first, second]))
        self.assertEqual(counts, [8, 8])
        raw = self.n.load_raw_state()
        self.assertEqual(raw['buffers'], {})
        for ident in (first, second):
            rows = raw['worlds']['spaces'][ident]['buffers']
            self.assertEqual(len(rows), 8)
            self.assertTrue(all(ident in row['residual'] for row in rows.values()))


if __name__ == '__main__':
    unittest.main()
