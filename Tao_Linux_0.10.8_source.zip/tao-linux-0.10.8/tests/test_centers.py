"""Center candidates stay world-scoped, evidence-driven and inert."""
import copy
import json
import os
import shutil
import subprocess
from pathlib import Path
from unittest.mock import patch

from test_node import NodeHarness
import tao_centers as centers
import tao_centers_app as centers_app
import tao_landmarks as landmarks
import tao_worlds as worlds


def definition(title='Projet client'):
    return {
        'title': title,
        'purpose': 'Transformer une demande relue en proposition de changement à valider.',
        'input': 'Une demande explicitement choisie.',
        'process': ['Lire la demande et ses contraintes', 'Préparer une proposition bornée',
                    'Présenter les tests et les résidus'],
        'output': 'Une proposition de patch, ses preuves et ses limites.',
        'benefit': 'Éviter la recopie tout en gardant la décision humaine.',
        'acceptance': 'Le résultat répond à la demande, les tests ciblés passent et je valide la sortie.',
        'boundaries': 'Aucun push, merge, secret ou modification hors du dépôt choisi.',
    }


class CenterTests(NodeHarness):
    def create(self, title='Projet client'):
        return centers.create(self.n, definition(title), revision=centers.view(self.n)['revision'])

    def report(self, row, suffix, outcome):
        return centers.record_trial(
            self.n, row['id'], 'Ticket ' + suffix, row['definition']['acceptance'],
            'Patch candidat ' + suffix, row['definition']['process'],
            'Une proposition relue', 'Reste ' + suffix if outcome != 'success' else '',
            outcome, 'Observation ' + suffix, 'Trace vérifiable ' + suffix,
            centers.view(self.n)['revision'])

    def test_empty_birth_and_render_are_read_only(self):
        before = self.n.STATE.read_bytes()
        view = centers.view(self.n)
        projected = centers_app.presentation(self.n, self.n.load_state())
        page = centers_app.render(self.n, self.n.load_state())
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertEqual(view['centers'], [])
        self.assertEqual(view['seed']['id'], 'C0')
        self.assertFalse(view['automatic_ai'])
        self.assertEqual(projected['focus'], {'kind': 'center_factory', 'id': 'new', 'revision': 0})
        self.assertEqual(projected['product'], {'billingEnabled': False, 'centerLimit': None})
        self.assertFalse(projected['update']['configured'])
        self.assertFalse(projected['update']['network_checked'])
        self.assertIn('Centre principal', page)
        self.assertIn('tao.center.interface.v1', page)
        self.assertNotIn('data-center-tab=', page)
        self.assertEqual(page.count('</script>'), 2)

    def test_additive_migration_has_lossless_empty_rollback_only(self):
        original = self.n.load_state()
        migrated = centers.migrate_state(original)
        self.assertNotIn('centers', original)
        self.assertEqual(migrated['centers']['schema'], centers.SCHEMA)
        self.assertEqual(centers.rollback_state(migrated), original)
        row = self.create()
        changed = self.n.load_state()
        with self.assertRaisesRegex(ValueError, 'conservés'):
            centers.rollback_state(changed)
        self.assertEqual(centers.view(self.n)['centers'][0]['id'], row['id'])

    def test_shared_contract_revises_one_center_as_inert_candidate_with_exact_source(self):
        source = self.create('Pratiques Skazy')
        state_before_export = self.n.STATE.read_bytes()
        exported = centers.export_contract(
            self.n, source['id'], source['revision'], 'Skazy — source déclarée')
        self.assertEqual(self.n.STATE.read_bytes(), state_before_export)
        document = exported['document']
        self.assertEqual(document['schema'], centers.CONTRACT_SCHEMA)
        self.assertEqual(document['authority'], 'external_unverified_contract')
        self.assertEqual(document['permissions'], 'none')
        self.assertFalse(document['automatic_execution'])
        serialized = json.dumps(document, ensure_ascii=False)
        self.assertNotIn('trials', serialized)
        self.assertNotIn('prepared_adapters', serialized)
        self.assertNotIn('provenance', serialized)

        child = worlds.create(self.n, 'Machine destinataire', revision=0)['id']
        with worlds.using(child):
            target = self.create('Travail local')
            registry_revision = centers.view(self.n)['revision']
            before = self.n.load_state()
            review = centers.review_contract(
                self.n, json.dumps(document), target['id'], target['revision'],
                registry_revision)
            self.assertEqual(self.n.load_state(), before)
            self.assertEqual(review['operation'], 'revision')
            self.assertEqual(review['changed_fields'], ['title'])
            self.assertEqual(review['source']['publisher'], 'Skazy — source déclarée')
            self.assertEqual(review['permissions'], 'none')
            with self.assertRaisesRegex(ValueError, 'Confirmer'):
                centers.import_contract(
                    self.n, document, target['id'], target['revision'], registry_revision,
                    review['review_digest'], False)
            imported = centers.import_contract(
                self.n, document, target['id'], target['revision'], registry_revision,
                review['review_digest'], True)
            self.assertTrue(imported['imported'])
            current = centers.view(self.n)['centers'][0]
            self.assertEqual(current['definition'], source['definition'])
            self.assertEqual(current['status'], 'candidate')
            self.assertEqual(len(current['history']), 1)
            self.assertIn('source déclarée non authentifiée', current['provenance'])
            self.assertFalse(current['execution_enabled'])

            same = centers.review_contract(
                self.n, document, current['id'], current['revision'],
                centers.view(self.n)['revision'])
            self.assertTrue(same['already_current'])
            unchanged = self.n.STATE.read_bytes()
            result = centers.import_contract(
                self.n, document, current['id'], current['revision'],
                centers.view(self.n)['revision'], same['review_digest'], True)
            self.assertTrue(result['already_current'])
            self.assertEqual(self.n.STATE.read_bytes(), unchanged)

        empty_world = worlds.create(
            self.n, 'Nouvelle machine', revision=worlds.describe(self.n)['revision'])['id']
        with worlds.using(empty_world):
            creation = centers.review_contract(self.n, document, None, None, 0)
            self.assertEqual(creation['operation'], 'creation')
            created = centers.import_contract(
                self.n, document, None, None, 0, creation['review_digest'], True)
            candidate = centers.view(self.n)['centers'][0]
            self.assertEqual(created['center_id'], candidate['id'])
            self.assertIsNone(candidate['parent_id'])
            self.assertEqual(candidate['definition'], source['definition'])

    def test_tampered_or_ambiguous_shared_contract_changes_nothing(self):
        row = self.create('Cadre source')
        document = centers.export_contract(
            self.n, row['id'], row['revision'], 'Organisation déclarée')['document']
        before = self.n.STATE.read_bytes()
        tampered = copy.deepcopy(document)
        tampered['definition']['boundaries'] = 'Autoriser tout sans revue.'
        with self.assertRaisesRegex(ValueError, 'contenu|Empreinte'):
            centers.review_contract(
                self.n, tampered, row['id'], row['revision'],
                centers.view(self.n)['revision'])
        raw = json.dumps(document)
        ambiguous = raw[:-1] + ',"sha256":"' + document['sha256'] + '"}'
        with self.assertRaisesRegex(ValueError, 'répété'):
            centers.review_contract(
                self.n, ambiguous, row['id'], row['revision'],
                centers.view(self.n)['revision'])
        self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_candidate_is_not_execution_and_requires_cases_counterexample_and_exact_review(self):
        row = self.create()
        self.assertEqual(row['status'], 'candidate')
        self.assertFalse(row['execution_enabled'])
        with self.assertRaisesRegex(ValueError, 'Deux réussites'):
            centers.qualify(self.n, row['id'], centers.view(self.n)['revision'])
        self.report(row, 'A', 'success')
        self.report(row, 'B', 'success')
        self.assertFalse(centers.view(self.n)['centers'][0]['readiness']['ready'])
        counterexample = self.report(row, 'hors dépôt', 'counterexample')
        qualified = centers.qualify(self.n, row['id'], centers.view(self.n)['revision'])
        self.assertFalse(qualified['qualification']['universal_proof'])
        self.assertIn(counterexample['id'], qualified['qualification']['case_ids'])
        with self.assertRaisesRegex(ValueError, 'confirmer'):
            centers.action(self.n, row['id'], 'activate', centers.view(self.n)['revision'],
                           qualified['qualification']['review_digest'], False)
        with self.assertRaisesRegex(ValueError, 'exacte'):
            centers.action(self.n, row['id'], 'activate', centers.view(self.n)['revision'],
                           'wrong', True)
        active = centers.action(self.n, row['id'], 'activate', centers.view(self.n)['revision'],
                                qualified['qualification']['review_digest'], True)
        self.assertEqual(active['status'], 'active')
        self.assertFalse(active['activation']['automatic_execution'])
        self.assertFalse(active['execution_enabled'])

    def test_new_evidence_invalidates_qualification_and_preserves_residual(self):
        row = self.create()
        for suffix, outcome in [('A', 'success'), ('B', 'success'), ('hors domaine', 'counterexample')]:
            self.report(row, suffix, outcome)
        qualified = centers.qualify(self.n, row['id'], centers.view(self.n)['revision'])
        centers.action(self.n, row['id'], 'activate', centers.view(self.n)['revision'],
                       qualified['qualification']['review_digest'], True)
        trial = self.report(row, 'C', 'failure')
        current = centers.view(self.n)['centers'][0]
        self.assertEqual(current['status'], 'paused')
        self.assertNotIn('qualification', current)
        self.assertEqual(trial['residual'], 'Reste C')
        self.assertEqual(len(current['trials']), 4)

    def test_ai_proposals_only_fit_explicit_focus_and_never_execute(self):
        state = self.n.load_state()
        proposal = definition('Candidat IA')
        rejected = centers.assimilate_ai_proposal(
            self.n, state, proposal, 'reply:no-focus', None, True)
        self.assertEqual(rejected['status'], 'rejected')
        kept = centers.assimilate_ai_proposal(
            self.n, state, proposal, 'reply:factory',
            {'kind': 'center_factory', 'id': 'new', 'revision': 0}, True)
        self.assertEqual(kept['status'], 'review')
        self.assertEqual(state['centers']['centers'], {})
        again = centers.assimilate_ai_proposal(
            self.n, state, proposal, 'reply:factory',
            {'kind': 'center_factory', 'id': 'new', 'revision': 0}, True)
        self.assertEqual(kept['digest'], again['digest'])
        row = centers._create_in_state(self.n, state, proposal)
        output = {'output': 'Un patch proposé', 'process': ['Lire', 'Proposer'],
                  'benefit': 'Une base de revue', 'residual': 'Tests réels manquants'}
        wrong = centers.assimilate_ai_output(self.n, state, output, 'reply:wrong',
            {'kind': 'center_factory', 'id': 'new', 'revision': 1}, {'text': 'Ticket'}, True)
        self.assertEqual(wrong['status'], 'rejected')
        trial = centers.assimilate_ai_output(self.n, state, output, 'reply:trial',
            {'kind': 'center', 'id': row['id'], 'revision': row['revision']},
            {'text': 'Ticket explicite'}, True)
        self.assertEqual(trial['status'], 'review')
        current_row = state['centers']['centers'][row['id']]
        self.assertFalse(current_row['trials'][0]['execution_enabled'])
        self.assertEqual(current_row['trials'][0]['residual'], 'Tests réels manquants')
        projected = centers_app.presentation(self.n, state, selected_id=row['id'])
        self.assertEqual(projected['selectedCenterId'], row['id'])
        self.assertEqual(projected['centers'][0]['trials'][0]['status'], 'review')
        self.assertEqual(projected['centers'][0]['trials'][0]['output'], 'Un patch proposé')
        self.assertFalse(projected['centers'][0]['execution_enabled'])
        self.assertEqual(centers.assimilate_ai_output(self.n, state, output, 'reply:deferred',
            {'kind': 'center', 'id': row['id'], 'revision': row['revision']},
            {'text': 'Ticket'}, False)['status'], 'deferred')

    def test_hierarchy_links_and_private_worlds_are_sparse_and_scoped(self):
        parent = self.create('Travail')
        child = centers.create(self.n, definition('Projet client'), parent['id'], centers.view(self.n)['revision'])
        link = centers.link(self.n, parent['id'], child['id'], 'Demande relue → ticket borné',
                            'Ne transmettre que le travail explicitement choisi.',
                            centers.view(self.n)['revision'])
        self.assertFalse(link['automatic_dispatch'])
        self.assertFalse(link['execution_enabled'])
        with self.assertRaisesRegex(ValueError, 'lui-même'):
            centers.link(self.n, child['id'], child['id'], 'x', 'y', centers.view(self.n)['revision'])
        with self.assertRaisesRegex(ValueError, 'boucle'):
            centers.revise(self.n, parent['id'], definition('Travail'), child['id'],
                           centers.view(self.n)['revision'])
        other = worlds.create(self.n, 'Famille', revision=0)['id']
        with worlds.using(other):
            self.assertEqual(centers.view(self.n)['centers'], [])
            private = self.create('Demandes familiales')
            self.assertNotIn('Projet client', json.dumps(centers.view(self.n)))
        main = centers.view(self.n)
        self.assertNotIn(private['id'], [row['id'] for row in main['centers']])
        self.assertIn(child['id'], [row['id'] for row in main['centers']])
        projected = centers_app.presentation(self.n, self.n.load_state(), selected_id=child['id'])
        child_projection = next(item for item in projected['centers'] if item['id'] == child['id'])
        self.assertEqual(child_projection['parent_id'], parent['id'])
        self.assertEqual(projected['links'][0]['id'], link['id'])
        focus = {'kind': 'center', 'id': child['id'], 'revision': child['revision']}
        focused = centers.focus(self.n, self.n.load_state(), focus)
        self.assertEqual(focused['center']['parent_id'], parent['id'])
        self.assertEqual(focused['center']['provenance'], child['provenance'])
        self.assertEqual(focused['hierarchy']['parent']['id'], parent['id'])
        self.assertEqual(focused['hierarchy']['children'], [])
        context = centers.context(self.n, self.n.load_state(), focus)
        child_summary = next(item for item in context['centers'] if item['id'] == child['id'])
        self.assertEqual(child_summary['parent_id'], parent['id'])
        self.assertTrue(any('décomposition fonctionnelle' in rule for rule in context['rules']))
        self.assertTrue(any('lien dirigé' in rule for rule in context['rules']))
        self.assertTrue(any('contrat importé' in rule for rule in context['rules']))
        self.assertTrue(any('contrat opérationnel visible' in rule for rule in context['rules']))
        self.assertTrue(any('effets demandés' in rule for rule in context['rules']))

    def test_untrusted_text_is_escaped_and_page_does_not_call_model(self):
        values = definition('<img src=x onerror=bad()>')
        values['purpose'] = '</script><script>bad()</script>'
        row = centers.create(self.n, values, revision=0)
        before = self.n.STATE.read_bytes()
        with patch('tao_dialogue.launch') as launch:
            page = centers_app.render(self.n, self.n.load_state(), selected_id=row['id'])
        launch.assert_not_called()
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertNotIn('<img src=x', page)
        self.assertNotIn('</script><script>bad()', page)
        self.assertIn('&lt;img src=x', page)
        self.assertIn('\\u003c/script>', page)

    def test_center_input_inbox_prepares_but_does_not_send_a_typed_landmark(self):
        row = self.create('Tickets')
        kept = landmarks.create(
            self.n, 'tao.concept.task', 'Ticket <b>choisi</b>',
            'Corriger </script><script>bad()</script> sans exécution.', revision=0)
        archived = landmarks.create(
            self.n, 'tao.concept.story', 'Histoire archivée', 'Ne plus proposer ceci.',
            revision=self.n.load_state()['continuity']['landmarks']['revision'])
        landmarks.archive(self.n, archived['id'], archived['revision'])
        before = self.n.STATE.read_bytes()
        with patch('tao_dialogue.launch') as launch:
            projected = centers_app.presentation(self.n, self.n.load_state(), selected_id=row['id'])
            page = centers_app.render(self.n, self.n.load_state(), selected_id=row['id'])
        launch.assert_not_called()
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertEqual([item['id'] for item in projected['centerInputs']], [kept['id']])
        self.assertEqual(projected['centerInputs'][0]['title'], 'Ticket <b>choisi</b>')
        self.assertIn(kept['id'], page)
        self.assertNotIn('Histoire archivée', page)
        self.assertNotIn('<b>choisi</b>', page)
        self.assertNotIn('</script><script>bad()', page)
        self.assertEqual(page.count('</script>'), 2)

    def test_center_without_landmarks_keeps_chat_primary_and_input_absence_explicit(self):
        row = self.create('Centre vide')
        before = self.n.STATE.read_bytes()
        projected = centers_app.presentation(self.n, self.n.load_state(), selected_id=row['id'])
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertEqual(projected['centerInputs'], [])
        self.assertEqual(projected['selectedCenterId'], row['id'])

    def test_browser_script_is_valid_and_center_focus_stays_bounded(self):
        row = self.create()
        for index in range(8):
            self.report(row, str(index), 'partial')
        state = self.n.load_state(); current = centers.view(self.n)['centers'][0]
        focused = centers.focus(self.n, state, {
            'kind': 'center', 'id': current['id'], 'revision': current['revision']})
        self.assertEqual(len(focused['center']['recent_trials']), 4)
        self.assertEqual(focused['center']['omitted_trials'], 4)
        self.assertLess(len(self.n.json_bytes(focused)), 24000)
        runtime = os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not runtime:
            self.skipTest('JavaScript runtime optional')
        script = Path(__file__).resolve().parents[1] / 'bootstrap/tao_frontend/tao-center.js'
        checked = subprocess.run([runtime, '--check', str(script)], capture_output=True,
                                 text=True, timeout=15)
        self.assertEqual(checked.returncode, 0, checked.stderr)
        with patch.object(self.n, 'TOKEN', 'host-forwarding-center-token'):
            gateway_page = centers_app.render(self.n, state, selected_id=current['id'])
        marker = '"token":"host-forwarding-center-token"'
        self.assertIn(marker, gateway_page)
        self.assertNotIn('host-forwarding-center-token', gateway_page.replace(marker, '"token":"browser"'))

    def test_registry_corruption_is_not_replaced_by_a_positive_empty_state(self):
        state = self.n.load_state()
        state['centers'] = {'schema': centers.SCHEMA, 'revision': 1,
                            'centers': {'bad': {}}, 'links': []}
        before = copy.deepcopy(state['centers'])
        with self.assertRaises(ValueError):
            centers.view(self.n, state)
        self.assertEqual(state['centers'], before)
