import copy
import json
from unittest.mock import patch

from test_node import NodeHarness
from test_ecology import HEALTHY
import tao_adaptation as adapt
import tao_continuity as memory
import tao_dialogue as talk
import tao_worlds as worlds


WORDS = 'Je veux comprendre mon jardin et éviter tout envoi sans mon accord.'


class ContinuityTests(NodeHarness):
    def seed(self, ident='message-1', text=WORDS):
        s = self.n.load_state(); d = talk.ensure(s)
        if not any(m['id'] == ident for m in d['messages']):
            d['messages'].append({'id': ident, 'role': 'user', 'text': text,
                                  'source': 'human', 'at': self.n.now()})
        self.n.atomic_json(self.n.STATE, s, backup=True)
        return s

    def extraction(self, ident='message-1', quote=WORDS):
        return {'notes': [{'kind': 'constraint', 'text': 'Aucun envoi sans accord.',
                           'message_id': ident, 'quote': quote}],
                'needs': [{'title': 'Comprendre mon jardin', 'current': 'Je connais mal mon jardin.',
                           'desired': 'Comprendre les besoins des plantes.',
                           'acceptance': 'Décrire un cas réel avec ses observations.',
                           'next_step': 'Décrire une plante et son emplacement.',
                           'message_id': ident, 'quote': quote}]}

    def retain(self, ident='message-1', text=WORDS, value=None):
        s = self.seed(ident, text)
        result = memory.assimilate(self.n, s, value or self.extraction(ident, text), 'reply:' + ident)
        self.n.atomic_json(self.n.STATE, s, backup=True)
        return result

    def revision(self):
        return memory.ensure(self.n.load_state())['revision']

    def action(self, ident, action, **kwargs):
        return memory.need_action(self.n, ident, action, self.revision(), **kwargs)

    def test_extraction_requires_exact_human_provenance_and_allowlisted_data(self):
        allowed = [{'id': 'message-1', 'role': 'user', 'text': WORDS},
                   {'id': 'assistant-1', 'role': 'assistant', 'text': WORDS}]
        valid = memory.validate_extraction(self.extraction(), allowed)
        self.assertEqual(valid, self.extraction())
        cases = []
        for change in ({'message_id': 'invented'}, {'message_id': 'assistant-1'},
                       {'quote': 'Un récit inventé qui ne figure pas dans le message.'},
                       {'quote': 'Je veux'}, {'quote': ''}, {'kind': 'authority'},
                       {'text': {'command': 'anything'}}, {'command': 'anything'}):
            value = self.extraction(); value['notes'][0].update(change); cases.append(value)
        cases.extend([dict(self.extraction(), command='anything'), {'notes': [], 'needs': {}}])
        value = self.extraction(); value['needs'][0]['execution_enabled'] = True; cases.append(value)
        value = self.extraction(); value['needs'][0]['title'] = 'X' * 161; cases.append(value)
        value = self.extraction(); value['notes'] *= 5; cases.append(value)
        for value in cases:
            with self.subTest(value=value), self.assertRaises(ValueError):
                memory.validate_extraction(value, allowed)
        self.assertEqual(self.n.load_state()['buffers'], {})

    def test_transferred_assistant_text_cannot_become_a_human_source(self):
        transfer = {'id': 'message-1', 'role': 'user', 'text': 'Sélection humaine, contenu non vérifié : ' + WORDS,
                    'source': 'human_selected_transfer', 'original_role': 'assistant',
                    'source_world_id': 'world:first', 'source_message_id': 'original-message',
                    'origin': {'world_id': 'world:first', 'message_id': 'original-message',
                               'quote': WORDS, 'role': 'assistant', 'at': self.n.now()}}
        with self.assertRaises(ValueError): memory.validate_extraction(self.extraction(), [transfer])
        # A retransferred assistant message remains excluded even if its local
        # envelope is role=user and the most recent source was another transfer.
        transfer.update(source_world_id='world:second', source_message_id='intermediate')
        with self.assertRaises(ValueError): memory.validate_extraction(self.extraction(), [transfer])
        for missing in ('original_role', 'origin', 'source_world_id', 'source_message_id'):
            human = copy.deepcopy(transfer); human['original_role'] = 'user'; human['origin']['role'] = 'user'
            human.pop(missing)
            with self.subTest(missing=missing), self.assertRaises(ValueError):
                memory.validate_extraction(self.extraction(), [human])

    def test_transferred_human_quote_keeps_original_provenance_and_excludes_wrapper(self):
        transfer = {'id': 'message-1', 'role': 'user', 'text': 'Sélection humaine, contenu non vérifié : ' + WORDS,
                    'source': 'human_selected_transfer', 'original_role': 'user',
                    'source_world_id': 'world:second', 'source_message_id': 'intermediate-message',
                    'origin': {'world_id': 'world:first', 'message_id': 'first-human-message',
                               'quote': WORDS, 'role': 'user', 'at': self.n.now()}}
        clean = memory.validate_extraction(self.extraction(), [transfer])
        self.assertEqual(clean, self.extraction())
        with self.assertRaises(ValueError):
            memory.validate_extraction(self.extraction(quote='Sélection humaine, contenu non vérifié'), [transfer])
        s = self.n.load_state(); talk.ensure(s)['messages'] = [transfer]
        result = memory.assimilate(self.n, s, clean, 'reply:transfer')
        source = s['continuity']['notes'][0]['source_quote']
        self.assertEqual(source['origin']['message_id'], 'first-human-message')
        self.assertEqual(source['origin']['world_id'], 'world:first')
        self.assertEqual(source['source_world_id'], 'world:second')
        self.assertEqual(source['source_message_id'], 'intermediate-message')
        self.assertEqual(source['quote'], WORDS)
        self.assertTrue(result['note_ids'])

    def test_assimilation_is_sourced_inert_and_does_not_change_authority(self):
        policy = self.n.policy(); result = self.retain(); s = self.n.load_state()
        note = s['continuity']['notes'][0]; b = s['buffers'][result['need_ids'][0]]
        self.assertEqual(note['source'], 'ai_interpretation')
        self.assertEqual(note['verification'], 'unverified')
        self.assertEqual(note['source_quote']['quote'], WORDS)
        self.assertEqual(note['source_quote']['reply_id'], 'reply:message-1')
        self.assertEqual(note['origin_story_id'], self.n.story()['id'])
        self.assertEqual(b['story_id'], self.n.story()['id'])
        self.assertEqual(b['kind'], 'dialogue'); self.assertEqual(b['authority'], 'human')
        self.assertFalse(b['dialogue_need']['execution_enabled'])
        self.assertEqual(b['dialogue_need']['phase'], 'to_clarify')
        self.assertEqual(b['status'], 'open'); self.assertEqual(b['evidence'], [])
        self.assertNotIn('work_task', b); self.assertEqual(self.n.policy(), policy)
        with patch.object(talk, 'send', side_effect=AssertionError('No basal AI')):
            self.n.cycle()
        self.assertEqual(self.n.load_state()['buffers'][b['id']]['status'], 'open')
        self.assertEqual(self.n.load_state()['resource_profile']['external_ai_calls'], 0)

    def test_invalid_source_rejects_whole_extraction_before_partial_mutation(self):
        s = self.seed(); before = copy.deepcopy(s)
        bad = self.extraction(); bad['needs'][0]['quote'] = 'Cette phrase n’existe pas.'
        with self.assertRaises(ValueError): memory.assimilate(self.n, s, bad, 'reply:1')
        self.assertEqual(s['buffers'], before['buffers'])
        self.assertEqual(memory.ensure(s)['notes'], [])
        self.assertEqual(memory.ensure(s)['events'], [])

    def test_duplicates_do_not_overwrite_human_revision_or_reactivate_rejection(self):
        result = self.retain(); note_id = result['note_ids'][0]
        memory.edit_note(self.n, note_id, 'Une limite corrigée par moi.', 'rejected', self.revision())
        before = self.n.load_state(); s = copy.deepcopy(before)
        revised_model = self.extraction(); revised_model['notes'][0]['text'] = 'Une autre interprétation.'
        duplicate = memory.assimilate(self.n, s, revised_model, 'reply:again')
        self.assertEqual(s, before); self.assertEqual(duplicate['note_ids'], [note_id])
        self.assertEqual(s['continuity']['notes'][0]['status'], 'rejected')
        self.assertEqual(s['continuity']['notes'][0]['history'][0]['before']['text'], 'Aucun envoi sans accord.')
        self.assertEqual(memory.context(self.n, s)['notes'], [])
        self.action(result['need_ids'][0], 'withdraw')
        s = self.n.load_state(); memory.assimilate(self.n, s, self.extraction(), 'reply:new')
        self.assertEqual(s['buffers'][result['need_ids'][0]]['status'], 'withdrawn')

    def test_continuity_survives_new_discussion_and_old_projection_purge(self):
        result = self.retain(); ident = result['need_ids'][0]
        self.action(ident, 'resolve', evidence='J’ai observé puis expliqué les besoins sur le cas choisi.')
        talk.new_discussion(self.n, self.n.load_state()['dialogue']['revision'])
        s = self.n.load_state(); self.assertEqual(s['dialogue']['messages'], [])
        self.assertEqual(memory.context(self.n, s)['notes'][0]['source_quote']['quote'], WORDS)
        closed = copy.deepcopy(s['buffers'][ident]); del s['buffers'][ident]
        self.n.atomic_json(self.n.STATE, s, backup=True)
        recovered = self.n.load_state(); memory.ensure(recovered)
        self.assertEqual(recovered['buffers'][ident], closed)
        exported = json.loads(memory.exports(self.n, recovered))
        self.assertEqual(exported['needs'][0]['evidence'], closed['evidence'])
        self.assertIn(WORDS, memory.exports(self.n, recovered))

    def test_human_resolution_requires_evidence_and_is_never_verified_automatically(self):
        ident = self.retain()['need_ids'][0]
        before = self.n.STATE.read_bytes()
        with self.assertRaises(ValueError): self.action(ident, 'resolve')
        self.assertEqual(self.n.STATE.read_bytes(), before)
        b = self.action(ident, 'resolve', evidence='Cas observé : résultat attendu atteint.')
        self.assertEqual(b['status'], 'resolved')
        self.assertEqual(b['dialogue_need']['phase'], 'reported_resolved')
        self.assertEqual(b['evidence'][0]['source'], 'human_report')
        self.assertFalse(b['evidence'][0]['verified_automatically'])
        self.assertFalse(b['dialogue_need']['execution_enabled'])
        self.action(ident, 'reopen'); self.action(ident, 'withdraw')
        b = self.n.load_state()['buffers'][ident]
        self.assertEqual(b['status'], 'withdrawn'); self.assertEqual(len(b['evidence']), 1)
        self.assertEqual(b['dialogue_need']['history'][-1]['action'], 'withdraw')

    def test_human_actions_require_current_revision_and_preserve_field_history(self):
        ident = self.retain()['need_ids'][0]; old_revision = self.revision()
        self.action(ident, 'revise', values={'desired': 'Un résultat corrigé.'})
        before = self.n.STATE.read_bytes()
        with self.assertRaises(ValueError): memory.need_action(self.n, ident, 'pause', old_revision)
        with self.assertRaises(ValueError): self.action(ident, 'revise', values={'execution_enabled': True})
        self.assertEqual(self.n.STATE.read_bytes(), before)
        b = self.n.load_state()['buffers'][ident]
        self.assertEqual(b['desired'], 'Un résultat corrigé.')
        self.assertEqual(b['dialogue_need']['source'], 'human_revision')
        self.assertEqual(b['dialogue_need']['history'][0]['before']['desired'], 'Comprendre les besoins des plantes.')
        self.action(ident, 'pause')
        self.assertEqual(memory.context(self.n, self.n.load_state())['needs'], [])
        self.assertEqual(memory.context(self.n, self.n.load_state())['paused_needs'], 1)
        with self.assertRaises(ValueError): self.action(ident, 'focus')
        self.action(ident, 'resume'); self.action(ident, 'focus')
        self.assertTrue(self.n.load_state()['buffers'][ident]['dialogue_need']['focused'])

    def test_human_focus_is_unique_and_persists_across_model_assimilation(self):
        first = self.retain()['need_ids'][0]
        second = self.retain('message-2', 'Je veux comprendre une autre histoire de jardin.')['need_ids'][0]
        self.action(first, 'focus'); self.action(second, 'focus')
        self.retain('message-3', 'Je veux comprendre les saisons de mon jardin.')
        s = self.n.load_state(); focused = [b['id'] for b in s['buffers'].values() if b['dialogue_need']['focused']]
        self.assertEqual(focused, [second])
        self.assertEqual(memory.context(self.n, s)['needs'][0]['id'], second)
        self.assertEqual(s['buffers'][first]['dialogue_need']['history'][-1]['action'], 'focus_replaced')

    def test_disabling_stops_extraction_and_ai_memory_but_keeps_human_notes_and_needs(self):
        result = self.retain(); self.retain('message-2', 'Je veux apprendre à observer les plantes moi-même.')
        memory.edit_note(self.n, result['note_ids'][0], 'Je souhaite apprendre moi-même.', 'kept', self.revision())
        memory.save_settings(self.n, False, self.revision())
        s = self.n.load_state(); before = copy.deepcopy(s)
        result = memory.assimilate(self.n, s, {'not': 'validated when disabled'}, 'reply:any')
        self.assertEqual(result, {'note_ids': [], 'need_ids': [], 'warnings': []}); self.assertEqual(s, before)
        c = memory.context(self.n, s)
        self.assertFalse(c['enabled']); self.assertEqual(len(c['notes']), 1)
        self.assertEqual(c['notes'][0]['source'], 'human_revision'); self.assertEqual(len(c['needs']), 2)
        self.assertEqual(len(s['continuity']['notes']), 2)
        with self.assertRaises(ValueError): memory.save_settings(self.n, True, self.revision() - 1)

    def test_retention_refuses_without_silent_eviction_and_keeps_partial_success(self):
        self.seed(); s = self.n.load_state()
        with patch.object(memory, 'MAX_NOTES', 0):
            result = memory.assimilate(self.n, s, self.extraction(), 'reply:first')
        self.assertEqual(result['note_ids'], []); self.assertEqual(len(result['need_ids']), 1)
        self.assertIn('réponse brute', result['warnings'][0])
        self.n.atomic_json(self.n.STATE, s, backup=True)
        s = self.seed('message-2', 'Une seconde demande à conserver sans rien effacer.')
        before = copy.deepcopy(s['buffers'])
        with patch.object(memory, 'MAX_NEEDS', 1):
            result = memory.assimilate(self.n, s, self.extraction('message-2', 'Une seconde demande à conserver sans rien effacer.'), 'reply:second')
        self.assertEqual(s['buffers'], before); self.assertEqual(len(result['note_ids']), 1)
        self.assertEqual(result['need_ids'], []); self.assertTrue(result['warnings'])
        self.n.atomic_json(self.n.STATE, s, backup=True)
        before = self.n.STATE.read_bytes()
        with patch.object(memory, 'MAX_HISTORY', 0), self.assertRaises(ValueError):
            self.action(next(iter(s['buffers'])), 'revise', values={'current': 'Autre situation'})
        self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_context_is_bounded_counts_omissions_and_preserves_focused_need(self):
        for i in range(15):
            self.retain('message-' + str(i), 'Histoire du jardin numéro ' + str(i) + ', à clarifier.')
        s = self.n.load_state(); ident = list(s['buffers'])[-1]
        self.action(ident, 'focus'); s = self.n.load_state()
        c = memory.context(self.n, s)
        self.assertLessEqual(len(self.n.json_bytes(c)), memory.MAX_CONTEXT_BYTES)
        self.assertEqual(len(c['notes']) + c['omitted_notes'], 15)
        self.assertEqual(len(c['needs']) + c['omitted_needs'], 15)
        self.assertLessEqual(len(c['notes']), 12); self.assertLessEqual(len(c['needs']), 8)
        self.assertEqual(c['needs'][0]['id'], ident)
        # Worst-case JSON escaping cannot overflow even the one retained need.
        for field, limit in memory.NEED_LIMITS.items():
            s['buffers'][ident]['dialogue_need'][field] = '\u0001' * limit
        s['buffers'][ident]['dialogue_need']['source_quote']['quote'] = '\u0002' * 1000
        c = memory.context(self.n, s)
        self.assertLessEqual(len(self.n.json_bytes(c)), memory.MAX_CONTEXT_BYTES)
        self.assertEqual(c['needs'][0]['id'], ident)
        self.assertTrue(c['needs'][0].get('context_truncated_fields'))
        self.assertEqual(len(s['continuity']['notes']), 15)

    def test_task_attachment_is_explicit_idempotent_and_does_not_resolve_need(self):
        ident = self.retain()['need_ids'][0]; s = self.n.load_state()
        with self.assertRaises(ValueError): memory.attach_task(self.n, s, ident, 'missing')
        s['buffers']['work:fixture'] = dict(self.n.make_buffer('work:fixture', 'work', 'Aide fictive', authority='human'),
                                          work_task={'execution_enabled': False})
        memory.attach_task(self.n, s, ident, 'work:fixture'); before = copy.deepcopy(s)
        memory.attach_task(self.n, s, ident, 'work:fixture'); self.assertEqual(s, before)
        b = s['buffers'][ident]
        self.assertEqual(b['status'], 'open'); self.assertEqual(b['evidence'], [])
        self.assertEqual(b['dialogue_need']['task_ids'], ['work:fixture'])
        self.assertFalse(b['dialogue_need']['execution_enabled'])

    def test_note_history_and_event_limits_refuse_atomically(self):
        result = self.retain(); note_id = result['note_ids'][0]
        before = self.n.STATE.read_bytes()
        with patch.object(memory, 'MAX_HISTORY', 0), self.assertRaises(ValueError):
            memory.edit_note(self.n, note_id, 'Nouvelle formulation.', 'kept', self.revision())
        self.assertEqual(self.n.STATE.read_bytes(), before)
        with patch.object(memory, 'MAX_EVENTS', self.revision()), self.assertRaises(ValueError):
            memory.edit_note(self.n, note_id, 'Nouvelle formulation.', 'kept', self.revision())
        self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_full_journal_cannot_prevent_disabling_and_receipt_stays_bounded(self):
        self.retain()
        prior = self.n.load_state()
        events = copy.deepcopy(prior['continuity']['events'])
        previous_revision = self.revision()
        prior_signature = talk.signature(self.n, prior)
        with patch.object(memory, 'MAX_EVENTS', len(events)):
            saved = memory.save_settings(self.n, False, previous_revision)
            current = self.n.load_state(); retained = current['continuity']
            self.assertEqual(saved, {'enabled': False, 'revision': previous_revision + 1})
            self.assertEqual(retained['schema'], 'tao.continuity.v1')
            self.assertEqual(retained['events'], events)
            self.assertEqual(retained['notes'], prior['continuity']['notes'])
            self.assertEqual(current['buffers'], prior['buffers'])
            receipt = retained['disable_receipt']
            self.assertEqual(receipt['reason'], 'event_capacity')
            self.assertEqual(receipt['previous_revision'], previous_revision)
            self.assertEqual(receipt['revision'], previous_revision + 1)
            self.assertLess(len(self.n.json_bytes(receipt)), 512)
            self.assertNotEqual(talk.signature(self.n, current), prior_signature)
            self.assertEqual(memory.context(self.n, current)['notes'], [])
            before_assimilation = copy.deepcopy(current)
            captured = memory.assimilate(self.n, current, {'no': 'extraction while disabled'}, 'reply:none')
            self.assertEqual(captured, {'note_ids': [], 'need_ids': [], 'warnings': []})
            self.assertEqual(current, before_assimilation)
            before_repeat = self.n.STATE.read_bytes()
            with patch.object(self.n, 'atomic_json', wraps=self.n.atomic_json) as atomic:
                for _ in range(4):
                    memory.save_settings(self.n, False, saved['revision'])
                self.assertEqual(atomic.call_count, 0)
            self.assertEqual(self.n.STATE.read_bytes(), before_repeat)
            with self.assertRaisesRegex(ValueError, 'Journal'):
                memory.save_settings(self.n, True, saved['revision'])
            self.assertEqual(self.n.STATE.read_bytes(), before_repeat)
        # If an owner-supported future retention policy makes capacity available,
        # activation once again follows the ordinary event path, keeping receipt.
        memory.save_settings(self.n, True, saved['revision'])
        resumed = self.n.load_state()['continuity']
        self.assertTrue(resumed['enabled'])
        self.assertEqual(resumed['events'][:-1], events)
        self.assertEqual(resumed['events'][-1]['action'], 'continuity_enabled')
        self.assertEqual(resumed['disable_receipt'], receipt)
        self.assertEqual(resumed['events'][-1]['previous_disable_receipt'], receipt)
        previous_events = copy.deepcopy(resumed['events'])
        with patch.object(memory, 'MAX_EVENTS', len(previous_events)):
            memory.save_settings(self.n, False, resumed['revision'])
        stopped_again = self.n.load_state()['continuity']
        self.assertEqual(stopped_again['events'], previous_events)
        self.assertEqual(stopped_again['events'][-1]['previous_disable_receipt'], receipt)
        self.assertGreater(stopped_again['disable_receipt']['revision'], receipt['revision'])
        self.assertLess(len(self.n.json_bytes(stopped_again['disable_receipt'])), 512)

    def test_full_journal_disable_is_private_and_round_trips_as_optional_v1_field(self):
        ident = next(key for key, row in self.n.load_raw_state()['worlds']['spaces'].items()
                     if row.get('template_key') == 'work')
        with worlds.using(ident):
            self.retain()
            with patch.object(memory, 'MAX_EVENTS', len(self.n.load_state()['continuity']['events'])):
                memory.save_settings(self.n, False, self.revision())
            raw = self.n.load_raw_state(); view = worlds.project(raw)
            original = copy.deepcopy(view['continuity'])
            self.assertEqual(json.loads(memory.exports(self.n, view))['continuity'], original)
            view['cycles'] += 1
            merged = worlds.merge(raw, view)
            self.assertEqual(merged['worlds']['spaces'][ident]['continuity'], original)
            self.assertFalse(merged['worlds']['spaces'][ident]['continuity']['enabled'])
        self.assertNotIn('disable_receipt', self.n.load_state().get('continuity', {}))

    def dialogue_answer(self, during_response=None, invented_quote=False):
        revision = self.n.load_state().get('dialogue', {}).get('revision', 0)
        with patch.object(adapt, 'executable', return_value='/fixture/codex'), patch.object(talk, 'launch'):
            job = talk.send(self.n, WORDS, revision, 'continuity-fixture-001')
        def response(node, exe, job_row, cwd, prompt, timeout, cancelled):
            payload = self.n.load_json(cwd / 'context.json')
            source = next(m for m in reversed(payload['messages']) if m['role'] == 'user')
            value = self.extraction(source['id'], 'Cette citation a été inventée.' if invented_quote else source['text'])
            raw = {'reply': 'Clarifions ensemble cette histoire.', 'memory_suggestion': '',
                   'situation_map': None, 'proposal': None, 'continuity': value}
            (cwd / 'response.json').write_text(json.dumps(raw), encoding='utf-8')
            if during_response:
                during_response()
            return {'ok': True}
        with patch.object(adapt, 'executable', return_value='/fixture/codex'), \
                patch.object(talk, 'run_provider', side_effect=response), \
                patch.object(self.n, 'observe_environment', return_value=HEALTHY):
            return talk.worker(self.n, job['id'])

    def test_dialogue_worker_retains_exact_sources_then_binds_reply_to_new_revision(self):
        job = self.dialogue_answer(); s = self.n.load_state()
        self.assertEqual(job['status'], 'answered')
        reply = talk.reply(self.n, s, job['reply_id'])
        self.assertEqual(len(reply['captured']['note_ids']), 1)
        self.assertEqual(len(reply['captured']['need_ids']), 1)
        self.assertEqual(reply['signature'], talk.signature(self.n, s))
        need = s['buffers'][reply['captured']['need_ids'][0]]
        self.assertEqual(need['dialogue_need']['source_quote']['quote'], WORDS)
        self.assertEqual(need['status'], 'open')
        self.assertFalse(need['dialogue_need']['execution_enabled'])
        self.assertEqual(need['evidence'], [])

    def test_late_dialogue_reply_cannot_override_a_concurrent_human_memory_correction(self):
        note_id = self.retain()['note_ids'][0]
        def correction():
            memory.edit_note(self.n, note_id, 'Correction pendant la réponse.', 'kept', self.revision())
        job = self.dialogue_answer(during_response=correction)
        self.assertEqual(job['status'], 'answered')
        s = self.n.load_state(); reply = s['dialogue']['messages'][-1]
        self.assertEqual(reply['captured']['note_ids'], [])
        self.assertEqual(reply['captured']['need_ids'], [])
        self.assertTrue(any('contexte a changé' in warning for warning in reply['captured']['warnings']))
        self.assertEqual(len(s['continuity']['notes']), 1)
        self.assertEqual(s['continuity']['notes'][0]['text'], 'Correction pendant la réponse.')
        with self.assertRaises(ValueError):
            talk.reply(self.n, s, job['reply_id'])

    def test_malformed_extraction_preserves_reply_without_fabricated_memory(self):
        job = self.dialogue_answer(invented_quote=True)
        self.assertEqual(job['status'], 'answered')
        s = self.n.load_state(); reply = s['dialogue']['messages'][-1]
        self.assertEqual(reply['text'], 'Clarifions ensemble cette histoire.')
        self.assertEqual(s['continuity']['notes'], [])
        self.assertEqual(s['buffers'], {})
        self.assertTrue(reply['captured']['warnings'])
        raw_path = talk.file(self.n, job['id']).parent / 'response.json'
        self.assertIn('inventée', json.loads(raw_path.read_text(encoding='utf-8'))['continuity']['notes'][0]['quote'])
