import copy
from unittest.mock import patch

from test_node import NodeHarness
import tao_adaptation as adapt
import tao_continuity as memory
import tao_dialogue as talk
import tao_worlds as worlds


class DialogueFocusTests(NodeHarness):
    def seed(self, count=1):
        s=self.n.load_state(); d=talk.ensure(s)
        for number in range(count):
            ident='human-'+str(number); quote='Je souhaite comprendre ce jardin fictif numéro '+str(number)+'.'
            d['messages'].append({'id':ident,'role':'user','source':'human','at':self.n.now(),'text':quote})
            extraction={'notes':[{'kind':'context','text':'Interprétation IA du jardin '+str(number),
                                   'message_id':ident,'quote':quote}],
                        'needs':[{'title':'Jardin '+str(number),'current':'Situation à comprendre.',
                                   'desired':'Comprendre le jardin.','acceptance':'Décrire une observation.',
                                   'next_step':'Observer une plante.','message_id':ident,'quote':quote}]}
            memory.assimilate(self.n,s,extraction,'reply:fixture-'+str(number))
        self.n.atomic_json(self.n.STATE,s,backup=True)
        return s

    def queue(self, focus=None, text='Pourquoi cet élément a-t-il été interprété ainsi ?', nonce='focus-fixture-001'):
        revision=self.n.load_state().get('dialogue',{}).get('revision',0)
        with patch.object(adapt,'executable',return_value='/fixture/codex'), patch.object(talk,'launch'):
            return talk.send(self.n,text,revision,nonce,focus)

    def payload(self, job):
        return self.n.load_json(talk.file(self.n,job['id']).parent/'context.json')

    def finish_without_model(self, job):
        row=talk.load(self.n,job['id']); row.update(status='blocked',message='Fixture terminée.'); talk.save(self.n,row)

    def test_explicit_note_selection_retrieves_an_item_outside_default_context(self):
        s=self.seed(15); usual={row['id'] for row in memory.context(self.n,s)['notes']}
        chosen=next(row for row in s['continuity']['notes'] if row['id'] not in usual)
        focus={'kind':'note','id':chosen['id'],'revision':chosen['revision']}
        before_policy=self.n.policy(); job=self.queue(focus); payload=self.payload(job)
        self.assertEqual(payload['selected_focus']['ref'],focus)
        self.assertEqual(payload['selected_focus']['context']['text'],chosen['text'])
        self.assertEqual(payload['selected_focus']['context']['source_quote'],chosen['source_quote'])
        self.assertEqual(payload['selected_focus']['authority'],'context_only')
        self.assertFalse(payload['selected_focus']['execution_enabled'])
        self.assertEqual(self.n.load_state()['dialogue']['messages'][-1]['focus'],focus)
        self.assertFalse(any(chosen['text']==m['text'] for m in payload['messages']))
        with self.assertRaises(ValueError):
            memory.validate_extraction({'notes':[{'kind':'context','text':'Une proposition nouvelle.',
                'message_id':chosen['id'],'quote':chosen['text']}],'needs':[]},payload['messages'])
        self.assertEqual(self.n.policy(),before_policy)
        self.assertEqual(self.n.load_state()['continuity']['notes'],s['continuity']['notes'])

    def test_stale_unknown_or_forged_focus_rejects_before_writing_or_launching(self):
        s=self.seed(); note=s['continuity']['notes'][0]
        need=next(b for b in s['buffers'].values() if b.get('dialogue_need'))
        valid={'kind':'note','id':note['id'],'revision':note['revision']}
        invalid=[dict(valid,revision=0),dict(valid,revision=True),dict(valid,id='missing'),
                 dict(valid,kind='command'),dict(valid,text='Client-supplied replacement'),
                 {'kind':'need','id':need['id'],'revision':need['dialogue_need']['revision']-1},
                 {'kind':'space','id':'main','revision':99}, {'kind':'note','id':note['id']}]
        before=self.n.STATE.read_bytes()
        for focus in invalid:
            with self.subTest(focus=focus),patch.object(talk,'launch') as launch,self.assertRaises(ValueError):
                talk.send(self.n,'Une question légitime',0,'focus-invalid-001',focus)
            launch.assert_not_called()
            self.assertEqual(self.n.STATE.read_bytes(),before)
        self.assertFalse((self.n.ROOT/'dialogue').exists())

    def test_child_cannot_select_principal_note_need_or_another_space(self):
        s=self.seed(); note=s['continuity']['notes'][0]
        need=next(b for b in s['buffers'].values() if b.get('dialogue_need'))
        child=worlds.create(self.n,'Un contexte distinct',revision=0)['id']
        with worlds.using(child):
            before=self.n.STATE.read_bytes()
            for focus in ({'kind':'note','id':note['id'],'revision':note['revision']},
                          {'kind':'need','id':need['id'],'revision':need['dialogue_need']['revision']},
                          {'kind':'space','id':'main','revision':1}):
                with self.subTest(focus=focus),self.assertRaises(ValueError):
                    self.queue(focus)
                self.assertEqual(self.n.STATE.read_bytes(),before)
            job=self.queue({'kind':'space','id':child,'revision':1})
            payload=self.payload(job)
            self.assertEqual(payload['selected_focus']['context']['id'],child)
            self.assertEqual(payload['selected_focus']['context']['node_version'],self.n.NODE_VERSION)
            self.assertNotIn(note['text'],str(payload['selected_focus']))

    def test_need_selection_is_bounded_and_never_becomes_a_resolution(self):
        s=self.seed(); b=next(b for b in s['buffers'].values() if b.get('dialogue_need'))
        need=b['dialogue_need']
        for field,limit in memory.NEED_LIMITS.items():need[field]='\u0001'*limit
        need['source_quote']['quote']='\u0002'*1000
        self.n.atomic_json(self.n.STATE,s,backup=True)
        original=copy.deepcopy(need)
        focus={'kind':'need','id':b['id'],'revision':need['revision']}
        job=self.queue(focus); payload=self.payload(job); selected=payload['selected_focus']
        self.assertLessEqual(len(self.n.json_bytes(selected)),talk.MAX_FOCUS_CONTEXT)
        self.assertTrue(selected.get('context_truncated_fields'))
        self.assertEqual(selected['context']['status'],'open')
        self.assertEqual(selected['context']['phase'],'to_clarify')
        self.assertFalse(selected['execution_enabled'])
        current=self.n.load_state()['buffers'][b['id']]
        self.assertEqual(current['dialogue_need'],original)
        self.assertEqual(current['evidence'],[])

    def test_clearing_focus_and_archiving_do_not_reuse_the_old_selection(self):
        s=self.seed(); note=s['continuity']['notes'][0]
        job=self.queue({'kind':'note','id':note['id'],'revision':note['revision']})
        self.assertIsNotNone(self.payload(job)['selected_focus']); self.finish_without_model(job)
        second=self.queue(None,nonce='focus-fixture-002')
        self.assertIsNone(self.payload(second)['selected_focus']); self.finish_without_model(second)
        d=self.n.load_state()['dialogue']; talk.new_discussion(self.n,d['revision'])
        self.assertIsNone(talk.snapshot(self.n,self.n.load_state())['selected_focus'])

    def test_nonce_cannot_rebind_a_sent_message_to_a_different_focus(self):
        s=self.seed(); note=s['continuity']['notes'][0]
        focus={'kind':'note','id':note['id'],'revision':note['revision']}
        first=self.queue(focus)
        same=self.queue(focus)
        self.assertEqual(first['id'],same['id'])
        before=self.n.STATE.read_bytes()
        with self.assertRaises(ValueError):self.queue(None)
        self.assertEqual(before,self.n.STATE.read_bytes())

    def test_retry_uses_frozen_job_but_new_stale_focus_is_rejected(self):
        s=self.seed(); note=s['continuity']['notes'][0]
        focus={'kind':'note','id':note['id'],'revision':note['revision']}
        first=self.queue(focus)
        memory.edit_note(self.n,note['id'],'Une interprétation corrigée.','kept',
                         self.n.load_state()['continuity']['revision'])
        before=self.n.STATE.read_bytes(); original_payload=self.payload(first)
        same=self.queue(focus)
        self.assertEqual(same['id'],first['id']);self.assertEqual(before,self.n.STATE.read_bytes())
        self.assertEqual(self.payload(same),original_payload)
        self.finish_without_model(first)
        with self.assertRaises(ValueError):self.queue(focus,nonce='focus-fixture-002')
        snapshot=talk.snapshot(self.n,self.n.load_state())
        self.assertIsNone(snapshot['selected_focus'])
        self.assertTrue(snapshot['selected_focus_unavailable'])

    def test_selected_view_is_context_only_and_does_not_change_authority(self):
        before=self.n.policy(); worlds.save_presentation(self.n,'problems',revision=0)
        job=self.queue({'kind':'space','id':'main','revision':0})
        payload=self.payload(job)
        self.assertEqual(payload['presentation']['view'],'problems')
        self.assertEqual(payload['presentation']['authority'],'display_preference_only')
        self.assertEqual(payload['selected_focus']['context']['source'],'local_metadata')
        self.assertEqual(self.n.policy(),before)
