"""History import is an explicit, exact review; outside data stays inert."""
import json
import os
import shutil
import subprocess
from unittest.mock import patch

from test_node import NodeHarness
from test_mobile_ui import Page
import tao_onboarding_ui as ui
import tao_worlds as worlds


DOM = r'''
const assert=require('assert');
class Element{
 constructor(tag){this.tagName=tag;this.children=[];this.value='';this.textContent='';this.files=[];this.checked=false;this.disabled=false;this.hidden=false;this.classList={toggle(){}}}
 append(...items){this.children.push(...items)} appendChild(item){this.children.push(item);return item}
 replaceChildren(...items){this.children=[...items];this.textContent=''}
 setAttribute(){}
 querySelectorAll(selector){if(selector==='select')return all(this).filter(node=>node.tagName==='select');throw Error('Unexpected selector '+selector)}
 set innerHTML(value){throw Error('Unsafe insertion '+value)}
}
function all(node){return [node,...node.children.flatMap(all)]}
const nodes=new Map(),document={body:new Element('body'),createElement:tag=>new Element(tag),getElementById:id=>{if(!nodes.has(id))nodes.set(id,new Element('div'));return nodes.get(id)}};
const location={origin:'https://tao.example.test'},token='owner-csrf',config={world:'main',login:'/host/login'};
const btoa=value=>Buffer.from(value,'binary').toString('base64');
const prepared={schema:'tao.history_import.v1',id:'history-1',title:'<script>title</script>',spaces:[]};
const plan={title:'<script>title</script>',review_digest:'exact-review',already_imported:false,counts:{new_spaces:1,notes:1,needs:1},spaces:[{key:'work',id:'012345abcdef',title:'<img onerror=bad()>',parent_id:'main',existing:false,description:'Travail',story:'Mon histoire <script>story</script>',story_mode:'proposed_story',source_ids:['s1'],notes:[{kind:'question',text:'<script>question</script>',source_ids:['s1']}],needs:[{title:'Besoin',current:'Actuel',desired:'Souhait',acceptance:'Preuve',next_step:'Première étape',source_ids:['s1']}],sources:[{id:'s1',label:'<script>source</script>',kind:'user',text:'javascript:evil()'}]}]};
const archivePlan={...plan,assignments:[{conversation_id:'c1',space_key:'work',title:'Titre de conversation',message_count:2}],categories:[{key:'work',title:'Travail'},{key:'learning',title:'Apprentissage'}],warnings:['Une pièce jointe reste hors de cet import.']};
const environment={observed_at:'2026-09-28',host:{system:'Linux',python:'3.12'},tools:[{name:'Codex',present:true,authenticated:null}],resources:{disk_free:123},limitations:['Observation seulement']};
const calls=[];let handler=null;
const fetch=async(path,options)=>{const data=options.body?JSON.parse(options.body):undefined;const call={path,options,data};calls.push(call);if(handler){const result=await handler(call);if(result)return result}let result=environment;
 if(path.startsWith('/api/onboarding/preview'))result=plan;
 if(path.startsWith('/api/history/preview'))result=archivePlan;
 if(path.includes('/apply'))result={spaces:plan.spaces,already_imported:false};
 return {ok:true,status:200,json:async()=>result};
};
function file(data,name='history.json'){return {name,size:Buffer.byteLength(JSON.stringify(data)),text:async()=>JSON.stringify(data)}}
function zipFile(data,name='export.zip'){const bytes=Buffer.from(data);return {name,type:'application/zip',size:bytes.length,arrayBuffer:async()=>bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength)}}
function selectFileValue(value){nodes.get('history-file').files=[value];return nodes.get('history-file').onchange()}
function selectFileValues(values){nodes.get('history-file').files=values;return nodes.get('history-file').onchange()}
function submit(){return nodes.get('import-form').onsubmit({preventDefault(){}})}
function rendered(node){return all(node).map(item=>item.textContent).join('\n')}
const turn=()=>new Promise(setImmediate);
'''


class OnboardingUITests(NodeHarness):
    def run_js(self, source, syntax=False):
        node = os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node:
            self.skipTest('Node optional: browser controller check')
        path = self.base / 'history-ui.js'
        path.write_text(source)
        result = subprocess.run([node, *(['--check'] if syntax else []), str(path)],
                                capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_bootstrap_is_safe_mobile_ready_and_children_link_to_main(self):
        with patch.object(self.n, 'TOKEN', '</script><img src=x>'), \
                patch.dict(os.environ, {'TAO_HOSTED': '1'}):
            rendered = ui.render(self.n, self.n.load_state())
        parsed = Page(rendered)
        self.assertEqual(len(parsed.ids), len(set(parsed.ids)))
        self.assertEqual(rendered.count('</script>'), 1)
        self.assertNotIn('<img src=x>', rendered)
        self.assertIn(r'\u003c/script>', rendered)
        self.assertIn('width=device-width,initial-scale=1', rendered)
        self.assertIn('href="/?world=main">Voir ma maison</a>', rendered)
        self.assertIn('accept=".zip,application/zip,application/x-zip-compressed,.json,application/json"', rendered)
        self.assertIn('type="file" multiple', rendered)
        self.assertIn('Récupérer mon export', rendered)
        self.assertIn('https://chatgpt.com/settings/data-controls', rendered)
        self.assertIn('https://claude.ai/settings/data-privacy-controls', rendered)
        self.assertIn('https://takeout.google.com/', rendered)
        self.assertIn('ne reconnaît pas encore son format', rendered)
        self.assertIn('En attendant mon export', rendered)
        self.assertIn('href="/?world=main">Parler dans le centre principal</a>', rendered)
        self.assertIn('href="/explore?world=main#spaces-title"', rendered)
        self.assertIn('Parler dans le centre principal', rendered)
        config = json.loads(rendered.split('const config=', 1)[1].split(';\n', 1)[0])
        self.assertEqual(config, {'world': 'main', 'login': '/host/login'})
        consent = next(attrs for form in parsed.forms for tag, attrs in form['fields']
                       if attrs.get('id') == 'confirm-import')
        self.assertIn('required', consent)
        self.assertNotIn('checked', consent)
        self.run_js(rendered.split('<script>')[1].split('</script>')[0], syntax=True)
        child = worlds.create(self.n, 'Travail', revision=0)
        with worlds.using(child['id']):
            child_page = ui.render(self.n, self.n.load_state())
        self.assertIn('/onboarding?world=main', child_page)
        self.assertIn('/?world=' + child['id'], child_page)
        self.assertNotIn('<script>', child_page)
        self.assertNotIn('history-file', child_page)

    def test_loading_reads_host_only_then_review_preserves_inert_exact_text(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();assert.equal(calls.length,1);assert.equal(calls[0].path,'/api/onboarding/environment?world=main');assert.equal(calls[0].options.method,undefined);
 const observed=rendered(nodes.get('environment-data'));assert(observed.includes('Linux'));assert(observed.includes('Non vérifié'));
 await selectFileValue(file(prepared));assert.equal(calls.length,2);assert.deepEqual(calls[1].data,{document:prepared});assert.equal(calls[1].options.headers['X-Tao-Token'],'owner-csrf');
 for(const text of ['<img onerror=bad()>','Mon histoire <script>story</script>','<script>question</script>','Actuel','Souhait','Preuve','Première étape','javascript:evil()'])assert(rendered(nodes.get('space-preview')).includes(text));
 assert(!all(nodes.get('space-preview')).some(node=>node.href==='javascript:evil()'));
 assert.equal(nodes.get('apply-import').disabled,true);assert.equal(nodes.get('confirm-import').checked,false);assert(!calls.some(call=>call.path.includes('/apply')));
 await submit();assert.equal(calls.length,2);
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_explicit_apply_uses_exact_review_and_ignores_second_click(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();await selectFileValue(file(prepared));let release;
 handler=call=>call.path.includes('/apply')?new Promise(resolve=>{release=()=>resolve({ok:true,status:200,json:async()=>({spaces:plan.spaces,already_imported:false})})}):null;
 nodes.get('confirm-import').checked=true;nodes.get('confirm-import').onchange();const first=submit();const second=submit();
 assert.equal(calls.filter(call=>call.path.includes('/apply')).length,1);assert.equal(nodes.get('history-file').disabled,true);
 const sent=calls.find(call=>call.path.includes('/apply'));assert.deepEqual(sent.data,{document:prepared,review_digest:'exact-review',confirmed:true});assert.equal(sent.path,'/api/onboarding/apply?world=main');
 release();await first;await second;assert.equal(nodes.get('done').hidden,false);assert.equal(nodes.get('apply-import').disabled,true);assert.equal(nodes.get('history-file').disabled,false);
 assert(all(nodes.get('space-links')).some(node=>node.href==='/explore?world=012345abcdef'));assert.equal(nodes.get('confirm-import').checked,false);
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_archive_classification_change_requires_new_preview(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();const archive=[{title:'Discussion',mapping:{}}];await selectFileValue(file(archive,'conversations.json'));
 assert.equal(calls[1].path,'/api/history/preview?world=main');assert.deepEqual(calls[1].data,{archive});
 assert(rendered(nodes.get('import-warnings')).includes('pièces jointes ne sont pas transférées'));
 const select=all(nodes.get('conversation-assignments')).find(node=>node.tagName==='select');assert.equal(select.value,'work');
 nodes.get('confirm-import').checked=true;select.value='learning';select.onchange();assert.equal(nodes.get('review').hidden,true);assert.equal(nodes.get('apply-import').disabled,true);await submit();assert(!calls.some(call=>call.path.includes('/apply')));
 handler=call=>call.path.includes('/history/preview')?{ok:true,status:200,json:async()=>({...archivePlan,review_digest:'new-review',assignments:[{...archivePlan.assignments[0],space_key:'learning'}]})}:null;
 await nodes.get('reclassify').onclick();const previews=calls.filter(call=>call.path.includes('/preview'));assert.deepEqual(previews[1].data,{archive,assignments:[{conversation_id:'c1',space_key:'learning'}]});
 assert.equal(nodes.get('confirm-import').checked,false);nodes.get('confirm-import').checked=true;await submit();
 const apply=calls.find(call=>call.path.includes('/apply'));assert.equal(apply.path,'/api/history/apply?world=main');assert.deepEqual(apply.data,{archive,assignments:[{conversation_id:'c1',space_key:'learning'}],review_digest:'new-review',confirmed:true});
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_old_preview_response_cannot_replace_new_selection(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();let finishOld;handler=call=>call.path.includes('/preview')&&call.data.document.id==='old'?new Promise(resolve=>{finishOld=()=>resolve({ok:true,status:200,json:async()=>({...plan,title:'Ancien',review_digest:'old'})})}):null;
 const old=selectFileValue(file({...prepared,id:'old'}));await turn();await selectFileValue(file({...prepared,id:'new'}));finishOld();await old;
 assert.equal(nodes.get('review-title').textContent,plan.title);nodes.get('confirm-import').checked=true;await submit();const apply=calls.find(call=>call.path.includes('/apply'));assert.equal(apply.data.document.id,'new');assert.equal(apply.data.review_digest,'exact-review');
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_failed_apply_clears_approval_and_requires_fresh_preview(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();await selectFileValue(file(prepared));handler=call=>call.path.includes('/apply')?{ok:false,status:409,json:async()=>({error:'Contexte modifié : prépare un nouvel aperçu.'})}:null;
 nodes.get('confirm-import').checked=true;await submit();assert.equal(nodes.get('review').hidden,true);assert.equal(nodes.get('confirm-import').checked,false);assert.equal(nodes.get('apply-import').disabled,true);assert.equal(nodes.get('preview-again').disabled,false);assert(rendered(nodes.get('message')).includes('Contexte modifié'));
 await submit();assert.equal(calls.filter(call=>call.path.includes('/apply')).length,1);
 handler=call=>call.path.includes('/preview')?{ok:true,status:200,json:async()=>({...plan,already_imported:true})}:null;
 await nodes.get('preview-again').onclick();assert.equal(nodes.get('apply-import').disabled,true);assert.equal(nodes.get('done').hidden,false);assert.equal(calls.filter(call=>call.path.includes('/apply')).length,1);
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_zip_reaches_review_while_invalid_and_oversized_files_do_not(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();const encoded=Buffer.from('PK minimal fixture').toString('base64');await selectFileValue(zipFile('PK minimal fixture'));
 assert.equal(calls[1].path,'/api/history/preview?world=main');assert.deepEqual(calls[1].data,{archive_zip:encoded});assert(rendered(nodes.get('file-status')).includes('ZIP prêt à relire'));
 nodes.get('confirm-import').checked=true;await submit();const applied=calls[2];assert.equal(applied.path,'/api/history/apply?world=main');assert.deepEqual(applied.data,{archive_zip:encoded,assignments:[{conversation_id:'c1',space_key:'work'}],review_digest:'exact-review',confirmed:true});
 const count=calls.length;
 await selectFileValue({name:'too-large.json',size:16777217,text:async()=>{throw Error('Must not read oversized file')}});assert(rendered(nodes.get('message')).includes('16 Mio'));
 await selectFileValue({name:'broken.json',size:10,text:async()=>'{oops'});assert(rendered(nodes.get('message')).includes('JSON lisible'));
 await selectFileValue({...file(prepared),size:262145});assert(rendered(nodes.get('message')).includes('256 Kio'));
 await selectFileValues(Array.from({length:9},(_,index)=>file(prepared,'export-'+index+'.json')));assert(rendered(nodes.get('message')).includes('maximum 8 exports'));
 assert.equal(calls.length,count);assert.equal(nodes.get('apply-import').disabled,true);
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_multiple_exports_keep_separate_reviews_and_preserve_the_next_file(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();const first=zipFile('PK chatgpt','chatgpt.zip'),second=[{title:'Claude',mapping:{}}];await selectFileValues([first,file(second,'claude.json')]);
 assert.equal(calls[1].path,'/api/history/preview?world=main');assert(calls[1].data.archive_zip);assert(rendered(nodes.get('file-status')).includes('export 1/2'));
 assert.equal(nodes.get('next-file').hidden,false);assert(nodes.get('next-file').textContent.includes('sans importer celui-ci'));assert.equal(calls.filter(call=>call.path.includes('/preview')).length,1);
 nodes.get('confirm-import').checked=true;await submit();assert.equal(calls.filter(call=>call.path.includes('/apply')).length,1);assert(nodes.get('next-file').textContent.startsWith('Relire'));
 await nodes.get('next-file').onclick();assert.equal(calls.filter(call=>call.path.includes('/preview')).length,2);const latest=calls.at(-1);assert.equal(latest.path,'/api/history/preview?world=main');assert.deepEqual(latest.data,{archive:second});
 assert(rendered(nodes.get('file-status')).includes('export 2/2'));assert.equal(nodes.get('next-file').hidden,true);assert.equal(nodes.get('confirm-import').checked,false);assert.equal(calls.filter(call=>call.path.includes('/apply')).length,1);
 const before=calls.length;await selectFileValues([{name:'broken.json',size:4,text:async()=>'{bad'},file(prepared)]);assert(rendered(nodes.get('message')).includes('JSON lisible'));assert.equal(nodes.get('next-file').hidden,false);await nodes.get('next-file').onclick();assert.equal(calls.length,before+1);assert.equal(calls.at(-1).path,'/api/onboarding/preview?world=main');
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_expired_session_only_links_to_fixed_login(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();handler=call=>call.path.includes('/preview')?{ok:false,status:401,json:async()=>({login_url:'https://attacker.invalid'})}:null;
 await selectFileValue(file(prepared));assert(all(nodes.get('message')).some(node=>node.href==='/host/login'));assert(!all(nodes.get('message')).some(node=>node.href==='https://attacker.invalid'));assert.equal(nodes.get('apply-import').disabled,true);
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_archive_page_is_available_in_child_and_has_no_write_token(self):
        child = worlds.create(self.n, 'Travail', revision=0)
        with worlds.using(child['id']):
            page = ui.render_archives(self.n, self.n.load_state())
        parsed = Page(page)
        self.assertEqual(len(parsed.ids), len(set(parsed.ids)))
        config = json.loads(page.split('const config=', 1)[1].split(';\n', 1)[0])
        self.assertEqual(config['world'], child['id'])
        self.assertIn('/onboarding?world=main', page)
        self.assertNotIn('const token=', page)
        self.run_js(page.split('<script>')[1].split('</script>')[0], syntax=True)

    def test_archive_search_download_and_results_stay_in_current_world(self):
        prefix = DOM.replace("config={world:'main'", "config={world:'work'")
        self.run_js(prefix + r'''
handler=call=>({ok:true,status:200,json:async()=>call.path.includes('/search')?{excerpts:[{title:'<img src=x>',source_role:'assistant',text:'<script>not a command</script>',conversation_id:'c1',message_id:'m1',truncated:true}]}:{archives:[{id:'a'.repeat(64),conversations:2,messages:8,source:{label:'<script>claimed source</script>'}}]}});
''' + ui.ARCHIVES_JS + r'''
(async()=>{
 await turn();assert.equal(calls.length,1);assert.equal(calls[0].path,'/api/history/archives?world=work');assert.equal(calls[0].options.method,undefined);
 assert(rendered(nodes.get('archive-list')).includes('<script>claimed source</script>'));const link=all(nodes.get('archive-list')).find(node=>node.tagName==='a');assert.equal(link.href,'/api/history/archive?id='+'a'.repeat(64)+'&world=work');
 document.getElementById('archive-query').value='Mon objectif';await nodes.get('archive-search').onsubmit({preventDefault(){}});
 assert.equal(calls[1].path,'/api/history/search?q=Mon+objectif&world=work');const result=rendered(nodes.get('search-results'));assert(result.includes('<script>not a command</script>'));assert(result.includes('assistant'));assert(result.includes('Extrait abrégé'));
 assert(calls.every(call=>call.options.method===undefined));
})().catch(error=>{console.error(error);process.exitCode=1});
''')
