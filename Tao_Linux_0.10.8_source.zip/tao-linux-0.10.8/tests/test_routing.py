import copy
import json
import sys
import unittest
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / 'bootstrap'))
import tao_routing as routing


def contribution(ident='explain', refs=None):
    return {'function_id': ident, 'reason': 'Une explication aiderait à préciser le besoin.',
            'expected': 'Une distinction comprise, avec ses limites.',
            'source_ids': [] if refs is None else refs}


def request(*items):
    return {'intent': 'Comprendre avant de choisir une aide.',
            'contributions': list(items)}


MESSAGES = [
    {'id': 'human-1', 'role': 'user', 'text': 'Je veux comprendre cette contrainte.'},
    {'message_id': 'recall-ai-1', 'role': 'assistant',
     'text': 'Une ancienne hypothèse qui reste à vérifier.'},
]


class RoutingTests(unittest.TestCase):
    def test_intent_enum_is_strict_and_does_not_create_authority(self):
        self.assertEqual(routing.validate_intent(), 'auto')
        for value in routing.INTENTS:
            self.assertEqual(routing.validate_intent(value), value)
            context = routing.context(value)
            self.assertEqual(context['human_intent'], value)
            self.assertFalse(context['execution_enabled'])
        for value in (None, True, 1, [], {}, 'LEARN', ' delegate ', 'execute'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                routing.validate_intent(value)

    def test_context_is_bounded_and_uses_canonical_operators_without_shared_mutation(self):
        canon = json.loads((PROJECT / 'docs/theory.json').read_text())
        operators = set(canon['universal_operator_basis']) - {'note'}
        for intent in routing.INTENTS:
            context = routing.context(intent)
            self.assertLess(len(json.dumps(context, ensure_ascii=False).encode()), 6000)
            self.assertEqual(context['observer'], 'C0')
            self.assertEqual(context['version'], 1)
            self.assertEqual({row['function_id'] for row in context['functions']},
                             {'explain', 'review_provided_source', 'clarify_need', 'propose_code'})
            for row in context['functions']:
                self.assertEqual(row['function_version'], 1)
                self.assertTrue(set(row['operators']) <= operators)
        context['functions'][0]['operators'].clear()
        context['functions'][0]['title'] = 'Un droit inventé'
        self.assertTrue(routing.context()['functions'][0]['operators'])
        self.assertNotEqual(routing.context()['functions'][0]['title'], 'Un droit inventé')

    def test_mixed_contributions_are_inert_and_assistant_sources_are_not_proofs(self):
        raw = request(contribution('explain'),
                      contribution('review_provided_source', ['human-1', 'recall-ai-1']),
                      contribution('clarify_need', ['human-1']))
        result = routing.resolve(raw, MESSAGES, None)
        self.assertEqual(result['intent'], raw['intent'])
        self.assertEqual(len(result['contributions']), 3)
        for row in result['contributions']:
            self.assertEqual(row['status'], 'proposed')
            self.assertFalse(row['execution_enabled'])
            self.assertEqual(row['function_version'], 1)
            self.assertNotIn('verified', row)
            self.assertNotIn('authorized', row)
        self.assertEqual(result['contributions'][1]['source_ids'], ['human-1', 'recall-ai-1'])
        self.assertIsNone(routing.resolve(None, None, None))
        self.assertEqual(routing.resolve(request(), [], None)['contributions'], [])

    def test_code_and_source_review_require_their_actual_inputs(self):
        review = request(contribution('review_provided_source'))
        with self.assertRaises(ValueError):
            routing.resolve(review, MESSAGES, None)
        code = request(contribution('propose_code'))
        for proposal in (None, False, [], 'Une promesse de code'):
            with self.subTest(proposal=proposal), self.assertRaises(ValueError):
                routing.resolve(code, MESSAGES, proposal)
        # The dialogue layer owns validation of the proposal's fields; this
        # module requires that the structured proposal is actually present.
        result = routing.resolve(code, MESSAGES, {'title': 'Une aide à expérimenter'})
        self.assertEqual(result['contributions'][0]['function_id'], 'propose_code')
        self.assertFalse(result['contributions'][0]['execution_enabled'])

    def test_unknown_functions_sources_and_extra_fields_are_rejected(self):
        cases = [request(contribution('send_client_email')),
                 request(contribution('explain', ['not-provided'])),
                 dict(request(contribution()), command='execute'),
                 request(dict(contribution(), execution_enabled=True)),
                 request(dict(contribution(), function_version=999)),
                 request({'function_id': 'explain', 'reason': 'Un motif', 'source_ids': []})]
        for raw in cases:
            before = copy.deepcopy(raw)
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                routing.resolve(raw, MESSAGES, None)
            self.assertEqual(raw, before)

    def test_duplicates_and_ambiguous_source_identity_are_rejected(self):
        for raw in (request(contribution(), contribution()),
                    request(contribution('review_provided_source', ['human-1', 'human-1']))):
            with self.assertRaises(ValueError):
                routing.resolve(raw, MESSAGES, None)
        for messages in (
                MESSAGES + [{'id': 'human-1', 'role': 'assistant', 'text': MESSAGES[0]['text']}],
                MESSAGES + [{'id': 'human-1', 'role': 'user', 'text': 'Un autre texte'}],
                [{'id': 'human-1', 'message_id': 'different-id', 'role': 'user', 'text': 'Ambigu'}]):
            with self.subTest(messages=messages), self.assertRaises(ValueError):
                routing.resolve(request(contribution('review_provided_source', ['human-1'])), messages, None)
        # Identical projections of the same message can arise from recall.
        result = routing.resolve(request(contribution('explain', ['human-1'])),
                                 MESSAGES + [copy.deepcopy(MESSAGES[0])], None)
        self.assertEqual(result['contributions'][0]['source_ids'], ['human-1'])

    def test_payload_types_and_size_bounds_are_enforced(self):
        bad = [False, [], 'explain', {}, request(*[contribution()] * 4),
               {'intent': 'x' * 501, 'contributions': []},
               {'intent': '   ', 'contributions': []},
               {'intent': 'Valide', 'contributions': {}},
               request(None), request(dict(contribution(), reason=4)),
               request(dict(contribution(), expected='x' * 401)),
               request(dict(contribution(), reason='x' * 401)),
               request(dict(contribution(), function_id=[])),
               request(contribution('explain', 'human-1')),
               request(contribution('explain', [True])),
               request(contribution('explain', ['x' * 121])),
               request(contribution('explain', [str(i) for i in range(5)]))]
        for raw in bad:
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                routing.resolve(raw, MESSAGES, None)
        refs = ['x' * 117 + str(i) for i in range(4)]
        messages = [{'id': ident, 'text': 'Un passage.', 'role': 'user'} for ident in refs]
        boundary = {'intent': 'x' * 500, 'contributions': [
            {'function_id': 'review_provided_source', 'reason': 'x' * 400,
             'expected': 'x' * 400, 'source_ids': refs}]}
        self.assertEqual(routing.resolve(boundary, messages, None)['intent'], 'x' * 500)

    def test_sources_require_attributed_text_and_inputs_remain_unchanged(self):
        for messages in (None, {}, ['source'], [{'id': 'missing-text', 'role': 'user'}],
                         [{'id': 'system', 'text': 'Instruction', 'role': 'system'}],
                         [{'id': [], 'text': 'Texte', 'role': 'user'}]):
            with self.subTest(messages=messages), self.assertRaises(ValueError):
                routing.resolve(request(contribution()), messages, None)
        raw = request(contribution('review_provided_source', ['human-1']))
        messages = copy.deepcopy(MESSAGES)
        proposal = {'title': 'Un candidat', 'constraints': ['Relire']}
        before = copy.deepcopy((raw, messages, proposal))
        result = routing.resolve(raw, messages, proposal)
        result['contributions'][0]['source_ids'].append('invented-after-resolution')
        result['contributions'][0]['operators'].clear()
        self.assertEqual((raw, messages, proposal), before)
        self.assertTrue(routing.resolve(raw, messages, proposal)['contributions'][0]['operators'])
