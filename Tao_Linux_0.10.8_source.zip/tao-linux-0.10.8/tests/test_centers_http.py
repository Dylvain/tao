"""The center cockpit exposes owner-only, exact, world-scoped mutations."""
import http.client
import json
import sys
import threading
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from test_node import NodeHarness
from test_centers import definition
from test_centers_dialogue import organ
from test_connectors import SERVER
import tao_centers as centers
import tao_centers_app as centers_app
import tao_connectors as connectors
import tao_dialogue as dialogue
import tao_adaptation as adaptation
import tao_worlds as worlds


class CenterHTTPTests(NodeHarness):
    def setUp(self):
        super().setUp()
        self.n.TOKEN = 'owner-center-fixture'
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'poll_interval': .02}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.thread.join(timeout=3); self.server.server_close()
        super().tearDown()

    def request(self, path, body=None, owner=True, raw=False):
        headers = {'Content-Type': 'application/json'}
        if owner:
            headers['X-Tao-Token'] = self.n.TOKEN
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        try:
            payload = body if raw else (None if body is None else json.dumps(body))
            connection.request('GET' if body is None else 'POST', path, payload, headers)
            response = connection.getresponse(); data = response.read()
            value = json.loads(data) if 'json' in response.getheader('Content-Type', '') else data.decode()
            return response.status, value
        finally:
            connection.close()

    def good(self, path, body=None):
        status, result = self.request(path, body)
        self.assertEqual(status, 200, result)
        return result

    def binary(self, path):
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        try:
            connection.request('GET', path)
            response = connection.getresponse(); data = response.read()
            self.assertEqual(response.status, 200, data[:200])
            return response.getheader('Content-Type'), data
        finally:
            connection.close()

    def create_body(self, title='Projet client', revision=0):
        return dict(definition(title), parent_id=None, revision=revision)

    def ready_tool(self):
        program = self.base / 'center-tool.py'; program.write_text(SERVER)
        control = self.base / 'center-tool-control'; control.mkdir()
        current = connectors.catalog(self.n)['revision']
        row = connectors.register(self.n, {
            'label': 'Outil existant',
            'argv': [sys.executable, str(program), str(control)],
            'cwd': str(self.base), 'env_names': [], 'revision': current,
            'owner_confirmed': True,
        })
        return connectors.inspect(self.n, row['id'], connectors.catalog(self.n)['revision']), control

    def test_page_and_empty_api_are_read_only_and_never_start_ai(self):
        before = self.n.STATE.read_bytes()
        with patch.object(self.n.dialogue if hasattr(self.n, 'dialogue') else __import__('tao_dialogue'),
                          'launch') as launch:
            page = self.good('/centers?world=main&lang=fr')
            api = self.good('/api/centers?world=main')
        launch.assert_not_called()
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertIn('Centre principal', page)
        self.assertIn('id="tao-root"', page)
        self.assertIn('id="tao-bootstrap" type="application/json"', page)
        self.assertIn('src="/assets/tao-center.js"', page)
        self.assertIn('rel="manifest" href="/app.webmanifest" crossorigin="use-credentials"', page)
        self.assertIn('"billingEnabled":false', page)
        self.assertIn('"centerLimit":null', page)
        self.assertNotIn('class="chat-panel"', page)
        style = self.good('/assets/tao-center.css?world=main')
        script = self.good('/assets/tao-center.js?world=main')
        self.assertIn('.tao-app', style)
        self.assertIn('tao.center.interface.v1', script)
        self.assertIn('center_receipt', script)
        self.assertIn('Utiliser dans', script)
        self.assertIn('Hiérarchie', script)
        self.assertIn('Envoie vers', script)
        self.assertIn('Center hierarchy cycle', script)
        self.assertIn('Contrat du centre', script)
        self.assertIn('Équipement et règles', script)
        self.assertIn('IA de la conversation', script)
        self.assertIn('Aucun droit implicite', script)
        self.assertIn('Demandé · non accordé', script)
        self.assertIn('Option avancée · sans agents, outils ni droits', script)
        self.assertIn('/api/centers/contract/preview', script)
        self.assertIn('Source déclarée · non authentifiée', script)
        manifest = self.good('/app.webmanifest?world=main')
        self.assertEqual(manifest['id'], '/')
        self.assertEqual(manifest['display'], 'standalone')
        self.assertEqual([icon['sizes'] for icon in manifest['icons']], ['192x192', '512x512'])
        for size in ('192', '512'):
            content_type, icon = self.binary('/assets/tao-icon-' + size + '.png?world=main')
            self.assertEqual(content_type, 'image/png')
            self.assertTrue(icon.startswith(b'\x89PNG\r\n\x1a\n'))
        self.assertEqual(api['centers'], [])
        self.assertFalse(api['automatic_ai'])

    def test_root_is_the_main_center_and_legacy_views_remain_secondary(self):
        before = self.n.STATE.read_bytes()
        with patch('subprocess.Popen', side_effect=AssertionError('No process on arrival')):
            root = self.good('/?world=main&lang=fr')
            library = self.good('/explore?world=main&lang=fr')
            arrival = self.good('/explore?world=main&lang=fr&arrival=1')
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertIn('Centre principal', root)
        self.assertIn('tao.center.interface.v1', root)
        self.assertIn('src="/assets/tao-center.js"', root)
        self.assertNotIn('data-tao-sidebar', root)
        self.assertNotIn('id="steward-form"', root)
        self.assertIn('id="house-map"', library)
        self.assertNotIn('id="steward-form"', library)
        self.assertIn('id="house-map"', arrival)
        self.assertNotIn('id="steward-form"', arrival)
        classic = self.good('/classic?world=main&lang=fr')
        self.assertIn('tao.center.interface.v1', classic)
        self.assertIn('src="/assets/tao-center.js"', classic)
        self.assertNotIn('class="chat-panel"', classic)
        self.assertEqual(self.request('/explore?arrival=2')[0], 503)
        self.assertEqual(self.request('/explore?arrival=1&type=task')[0], 503)
        self.assertEqual(self.request('/api/steward/route',
                                      {'question': 'travail', 'locale': 'fr',
                                       'revision': 0})[0], 404)

    def test_exact_owner_create_route_and_duplicate_keys_fail_closed(self):
        body = self.create_body()
        self.assertEqual(self.request('/api/centers/create?world=main', body, owner=False)[0], 403)
        self.assertEqual(self.request('/api/centers/create?world=main', dict(body, surprise=True))[0], 400)
        duplicate = json.dumps(body)[:-1] + ',"revision":0}'
        self.assertEqual(self.request('/api/centers/create?world=main', duplicate, raw=True)[0], 400)
        with patch('subprocess.Popen') as process:
            row = self.good('/api/centers/create?world=main', body)
        process.assert_not_called()
        self.assertEqual(row['status'], 'candidate')
        self.assertFalse(row['execution_enabled'])
        page = self.good('/centers?world=main&lang=fr&center=' + row['id'])
        self.assertIn('Projet client', page)
        self.assertIn('"execution_enabled":false', page)
        self.assertEqual(self.request('/centers?world=main&center=' + row['id'] + '&center=' + row['id'])[0], 503)

    def test_shared_contract_export_preview_and_import_are_exact_owner_actions(self):
        source = self.good('/api/centers/create?world=main', self.create_body('Pratiques partagées'))
        export_body = {'id': source['id'], 'center_revision': source['revision'],
                       'publisher': 'Skazy — source déclarée'}
        self.assertEqual(self.request(
            '/api/centers/contract/export?world=main', export_body, owner=False)[0], 403)
        exported = self.good('/api/centers/contract/export?world=main', export_body)
        document_json = json.dumps(exported['document'], ensure_ascii=False)
        self.assertEqual(exported['authentication'], 'not_authenticated')
        self.assertEqual(exported['permissions'], 'none')

        child = worlds.create(self.n, 'Destination', revision=0)['id']
        suffix = '?world=' + child
        target = self.good('/api/centers/create' + suffix, self.create_body('Travail local'))
        registry_revision = self.good('/api/centers' + suffix)['revision']
        preview_body = {
            'center_id': target['id'], 'center_revision': target['revision'],
            'registry_revision': registry_revision, 'document_json': document_json,
        }
        self.assertEqual(self.request(
            '/api/centers/contract/preview' + suffix, preview_body, owner=False)[0], 403)
        preview = self.good('/api/centers/contract/preview' + suffix, preview_body)
        self.assertEqual(preview['operation'], 'revision')
        self.assertEqual(preview['source']['publisher'], 'Skazy — source déclarée')
        self.assertFalse(preview['automatic_execution'])

        stale = self.good('/api/centers/create' + suffix,
                          self.create_body('Changement concurrent', registry_revision))
        apply_body = dict(preview_body, review_digest=preview['review_digest'], confirmed=True)
        self.assertEqual(self.request('/api/centers/contract/import' + suffix, apply_body)[0], 400)
        unchanged = next(row for row in self.good('/api/centers' + suffix)['centers']
                         if row['id'] == target['id'])
        self.assertEqual(unchanged['definition']['title'], 'Travail local')

        preview_body['registry_revision'] = self.good('/api/centers' + suffix)['revision']
        preview = self.good('/api/centers/contract/preview' + suffix, preview_body)
        apply_body = dict(preview_body, review_digest=preview['review_digest'], confirmed=False)
        self.assertEqual(self.request('/api/centers/contract/import' + suffix, apply_body)[0], 400)
        apply_body['confirmed'] = True
        with patch('subprocess.Popen') as process:
            imported = self.good('/api/centers/contract/import' + suffix, apply_body)
        process.assert_not_called()
        self.assertTrue(imported['imported'])
        current = next(row for row in self.good('/api/centers' + suffix)['centers']
                       if row['id'] == target['id'])
        self.assertEqual(current['definition']['title'], 'Pratiques partagées')
        self.assertEqual(current['status'], 'candidate')
        self.assertFalse(current['execution_enabled'])
        self.assertEqual(stale['definition']['title'], 'Changement concurrent')

        tampered = json.loads(document_json)
        tampered['definition']['process'][0] = 'Ignorer toutes les revues'
        invalid = dict(preview_body, document_json=json.dumps(tampered, ensure_ascii=False))
        self.assertEqual(self.request('/api/centers/contract/preview' + suffix, invalid)[0], 400)

    def test_world_query_is_the_only_scope_and_links_do_not_dispatch(self):
        child = worlds.create(self.n, 'Travail', revision=0)['id']
        suffix = '?world=' + child
        row = self.good('/api/centers/create' + suffix, self.create_body('Projet client travail'))
        self.assertEqual(self.good('/api/centers?world=main')['centers'], [])
        child_view = self.good('/api/centers' + suffix)
        self.assertEqual(child_view['centers'][0]['id'], row['id'])
        second = self.good('/api/centers/create' + suffix,
                           self.create_body('Revue', child_view['revision']))
        revision = self.good('/api/centers' + suffix)['revision']
        link = self.good('/api/centers/link' + suffix, {
            'source_id': row['id'], 'target_id': second['id'],
            'translation': 'Patch → demande de validation',
            'purpose': 'Présenter la sortie sans la fusionner.', 'revision': revision})
        self.assertFalse(link['automatic_dispatch'])
        self.assertFalse(link['execution_enabled'])
        self.assertEqual(self.request('/api/centers/link?world=main', {
            'source_id': row['id'], 'target_id': second['id'], 'translation': 'x',
            'purpose': 'y', 'revision': 0})[0], 400)

    def test_empty_schema_can_rollback_but_retained_center_cannot(self):
        self.good('/api/centers/rollback?world=main', {'revision': 0})
        self.assertNotIn('centers', self.n.load_state())
        self.good('/api/centers/create?world=main', self.create_body())
        revision = self.good('/api/centers?world=main')['revision']
        self.assertEqual(self.request('/api/centers/rollback?world=main', {'revision': revision})[0], 400)
        self.assertEqual(len(self.good('/api/centers?world=main')['centers']), 1)

    def test_owner_can_decide_exact_conversational_revision(self):
        row = self.good('/api/centers/create?world=main', self.create_body('Tickets'))
        state = self.n.load_state()
        revised = definition('Tickets relus')
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        capture = centers.assimilate_ai_revision(
            self.n, state, revised, 'reply:aaaaaaaaaaaa', focus, True)
        thread = dialogue.ensure(state)
        thread['messages'].append({'id': 'reply:aaaaaaaaaaaa', 'role': 'assistant',
                                   'text': 'Révision à relire.',
                                   'center_capture': {'revision': capture}})
        thread['revision'] += 1
        self.n.atomic_json(self.n.STATE, state, backup=True)
        body = {'reply_id': 'reply:aaaaaaaaaaaa', 'kind': 'revision',
                'decision': 'accept', 'dialogue_revision': thread['revision']}
        self.assertEqual(self.request('/api/centers/proposal?world=main', body, owner=False)[0], 403)
        self.assertEqual(self.request('/api/centers/proposal?world=main',
                                     dict(body, surprise=True))[0], 400)
        accepted = self.good('/api/centers/proposal?world=main', body)
        self.assertEqual(accepted['status'], 'accepted')
        current = self.good('/api/centers?world=main')['centers'][0]
        self.assertEqual(current['definition']['title'], 'Tickets relus')
        self.assertFalse(current['execution_enabled'])

    def test_owner_can_prepare_organ_card_but_route_starts_no_implementation(self):
        row = self.good('/api/centers/create?world=main', self.create_body('Tickets'))
        state = self.n.load_state()
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        capture = centers.assimilate_ai_organ(
            self.n, state, organ(), 'reply:bbbbbbbbbbbb', focus, True)
        thread = dialogue.ensure(state)
        thread['messages'].append({'id': 'reply:bbbbbbbbbbbb', 'role': 'assistant',
                                   'text': 'Organe à relire.',
                                   'center_capture': {'organ': capture}})
        thread['revision'] += 1
        self.n.atomic_json(self.n.STATE, state, backup=True)
        body = {'reply_id': 'reply:bbbbbbbbbbbb', 'kind': 'organ',
                'decision': 'accept', 'dialogue_revision': thread['revision']}
        with patch('subprocess.Popen') as process:
            accepted = self.good('/api/centers/proposal?world=main', body)
        process.assert_not_called()
        self.assertEqual(accepted['status'], 'accepted')
        prepared = self.good('/api/centers?world=main')['centers'][0]['prepared_adapters'][0]
        self.assertEqual(prepared['name'], 'Boîte de demandes')
        self.assertEqual(prepared['requested_effects'], ['read', 'network'])
        self.assertFalse(prepared['credentials_configured'])
        self.assertFalse(prepared['connection_tested'])
        self.assertFalse(prepared['automatic_dispatch'])
        self.assertFalse(prepared['automatic_polling'])
        self.assertFalse(prepared['execution_enabled'])

    def test_owner_builds_one_exact_organ_task_through_the_existing_workshop(self):
        row = self.good('/api/centers/create?world=main', self.create_body('Tickets'))
        state = self.n.load_state()
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        capture = centers.assimilate_ai_organ(
            self.n, state, organ(), 'reply:cccccccccccc', focus, True)
        thread = dialogue.ensure(state)
        thread['messages'].append({'id': 'reply:cccccccccccc', 'role': 'assistant',
                                   'text': 'Organe à construire.',
                                   'center_capture': {'organ': capture}})
        thread['revision'] += 1
        self.n.atomic_json(self.n.STATE, state, backup=True)
        accepted = self.good('/api/centers/proposal?world=main', {
            'reply_id': 'reply:cccccccccccc', 'kind': 'organ',
            'decision': 'accept', 'dialogue_revision': thread['revision']})
        body = {'center_id': row['id'], 'center_revision': row['revision'],
                'reply_id': 'reply:cccccccccccc', 'digest': accepted['digest']}
        self.assertEqual(self.request('/api/centers/organ/build?world=main', body,
                                     owner=False)[0], 403)
        self.assertEqual(self.request('/api/centers/organ/build?world=main',
                                     dict(body, surprise=True))[0], 400)

        def start(node, task_id, operation):
            self.assertEqual(operation, 'generate')
            with node.LOCK:
                current = node.load_state()
                current['buffers'][task_id]['work_task']['adaptation_id'] = 'feedfacecafe'
                node.atomic_json(node.STATE, current, backup=True)
            return {'id': 'feedfacecafe'}

        ready = {'ready': True, 'blockers': [], 'source': '/fixture',
                 'codex_detected': True}
        with patch.object(adaptation, 'diagnose', return_value=ready), \
                patch.object(adaptation, 'request', side_effect=start) as request:
            first = self.good('/api/centers/organ/build?world=main', body)
            second = self.good('/api/centers/organ/build?world=main', body)
        request.assert_called_once()
        self.assertTrue(first['prepared'])
        self.assertTrue(second['already_prepared'])
        self.assertEqual(first['task_id'], second['task_id'])
        self.assertEqual(first['adaptation_id'], 'feedfacecafe')
        task = self.n.load_state()['buffers'][first['task_id']]
        self.assertFalse(task['work_task']['execution_enabled'])
        example = task['work_task']['example']
        self.assertEqual(example['organ_blueprint']['name'], organ()['name'])
        self.assertEqual(example['organ_origin']['digest'], accepted['digest'])
        self.assertNotIn('dialogue_context', task['work_task'])
        prepared = self.good('/api/centers?world=main')['centers'][0]['prepared_adapters'][0]
        self.assertEqual(prepared['build']['status'], 'adaptation_started')
        self.assertEqual(prepared['build']['adaptation_id'], 'feedfacecafe')

    def test_changed_center_refuses_old_organ_build_without_creating_a_task(self):
        row = self.good('/api/centers/create?world=main', self.create_body('Tickets'))
        state = self.n.load_state()
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        capture = centers.assimilate_ai_organ(
            self.n, state, organ(), 'reply:dddddddddddd', focus, True)
        thread = dialogue.ensure(state)
        thread['messages'].append({'id': 'reply:dddddddddddd', 'role': 'assistant',
                                   'text': 'Organe à construire.',
                                   'center_capture': {'organ': capture}})
        thread['revision'] += 1
        self.n.atomic_json(self.n.STATE, state, backup=True)
        accepted = self.good('/api/centers/proposal?world=main', {
            'reply_id': 'reply:dddddddddddd', 'kind': 'organ',
            'decision': 'accept', 'dialogue_revision': thread['revision']})
        changed = definition('Tickets révisés')
        revised = centers.revise(self.n, row['id'], changed,
                                 revision=centers.view(self.n)['revision'])
        before = set(self.n.load_state()['buffers'])
        status, result = self.request('/api/centers/organ/build?world=main', {
            'center_id': row['id'], 'center_revision': revised['revision'],
            'reply_id': 'reply:dddddddddddd', 'digest': accepted['digest']})
        self.assertEqual(status, 400, result)
        self.assertIn('reformuler', result['error'])
        self.assertEqual(set(self.n.load_state()['buffers']), before)

    def test_center_tool_call_is_exact_owner_review_and_runs_only_after_click(self):
        row = self.good('/api/centers/create?world=main', self.create_body('Demandes'))
        target = self.good('/api/centers/create?world=main', self.create_body(
            'Décisions', revision=centers.view(self.n)['revision']))
        link = centers.link(
            self.n, row['id'], target['id'],
            'Le reçu externe devient une entrée attribuée à relire.',
            'Permettre une étape suivante sans confondre les autorités.',
            revision=centers.view(self.n)['revision'])
        connector, control = self.ready_tool()
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        context = dialogue.center_tools_context(self.n, focus)
        self.assertEqual(context['status'], 'available')
        self.assertEqual(context['tools'][0]['tool'], 'echo')
        provider_context = json.dumps(context)
        self.assertNotIn(str(self.base), provider_context)
        self.assertNotIn('argv', provider_context)
        self.assertNotIn('env_names', provider_context)
        starts_before = control.joinpath('starts').read_text()
        proposal = {
            'connector_id': connector['id'], 'tool': 'echo',
            'arguments_json': json.dumps({'value': 'Entrée choisie'}),
            'purpose': 'Transmettre cette entrée à l’outil explicitement installé.',
            'expected': 'L’outil renvoie la même valeur comme donnée externe.',
            'risk': 'Le serveur local possède les droits du compte Linux.',
            'rollback': 'Aucun effet attendu pour cet outil de lecture ; conserver le reçu.',
        }
        state = self.n.load_state()
        capture = centers.assimilate_ai_action(
            self.n, state, proposal, 'reply:eeeeeeeeeeee', focus, True, context)
        self.assertEqual(capture['status'], 'review')
        self.assertFalse(capture['automatic_execution'])
        self.assertEqual(control.joinpath('starts').read_text(), starts_before)
        self.assertFalse(control.joinpath('calls').exists())
        thread = dialogue.ensure(state)
        thread['messages'].extend([
            {'id': 'human-action', 'role': 'user', 'text': 'Utilise mon outil.',
             'job_id': 'eeeeeeeeeeee', 'focus': focus},
            {'id': 'reply:eeeeeeeeeeee', 'role': 'assistant', 'text': 'Appel à relire.',
             'job_id': 'eeeeeeeeeeee', 'center_capture': {'action': capture}},
        ])
        thread['revision'] += 1
        self.n.atomic_json(self.n.STATE, state, backup=True)

        projected = centers_app.presentation(self.n, self.n.load_state(), selected_id=row['id'])
        action = projected['messages'][-1]['center_capture']['action']
        self.assertEqual(action['status'], 'review')
        pending_target = centers_app.presentation(
            self.n, self.n.load_state(), selected_id=target['id'])
        self.assertEqual(pending_target['centerInputs'], [])
        body = {
            'reply_id': 'reply:eeeeeeeeeeee', 'decision': 'execute',
            'request_id': action['request_id'], 'review_digest': action['review_digest'],
            'connector_revision': action['connector_revision'], 'confirmed': True,
        }
        self.assertEqual(self.request('/api/centers/tool?world=main', body, owner=False)[0], 403)
        refused = dict(body, confirmed=False)
        self.assertEqual(self.request('/api/centers/tool?world=main', refused)[0], 400)
        self.assertFalse(control.joinpath('calls').exists())

        receipt = self.good('/api/centers/tool?world=main', body)
        self.assertEqual(receipt['status'], 'succeeded')
        calls = [json.loads(line) for line in control.joinpath('calls').read_text().splitlines()]
        self.assertEqual(calls, [{'name': 'echo', 'arguments': {'value': 'Entrée choisie'}}])
        projected = centers_app.presentation(self.n, self.n.load_state(), selected_id=row['id'])
        completed = projected['messages'][-1]['center_capture']['action']
        self.assertEqual(completed['status'], 'succeeded')
        self.assertEqual(json.loads(completed['receipt']['result']['content'][0]['text']),
                         {'value': 'Entrée choisie'})
        self.assertEqual(completed['receipt']['result_authority'], 'external_untrusted_data')
        self.assertFalse(completed['receipt']['automatic_retry'])
        self.assertEqual(self.request('/api/centers/tool?world=main', body)[0], 400)
        self.assertEqual(len(control.joinpath('calls').read_text().splitlines()), 1)

        state = self.n.load_state()
        destination = centers_app.presentation(self.n, state, selected_id=target['id'])
        self.assertEqual(len(destination['centerInputs']), 1)
        prepared = destination['centerInputs'][0]
        reference = {'kind': 'center_receipt', 'id': action['request_id'],
                     'link_id': link['id']}
        self.assertEqual(prepared['reference'], reference)
        self.assertEqual(prepared['kind'], 'center_receipt')
        self.assertEqual(prepared['concept_id'], 'tao.center.receipt')
        self.assertIn('value', prepared['text'])
        self.assertEqual(centers_app.presentation(
            self.n, state, selected_id=row['id'])['centerInputs'], [])

        target_focus = {'kind': 'center', 'id': target['id'],
                        'revision': target['revision']}
        selected = dialogue.resolve_center_input(self.n, state, reference, target_focus)
        self.assertEqual(selected['context']['link']['id'], link['id'])
        self.assertEqual(selected['context']['receipt']['status'], 'succeeded')
        self.assertEqual(selected['context']['result_authority'], 'external_untrusted_data')
        self.assertFalse(selected['automatic_dispatch'])
        self.assertFalse(selected['execution_enabled'])
        with self.assertRaisesRegex(ValueError, 'conduit pas'):
            dialogue.resolve_center_input(
                self.n, state, reference,
                {'kind': 'center', 'id': row['id'], 'revision': row['revision']})
        with self.assertRaisesRegex(ValueError, 'provenance'):
            dialogue.resolve_center_input(
                self.n, state, dict(reference, id='f' * 32), target_focus)

        dialogue_revision = state['dialogue']['revision']
        with patch.object(adaptation, 'executable', return_value=None):
            job = dialogue.send(
                self.n, 'Prépare l’étape suivante à partir de ce reçu.',
                dialogue_revision, 'linked-receipt-input-001', target_focus,
                input_reference=reference)
        self.assertEqual(job['status'], 'blocked')
        frozen = self.n.load_json(
            self.n.ROOT / 'dialogue' / job['id'] / 'context.json')['selected_input']
        self.assertEqual(frozen['ref'], reference)
        self.assertEqual(frozen['context']['receipt']['status'], 'succeeded')
        self.assertEqual(frozen['context']['link']['translation'], link['translation'])
        self.assertEqual(len(control.joinpath('calls').read_text().splitlines()), 1)
        after = self.n.load_state()
        human = next(message for message in reversed(after['dialogue']['messages'])
                     if message.get('job_id') == job['id'])
        output_capture = centers.assimilate_ai_output(self.n, after, {
            'output': 'Décision proposée, non envoyée.',
            'process': ['Relire le reçu externe'],
            'benefit': 'Une étape suivante explicite.',
            'residual': 'La décision humaine reste nécessaire.',
        }, 'reply:abababababab', target_focus, human, True)
        self.assertEqual(output_capture['status'], 'review')
        target_state = after['centers']['centers'][target['id']]
        self.assertIn('Reçu externe choisi comme entrée', target_state['trials'][0]['input'])
        self.assertIn('value', target_state['trials'][0]['input'])

    def test_changed_tool_catalog_rejects_the_frozen_action_without_a_request(self):
        row = self.good('/api/centers/create?world=main', self.create_body('Demandes'))
        connector, control = self.ready_tool()
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        context = dialogue.center_tools_context(self.n, focus)
        proposal = {
            'connector_id': connector['id'], 'tool': 'echo',
            'arguments_json': json.dumps({'value': 'Entrée figée'}),
            'purpose': 'Préparer un appel depuis le catalogue figé.',
            'expected': 'Une donnée externe à relire.',
            'risk': 'Le catalogue peut changer pendant la réponse.',
            'rollback': 'Refuser la proposition et en demander une nouvelle.',
        }
        connectors.request(self.n, connector['id'], 'echo', {'value': 'autre demande'})
        before = connectors.catalog(self.n)
        capture = centers.assimilate_ai_action(
            self.n, self.n.load_state(), proposal, 'reply:ffffffffffff',
            focus, True, context)
        after = connectors.catalog(self.n)
        self.assertEqual(capture['status'], 'rejected')
        self.assertIn('catalogue d’outils a changé', capture['warnings'][0])
        self.assertEqual(len(after['requests']), len(before['requests']))
        self.assertFalse(control.joinpath('calls').exists())
