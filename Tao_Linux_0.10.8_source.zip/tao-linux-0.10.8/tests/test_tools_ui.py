"""Phone UI preserves authority and renders external MCP data as inert text."""
import json
import os
import shutil
import subprocess
from unittest.mock import patch

from test_node import NodeHarness
from test_mobile_ui import Page
import tao_tools_ui as ui
import tao_worlds as worlds


DOM = r'''
const assert=require('assert');
class Element{
 constructor(tag){this.tagName=tag;this.children=[];this.value='';this.textContent='';this.checked=false;this.hidden=false;this.dataset={};this.classList={toggle:()=>{}}}
 append(...items){this.children.push(...items)} appendChild(item){this.children.push(item);return item}
 replaceChildren(...items){this.children=[...items];this.textContent=''}
 setAttribute(){} removeAttribute(){} scrollIntoView(){} focus(){}
 querySelectorAll(selector){if(selector==='input[type=checkbox]')return all(this).filter(node=>node.tagName==='input'&&node.type==='checkbox');throw Error('Unexpected selector '+selector)}
 set innerHTML(value){throw Error('Unsafe HTML insertion: '+value)}
}
function all(node){return [node,...node.children.flatMap(all)]}
const nodes=new Map(),document={body:new Element('body'),createElement:tag=>new Element(tag),getElementById:id=>{if(!nodes.has(id))nodes.set(id,new Element('div'));return nodes.get(id)}};
const location={origin:'https://tao.example.test',hash:''},navigator={};
const token='owner-csrf',config={world:'work',login:'/host/login',node:'n'};
const row={id:'r1',revision:2,status:'qualified',definition:{title:'<img onerror=bad()>',description:'Un audit local',operation:'csv.audit',config:{columns:['id','title'],required:['id'],unique:['id']}},qualification:{ok:true,review_digest:'recipe-exact'},receipts:[],reports:[]};
const proposed={id:'request-1',revision:8,status:'review',connector_id:'c1',connector_label:'Mon connecteur',tool:'inspect',arguments:{name:'<script>argument</script>'},descriptor:{description:'<img onerror=tool()>'},review_digest:'action-exact',origin:'external'};
const state={world:{name:'Travail'},reuse:{recipes:[row],metrics:{completed_no_model_runs:0,human_useful:0}},bridge:{revision:4,grants:[],captures:[{id:'capture-1',status:'review',text:'<script>capture</script>',source:{title:'<img onerror=source()>',application:'Other AI',reference:'javascript:evil()'}}],available_tools:[{name:'tao_context',title:'Lire le contexte',description:'<script>description</script>'},{name:'tao_capture',title:'Proposer une mémoire'},{name:'tao_reuse_propose',title:'Proposer une aide'}]},connectors:{revision:9,connectors:[{id:'c1',label:'<script>server</script>',status:'ready',argv:['/usr/bin/trusted-tool'],cwd:'/home/owner/work',env_names:['TOKEN_NAME'],tools:[{name:'inspect',description:'<script>tool</script>',inputSchema:{type:'object'}}]}],requests:[proposed]}};
const calls=[];
const fetch=async(path,options)=>{const data=options.body?JSON.parse(options.body):undefined;calls.push({path,options,data});let result=state;
 if(path.startsWith('/api/reuse/template?'))result={title:'Audit exemple',operation:'csv.audit',config:{columns:['id','title']},cases:[{label:'Cas à examiner'}]};
 if(path.startsWith('/api/reuse/propose?')){row.status='candidate';row.revision=0;row.definition=data.proposal;row.qualification=null;state.reuse.recipes=[row];result=row}
 if(path.startsWith('/api/reuse/qualify?')){row.status='qualified';row.revision++;row.qualification={ok:true,review_digest:'recipe-exact'};result=row}
 if(path.startsWith('/api/reuse/activate?')){row.status='active';row.revision++;result=row}
 if(path.startsWith('/api/reuse/run?')){result={id:'receipt-1',recipe_id:row.id,at:'2026-09-28',output:{text:'<script>output</script>'},duration_seconds:0.001};row.receipts.push(result)}
 if(path.startsWith('/api/reuse/report?')){row.reports.push(data);row.revision++;result=row}
 if(path.startsWith('/api/bridge/grant?')){const grant={...data,id:'grant-1',world_id:'work',status:'active',expires_at:'tomorrow',calls:0};state.bridge.grants.push(grant);state.bridge.revision++;result=grant}
 if(path.startsWith('/api/bridge/config?'))result={mcpServers:{tao:{command:'/usr/bin/python3',args:['/home/owner/tao_bridge.py','--grant','grant-1']}}};
 if(path.startsWith('/api/bridge/revoke?')){state.bridge.grants[0].status='revoked';state.bridge.revision++}
 if(path.startsWith('/api/bridge/capture?')){state.bridge.captures[0].status=data.action==='accept'?'accepted':'rejected';state.bridge.revision++}
 if(path.startsWith('/api/connectors/execute?')){proposed.status='succeeded';proposed.result={content:[{type:'text',text:'<script>tool-result</script>'}]};result=proposed}
 return {ok:true,status:200,json:async()=>result};
};
function button(parent,label){const found=all(parent).find(node=>node.tagName==='button'&&node.textContent===label);assert(found,'Missing button '+label);return found}
function withButton(parent,label){return all(parent).find(node=>node.tagName==='form'&&all(node).some(child=>child.tagName==='button'&&child.textContent===label))}
const turn=()=>new Promise(setImmediate),submit=form=>form.onsubmit({preventDefault(){}});
'''


class ToolsUITests(NodeHarness):
    def run_js(self, source, syntax=False):
        node = os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node:
            self.skipTest('Node optional: browser controller check')
        path = self.base / 'tools-ui.js'
        path.write_text(source)
        result = subprocess.run([node, *(['--check'] if syntax else []), str(path)],
                                capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_mobile_render_has_fixed_scope_and_safe_bootstrap(self):
        child = worlds.create(self.n, 'Travail', revision=0)
        with worlds.using(child['id']), patch.dict(os.environ, {'TAO_HOSTED': '1'}), \
                patch.object(self.n, 'TOKEN', '</script><img src=x>'):
            rendered = ui.render(self.n, self.n.load_state())
        parsed = Page(rendered)
        self.assertEqual(len(parsed.ids), len(set(parsed.ids)))
        self.assertIn('width=device-width,initial-scale=1', rendered)
        self.assertEqual(rendered.count('</script>'), 1)
        self.assertNotIn('<img src=x>', rendered)
        self.assertIn(r'\u003c/script>', rendered)
        self.assertIn('const token=', rendered)
        with patch.object(self.n, 'TOKEN', 'host-forwarding-token'):
            gateway_page = ui.render(self.n, self.n.load_state())
        original = 'const token=' + json.dumps('host-forwarding-token') + ';'
        self.assertIn(original, gateway_page)
        self.assertNotIn('host-forwarding-token', gateway_page.replace(original, 'const token="browser-token";'))
        config = json.loads(rendered.split('const config=', 1)[1].split(';\n', 1)[0])
        self.assertEqual(config['world'], child['id'])
        self.assertEqual(config['login'], '/host/login')
        self.assertIn('/?world=' + child['id'], rendered)
        self.assertIn('ne connecte pas automatiquement l’application ChatGPT', rendered)
        self.assertIn('Aucun contrôleur de navigateur ou de bureau n’est installé', rendered)
        consent = next(attrs for form in parsed.forms for tag, attrs in form['fields']
                       if attrs.get('id') == 'grant-consent')
        self.assertIn('required', consent)
        self.assertNotIn('checked', consent)
        self.run_js(rendered.split('<script>')[1].split('</script>')[0], syntax=True)

    def test_loading_only_reads_scope_and_external_text_stays_inert(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();
 assert.equal(calls.length,1);assert.equal(calls[0].options.method,undefined);
 assert.equal(calls[0].path,'/api/tools?world=work');
 const rendered=[...nodes.values()].flatMap(all);
 for(const text of ['<img onerror=bad()>','<script>server</script>','<script>tool</script>','<script>capture</script>','<script>description</script>'])assert(rendered.some(node=>node.textContent===text));
 assert(rendered.some(node=>node.textContent==='Référence déclarée : javascript:evil()'));
 assert(!rendered.some(node=>node.href==='javascript:evil()'));
 assert(!rendered.some(node=>node.tagName==='input'&&node.id&&node.id.startsWith('run-reviewed-')&&node.checked));
 assert(!uiExists('/api/connectors/inspect'));assert(!uiExists('/api/bridge/grant'));assert(!uiExists('/api/reuse/run'));
 function uiExists(path){return calls.some(call=>call.path.startsWith(path))}
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_activation_execution_and_usefulness_are_separate_explicit_actions(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();showRecipe('r1');let form=withButton(nodes.get('recipe-detail'),'Activer cette aide');
 const consent=all(form).find(node=>node.type==='checkbox');assert.equal(consent.checked,false);
 const before=calls.length;submit(form);await turn();assert.equal(calls.length,before);
 consent.checked=true;submit(form);await turn();
 const activate=calls.find(call=>call.path.startsWith('/api/reuse/activate?'));
 assert.deepEqual(activate.data,{id:'r1',revision:2,review_digest:'recipe-exact',confirmed:true});
 assert.equal(activate.options.headers['X-Tao-Token'],'owner-csrf');assert(!calls.some(call=>call.path.startsWith('/api/reuse/run?')));
 form=withButton(nodes.get('recipe-detail'),'Exécuter cette aide sans IA');all(form).find(node=>node.id==='recipe-input').value='id,title\n1,Article';submit(form);await turn();
 const run=calls.find(call=>call.path.startsWith('/api/reuse/run?'));assert.deepEqual(run.data,{id:'r1',revision:3,inputs:{csv:'id,title\n1,Article'}});
 assert(!calls.some(call=>call.path.startsWith('/api/reuse/report?')));
 const result=all(nodes.get('recipe-detail')).find(node=>node.id==='recipe-result');
 assert(all(result).some(node=>node.tagName==='pre'&&node.textContent.includes('<script>output</script>')));
 const feedback=withButton(result,'Conserver mon retour');all(feedback).find(node=>node.id&&node.id.startsWith('receipt-note-')).value='Le doublon est visible dans mon export.';all(feedback).find(node=>node.id&&node.id.startsWith('receipt-useful-')).value='yes';submit(feedback);await turn();
 const report=calls.find(call=>call.path.startsWith('/api/reuse/report?'));assert.equal(report.data.receipt_id,'receipt-1');assert.equal(report.data.useful,true);assert.equal(report.data.revision,3);
 assert(calls.every(call=>call.path.includes('world=work')));assert.equal(calls.filter(call=>call.path.startsWith('/api/reuse/run?')).length,1);
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_bridge_grant_is_scoped_limited_and_capture_is_reviewed(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();const fields=document.getElementById('grant-sections'),memory=new Element('input');memory.type='checkbox';memory.value='memory';memory.checked=true;fields.appendChild(memory);
 const form=nodes.get('grant-form'),check=document.getElementById('grant-consent');document.getElementById('grant-label').value='Mon IA locale';document.getElementById('grant-duration').value='86400';
 const before=calls.length;submit(form);await turn();assert.equal(calls.length,before);
 check.checked=true;submit(form);await turn();
 const grant=calls.find(call=>call.path.startsWith('/api/bridge/grant?'));assert.deepEqual(grant.data,{label:'Mon IA locale',tools:['tao_context','tao_capture'],sections:['memory'],ttl_seconds:86400,max_calls:200,revision:4,confirmed:true});assert.equal(check.checked,false);
 assert(!calls.some(call=>call.path.startsWith('/api/bridge/config?')));
 button(nodes.get('grant-list'),'Afficher la configuration locale').onclick();await turn();
 assert(nodes.get('bridge-config').textContent.includes('mcpServers'));assert.equal(nodes.get('bridge-config-panel').hidden,false);
 nodes.get('hide-bridge-config').onclick();assert.equal(nodes.get('bridge-config').textContent,'');assert.equal(nodes.get('bridge-config-panel').hidden,true);
 button(nodes.get('capture-list'),'Conserver dans ma mémoire').onclick();await turn();
 const capture=calls.find(call=>call.path.startsWith('/api/bridge/capture?'));assert.deepEqual(capture.data,{id:'capture-1',action:'accept',revision:5});
 button(nodes.get('grant-list'),'Révoquer cet accès').onclick();await turn();
 const revoke=calls.find(call=>call.path.startsWith('/api/bridge/revoke?'));assert.deepEqual(revoke.data,{id:'grant-1',revision:6});assert.equal(nodes.get('bridge-config').textContent,'');
 assert(!calls.some(call=>call.path.startsWith('/api/connectors/execute?')));
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_starter_requires_separate_qualification_and_activation(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();nodes.get('start-csv').onclick();await turn();
 const proposal=calls.find(call=>call.path.startsWith('/api/reuse/propose?'));
 assert.equal(proposal.data.proposal.operation,'csv.audit');assert.deepEqual(Object.keys(proposal.data),['proposal']);
 assert(!calls.some(call=>call.path.startsWith('/api/reuse/qualify?')));assert(!calls.some(call=>call.path.startsWith('/api/reuse/activate?')));
 button(nodes.get('recipe-detail'),'Vérifier ses exemples').onclick();await turn();
 const qualify=calls.find(call=>call.path.startsWith('/api/reuse/qualify?'));assert.deepEqual(qualify.data,{id:'r1',revision:0});
 assert(!calls.some(call=>call.path.startsWith('/api/reuse/activate?')));
 const form=withButton(nodes.get('recipe-detail'),'Activer cette aide'),consent=all(form).find(node=>node.type==='checkbox');assert.equal(consent.checked,false);
 consent.checked=true;submit(form);await turn();assert.equal(calls.filter(call=>call.path.startsWith('/api/reuse/activate?')).length,1);
 assert(!calls.some(call=>call.path.startsWith('/api/reuse/run?')));
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_link_opens_only_an_existing_scoped_recipe_without_running_it(self):
        self.run_js(DOM + "row.id='abc123abc123';location.hash='#recipe-abc123abc123';\n" + ui.PAGE_JS + r'''
(async()=>{
 await turn();assert.equal(selectedRecipe,'abc123abc123');assert.equal(nodes.get('recipe-detail').hidden,false);
 assert.equal(calls.length,1);assert.equal(calls[0].options.method,undefined);
 selectedRecipe=null;location.hash='#recipe-<script>';openLinkedRecipe();assert.equal(selectedRecipe,null);
 location.hash='#recipe-ffffffffffff';openLinkedRecipe();assert.equal(selectedRecipe,null);assert(nodes.get('message').textContent.includes('pas disponible'));
 assert.equal(calls.length,1);
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_corrected_feedback_is_counted_once_and_audit_result_is_readable(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();row.receipts=[{id:'receipt-1',output:{}}];row.reports=[{receipt_id:'receipt-1',useful:true,note:'Ancien avis'},{receipt_id:'receipt-1',useful:false,note:'Correction observée'}];
 renderRecipes();showRecipe(row.id);
 assert(all(nodes.get('recipe-list')).some(node=>node.textContent.includes('0 retour(s) utile(s)')));
 assert(all(nodes.get('recipe-detail')).some(node=>node.textContent==='Correction observée'));
 assert(!all(nodes.get('recipe-detail')).some(node=>node.textContent==='Ancien avis'));
 const panel=new Element('div');auditSummary(panel,{row_count:2,issue_count:1,issues:[{kind:'duplicate',row:2,column:'id',first_row:1}]});
 assert(all(panel).some(node=>node.textContent==='Ligne 2 · id : valeur déjà présente à la ligne 1'));
 assert(panel.children.some(node=>node.tagName==='details'));assert(!panel.children.some(node=>node.tagName==='pre'));
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_connector_execution_requires_exact_review_and_never_retries(self):
        self.run_js(DOM + ui.PAGE_JS + r'''
(async()=>{
 await turn();const panel=nodes.get('connector-requests');let form=withButton(panel,'Exécuter cette action');
 const consent=all(form).find(node=>node.type==='checkbox');assert.equal(consent.checked,false);
 assert(all(panel).some(node=>node.tagName==='pre'&&node.textContent.includes('<script>argument</script>')));
 const before=calls.length;submit(form);await turn();assert.equal(calls.length,before);
 consent.checked=true;submit(form);await turn();
 const execute=calls.find(call=>call.path.startsWith('/api/connectors/execute?'));assert.deepEqual(execute.data,{id:'request-1',revision:8,review_digest:'action-exact',confirmed:true});
 assert(all(panel).some(node=>node.tagName==='pre'&&node.textContent.includes('<script>tool-result</script>')));
 await refresh();assert.equal(calls.filter(call=>call.path.startsWith('/api/connectors/execute?')).length,1);
 button(nodes.get('connector-list'),'Démarrer le connecteur et lire ses outils').onclick();await turn();
 const inspect=calls.find(call=>call.path.startsWith('/api/connectors/inspect?'));assert.deepEqual(inspect.data,{id:'c1',revision:9});
 assert(calls.filter(call=>call.options.method==='POST').every(call=>call.options.headers['X-Tao-Token']==='owner-csrf'));
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_expired_session_cannot_choose_external_credential_destination(self):
        request = 'async function request' + ui.PAGE_JS.split('async function request', 1)[1].split('async function perform', 1)[0]
        self.run_js(r'''
const assert=require('assert'),links=[],config={login:'/host/login'},token='csrf';
const scoped=path=>path,notify=()=>{},el=()=>({}),$=()=>({appendChild:node=>links.push(node)});
const fetch=async()=>({ok:false,status:401,json:async()=>({login_url:'https://attacker.test'})});
''' + request + r'''
(async()=>{await assert.rejects(()=>request('/api/tools'),error=>error.alreadyShown===true);assert.equal(links[0].href,'/host/login')})().catch(error=>{console.error(error);process.exitCode=1});
''')
