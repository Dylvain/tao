"""Owner routes, CLI framing and exact external actions through real HTTP."""
import http.client
import json
import subprocess
import sys
import threading
from http.server import ThreadingHTTPServer

from test_node import NodeHarness, NODE
from test_connectors import SERVER
import tao_worlds as worlds


class ToolsHTTPTests(NodeHarness):
    def test_cli_failed_qualification_has_failure_exit_and_keeps_report(self):
        proposal = self.good('/api/reuse/template?name=text.template')
        proposal['cases'][0]['expected']['text'] = 'Incorrect expected output'
        row = self.good('/api/reuse/propose', {'proposal': proposal})
        result = self.cli('reuse', 'qualify', row['id'], '--revision', str(row['revision']), check=False)
        self.assertEqual(result.returncode, 1, result.stderr)
        self.assertFalse(json.loads(result.stdout)['qualification']['ok'])
        self.assertEqual(self.good('/api/tools')['reuse']['recipes'][0]['status'], 'candidate')

    def setUp(self):
        super().setUp()
        self.n.TOKEN = 'owner-tools-fixture'
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'poll_interval': .02}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.thread.join(timeout=3); self.server.server_close()
        super().tearDown()

    def request(self, path, body=None, owner=True, headers=None):
        outgoing = {'Content-Type': 'application/json'}
        if owner: outgoing['X-Tao-Token'] = self.n.TOKEN
        outgoing.update(headers or {})
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        try:
            connection.request('GET' if body is None else 'POST', path,
                               None if body is None else json.dumps(body), outgoing)
            response = connection.getresponse(); data = response.read()
            return response.status, json.loads(data) if 'json' in response.getheader('Content-Type', '') else data.decode()
        finally:
            connection.close()

    def good(self, path, body=None):
        status, value = self.request(path, body)
        self.assertEqual(status, 200, value)
        return value

    def test_recipe_lifecycle_is_scoped_explicit_and_no_model(self):
        child = worlds.create(self.n, 'Travail', revision=0)['id']
        suffix = '?world=' + child
        self.assertIn('Mes aides', self.good('/tools' + suffix))
        proposal = self.good('/api/reuse/template?name=csv.audit&world=' + child)
        body = {'proposal': proposal}
        self.assertEqual(self.request('/api/reuse/propose' + suffix, body, owner=False)[0], 403)
        self.assertEqual(self.request('/api/reuse/propose' + suffix, body, headers={'Origin': 'https://untrusted.example'})[0], 403)
        self.assertEqual(self.request('/api/reuse/propose' + suffix, dict(body, world='main'))[0], 400)
        row = self.good('/api/reuse/propose' + suffix, body)
        self.assertEqual(self.good('/api/tools')['reuse']['recipes'], [])
        self.assertEqual(self.request('/api/reuse/qualify', {'id': row['id'], 'revision': row['revision']})[0], 400)
        self.assertEqual(self.request('/api/reuse/run' + suffix, {'id': row['id'], 'inputs': {'csv': 'id,title,url\n1,Accueil,/\n'}, 'revision': row['revision']})[0], 400)
        row = self.good('/api/reuse/qualify' + suffix, {'id': row['id'], 'revision': row['revision']})
        activation = {'id': row['id'], 'revision': row['revision'], 'review_digest': row['qualification']['review_digest']}
        self.assertEqual(self.request('/api/reuse/activate' + suffix, activation)[0], 400)
        row = self.good('/api/reuse/activate' + suffix, dict(activation, confirmed=True))
        self.assertEqual(self.request('/api/reuse/activate' + suffix, dict(activation, confirmed=True))[0], 400)
        self.assertEqual(self.good('/api/reuse/suggest?q=export&world='+child)[0]['id'], row['id'])
        self.assertEqual(self.good('/api/reuse/suggest?q='), [])
        run = {'id': row['id'], 'revision': row['revision'], 'inputs': {'csv': 'id,title,url\n1,' + 'x'*40000 + ',/\n'}, 'request_id': 'once'}
        receipt = self.good('/api/reuse/run' + suffix, run)
        self.assertEqual(receipt['model_calls'], 0)
        self.assertEqual(self.good('/api/reuse/run' + suffix, run)['id'], receipt['id'])
        self.good('/api/reuse/report' + suffix, {'id': row['id'], 'receipt_id': receipt['id'], 'revision': row['revision'], 'useful': False, 'note': 'Ce format ne convient plus à mon travail.'})
        self.assertEqual(self.request('/api/reuse/run' + suffix, run)[0], 400)
        self.assertEqual(self.good('/api/tools' + suffix)['reuse']['recipes'][0]['status'], 'retired')

    def test_bridge_cli_and_http_scopes_do_not_grant_owner_rights(self):
        child = worlds.create(self.n, 'Famille', revision=0)['id']
        suffix = '?world='+child
        body = {'label': 'Client choisi', 'tools': ['tao_context', 'tao_capture'], 'sections': ['memory'], 'ttl_seconds': 3600, 'max_calls': 10, 'revision': 0}
        self.assertEqual(self.request('/api/bridge/grant'+suffix, body)[0], 400)
        grant = self.good('/api/bridge/grant'+suffix, dict(body, confirmed=True))
        config = self.good('/api/bridge/config'+suffix, {'id': grant['id']})
        self.assertEqual(config['mcpServers']['tao']['env']['TAO_WORLD'], child)
        self.assertEqual(self.request('/api/bridge/config', {'id': grant['id']})[0], 400)
        frames = [
            {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {'name': 'test', 'version': '1'}}},
            {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
            {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call', 'params': {'name': 'tao_capture', 'arguments': {'text': 'Proposition extérieure à relire.', 'source': {'application': 'Fixture', 'title': 'Discussion', 'reference': 'ref-1'}, 'request_id': 'capture-1'}}}]
        completed = subprocess.run([sys.executable, str(NODE), '--world', child, 'bridge', 'serve', '--grant', grant['id']],
            input='\n'.join(json.dumps(frame) for frame in frames)+'\n', env=self.env, capture_output=True, text=True, timeout=10)
        self.assertEqual(completed.returncode, 0, completed.stderr)
        replies = [json.loads(line) for line in completed.stdout.splitlines()]
        self.assertEqual(len(replies), 2)  # No owner CLI footer pollutes MCP stdout.
        self.assertFalse(replies[1]['result'].get('isError', False), replies)
        from tao_bridge import MAX_MESSAGE
        invalid = subprocess.run([sys.executable, str(NODE), '--world', child, 'bridge', 'serve', '--grant', grant['id']],
            input='x'*(MAX_MESSAGE+1), env=self.env, capture_output=True, text=True, timeout=10)
        self.assertEqual(invalid.returncode, 1)
        self.assertEqual(json.loads(invalid.stdout)['error']['code'], -32600)
        view = self.good('/api/tools'+suffix)['bridge']
        capture = view['captures'][0]
        self.good('/api/bridge/capture'+suffix, {'id': capture['id'], 'action': 'accept', 'revision': view['revision']})
        with worlds.using(child): self.assertIn('Proposition extérieure', self.n.load_state()['dialogue']['memory'])
        self.assertNotIn('Proposition extérieure', self.n.load_state().get('dialogue', {}).get('memory', ''))
        view = self.good('/api/tools'+suffix)['bridge']
        self.good('/api/bridge/revoke'+suffix, {'id': grant['id'], 'revision': view['revision']})
        self.assertEqual(self.request('/api/bridge/config'+suffix, {'id': grant['id']})[0], 400)

    def test_program_registration_stays_local_exact_action_runs_once(self):
        program = self.base/'fixture-server.py'; program.write_text(SERVER)
        control = self.base/'control'; control.mkdir()
        config = {'label': 'Echo local', 'argv': [sys.executable, str(program), str(control)], 'cwd': str(self.base), 'env_names': [], 'revision': 0}
        file = self.base/'connector.json'; file.write_text(json.dumps(config))
        self.assertEqual(self.request('/api/connectors/register', config)[0], 400)
        self.assertNotEqual(self.cli('tools', 'register', str(file), check=False).returncode, 0)
        connector = json.loads(self.cli('tools', 'register', str(file), '--confirm').stdout)
        self.assertFalse((control/'starts').exists())
        self.good('/api/connectors/inspect', {'id': connector['id'], 'revision': connector['revision']})
        request = self.good('/api/connectors/request', {'connector_id': connector['id'], 'tool': 'echo', 'arguments': {'value': 'Bonjour'}, 'request_id': 'a'*32})
        self.assertFalse((control/'calls').exists())
        action = {'id': request['id'], 'revision': request['revision'], 'review_digest': request['review_digest']}
        self.assertEqual(self.request('/api/connectors/execute', action)[0], 400)
        self.assertEqual(self.request('/api/connectors/execute', dict(action, confirmed=True), owner=False)[0], 403)
        receipt = self.good('/api/connectors/execute', dict(action, confirmed=True))
        self.assertEqual(receipt['status'], 'succeeded', receipt)
        self.assertEqual(self.request('/api/connectors/execute', dict(action, confirmed=True))[0], 400)
        self.assertEqual(len((control/'calls').read_text().splitlines()), 1)
