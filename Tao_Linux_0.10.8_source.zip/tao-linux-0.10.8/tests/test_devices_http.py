"""Real HTTP boundary: owner consent and worker credentials remain distinct."""
import hashlib
import http.client
import json
import secrets
import threading
from http.server import ThreadingHTTPServer

from test_node import NodeHarness
import tao_worlds as worlds


class DevicesHttpTests(NodeHarness):
    def setUp(self):
        super().setUp()
        self.n.TOKEN = 'owner-http-fixture'
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'poll_interval': .02}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.thread.join(timeout=3); self.server.server_close()
        super().tearDown()

    def request(self, path, body=None, owner=False, bearer=None, origin=None):
        headers = {'Content-Type': 'application/json'}
        if owner: headers['X-Tao-Token'] = self.n.TOKEN
        if bearer: headers['Authorization'] = 'Bearer ' + bearer
        if origin is not None: headers['Origin'] = origin
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        try:
            connection.request('GET' if body is None else 'POST', path,
                               None if body is None else json.dumps(body), headers)
            response = connection.getresponse()
            data = response.read()
            return response.status, json.loads(data) if 'json' in response.getheader('Content-Type','') else data.decode()
        finally: connection.close()

    def test_owner_projects_reviewed_need_only_in_its_world(self):
        child = worlds.create(self.n, 'Travail', 'main', '', 0)['id']
        need_id = 'user:dialogue:work-request'
        snapshot = {'residual': 'Un écran de travail manque.', 'goal': 'Proposer cet écran.',
                    'acceptance': 'Le résultat est vérifié avec un exemple.'}
        with worlds.using(child):
            state = self.n.load_state()
            need = {'id': need_id, 'revision': 1, 'title': 'Écran de travail',
                    'current': snapshot['residual'], 'desired': snapshot['goal'],
                    'acceptance': snapshot['acceptance'], 'next_step': '', 'phase': 'to_clarify'}
            buffer = self.n.make_buffer(need_id, 'dialogue', need['current'], authority='human')
            buffer.update(dialogue_need=need, desired=need['desired'], acceptance=need['acceptance'])
            state['buffers'][need_id] = buffer
            self.n.atomic_json(self.n.STATE, state, backup=True)
        body = {'need_id': need_id, 'need_revision': 1, 'expected_snapshot': snapshot}
        route = '/api/devices/project-need?world=' + child
        self.assertEqual(self.request(route, body)[0], 403)
        self.assertEqual(self.request('/api/devices/project-need', body, owner=True)[0], 400)
        status, projected = self.request(route, body, owner=True)
        self.assertEqual(status, 200, projected)
        self.assertEqual(projected['source_need']['world_id'], child)
        self.assertFalse(projected['already_projected'])
        status, retry = self.request(route, body, owner=True)
        self.assertEqual(status, 200, retry)
        self.assertTrue(retry['already_projected'])
        self.assertEqual(retry['id'], projected['id'])
        self.assertEqual(self.request(route, dict(body, unexpected=True), owner=True)[0], 400)
        with worlds.using(child):
            state = self.n.load_state()
            self.assertEqual(state['buffers'][need_id]['status'], 'open')
            self.assertEqual(state['buffers'][projected['id']]['kind'], 'code_projection')

    def test_browser_consent_scoped_worker_and_review_through_http(self):
        child = worlds.create(self.n, 'PC de travail', 'main', '', 0)['id']
        scope = '?world=' + child
        status, view = self.request('/api/devices' + scope)
        self.assertEqual(status, 200, view)
        pair_body = {'label': 'Linux choisi', 'revision': view['revision']}
        self.assertEqual(self.request('/api/devices/pair' + scope, pair_body)[0], 403)
        status, pairing = self.request('/api/devices/pair' + scope, pair_body, owner=True)
        self.assertEqual(status, 200, pairing)
        token, machine = secrets.token_urlsafe(32), secrets.token_hex(16)
        enrol = {'code': pairing['code'], 'token': token, 'machine_id': machine, 'label': 'Mon PC'}
        self.assertEqual(self.request('/api/devices/enrol' + scope, enrol)[0], 400)
        self.assertEqual(self.request('/api/devices/enrol', enrol, origin='')[0], 403)
        status, device = self.request('/api/devices/enrol', enrol)
        self.assertEqual(status, 200, device)
        self.assertEqual(device['world_id'], child)
        poll = {'action': 'poll', 'machine_id': machine, 'repo_head': 'a' * 40,
                'git': True, 'python': True, 'codex': True, 'allow_tests': True,
                'clean': True, 'platform': 'Linux', 'request_id': secrets.token_hex(16)}
        self.assertEqual(self.request('/api/devices/worker', poll, owner=True)[0], 403)
        status, pending = self.request('/api/devices/worker', poll, bearer=token)
        self.assertEqual(status, 200, pending); self.assertIsNone(pending['work'])
        view = self.request('/api/devices' + scope)[1]
        approve = {'id': device['device_id'], 'action': 'approve', 'revision': view['revision']}
        self.assertEqual(self.request('/api/devices/device', approve, owner=True)[0], 400)
        status, approved = self.request('/api/devices/device' + scope, approve, owner=True)
        self.assertEqual(status, 200, approved)
        poll['request_id'] = secrets.token_hex(16)
        self.assertEqual(self.request('/api/devices/worker', poll, bearer=token)[0], 200)
        with worlds.using(child):
            buffer = self.n.add_buffer('Le texte d’accueil manque.', 'Afficher une aide.', 'Une aide visible.', 'undetermined')
        view = self.request('/api/devices' + scope)[1]
        enqueue = {'device_id': device['device_id'], 'buffer_id': buffer['id'], 'revision': view['revision'],
                   'expected_snapshot': {'residual': buffer['residual'], 'goal': buffer['desired'], 'acceptance': buffer['acceptance']}}
        status, job = self.request('/api/devices/jobs' + scope, enqueue, owner=True)
        self.assertEqual(status, 200, job)
        poll['request_id'] = secrets.token_hex(16)
        status, claimed = self.request('/api/devices/worker', poll, bearer=token)
        self.assertEqual(status, 200, claimed)
        work = claimed['work']; self.assertEqual(work['id'], job['id'])
        self.assertEqual(work['world_id'], child)
        self.assertEqual(self.request('/api/devices/worker', poll, bearer=token)[1]['work'], work)
        patch = 'diff --git a/help.txt b/help.txt\n+Bienvenue\n'
        report = {'action': 'report', 'id': job['id'], 'phase': 'generate', 'lease_id': work['lease_id'],
                  'result': {'ok': True, 'status': 'review', 'patch': patch,
                             'patch_sha256': hashlib.sha256(patch.encode()).hexdigest(),
                             'summary': 'Candidat préparé.', 'elapsed_seconds': 1}}
        status, reported = self.request('/api/devices/worker', report, bearer=token)
        self.assertEqual(status, 200, reported)
        status, detail = self.request('/api/devices/job?id=' + job['id'] + '&world=' + child)
        self.assertEqual(status, 200, detail); self.assertEqual(detail['patch'], patch)
        verify = {'id': job['id'], 'action': 'verify', 'revision': detail['revision'],
                  'review_digest': detail['review_digest'], 'confirmed': True}
        self.assertEqual(self.request('/api/devices/job' + scope, verify, bearer=token)[0], 403)
        verify['confirmed'] = False
        self.assertEqual(self.request('/api/devices/job' + scope, verify, owner=True)[0], 400)
        self.assertNotIn(token, json.dumps(detail)); self.assertNotIn(pairing['code'], json.dumps(detail))
        self.assertEqual(self.request('/api/devices')[1]['devices'], [])
        status, page = self.request('/devices' + scope)
        self.assertEqual(status, 200, page[:200]); self.assertIn('Mes appareils', page)
