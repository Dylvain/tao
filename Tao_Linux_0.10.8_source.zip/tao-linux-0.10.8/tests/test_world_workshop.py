import json
import os
from pathlib import Path
from unittest.mock import patch

from test_node import NodeHarness
import tao_adaptation as adapt
import tao_learning as learning
import tao_workshop as workshop
import tao_worlds as worlds


class WorldWorkshopTests(NodeHarness):
    def setUp(self):
        super().setUp()
        with worlds.using('main'):
            self.work = worlds.create(self.n, 'Travail fictif', revision=0)['id']
            self.family = worlds.create(self.n, 'Famille fictive', revision=1)['id']

    def repository(self):
        repo = self.base / 'repo'; repo.mkdir(); (repo / 'scripts').mkdir()
        (repo / 'value.txt').write_text('before\n')
        # Fresh test nodes have only their principal space. The caller remains
        # inside its own space even though this subprocess starts at main.
        (repo / 'scripts/verify.sh').write_text(
            'set -eu\ntest "$TAO_WORLD" = main\ntest "$(cat value.txt)" = after\n')
        workshop.git(repo, 'init'); workshop.git(repo, 'add', '.')
        workshop.git(repo, *workshop.identity_args(), 'commit', '-m', 'Fictional baseline')
        return repo

    def task(self):
        self.n.work.save_context(self.n, 'Un travail fictif', 'Continuer à comprendre')
        row = self.n.work.add_task(self.n, 'Une aide fictive')
        return self.n.work.save_example(self.n, row['id'], 'Un cas fictif', 'Un résultat vérifiable')

    def test_work_contexts_and_equal_named_tasks_have_distinct_world_identities(self):
        identities, tasks = {}, {}
        for ident in ('main', self.work, self.family):
            with worlds.using(ident):
                b = self.task()
                identities[ident] = self.n.load_state()['work_context']['id']
                tasks[ident] = b['id']
        self.assertEqual(len(set(identities.values())), 3)
        self.assertEqual(len(set(tasks.values())), 3)
        self.assertEqual(identities['main'], 'work:' + self.n.load_state()['id'])
        self.assertTrue(identities[self.work].endswith(':' + self.work))

    def test_experiment_context_is_checked_before_reading_diffs_or_running_tests(self):
        repo = self.repository(); w = workshop.Workshop(self.n)
        with worlds.using(self.work):
            b = self.n.add_buffer('Un résidu privé', 'Une amélioration', 'Un test local')
            e = w.prepare(repo, b['id'])
            self.assertEqual(e['world_id'], self.work)
            (Path(e['candidate']) / 'value.txt').write_text('after\n')
            with patch.dict(os.environ, {'TAO_WORLD': self.work}):
                result = w.verify(e['id'], True)
            self.assertEqual(result['status'], 'verified', result)
            self.assertEqual(worlds.current(), self.work)
        for ident in ('main', self.family):
            with worlds.using(ident):
                self.assertEqual(w.list(), [])
                for operation in (w.load, w.diff, w.run, w.accept, w.rollback):
                    with self.assertRaises(ValueError): operation(e['id'])
                with self.assertRaises(ValueError): w.verify(e['id'], True)
                with self.assertRaises(ValueError): w.save(dict(e, world_id=ident))
        with worlds.using(self.work):
            self.assertEqual(w.load(e['id'])['status'], 'verified')
            w.accept(e['id'])
        self.assertEqual((repo / 'value.txt').read_text(), 'after\n')
        with worlds.using('main'):
            self.assertNotIn('Un résidu privé', json.dumps(self.n.load_state(), ensure_ascii=False))

    def test_legacy_experiments_stay_principal_and_storage_cap_is_global(self):
        w = workshop.Workshop(self.n)
        # Earlier versions omit world_id. These records belong to main.
        for i in range(100):
            self.n.atomic_json(w._file(f'{i:012x}'), {'id': f'{i:012x}', 'status': 'prepared'})
        with worlds.using('main'):
            self.assertEqual(len(w.list()), 100)
            self.assertEqual(w.load('000000000000')['status'], 'prepared')
        with worlds.using(self.work):
            self.assertEqual(w.list(), [])
            with self.assertRaises(ValueError): w.load('000000000000')
            b = self.n.add_buffer('Un besoin', 'Un résultat', 'Une preuve')
            with patch.object(workshop, 'git') as git:
                with self.assertRaisesRegex(ValueError, '100 expériences'):
                    w.prepare(self.base, b['id'])
                git.assert_not_called()
        self.assertEqual(len(list(w.root.glob('*/experiment.json'))), 100)

    def test_learning_never_reads_foreign_attempts_even_with_an_equal_task_id(self):
        with worlds.using(self.work):
            task = self.task(); bid = task['id']; w = workshop.Workshop(self.n)
            own = {'id': '000000000001', 'task_id': bid, 'world_id': self.work,
                   'status': 'test_failed', 'task_revision': 2, 'context_revision': 1,
                   'message': 'Le cas propre à cet espace', 'experiment_id': '000000000011'}
            self.n.atomic_json(adapt.path(self.n, own['id']), own)
            w.save({'id': own['experiment_id'], 'world_id': self.work, 'status': 'test_failed',
                    'verification': {'ok': False}, 'runs': []})
            self.n.durable_bytes(w._file(own['experiment_id']).parent / 'tests.log', b'OWN_TEST_FAILURE')
            foreign = dict(own, id='000000000002', world_id=self.family,
                           message='FOREIGN_PRIVATE_MESSAGE', experiment_id='000000000022')
            self.n.atomic_json(adapt.path(self.n, foreign['id']), foreign)
            legacy = dict(own, id='000000000003', message='PRINCIPAL_PRIVATE_MESSAGE')
            legacy.pop('world_id')
            self.n.atomic_json(adapt.path(self.n, legacy['id']), legacy)
            with patch.object(adapt, 'read_local', wraps=adapt.read_local) as read:
                context = learning.preparation_context(self.n, self.n.load_state(), bid)
            self.assertEqual(len(context['previous_attempts']), 1)
            self.assertEqual(context['previous_attempts'][0]['id'], own['id'])
            self.assertIn('OWN_TEST_FAILURE', json.dumps(context))
            self.assertNotIn('PRIVATE_MESSAGE', json.dumps(context))
            self.assertEqual(read.call_count, 1)
            self.assertEqual(read.call_args.args[0].parent.name, own['experiment_id'])

    def test_child_adaptation_installer_restarts_from_main_without_changing_worker_context(self):
        repo = self.base / 'install-source'; (repo / 'bootstrap').mkdir(parents=True)
        script = repo / 'bootstrap/install.py'
        script.write_text('import os\nfrom pathlib import Path\n'
            'assert os.environ["TAO_WORLD"] == "main"\n'
            'root=Path(os.environ["TAO_ROOT"])/"runtime"\nroot.mkdir(exist_ok=True)\n'
            '(root/"installed-world.txt").write_text(os.environ["TAO_WORLD"])\n')
        expected = {'files': {'installed-world.txt': self.n.digest_bytes(b'main')},
                    'installer': self.n.digest_bytes(script.read_bytes()), 'node_version': self.n.NODE_VERSION}
        with worlds.using(self.work):
            task = self.task()
            with patch.object(adapt, 'diagnose', return_value={'ready': True, 'source': str(repo)}), \
                    patch.object(adapt, 'launch'):
                job = adapt.request(self.n, task['id'], 'generate')
            job.update(operation='apply', status='queued', experiment_id='000000000033',
                       authorized_review_digest=self.n.digest_bytes(b'patch'))
            adapt.save(self.n, job)
            workshop.Workshop(self.n).save({'id': job['experiment_id'], 'world_id': self.work,
                'status': 'accepted', 'accepted_commit': 'commit', 'candidate': str(repo),
                'verification': {'candidate_commit': 'commit'}})
            def git(path, *args):
                return 'commit' if args == ('rev-parse', 'HEAD') else ''
            with patch.object(adapt, 'verified_runtime', return_value=expected), \
                    patch.object(workshop.Workshop, 'diff', return_value='patch'), \
                    patch.object(workshop, 'git', side_effect=git), \
                    patch.object(self.n, 'local_request', return_value={
                        'ok': True, 'node_version': self.n.NODE_VERSION, 'session': 'new-session'}), \
                    patch.dict(os.environ, {'TAO_WORLD': self.work}):
                result = adapt.worker(self.n, job['id'], 'apply')
            self.assertEqual(result['status'], 'installed', result)
            self.assertEqual(worlds.current(), self.work)
            self.assertEqual(adapt.load(self.n, job['id'])['world_id'], self.work)
        self.assertEqual((self.n.ROOT / 'runtime/installed-world.txt').read_text(), 'main')
        with worlds.using('main'), self.assertRaises(ValueError):
            adapt.load(self.n, job['id'])
