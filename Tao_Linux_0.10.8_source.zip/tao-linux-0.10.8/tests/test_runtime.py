"""The installed and inherited Tao body has one explicit composition."""
import json
import unittest

from test_node import BOOT, PROJECT
import tao_runtime as runtime


class RuntimeInventoryTests(unittest.TestCase):
    def test_groups_are_disjoint_and_cover_every_runtime_module(self):
        groups = (
            runtime.KERNEL_FILES,
            runtime.INTELLIGENCE_FILES,
            runtime.EVOLUTION_FILES,
            runtime.CAPABILITY_FILES,
            runtime.PROJECTION_FILES,
        )
        flattened = tuple(name for group in groups for name in group)
        self.assertEqual(flattened, runtime.RUNTIME_FILES)
        self.assertEqual(len(flattened), len(set(flattened)))
        self.assertEqual(set(flattened), {path.name for path in BOOT.glob('tao_*.py')})
        self.assertNotIn('tao_centers_ui.py', flattened)
        self.assertNotIn('tao_steward.py', flattened)

    def test_source_manifest_and_release_follow_the_inventory(self):
        manifest = json.loads((PROJECT / 'MANIFEST.json').read_text())
        expected = ['bootstrap/' + name for name in runtime.RUNTIME_FILES]
        self.assertEqual(manifest['runtime'], expected)
        release = set(json.loads((PROJECT / 'RELEASE_FILES.json').read_text())['files'])
        self.assertTrue(set(expected) <= release)
        self.assertIn('docs/TECHNICAL.md', release)
        self.assertNotIn('bootstrap/tao_centers_ui.py', release)
        self.assertNotIn('bootstrap/tao_steward.py', release)

    def test_assets_are_present_in_source_and_manifest(self):
        manifest = json.loads((PROJECT / 'MANIFEST.json').read_text())
        for name in runtime.RUNTIME_ASSETS:
            path = BOOT / 'tao_frontend' / name
            self.assertTrue(path.is_file(), name)
            self.assertEqual(manifest['runtime_assets'][name],
                             'bootstrap/tao_frontend/' + name)


if __name__ == '__main__':
    unittest.main()
