"""Selected-memory transfer through real HTTP; no account or model is used."""
import copy
import http.client
import json
import threading
from http.server import ThreadingHTTPServer

from test_node import NodeHarness
import tao_dialogue as dialogue
import tao_worlds as worlds


class HandoffHttpTests(NodeHarness):
    def setUp(self):
        super().setUp()
        self.n.TOKEN = 'handoff-http-test-token'
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'poll_interval': .02}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.thread.join(timeout=3); self.server.server_close()
        super().tearDown()

    def request(self, path, value=None, world='main', token=True):
        host = '127.0.0.1:' + str(self.server.server_port)
        headers = {'Host': host}
        body = None
        if value is not None:
            body = json.dumps(value, ensure_ascii=False).encode()
            headers.update({'Content-Type': 'application/json', 'Origin': 'http://' + host})
            if token: headers['X-Tao-Token'] = self.n.TOKEN
        conn = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        try:
            conn.request('POST' if value is not None else 'GET', path + '?world=' + world,
                         body, headers)
            response = conn.getresponse()
            return response.status, json.loads(response.read())
        finally: conn.close()

    def test_selected_transfer_requires_session_preserves_destination_and_is_idempotent(self):
        dialogue.save_memory(self.n, 'Contexte choisi sur le premier Tao.', 0)
        status, document = self.request('/dialogue/handoff')
        self.assertEqual(status, 200, document)
        child = worlds.create(self.n, 'Destination', 'main', '', 0)['id']
        with worlds.using(child):
            dialogue.save_memory(self.n, 'Mémoire déjà présente.', 0)
        payload = {'document': document, 'revision': 1}
        self.assertEqual(self.request('/api/dialogue/handoff', payload, child, False)[0], 403)
        status, result = self.request('/api/dialogue/handoff', payload, child)
        self.assertEqual(status, 200, result)
        self.assertTrue(result['imported'])
        status, duplicate = self.request('/api/dialogue/handoff', payload, child)
        self.assertEqual(status, 200, duplicate)
        self.assertTrue(duplicate['already_imported'])
        with worlds.using(child):
            state = self.n.load_state()
            self.assertIn('Mémoire déjà présente.', state['dialogue']['memory'])
            self.assertIn(document['text'], state['dialogue']['memory'])
            self.assertEqual(len(state['dialogue']['handoff_receipts']), 1)
            self.assertEqual(state['dialogue']['messages'], [])
        self.assertEqual(self.n.load_state()['dialogue']['memory'], document['text'])
        damaged = copy.deepcopy(document); damaged['text'] += ' modifié'
        self.assertEqual(self.request('/api/dialogue/handoff', {'document': damaged, 'revision': 2}, child)[0], 400)

    def test_cli_export_import_and_global_host_links(self):
        dialogue.save_memory(self.n, 'Une mémoire portable.', 0)
        exported = json.loads(self.cli('handoff', 'export').stdout)
        path = self.base / 'chosen-memory.json'
        path.write_text(json.dumps(exported))
        reply = self.cli('handoff', 'import', str(path), '--revision', '1')
        self.assertTrue(json.loads(reply.stdout)['imported'])
        child = worlds.create(self.n, 'Autre espace', 'main', '', 0)['id']
        with worlds.using(child):
            page = self.n.scoped_links('<a href="/host/ai">IA</a><a href="/host/account">Compte</a><a href="/dialogue/handoff">Mémoire</a>')
        self.assertIn('href="/host/ai"', page)
        self.assertIn('href="/host/account"', page)
        self.assertIn('/dialogue/handoff?world=' + child, page)
