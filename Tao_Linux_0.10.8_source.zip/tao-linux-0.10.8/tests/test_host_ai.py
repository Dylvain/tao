import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'bootstrap'))
import tao_host_ai as ai


class HostAITests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name)
        self.codex_home=self.base/'persistent-codex';self.codex_home.mkdir()
        self.root=self.base/'tao';self.root.mkdir();self.node=SimpleNamespace(ROOT=self.root)
        self.env=patch.dict(os.environ,{'CODEX_HOME':str(self.codex_home),'HOME':str(self.base),
            'RAILWAY_TOKEN':'fixture-project-secret','TAO_HOST_PASSWORD':'fixture-password','OPENAI_API_KEY':'fixture-api-secret'})
        self.env.start();self.addCleanup(self.env.stop);self.addCleanup(self.temp.cleanup)
        self.binary=self.base/'codex'
        self.binary.write_text('#!'+sys.executable+'''\nimport json,os,signal,sys,time
from pathlib import Path
home=Path(os.environ['CODEX_HOME'])
with (home/'calls.jsonl').open('a') as f:f.write(json.dumps({'args':sys.argv[1:],'keys':list(os.environ)})+'\\n')
mode=(home/'mode').read_text() if (home/'mode').exists() else 'wait'
if sys.argv[1:]==['login','status']:
    print('PRIVATE_STATUS_DETAIL fixture-account@example.invalid sk-secret-not-for-browser')
    if mode=='status_timeout':time.sleep(30)
    sys.exit(0 if (home/'connected').exists() else 1)
assert sys.argv[1:]==['login','--device-auth']
(home/'pid').write_text(str(os.getpid()))
if mode=='output_limit':
    print('x'*100000,flush=True);time.sleep(30)
if mode=='unsupported_url':
    print('https://attacker.invalid/login',flush=True);time.sleep(30)
print('PRIVATE_DEBUG_DETAIL fixture-debug-secret',flush=True)
print('1. Open this link in your browser and sign in to your account',flush=True)
print('\\x1b[94mhttps://auth.openai.com/codex/device\\x1b[0m',flush=True)
print('2. Enter this one-time code (expires in 15 minutes)',flush=True)
print('\\x1b[94mABCD-EFGHI\\x1b[0m',flush=True)
if mode=='unconfirmed_success':sys.exit(0)
if mode=='close_stdout':os.close(1);os.close(2)
while not (home/'connected').exists():time.sleep(.02)
sys.exit(0)
''')
        self.binary.chmod(0o700);self.manager=ai.HostAI(self.node,str(self.binary));self.addCleanup(self.manager.close)

    def wait(self,condition,timeout=5):
        until=time.monotonic()+timeout
        while time.monotonic()<until:
            result=self.manager._snapshot()
            if condition(result):return result
            time.sleep(.02)
        self.fail('Timed out: '+json.dumps(self.manager._snapshot()))

    def calls(self):
        file=self.codex_home/'calls.jsonl'
        return [json.loads(line) for line in file.read_text().splitlines()] if file.exists() else []

    def assert_stopped(self):
        pidfile=self.codex_home/'pid'
        if pidfile.exists():
            with self.assertRaises(ProcessLookupError):os.kill(int(pidfile.read_text()),0)

    def test_official_prompt_only_exposes_labelled_code_and_exact_url(self):
        self.assertEqual(ai._instructions('Banner SECRET-SECRET\n'+ai.DEVICE_URL+'\n'),(None,None))
        text='debug secret ignored\n'+ai.DEVICE_URL+'\n2. Enter this one-time code (expires in 15 minutes)\n\x1b[94mABCD-EFGHI\x1b[0m\n'
        self.assertEqual(ai._instructions(text),(ai.DEVICE_URL,'ABCD-EFGHI'))
        for url in ('https://evil.invalid/code','https://auth.openai.com.evil.invalid/codex/device',
                    'http://auth.openai.com/codex/device','https://auth.openai.com/codex/device?code=private'):
            with self.subTest(url=url),self.assertRaises(ValueError):ai._instructions(text.replace(ai.DEVICE_URL,url))
        with self.assertRaises(ValueError):ai._instructions(text.replace('ABCD-EFGHI','not a code or a command'))

    def test_single_device_flow_confirms_with_status_and_keeps_codex_home(self):
        self.assertFalse(self.manager.status()['connected'])
        self.manager.start();waiting=self.wait(lambda row:row['state']=='awaiting_authorization')
        self.assertEqual(waiting['verification_url'],ai.DEVICE_URL);self.assertEqual(waiting['user_code'],'ABCD-EFGHI')
        self.manager.start();self.manager.start()
        self.assertEqual(sum(row['args']==['login','--device-auth'] for row in self.calls()),1)
        for row in self.calls():
            for secret in ('RAILWAY_TOKEN','TAO_HOST_PASSWORD','OPENAI_API_KEY'):self.assertNotIn(secret,row['keys'])
            self.assertIn('CODEX_HOME',row['keys'])
        self.assertNotIn('fixture-debug-secret',json.dumps(waiting));self.assertNotIn('fixture-account',json.dumps(waiting))
        (self.codex_home/'connected').write_text('fixture confirmed by owner')
        done=self.wait(lambda row:not row['login_in_progress'])
        self.assertEqual(done['state'],'connected');self.assertTrue(done['connected'])
        self.assertIsNone(done['user_code']);self.assertIsNone(done['verification_url']);self.assertIsNone(done['expires_at'])
        second=ai.HostAI(self.node,str(self.binary));self.addCleanup(second.close)
        self.assertTrue(second.status()['connected'])
        self.assertEqual(sum(row['args']==['login','--device-auth'] for row in self.calls()),1)
        self.assert_stopped()

    def test_separate_managers_cannot_open_two_flows_for_same_node(self):
        self.manager.start();self.wait(lambda row:row['state']=='awaiting_authorization')
        second=ai.HostAI(self.node,str(self.binary));self.addCleanup(second.close)
        with self.assertRaisesRegex(ValueError,'déjà en cours'):second.start()
        self.assertEqual(sum(row['args']==['login','--device-auth'] for row in self.calls()),1)

    def test_timeout_erases_code_and_reaps_child(self):
        with patch.object(ai,'AUTH_TIMEOUT',.25):
            self.manager.start();self.wait(lambda row:row['state']=='awaiting_authorization')
            done=self.wait(lambda row:not row['login_in_progress'])
        self.assertEqual(done['state'],'expired');self.assertIsNone(done['user_code']);self.assert_stopped()

    def test_cancel_and_close_work_even_after_cli_closes_its_output(self):
        (self.codex_home/'mode').write_text('close_stdout')
        self.manager.start();self.wait(lambda row:row['state']=='awaiting_authorization')
        cancelled=self.manager.cancel();self.assertIsNone(cancelled['user_code'])
        self.manager.close();done=self.manager._snapshot()
        self.assertFalse(done['login_in_progress']);self.assertEqual(done['state'],'cancelled');self.assert_stopped()
        with self.assertRaises(ValueError):self.manager.start()

    def test_unexpected_url_and_excessive_output_are_not_shown(self):
        for mode in ('unsupported_url','output_limit'):
            with self.subTest(mode=mode):
                (self.codex_home/'mode').write_text(mode)
                self.manager.start();done=self.wait(lambda row:not row['login_in_progress'])
                self.assertEqual(done['state'],'failed');self.assertIsNone(done['verification_url']);self.assertIsNone(done['user_code'])
                self.assertNotIn('attacker',json.dumps(done));self.assert_stopped()

    def test_zero_login_exit_without_confirmed_status_is_not_connected(self):
        (self.codex_home/'mode').write_text('unconfirmed_success')
        self.manager.start();done=self.wait(lambda row:not row['login_in_progress'])
        self.assertEqual(done['state'],'failed');self.assertFalse(done['connected']);self.assertIsNone(done['user_code'])

    def test_status_is_bounded_cached_and_never_a_model_request(self):
        (self.codex_home/'mode').write_text('status_timeout')
        with patch.object(ai,'STATUS_TIMEOUT',.1):
            first=self.manager.status();second=self.manager.status()
        self.assertIsNone(first['connected']);self.assertEqual(first['checked_at'],second['checked_at'])
        self.assertEqual([row['args'] for row in self.calls()],[['login','status']])
        self.assertFalse(first['model_request_sent'])

    def test_routes_require_owner_and_accept_no_command_parameters(self):
        class Handler:
            command='GET';path='/host/ai/status';auth_session=None;body_value={}
            def json(self,status,obj):self.result=(status,obj)
            def send_body(self,status,body,ctype):self.result=(status,body,ctype)
            def browser_token(self):return '</script><script>unsafe</script>'
        h=Handler();self.assertTrue(self.manager.route(h));self.assertEqual(h.result[0],401);self.assertEqual(self.calls(),[])
        h.auth_session={'id':'fixture-session'};h.path='/host/ai';self.manager.route(h)
        self.assertEqual(h.result[0],200);page=h.result[1].decode()
        self.assertNotIn('</script><script>unsafe',page);self.assertIn('\\u003c/script>',page)
        h.command='POST';h.path='/host/ai/start';h.body_value={'command':'arbitrary'}
        self.manager.route(h);self.assertEqual(h.result[0],400);self.assertEqual(self.calls(),[])
        h.path='/host/ai/other';self.assertFalse(self.manager.route(h))

    def test_browser_ignores_old_status_recovers_expired_session_and_never_replays_action(self):
        node=os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node:self.skipTest('Node absent ; comportement JavaScript à vérifier dans un navigateur.')
        script=re.search(r'<script>(.*?)</script>',ai.PAGE,re.S).group(1).replace('__TOKEN__',json.dumps('fixture-token'))
        harness=r'''
const vm=require('vm'),assert=require('assert'),fs=require('fs');const script=fs.readFileSync(0,'utf8');
function surface(){const nodes={},pending=[],timers=new Map();let id=0;
const context={document:{getElementById:id=>nodes[id]||(nodes[id]={hidden:false,textContent:'',disabled:false})},
navigator:{clipboard:{writeText:async()=>{}}},setTimeout:fn=>{timers.set(++id,fn);return id},clearTimeout:id=>timers.delete(id),
fetch:(path,options)=>new Promise((resolve,reject)=>pending.push({path,options,resolve,reject}))};
vm.createContext(context);vm.runInContext(script,context);return {nodes,pending,timers,context}}
const idle={message:'Non connecté',verification_url:null,user_code:null,login_in_progress:false,cli_available:true,connected:false};
const active={message:'Code prêt',verification_url:'https://auth.openai.com/codex/device',user_code:'ABCD-1234',login_in_progress:true,cli_available:true,connected:false};
const tick=()=>new Promise(resolve=>setImmediate(resolve));
async function reply(s,i,data,status=200){s.pending[i].resolve({ok:status===200,status,json:async()=>data});await tick()}
(async()=>{
const s=surface();assert(s.nodes.start.disabled);await reply(s,0,idle);assert(!s.nodes.start.disabled);
s.context.refresh();const start=s.nodes.start.onclick();assert.equal(s.pending[2].path,'/host/ai/start');
await reply(s,2,active);await start;assert.equal(s.nodes.code.textContent,'ABCD-1234');assert.equal(s.timers.size,1);
await reply(s,1,idle);assert.equal(s.nodes.code.textContent,'ABCD-1234');assert.equal(s.timers.size,1);
const refresh=s.context.refresh();await reply(s,3,{error:'Session expirée',login_url:'/host/login'},401);await refresh;
assert(s.nodes.pairing.hidden);assert.equal(s.nodes.code.textContent,'');assert(s.nodes.start.disabled);assert(s.nodes.cancel.hidden);
assert(!s.nodes['session-expired'].hidden);assert.equal(s.timers.size,0);assert.equal(s.pending.filter(r=>r.options.method==='POST').length,1);
await s.context.refresh();assert.equal(s.pending.length,4);
const t=surface();await reply(t,0,active);const cancel=t.nodes.cancel.onclick();t.pending[1].reject(Error('Network unavailable'));await cancel;
assert(t.nodes.status.textContent.includes('non confirmé'));assert(t.nodes.pairing.hidden);assert.equal(t.nodes.code.textContent,'');
assert(!t.nodes.refresh.disabled);assert.equal(t.pending.filter(r=>r.options.method==='POST').length,1);assert.equal(t.timers.size,0);
})().catch(error=>{console.error(error);process.exitCode=1});
'''
        result=subprocess.run([node,'-e',harness],input=script,capture_output=True,text=True,timeout=10)
        self.assertEqual(result.returncode,0,result.stderr)
