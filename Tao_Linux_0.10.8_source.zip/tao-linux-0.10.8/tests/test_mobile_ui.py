"""Phone-facing rendering and browser draft behavior; no browser dependency."""
import json
import os
import shutil
import subprocess
from html.parser import HTMLParser
from unittest.mock import patch

from test_node import NodeHarness
import tao_adaptation as adaptation
import tao_ui as ui


class Page(HTMLParser):
    def __init__(self, text):
        super().__init__(); self.ids=[]; self.forms=[]; self.stack=[]; self.feed(text)

    def handle_starttag(self, tag, attrs):
        attrs=dict(attrs)
        if attrs.get('id'): self.ids.append(attrs['id'])
        if tag=='form':
            if self.stack: raise AssertionError('Nested forms')
            self.forms.append({'attributes':attrs,'fields':[]}); self.stack.append(self.forms[-1])
        elif self.stack and tag in {'input','textarea','select'}:
            self.stack[-1]['fields'].append((tag,attrs))

    def handle_endtag(self, tag):
        if tag=='form': self.stack.pop()


class MobileUITests(NodeHarness):
    def run_js(self, source, syntax_only=False):
        node=os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node: self.skipTest('Node optional: browser behavior needs a JavaScript runtime')
        path=self.base/'browser-check.js'; path.write_text(source)
        result=subprocess.run([node,*(['--check'] if syntax_only else []),str(path)],capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_page_distinguishes_execution_host_and_current_device(self):
        page=self.n.dashboard(self.n.load_state()); parsed=Page(page)
        self.assertEqual(len(parsed.ids),len(set(parsed.ids)))
        self.assertIn('Téléphone ou ordinateur : tu retrouves les mêmes espaces.',page)
        self.assertIn('Les fichiers exportés se téléchargent sur l’appareil que tu utilises.',page)
        self.assertNotIn('Sur cette machine',page)
        self.assertIn('drafts-panel',parsed.ids)
        for form in parsed.forms:
            if not any(tag=='textarea' for tag,_ in form['fields']): continue
            self.assertTrue(form['attributes'].get('id') or form['attributes'].get('class'))
            for tag,attrs in form['fields']:
                if tag=='textarea': self.assertTrue(attrs.get('id') or attrs.get('name'))

    def test_code_approval_names_linux_host_and_starts_unchecked(self):
        task={'id':'test-task','work_task':{}}
        for status in ['review','verified']:
            row={'id':'abc','status':status,'review_digest':'digest'}
            with patch.object(adaptation,'diagnose',return_value={'ready':True}),patch.object(adaptation,'current',return_value=row),patch.object(adaptation,'view',return_value={}):
                html=ui.render_adaptation(self.n,task)
            parsed=Page(html); fields=[attrs for form in parsed.forms for tag,attrs in form['fields'] if attrs.get('name')=='confirmed']
            self.assertEqual(len(fields),1)
            self.assertIn('required',fields[0]); self.assertNotIn('checked',fields[0])
            self.assertIn('sur l’ordinateur qui héberge Tao.',html)

    def test_rendered_script_syntax_and_auth_link(self):
        page=self.n.dashboard(self.n.load_state()); script=page.split('<script>')[-1].split('</script>')[0]
        self.assertIn('id="workshop-link"',page)
        self.assertIn('href="#work-progress"',page)
        self.assertIn('href="/explore?world=main"',page)
        self.run_js(script,syntax_only=True)
        # A server error may not choose another origin for credential entry.
        login=script.split('function loginRequired',1)[1].split('function retryNotice',1)[0]
        self.run_js("const assert=require('assert');let preserved=0;const target={appendChild:x=>{assert.equal(x.href,'/mobile/login')}};const document={createElement:()=>({})};const keepAllDrafts=()=>preserved++;const message=()=>target;function loginRequired"+login+";loginRequired({login_url:'https://attacker.invalid/'});assert.equal(preserved,1);")

    def test_drafts_are_scoped_and_only_submitted_form_is_removed(self):
        self.run_js(ui.DRAFT_STORE_JS+r'''
const assert=require('assert'), data=new Map();
const storage={getItem:k=>data.get(k),setItem:(k,v)=>data.set(k,v)};
const main=createDraftStore(storage,'node-a','main'), family=createDraftStore(storage,'node-a','family'), other=createDraftStore(storage,'node-b','main');
assert(main.put('memory',{values:{text:'My draft'},base:{text:'Original'},revision:'4'}));
assert(main.put('need',{values:{title:'My goal'},base:{title:''}}));
assert.deepEqual(family.read(),{});assert.deepEqual(other.read(),{});
assert(main.drop('need'));assert.equal(main.read().memory.values.text,'My draft');
assert.equal(main.read().memory.base.text,'Original');assert.equal(main.read().memory.revision,'4');
assert.equal(main.read().need,undefined);
''')

    def test_storage_failure_and_limits_preserve_existing_drafts(self):
        self.run_js(ui.DRAFT_STORE_JS+r'''
const assert=require('assert'), data=new Map();let blocked=false;
const storage={getItem:k=>data.get(k),setItem:(k,v)=>{if(blocked)throw Error('Quota');data.set(k,v)}};
const drafts=createDraftStore(storage,'node','main');assert(drafts.put('saved',{values:{text:'Important'}}));
assert.equal(drafts.put('huge',{values:{text:'x'.repeat(200001)}}),false);assert.equal(drafts.read().saved.values.text,'Important');assert.equal(drafts.read().huge,undefined);
blocked=true;assert.equal(drafts.put('later',{values:{text:'Still on screen'}}),false);assert.equal(drafts.read().saved.values.text,'Important');blocked=false;
for(let i=0;i<59;i++)assert(drafts.put('draft'+i,{values:{text:'Small'}}));assert.equal(drafts.put('over-limit',{values:{text:'No eviction'}}),false);assert.equal(Object.keys(drafts.read()).length,60);
''')

    def test_draft_restoration_never_restores_consent_or_credentials(self):
        self.run_js(ui.DRAFT_STORE_JS+r'''
const assert=require('assert');
const fields=[{tagName:'TEXTAREA',id:'text',value:'Server now',maxLength:12000},{tagName:'INPUT',type:'checkbox',name:'confirmed',value:'on',checked:false},{tagName:'INPUT',type:'password',name:'password',value:''},{tagName:'INPUT',type:'hidden',name:'token',value:'current-token'},{tagName:'INPUT',type:'text',id:'title',value:'Server title',maxLength:160},{tagName:'SELECT',id:'choice',value:'one',options:[{value:'one'},{value:'two'}]}];
const form={querySelectorAll:()=>fields,dataset:{revision:'9'}};
assert.deepEqual(Object.keys(draftValues(form)),['text','title','choice']);
restoreDraftFields(form,{text:'My draft',confirmed:'on',password:'secret',token:'old-token',title:'Corrected',choice:'two',revision:'1'});
assert.equal(fields[0].value,'My draft');assert.equal(fields[1].checked,false);assert.equal(fields[2].value,'');assert.equal(fields[3].value,'current-token');assert.equal(fields[5].value,'two');assert.equal(form.dataset.revision,'9');
restoreDraftFields(form,{text:'x'.repeat(12001),title:'x'.repeat(161),choice:'removed-option'});
assert.equal(fields[0].value,'My draft');assert.equal(fields[4].value,'Corrected');assert.equal(fields[5].value,'two');
''')

    def test_pending_draft_is_not_overwritten_before_explicit_choice(self):
        page=self.n.dashboard(self.n.load_state()); script=page.split('<script>')[-1].split('</script>')[0]
        keep=script.split('function keepFormDraft',1)[1].split('function keepAllDrafts',1)[0]
        self.run_js(ui.DRAFT_STORE_JS+r'''
const assert=require('assert');let dropped=0,written=0;
const field={tagName:'TEXTAREA',id:'text',value:'Server',maxLength:100};
const form={dataset:{pendingDraft:'true',revision:'3'},querySelectorAll:()=>[field]};
const draftBaselines=new Map([[form,{text:'Server'}]]), draftStore={drop:()=>{dropped++;return true},put:()=>{written++;return true}}, dialogueForm={}, formKey=()=> 'form',selectedFocus=null;
function keepFormDraft'''+keep+r'''
assert.equal(keepFormDraft(form),true);assert.equal(dropped,0);
field.value='New unsaved text';assert.equal(keepFormDraft(form),false);assert.equal(written,0);
delete form.dataset.pendingDraft;assert.equal(keepFormDraft(form),true);assert.equal(written,1);
''')

    def test_network_results_preserve_other_drafts_and_edits_made_in_flight(self):
        script=self.n.dashboard(self.n.load_state()).split('<script>')[-1].split('</script>')[0]
        send='async function send'+script.split('async function send',1)[1].split('const contextForm',1)[0]
        keep='function keepFormDraft'+script.split('function keepFormDraft',1)[1].split('function keepAllDrafts',1)[0]
        self.run_js(ui.DRAFT_STORE_JS+r'''
const assert=require('assert'), stored=new Map();
const draftStore=createDraftStore({getItem:k=>stored.get(k),setItem:(k,v)=>stored.set(k,v)},'node','main');
const field={tagName:'TEXTAREA',id:'memory',value:'My edit',maxLength:12000};
const form={id:'memory-form',dataset:{revision:'4'},querySelectorAll:()=>[field]};
const draftBaselines=new Map([[form,{memory:'Server'}]]),dirtyForms=new Set([form]),dialogueForm={},formKey=f=>f.id;
let currentSubmission=form,selectedFocus=null,reloads=0,loginCalls=0,mode='success',lastMessage='';
const document={querySelector:()=>null,querySelectorAll:()=>[]},scoped=x=>x,token='csrf-current';
const location={reload:()=>reloads++},message=text=>{lastMessage=text;return {}},keepAllDrafts=()=>true,showFocus=()=>{},loginRequired=()=>loginCalls++;
const fetch=async()=>{if(mode==='offline')throw Error('Failed to fetch');if(mode==='edited')field.value='More typing while request was in flight';return {status:mode==='expired'?401:200,ok:mode!=='expired',json:async()=>({message:'Saved'})}};
'''+keep+send+r'''
(async()=>{
draftStore.put('memory-form',{values:{memory:'My edit'}});draftStore.put('other-form',{values:{text:'Other unsaved draft'}});
await send('/api/dialogue/memory',{});assert.equal(draftStore.read()['memory-form'],undefined);assert.equal(draftStore.read()['other-form'].values.text,'Other unsaved draft');assert.equal(reloads,1);
field.value='Next edit';draftBaselines.set(form,{memory:'My edit'});dirtyForms.add(form);keepFormDraft(form);mode='offline';currentSubmission=form;await send('/api/dialogue/memory',{});assert.equal(draftStore.read()['memory-form'].values.memory,'Next edit');assert.equal(reloads,1);assert(lastMessage.includes('le résultat n’est pas confirmé'));assert(lastMessage.includes('peut-être déjà été appliquée'));assert(lastMessage.includes('Actualise puis vérifie l’état avant tout nouvel envoi.'));
mode='expired';currentSubmission=form;await send('/api/dialogue/memory',{});assert.equal(loginCalls,1);assert.equal(draftStore.read()['memory-form'].values.memory,'Next edit');assert.equal(reloads,1);
mode='edited';currentSubmission=form;await send('/api/dialogue/memory',{});assert.equal(draftStore.read()['memory-form'].values.memory,'More typing while request was in flight');assert.equal(draftStore.read()['memory-form'].base.memory,'Next edit');assert.equal(draftStore.read()['other-form'].values.text,'Other unsaved draft');assert.equal(reloads,2);
})().catch(error=>{console.error(error);process.exitCode=1});
''')
