import copy
import json
import math
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / 'bootstrap'))
import tao_integrability as integrability


def series(samples=None, bounds=None):
    return {'schema': 'tao.integrability.request.v1', 'quantity': 'Réserve déclarée',
            'unit': 'XPF', 'time_unit': 's',
            'reference': 'Exemple fictif fourni pour une vérification, pas un compte connecté.',
            'samples': [{'t': t, 'value': value, 'source_id': 'sample-' + str(i)}
                        for i, (t, value) in enumerate(samples if samples is not None else
                                                       [(0, 0), (3, 6), (10, 20)])],
            'bounds': bounds if bounds is not None else {
                'state': {'min': 0, 'max': 100}, 'trend': {'max_abs': 2},
                'trend_change': {'max_abs': 0}}}


class IntegrabilityTests(unittest.TestCase):
    def test_constant_rate_on_irregular_grid_has_zero_change(self):
        result = integrability.evaluate(series())
        self.assertEqual(result['status'], 'within_model_bounds')
        self.assertEqual([item['unit'] for item in result['orders']], ['XPF', '(XPF)/s', '(XPF)/s²'])
        self.assertEqual([item['required_samples'] for item in result['orders']], [1, 2, 3])
        self.assertEqual([item['value'] for item in result['observations']['trend']], [2, 2])
        self.assertEqual(result['observations']['trend_change'][0]['value'], 0)
        self.assertFalse(result['execution_enabled'])
        self.assertFalse(result['provenance']['verified'])

    def test_acceleration_uses_distance_between_interval_midpoints(self):
        # x(t)=t² at t=0,1,4. Interval velocities 1 and 5 live at .5 and 2.5;
        # their difference is 4 over 2 seconds, not over the last 3 seconds.
        result = integrability.evaluate(series([(0, 0), (1, 1), (4, 16)], {
            'state': {'max': 20}, 'trend': {'max_abs': 5}, 'trend_change': {'max_abs': 2}}))
        point = result['observations']['trend_change'][0]
        self.assertEqual(point['value'], 2)
        self.assertEqual((point['from_t'], point['to_t'], point['t']), (0.5, 2.5, 1.5))
        self.assertEqual(point['sample_indices'], [0, 1, 2])
        self.assertEqual(point['source_ids'], ['sample-0', 'sample-1', 'sample-2'])
        self.assertEqual(result['status'], 'within_model_bounds')

    def test_declared_bounds_are_inclusive_and_independent_at_all_orders(self):
        base = series([(0, 0), (1, 1), (4, 16)], {
            'state': {'min': 0, 'max': 16}, 'trend': {'max_abs': 5}, 'trend_change': {'max_abs': 2}})
        self.assertEqual(integrability.evaluate(base)['status'], 'within_model_bounds')
        for index, (key, maximum) in enumerate([('state', 15), ('trend', 4), ('trend_change', 1)]):
            payload = copy.deepcopy(base)
            payload['bounds'][key] = {'max_abs': maximum}
            result = integrability.evaluate(payload)
            with self.subTest(order=key):
                self.assertEqual(result['status'], 'exceeds')
                self.assertEqual(result['orders'][index]['status'], 'exceeds')
                self.assertTrue(result['orders'][index]['violations'])
                self.assertEqual(sum(row['status'] == 'exceeds' for row in result['orders']), 1)

    def test_minimum_can_fail_while_maximum_and_other_orders_hold(self):
        payload = series([(0, 2), (1, 0), (2, -2)])
        result = integrability.evaluate(payload)
        self.assertEqual(result['orders'][0]['violations'], [2])
        self.assertEqual(result['observations']['state'][2]['violation'], 'below_min')
        self.assertEqual(result['orders'][1]['status'], 'within_model_bounds')
        self.assertEqual(result['orders'][2]['status'], 'within_model_bounds')
        payload['bounds']['state'] = {'max': 2}
        self.assertEqual(integrability.evaluate(payload)['status'], 'within_model_bounds')

    def test_missing_bounds_are_unknown_not_zero_or_success(self):
        result = integrability.evaluate(series(bounds={}))
        self.assertEqual(result['status'], 'unknown')
        self.assertTrue(all(row['status'] == 'unknown' for row in result['orders']))
        self.assertTrue(all(row['reason'] == 'no_declared_bounds' for row in result['orders']))
        self.assertTrue(all(row['bounds'] is None for row in result['orders']))
        self.assertEqual(result['observations']['trend'][0]['value'], 2)
        limited = integrability.evaluate(series(bounds={'state': {'max': 100}}))
        self.assertEqual(limited['orders'][0]['status'], 'within_model_bounds')
        self.assertEqual(limited['status'], 'unknown')

    def test_declared_bounds_require_one_two_and_three_observations(self):
        for count in range(3):
            result = integrability.evaluate(series([(i, 0) for i in range(count)]))
            with self.subTest(count=count):
                self.assertEqual(result['status'], 'insufficient_data')
                for row in result['orders'][count:]:
                    self.assertEqual(row['status'], 'insufficient_data')
                    self.assertEqual(row['count'], 0)
                    self.assertIsNone(row['observed_range'])
        self.assertEqual(integrability.evaluate(series([], {}))['status'], 'unknown')

    def test_observed_violation_remains_visible_despite_missing_higher_orders(self):
        result = integrability.evaluate(series([(0, -1)]))
        self.assertEqual(result['status'], 'exceeds')
        self.assertEqual(result['orders'][1]['status'], 'insufficient_data')
        self.assertEqual(result['orders'][2]['status'], 'insufficient_data')
        del result['input']['bounds']['trend_change']
        again = integrability.evaluate(result['input'])
        self.assertEqual(again['status'], 'exceeds')
        self.assertEqual(again['orders'][2]['status'], 'unknown')

    def test_decimal_boundary_does_not_create_binary_rounding_false_alarm(self):
        result = integrability.evaluate(series([(0, 0.1), (1, 0.2), (2, 0.3)], {
            'state': {'min': 0.1, 'max': 0.3}, 'trend': {'max_abs': 0.1},
            'trend_change': {'max_abs': 0}}))
        self.assertEqual(result['status'], 'within_model_bounds')
        self.assertEqual(result['observations']['trend_change'][0]['value'], 0)

    def test_daily_basis_preserves_declared_decimal_boundary_without_float_conversion(self):
        payload = series([(0, 0.1), (1, 0.2), (2, 0.3)], {
            'state': {'max_abs': 1}, 'trend': {'max_abs': 0.1},
            'trend_change': {'max_abs': 0}})
        payload['time_unit'] = 'day'
        result = integrability.evaluate(payload)
        self.assertEqual(result['status'], 'within_model_bounds')
        self.assertEqual(result['input']['time_unit'], 'day')
        self.assertEqual([row['unit'] for row in result['orders']], ['XPF', '(XPF)/day', '(XPF)/day²'])
        self.assertEqual(result['observations']['trend'][0]['value'], 0.1)
        self.assertEqual(result['observations']['trend_change'][0]['value'], 0)

    def test_fixed_days_and_seconds_give_dimensionally_equivalent_results(self):
        daily = series([(0, 10), (1, 12), (3, 16)], {
            'state': {'min': 0}, 'trend': {'min': 0, 'max': 3}, 'trend_change': {'max_abs': 1}})
        daily['time_unit'] = 'day'
        seconds = copy.deepcopy(daily)
        seconds['time_unit'] = 's'
        for row in seconds['samples']:
            row['t'] *= 86400
        seconds['bounds']['trend']['max'] /= 86400
        seconds['bounds']['trend_change']['max_abs'] /= 86400 ** 2
        by_day = integrability.evaluate(daily)
        by_second = integrability.evaluate(seconds)
        self.assertEqual(by_day['status'], by_second['status'])
        self.assertAlmostEqual(by_day['observations']['trend'][0]['value'],
                               by_second['observations']['trend'][0]['value'] * 86400)
        self.assertEqual(by_day['observations']['trend_change'][0]['value'], 0)
        self.assertEqual(by_second['observations']['trend_change'][0]['value'], 0)

    def test_times_are_explicit_seconds_strictly_ordered_and_not_sorted(self):
        for points in [[(0, 0), (0, 1)], [(2, 0), (1, 0)], [(0, 0), (2, 0), (1, 0)]]:
            with self.subTest(points=points), self.assertRaises(ValueError):
                integrability.evaluate(series(points))
        for wrong in ['days', 'UTC', 1, None, ['s']]:
            payload = series()
            payload['time_unit'] = wrong
            with self.subTest(unit=wrong), self.assertRaises(ValueError):
                integrability.evaluate(payload)
        shifted = integrability.evaluate(series([(-10, 0), (-7, 6), (0, 20)]))
        self.assertEqual(shifted['status'], 'within_model_bounds')

    def test_times_and_values_and_bounds_reject_nonfinite_boolean_and_string_numbers(self):
        for bad in [True, False, None, '1', float('nan'), float('inf'), -float('inf'), [], {}, 10 ** 400]:
            for field in ['t', 'value']:
                payload = series()
                payload['samples'][0][field] = bad
                with self.subTest(field=field, value=repr(bad)), self.assertRaises(ValueError):
                    integrability.evaluate(payload)
            payload = series()
            payload['bounds']['state']['min'] = bad
            with self.subTest(field='bound', value=repr(bad)), self.assertRaises(ValueError):
                integrability.evaluate(payload)

    def test_mixed_currencies_or_units_are_rejected_without_implicit_conversion(self):
        for unit in ['EUR', 'USD', 'XPF/month']:
            payload = series()
            payload['samples'][0]['unit'] = unit
            with self.subTest(unit=unit), self.assertRaises(ValueError):
                integrability.evaluate(payload)
        payload = series()
        for sample in payload['samples']:
            sample['unit'] = 'XPF'
        result = integrability.evaluate(payload)
        self.assertEqual(result['input']['unit'], 'XPF')
        self.assertNotIn('conversion', result)

    def test_invalid_bound_shapes_cannot_be_silently_ignored(self):
        for bad in [None, [], 0, {}, {'max_abs': -1}, {'min': 2, 'max': 1},
                    {'max_abs': 2, 'min': 0}, {'unknown': 2}, {'max': 1, 'unit': 'EUR'}]:
            payload = series(bounds={'state': bad})
            with self.subTest(bound=bad), self.assertRaises(ValueError):
                integrability.evaluate(payload)
        for bad in [None, [], {'jerk': {'max_abs': 1}}, {'1': {'max_abs': 1}}]:
            payload = series()
            payload['bounds'] = bad
            with self.subTest(bounds=bad), self.assertRaises(ValueError):
                integrability.evaluate(payload)

    def test_unknown_commands_and_oversized_or_untrusted_fields_are_rejected(self):
        cases = [None, False, [], {}, dict(series(), execute=True),
                 dict(series(), schema='future'), dict(series(), unit=''),
                 dict(series(), quantity='x' * 121), dict(series(), unit='x' * 41),
                 dict(series(), reference='x' * 1001), dict(series(), reference='bad\nsource')]
        for extra in [{'value': 1}, {'t': 1}, {'t': 1, 'value': 1, 'execute': True},
                      {'t': 1, 'value': 1, 'source_id': 'x' * 121}]:
            cases.append(dict(series(), samples=[extra]))
        for payload in cases:
            with self.subTest(payload=payload), self.assertRaises(ValueError):
                integrability.evaluate(payload)

    def test_sample_limit_and_trace_are_bounded(self):
        maximum = series([(i, i) for i in range(200)], {
            'state': {'max': 200}, 'trend': {'max_abs': 1}, 'trend_change': {'max_abs': 0}})
        result = integrability.evaluate(maximum)
        self.assertEqual([row['count'] for row in result['orders']], [200, 199, 198])
        self.assertLess(len(json.dumps(result)), 200000)
        with self.assertRaises(ValueError):
            integrability.evaluate(series([(i, i) for i in range(201)]))

    def test_extreme_finite_difference_can_be_representable_without_intermediate_overflow(self):
        result = integrability.evaluate(series([(0, -1e308), (1e308, 1e308)], {}))
        self.assertEqual(result['observations']['trend'][0]['value'], 2)
        json.dumps(result, allow_nan=False)

    def test_unrepresentable_rates_do_not_become_infinity_or_silent_zero(self):
        for points in [[(0, 0), (1e-308, 1e308)], [(0, 0), (1e308, 1e-308)]]:
            with self.subTest(points=points), self.assertRaises(ValueError):
                integrability.evaluate(series(points, {}))

    def test_result_is_inert_and_independent_of_inputs_and_prior_results(self):
        payload = series()
        before = copy.deepcopy(payload)
        with patch('builtins.open') as files:
            result = integrability.evaluate(payload)
        files.assert_not_called()
        self.assertEqual(payload, before)
        result['input']['samples'][0]['value'] = 999
        result['orders'][0]['bounds']['max'] = -100
        self.assertEqual(payload, before)
        self.assertEqual(integrability.evaluate(payload)['status'], 'within_model_bounds')

    def test_sparse_samples_do_not_prove_unobserved_trajectory_or_future(self):
        # Both x(t)=0 and x(t)=10*sin(pi*t/2) fit these observations. The
        # second exceeds zero between samples; the calculator cannot see it.
        result = integrability.evaluate(series([(0, 0), (2, 0), (4, 0)], {
            key: {'max_abs': 0} for key in integrability.ORDER_KEYS}))
        self.assertGreater(10 * math.sin(math.pi / 2), 0)
        self.assertEqual(result['status'], 'within_model_bounds')
        self.assertEqual(result['scope'], 'provided_discrete_samples_and_declared_bounds')
        self.assertNotIn('safe', result)
        self.assertNotIn('forecast', result)
        self.assertTrue(any('entre mesures' in limit and 'futur' in limit for limit in result['limits']))


if __name__ == '__main__':
    unittest.main()
