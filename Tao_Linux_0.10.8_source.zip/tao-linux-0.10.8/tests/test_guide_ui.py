"""The beginner guide is descriptive, catalogue-backed and entirely read-only."""
import copy
import html
import http.client
import re
import threading
from http.server import ThreadingHTTPServer
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

from test_node import NodeHarness
from test_mobile_ui import Page
import tao_guide_ui as guide
import tao_logic as logic
import tao_foundations as foundations
import tao_worlds as worlds


class GuideUITests(NodeHarness):
    def test_guide_needs_no_private_state_token_or_script_and_keeps_catalogue_labels(self):
        before = self.n.STATE.read_bytes()
        with patch.object(self.n, 'load_state', side_effect=AssertionError('private state read')), \
                patch.object(self.n, 'load_raw_state', side_effect=AssertionError('private state read')), \
                patch.object(self.n, 'TOKEN', 'OWNER_SECRET_NEVER_IN_GUIDE'):
            for locale in ('fr', 'en'):
                page = guide.render(self.n, {'private_marker': 'PRIVATE_HISTORY_NEVER_IN_GUIDE'}, locale)
                parsed = Page(page)
                self.assertEqual(parsed.forms, [])
                self.assertEqual(len(parsed.ids), len(set(parsed.ids)))
                self.assertNotIn('<script', page)
                self.assertNotIn('OWNER_SECRET_NEVER_IN_GUIDE', page)
                self.assertNotIn('PRIVATE_HISTORY_NEVER_IN_GUIDE', page)
                self.assertIn('width=device-width,initial-scale=1', page)
                for term in logic.catalog(locale)['terms']:
                    self.assertIn('id="term-' + term['key'] + '"', page)
                    self.assertIn(html.escape(term['definition'], quote=True), page)
                    self.assertIn(html.escape(term['label'], quote=True), page)
                for anchor in re.findall('href="#([^"]+)"', page):
                    self.assertIn(anchor, parsed.ids)
        self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_catalogue_text_stays_inert_and_proposed_ideas_keep_their_status(self):
        catalogue = copy.deepcopy(logic.catalog('fr'))
        story = next(row for row in catalogue['terms'] if row['key'] == 'story')
        story.update(label='<img src=x onerror=alert(1)>', definition='</details><script>alert(1)</script>',
                     aliases=['javascript:execute()'])
        with patch.object(logic, 'catalog', return_value=catalogue):
            page = guide.render(self.n)
        self.assertNotIn('<img src=x', page)
        self.assertNotIn('<script>', page)
        self.assertIn('&lt;script&gt;', page)
        for key, status, label in [('steward', 'proposed', 'Proposé'),
                                   ('contextual_self', 'proposed', 'Proposé')]:
            term = next(row for row in catalogue['terms'] if row['key'] == key)
            self.assertEqual(term['implementation']['status'], status)
            entry = page.split('id="term-' + key + '"', 1)[1].split('</div></details>', 1)[0]
            self.assertIn('badge ' + status, entry)
            self.assertIn(label, entry)
        coordination = next(row for row in catalogue['formalisms']
                            if row['id'] == 'tao.logic.formalism.coordination')
        self.assertEqual(coordination['epistemic_status'], 'proposed')
        self.assertIn('ne constituent pas encore un intendant autonome livré', page)
        self.assertIn('ne récupère pas automatiquement vos anciennes conversations', page)
        self.assertIn('ne synchronise pas deux installations séparées', page)

    def test_links_keep_world_and_supported_locale_without_changing_legacy_routes(self):
        area = next(row for row in foundations.overview(self.n)['areas'] if row['key'] == 'work')
        with worlds.using(area['world_id']):
            page = guide.render(self.n, locale='en')
        self.assertIn('<html lang="en">', page)
        self.assertIn('The loop in five steps', page)
        links = [html.unescape(link) for link in re.findall('href="([^"]+)"', page) if link.startswith('/')]
        for link in links:
            path, params = urlsplit(link).path, parse_qs(urlsplit(link).query)
            if path == '/onboarding':
                self.assertEqual(params, {'world': ['main']})
            elif path in ('/explore', '/connect', '/trends', '/guide'):
                self.assertEqual(params['world'], [area['world_id']])
                self.assertIn(params['lang'], (['fr'], ['en']))
            elif path == '/':
                self.assertEqual(params, {'world': [area['world_id']], 'view': ['dialogue']})
            else:
                self.assertIn(path, ('/tools', '/devices'))
                self.assertEqual(params, {'world': [area['world_id']]})

    def test_real_guide_route_keeps_neighbor_memory_private_and_remains_read_only(self):
        area = next(row for row in foundations.overview(self.n)['areas'] if row['key'] == 'work')
        with worlds.using(area['world_id']):
            import tao_landmarks as landmarks
            landmarks.create(self.n, 'story', 'Privé', 'NEIGHBOR_MEMORY_SHOULD_NOT_APPEAR', 0)
        before = self.n.STATE.read_bytes()
        server = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        server.daemon_threads = True
        thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
        thread.start()
        try:
            for world in ('main', area['world_id']):
                connection = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=5)
                try:
                    connection.request('GET', '/guide?world=' + world + '&lang=en')
                    response = connection.getresponse()
                    text = response.read().decode()
                    self.assertEqual(response.status, 200, text[:1000])
                    self.assertIn('Understand Tao', text)
                    self.assertNotIn('NEIGHBOR_MEMORY_SHOULD_NOT_APPEAR', text)
                    self.assertNotIn('<script', text)
                finally:
                    connection.close()
        finally:
            server.shutdown(); thread.join(timeout=3); server.server_close()
        self.assertEqual(self.n.STATE.read_bytes(), before)
