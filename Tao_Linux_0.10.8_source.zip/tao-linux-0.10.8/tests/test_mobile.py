"""Real gateway and local node HTTP listeners; no Tailscale network is assumed."""
import concurrent.futures
import http.client
import json
import socket
import threading
import time
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from test_node import NodeHarness
import tao_mobile as mobile

ORIGIN = 'https://fixture.private.ts.net'
OWNER = 'owner@example.test'


def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


class MobileTests(NodeHarness):
    def test_paired_browser_can_prepare_and_verify_core_backup(self):
        self.associate()
        marker = self.n.add_buffer('Sauvegarde mobile', 'Conserver', 'Présent')
        status, body, _ = self.request('/api/backup/export?world=main', {'scope': 'core'})
        self.assertEqual(status, 200, body)
        exported = json.loads(body)
        self.assertIn(marker['id'], exported['bundle']['state']['buffers'])
        self.assertNotIn(self.n.TOKEN, body)
        status, body, _ = self.request('/api/backup/inspect?world=main', {'bundle': exported['bundle']})
        self.assertEqual(status, 200, body)
        self.assertEqual(json.loads(body)['schema'], 'tao.portable.core.preview.v1')
        self.assertGreater(mobile.MAX_BACKUP_BODY, mobile.MAX_RESPONSE)

    def test_workspace_pages_never_expose_upstream_credentials(self):
        self.associate()
        for path in ('/explore?lang=en', '/connect', '/trends'):
            status, page, _ = self.request(path)
            self.assertEqual(status, 200, page)
            self.assertNotIn(self.n.TOKEN, page)
            self.assertIn('const token=', page)

    def setUp(self):
        super().setUp()
        self.n.TOKEN = 'local-only-token-one'
        self.node = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        self.node.daemon_threads = True
        self.node.session_id = 'fixture-session'
        policy = self.n.policy(); policy['http_port'] = self.node.server_port
        self.n.policy = lambda: dict(policy)
        self.node_thread = threading.Thread(target=self.node.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
        self.node_thread.start()
        self.n.atomic_json(self.root / 'session.json', {'id': self.node.session_id, 'port': self.node.server_port, 'token': self.n.TOKEN})
        self.n.set_story('PRIVATE_TEST: mon histoire reste privée')
        self.port = free_port()
        mobile.configure(self.n, ORIGIN, OWNER, self.port)
        self.handle = mobile.start(self.n)
        self.cookie = None

    def tearDown(self):
        mobile.stop(self.handle)
        self.node.shutdown(); self.node_thread.join(timeout=3); self.node.server_close()
        super().tearDown()

    def request(self, path='/', data=None, headers=None, cookie=True, method=None):
        body = json.dumps(data).encode() if data is not None else None
        outgoing = {'Host': ORIGIN.removeprefix('https://'), 'Tailscale-User-Login': OWNER}
        if cookie and self.cookie:
            outgoing['Cookie'] = self.cookie
        if data is not None:
            outgoing.update({'Origin': ORIGIN, 'Content-Type': 'application/json', 'X-Tao-Token': 'browser-token'})
        for key, value in (headers or {}).items():
            if value is None:
                outgoing.pop(key, None)
            else:
                outgoing[key] = value
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=4)
        try:
            conn.request(method or ('POST' if data is not None else 'GET'), path, body, outgoing)
            response = conn.getresponse()
            return response.status, response.read().decode(), dict(response.getheaders())
        finally:
            conn.close()

    def associate(self, label='Téléphone de test'):
        invitation = mobile.pair(self.n, label)
        status, body, headers = self.request('/mobile/pair', {'code': invitation['code']}, cookie=False)
        self.assertEqual(status, 200, body)
        self.cookie = headers['Set-Cookie'].split(';', 1)[0]
        return invitation, headers['Set-Cookie']

    def test_all_reads_are_private_and_login_is_minimal(self):
        for path in ['/state', '/health', '/dialogue/export', '/continuity/export', '/dialogue/context?id=abc',
                     '/dialogue/archive?id=abc', '/lexicon', '/api/adaptation?id=abc', '/lens/snapshot']:
            status, body, _ = self.request(path)
            self.assertEqual(status, 401, path)
            self.assertEqual(json.loads(body)['login_url'], '/mobile/login')
            self.assertNotIn('PRIVATE_TEST', body)
        for path in ['/', '/?world=main', '/mobile/login']:
            status, body, _ = self.request(path)
            self.assertEqual(status, 200)
            self.assertIn('Code d’association', body)
            self.assertNotIn('PRIVATE_TEST', body)
            self.assertNotIn(self.n.TOKEN, body)

    def test_pair_code_single_use_hashes_only_secure_cookie_and_local_state(self):
        invitation, cookie = self.associate()
        for flag in ['Secure', 'HttpOnly', 'SameSite=Strict', 'Path=/']:
            self.assertIn(flag, cookie)
        self.assertTrue(cookie.startswith('__Host-tao-mobile='))
        raw = (self.root / 'mobile.json').read_text()
        self.assertNotIn(invitation['code'], raw)
        self.assertNotIn(self.cookie.split('=', 1)[1], raw)
        self.assertEqual((self.root / 'mobile.json').stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.request('/mobile/pair', {'code': invitation['code']}, cookie=False)[0], 403)
        status, body, _ = self.request('/state')
        self.assertEqual(status, 200, body)
        self.assertIn('PRIVATE_TEST', body)
        public = json.dumps(mobile.status(self.n))
        self.assertNotIn('hash', public)
        self.assertNotIn(invitation['code'], public)
        self.assertNotIn(self.cookie.split('=', 1)[1], public)
        self.assertTrue(mobile.status(self.n)['running'], repr((mobile.status(self.n), self.n.load_json(self.root / 'mobile-listener.json'))))

    def test_owner_identity_and_external_host_required_even_with_cookie(self):
        self.associate()
        for headers in [{'Tailscale-User-Login': None}, {'Tailscale-User-Login': 'other@example.test'},
                        {'Host': 'evil.example'}, {'Host': '127.0.0.1:' + str(self.port)},
                        {'Host': 'fixture.private.ts.net.evil.example'}]:
            self.assertEqual(self.request('/state', headers=headers)[0], 403)
        # Funnel lacks the identity header, so it cannot even expose the login.
        self.assertEqual(self.request('/mobile/login', headers={'Tailscale-User-Login': None})[0], 403)

    def test_csrf_origin_custom_header_and_json_required(self):
        self.associate()
        data = {'text': 'new story'}
        for headers in [{'Origin': 'https://evil.example'}, {'Origin': None}, {'X-Tao-Token': None}]:
            self.assertEqual(self.request('/api/story', data, headers)[0], 403)
        self.assertEqual(self.request('/api/story', data, {'Content-Type': 'text/plain'})[0], 415)
        self.assertEqual(self.request('/api/story', data, cookie=False)[0], 401)
        self.assertIn('PRIVATE_TEST', self.n.story()['text'])

    def test_post_rewrites_local_boundary_token_freshly_and_executes_once(self):
        self.associate()
        self.n.TOKEN = 'local-token-after-node-restart'
        self.n.atomic_json(self.root / 'session.json', {'id': 'new-session', 'port': self.node.server_port, 'token': self.n.TOKEN})
        with patch.object(self.n, 'set_story', wraps=self.n.set_story) as called:
            status, body, _ = self.request('/api/story', {'text': 'Une histoire envoyée du téléphone'},
                                         {'X-Tao-Token': 'obsolete-browser-token', 'X-Forwarded-Host': 'evil.example'})
        self.assertEqual(status, 200, body)
        self.assertEqual(called.call_count, 1)
        self.assertEqual(self.n.story()['text'], 'Une histoire envoyée du téléphone')

    def test_world_query_and_existing_authority_routes_preserved(self):
        self.associate()
        status, body, _ = self.request('/api/worlds/create', {'title': 'Famille', 'parent_id': 'main', 'description': '', 'revision': 0})
        self.assertEqual(status, 200, body)
        ident = json.loads(body)['id']
        status, body, _ = self.request('/api/story?world=' + ident, {'text': 'Une histoire dans cet espace seulement'})
        self.assertEqual(status, 200, body)
        self.assertIn('PRIVATE_TEST', self.n.story()['text'])
        status, body, _ = self.request('/state?world=' + ident)
        self.assertEqual(status, 200, body)
        self.assertIn('Une histoire dans cet espace seulement', body)
        self.assertNotIn('PRIVATE_TEST', body)
        self.assertEqual(self.request('/api/stop?world=main', {})[0], 403)
        self.assertFalse(self.n.STOP.is_set())

    def test_cookie_survives_gateway_restart_but_revocation_is_immediate(self):
        self.associate()
        mobile.stop(self.handle); self.handle = None
        self.assertTrue(mobile.status(self.n)['restart_required'])
        self.handle = mobile.start(self.n)
        self.assertEqual(self.request('/state')[0], 200)
        ident = mobile.status(self.n)['sessions'][0]['id']
        mobile.revoke(self.n, ident)
        self.assertEqual(self.request('/state')[0], 401)
        self.assertEqual(mobile.status(self.n)['sessions'], [])

    def test_pairing_expiry_and_session_expiry_are_enforced(self):
        invitation = mobile.pair(self.n)
        with patch.object(mobile.time, 'time', return_value=invitation['expires_at']):
            self.assertEqual(self.request('/mobile/pair', {'code': invitation['code']}, cookie=False)[0], 403)
        self.associate()
        expires = mobile.status(self.n)['sessions'][0]['expires_at']
        with patch.object(mobile.time, 'time', return_value=expires):
            self.assertEqual(self.request('/state')[0], 401)

    def test_device_limit_rotation_and_disable(self):
        first, _ = self.associate()
        for index in range(mobile.MAX_SESSIONS - 1):
            self.associate('Appareil ' + str(index))
        with self.assertRaisesRegex(ValueError, 'Huit'):
            mobile.pair(self.n)
        mobile.configure(self.n, ORIGIN, OWNER, self.port)
        self.assertEqual(len(mobile.status(self.n)['sessions']), mobile.MAX_SESSIONS)
        mobile.configure(self.n, ORIGIN, 'new@example.test', self.port)
        self.assertEqual(mobile.status(self.n)['sessions'], [])
        self.assertTrue(mobile.status(self.n)['restart_required'])
        self.assertEqual(self.request('/state')[0], 503)
        mobile.disable(self.n)
        self.assertEqual(self.request('/state')[0], 503)
        self.assertFalse(mobile.status(self.n)['enabled'])

    def test_configuration_refuses_public_http_ports_and_other_origin_parts(self):
        for origin in ['http://fixture.private.ts.net', 'https://example.com', 'https://ts.net',
                       'https://fixture.private.ts.net/path', 'https://fixture.private.ts.net#fragment',
                       'https://user@fixture.private.ts.net', 'https://fixture.private.ts.net:1234',
                       'https://fixture.private.ts.net?x=y', 'https://-invalid.private.ts.net']:
            with self.assertRaises(ValueError, msg=origin):
                mobile.configure(self.n, origin, OWNER, self.port)
        with self.assertRaises(ValueError):
            mobile.configure(self.n, ORIGIN, OWNER, self.node.server_port)
        self.assertEqual(mobile.configure(self.n, ORIGIN + ':8443', OWNER, self.port)['origin'], ORIGIN + ':8443')

    def raw_request(self, extra, path='/api/story', body=b'{}'):
        headers = ('POST ' + path + ' HTTP/1.1\r\nHost: fixture.private.ts.net\r\n'
                   'Tailscale-User-Login: ' + OWNER + '\r\nOrigin: ' + ORIGIN + '\r\n'
                   'X-Tao-Token: fixture\r\nContent-Type: application/json\r\n'
                   'Cookie: ' + self.cookie + '\r\n' + extra + '\r\n').encode()
        with socket.create_connection(('127.0.0.1', self.port), timeout=4) as sock:
            sock.sendall(headers + body)
            response = sock.recv(4096)
        return int(response.split(b' ', 2)[1])

    def test_malformed_framing_and_oversized_body_never_reach_node(self):
        self.associate()
        self.assertEqual(self.raw_request('Content-Length: 2\r\nContent-Length: 2\r\n'), 400)
        self.assertEqual(self.raw_request('Content-Length: 2\r\nTransfer-Encoding: chunked\r\n'), 400)
        self.assertEqual(self.raw_request('Content-Length: 32769\r\n'), 413)
        self.assertEqual(self.raw_request('Content-Length: 2\r\n', path='http://evil.example/api/story'), 400)
        self.assertIn('PRIVATE_TEST', self.n.story()['text'])

    def test_backend_unavailable_does_not_retry_write_and_local_origin_remains_strict(self):
        self.associate()
        (self.root / 'session.json').unlink()
        with patch.object(self.n, 'set_story', wraps=self.n.set_story) as called:
            self.assertEqual(self.request('/api/story', {'text': 'not applied'})[0], 503)
        self.assertEqual(called.call_count, 0)
        conn = http.client.HTTPConnection('127.0.0.1', self.node.server_port, timeout=4)
        conn.request('GET', '/state', headers={'Host': 'fixture.private.ts.net'})
        response = conn.getresponse(); response.read(); conn.close()
        self.assertEqual(response.status, 403)

    def test_simultaneous_pair_redemption_creates_only_one_session(self):
        invitation = mobile.pair(self.n)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            requests = [pool.submit(self.request, '/mobile/pair', {'code': invitation['code']}, cookie=False)
                        for _ in range(2)]
            statuses = sorted(future.result()[0] for future in requests)
        self.assertEqual(statuses, [200, 403])
        self.assertEqual(len(mobile.status(self.n)['sessions']), 1)

    def test_response_limit_and_redirect_are_not_forwarded(self):
        self.associate()
        with patch.object(mobile, 'MAX_RESPONSE', 32):
            status, body, _ = self.request('/state')
        self.assertEqual(status, 502)
        self.assertNotIn('PRIVATE_TEST', body)

        def redirect(handler):
            handler.send_response(302)
            handler.send_header('Location', 'https://example.invalid/private')
            handler.send_header('Content-Length', '0')
            handler.end_headers()

        with patch.object(self.n.Handler, 'scoped_GET', redirect):
            status, body, headers = self.request('/state')
        self.assertEqual(status, 502)
        self.assertNotIn('Location', headers)

    def test_new_invitation_and_revoke_all_cancel_old_pairing_codes(self):
        previous = mobile.pair(self.n)
        current = mobile.pair(self.n)
        self.assertEqual(self.request('/mobile/pair', {'code': previous['code']}, cookie=False)[0], 403)
        mobile.revoke(self.n)
        self.assertEqual(self.request('/mobile/pair', {'code': current['code']}, cookie=False)[0], 403)
        mobile.disable(self.n)
        self.assertIsNone(mobile.start(self.n))

    def test_failed_listener_start_removes_its_marker_and_releases_port(self):
        mobile.stop(self.handle); self.handle = None
        with patch.object(mobile.threading.Thread, 'start', side_effect=RuntimeError('fixture thread failure')):
            with self.assertRaisesRegex(RuntimeError, 'fixture thread failure'):
                mobile.start(self.n)
        self.assertFalse((self.root / 'mobile-listener.json').exists())
        self.assertTrue(mobile.status(self.n)['restart_required'])
        self.handle = mobile.start(self.n)
        self.assertTrue(mobile.status(self.n)['running'])

    def test_corrupt_config_fails_closed_without_affecting_local_node(self):
        row = self.n.load_json(self.root / 'mobile.json')
        row['sessions'] = [{'expires_at': 'invalid'}]
        self.n.atomic_json(self.root / 'mobile.json', row)
        with self.assertRaisesRegex(ValueError, 'Session mobile illisible'):
            mobile.status(self.n)
        self.assertEqual(self.request('/state')[0], 503)
        conn = http.client.HTTPConnection('127.0.0.1', self.node.server_port, timeout=4)
        conn.request('GET', '/state')
        response = conn.getresponse(); body = response.read(); conn.close()
        self.assertEqual(response.status, 200, body)

    def test_ambiguous_post_failure_does_not_suggest_blind_retry(self):
        self.associate()
        def interrupted_after_write(handler):
            handler.rfile.read(int(handler.headers['Content-Length']))
            self.n.set_story('Applied before connection closed')
            handler.close_connection = True
        with patch.object(self.n.Handler, 'scoped_POST', interrupted_after_write):
            status, body, _ = self.request('/api/story', {'text': 'sent'})
        self.assertEqual(status, 503)
        self.assertIn('résultat de cette action est inconnu', body)
        self.assertIn('vérifier son état', body)
        self.assertNotIn('Réessayer dans quelques secondes', body)
        self.assertEqual(self.n.story()['text'], 'Applied before connection closed')
