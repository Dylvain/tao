"""Device onboarding keeps scope, secrets and remote-code review explicit."""
import json
import os
import shutil
import subprocess
from unittest.mock import patch

from test_node import NodeHarness
from test_mobile_ui import Page
import tao_devices_ui as ui
import tao_worlds as worlds


class DevicesUITests(NodeHarness):
    def run_js(self, source, syntax=False):
        node = os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node:
            self.skipTest('Node optional: browser behavior check')
        path = self.base / 'devices-ui.js'
        path.write_text(source)
        result = subprocess.run([node, *(['--check'] if syntax else []), str(path)],
                                capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_render_is_mobile_and_script_cannot_be_closed_by_buffer_text(self):
        s = self.n.load_state()
        b = self.n.make_buffer('visible', 'user', '</script><img src=x onerror=attack()>')
        b.update(desired='Du code utile', acceptance='Un test reproductible')
        s['buffers'][b['id']] = b
        for ident, extra in [('need', {'dialogue_need': {}}), ('task', {'work_task': {}}),
                             ('closed', {'status': 'resolved'}), ('observed', {'kind': 'resource'})]:
            hidden = dict(b, id=ident, residual='secret-' + ident, **extra)
            s['buffers'][ident] = hidden
        page = ui.page(self.n, s)
        parsed = Page(page)
        self.assertEqual(len(parsed.ids), len(set(parsed.ids)))
        self.assertIn('width=device-width,initial-scale=1', page)
        self.assertEqual(page.count('</script>'), 1)
        self.assertNotIn('<img src=x onerror=attack()>', page)
        self.assertIn(r'\u003c/script>', page)
        for ident in ('need', 'task', 'closed', 'observed'):
            self.assertNotIn('secret-' + ident, page)
        self.run_js(page.split('<script>')[1].split('</script>')[0], syntax=True)

    def test_help_preserves_existing_draft_and_never_restores_authorization(self):
        self.run_js(ui.DRAFT_STORE_JS + ui.GUIDE_JS + r'''
const assert=require('assert'),data=new Map();
const storage={getItem:key=>data.get(key),setItem:(key,value)=>data.set(key,value)};
const text=connectionQuestion('linux','Git n’est pas installé');
keepConnectionQuestion(storage,'node','work',text);
const saved=createDraftStore(storage,'node','work').read()['dialogue-send'];
assert.equal(saved.values['dialogue-text'],text);assert.equal(saved.values['dialogue-intent'],'understand');
assert.deepEqual(saved.extra,{selectedFocus:null});assert.equal(saved.revision,null);
assert.deepEqual(createDraftStore(storage,'node','family').read(),{});
assert.throws(()=>keepConnectionQuestion(storage,'node','work','Remplacer'),/brouillon/);
assert.equal(createDraftStore(storage,'node','work').read()['dialogue-send'].values['dialogue-text'],text);
assert.throws(()=>keepConnectionQuestion(storage,'node','main','x'.repeat(6001)));
assert.throws(()=>keepConnectionQuestion({getItem:()=>null,setItem:()=>{throw Error('Quota')}},'node','main','Aide-moi'),/Copie/);
assert(deviceGuides.windows.text.includes('ne fournit pas de moteur natif Windows'));
assert(deviceGuides.mac.text.includes('aucun adaptateur macOS'));
assert(deviceGuides.other.text.includes('Aucun accès'));
assert.equal(shellQuote("https://example.test'bad"),"'https://example.test'\"'\"'bad'");
''')

    def test_scope_and_login_are_fixed_by_context(self):
        child = worlds.create(self.n, 'Travail', revision=0)
        with worlds.using(child['id']), patch.dict(os.environ, {'TAO_HOSTED': '1'}):
            page = ui.page(self.n, self.n.load_state())
        config = json.loads(page.split('const config=', 1)[1].split(';\n', 1)[0])
        self.assertEqual(config['world'], child['id'])
        self.assertEqual(config['login'], '/host/login')
        self.assertIn("url.searchParams.set('world',config.world)", page)
        self.assertIn('Tao hébergé reste accessible quand ton PC est éteint', page)
        self.assertIn('Codex peut exécuter des commandes', page)
        self.assertIn('tao device permissions --allow-tests', page)
        self.assertNotIn('tao device run --allow-tests', page)

    def test_review_requires_unchecked_consent_and_exact_snapshot(self):
        # Exercise the actual page controller using a tiny inert DOM. Remote
        # values become text nodes; neither reported code nor labels are HTML.
        setup = r'''
const assert=require('assert');
class Element{
 constructor(tag){this.tagName=tag;this.children=[];this.value='';this.textContent='';this.checked=false;this.dataset={};this.classList={toggle:()=>{}};this.disabled=false}
 append(...items){this.children.push(...items)} appendChild(item){this.children.push(item);return item}
 replaceChildren(...items){this.children=[...items];this.textContent=''}
 setAttribute(){} removeAttribute(){} scrollIntoView(){} focus(){}
 get options(){return this.children}
 set innerHTML(value){throw Error('Unsafe HTML: '+value)}
}
const nodes=new Map(),document={hidden:false,body:new Element('body'),createElement:tag=>new Element(tag),getElementById:id=>{if(!nodes.has(id))nodes.set(id,new Element('div'));return nodes.get(id)}};
document.getElementById('device-kind').value='linux';
const location={origin:'https://tao.example.test',href:''},setInterval=()=>{};
const token='owner-csrf',config={node:'n',world:'space-a',login:'/host/login',needs:[],buffers:[{id:'b',residual:'<img onerror=bad()>',goal:'But relu',acceptance:'Preuve relue'}]};
const state={revision:3,devices:[{id:'d',label:'<script>bad()</script>',pairing_label:'PC',machine_id:'m',status:'approved',last_seen_at:'2026-09-28',presence:{repo_head:'a'.repeat(40),git:true,python:true,codex:true,clean:true,allow_tests:true,platform:'Linux'}}],jobs:[{id:'j',device_id:'d',buffer_id:'b',status:'review'}],pairings:[],budget:{runs_reserved:1,runs_limit:3,seconds_reserved:600,seconds_limit:1800}};
const job={id:'j',device_id:'d',status:'review',revision:3,review_digest:'b'.repeat(64),patch:'<script>patch()</script>',residual:'Écart',goal:'But',acceptance:'Preuve',generation_result:{summary:'<img src=x>'}};
const calls=[];
const fetch=async(path,options)=>{calls.push({path,options});const body=options.body?JSON.parse(options.body):null;return {ok:true,status:200,json:async()=>path.startsWith('/api/devices/job?')?job:body&&path.startsWith('/api/devices/jobs?')?{id:'j'}:body&&path.startsWith('/api/devices/pair?')?{code:'one-use-secret',expires_at:'later'}:state}};
function all(node){return [node,...node.children.flatMap(all)]}
'''
        checks = r'''
(async()=>{
 await new Promise(setImmediate);
 assert(calls.every(call=>call.path.includes('world=space-a')));
 assert.equal(nodes.get('no-needs-link').href,'/?view=dialogue&world=space-a#continuity-panel');
 assert.equal(nodes.get('manual-buffer-link').href,'/?view=dialogue&world=space-a#advanced');
 assert(all(nodes.get('device-list')).some(node=>node.textContent==='<script>bad()</script>'));
 await openJob('j');
 const panel=nodes.get('job-detail'),form=all(panel).find(node=>node.tagName==='form'),check=all(form).find(node=>node.tagName==='input');
 assert.equal(check.required,true);assert.equal(check.checked,false);
 assert(all(panel).some(node=>node.tagName==='pre'&&node.textContent==='<script>patch()</script>'));
 const before=calls.length;form.onsubmit({preventDefault(){}});await new Promise(setImmediate);assert.equal(calls.length,before);
 check.checked=true;form.onsubmit({preventDefault(){}});await new Promise(setImmediate);
 const verify=calls.find(call=>call.options.body&&JSON.parse(call.options.body).action==='verify');
 assert(verify);assert.equal(verify.options.headers['X-Tao-Token'],'owner-csrf');
 assert.deepEqual(JSON.parse(verify.options.body),{id:'j',action:'verify',revision:3,review_digest:'b'.repeat(64),confirmed:true});
 nodes.get('job-buffer').value='b';nodes.get('job-device').value='d';
 nodes.get('job-form').onsubmit({preventDefault(){}});await new Promise(setImmediate);
 const enqueue=calls.find(call=>call.options.body&&call.path.startsWith('/api/devices/jobs?'));
 assert.deepEqual(JSON.parse(enqueue.options.body).expected_snapshot,{residual:'<img onerror=bad()>',goal:'But relu',acceptance:'Preuve relue'});
 assert.equal(calls.filter(call=>call.path.includes('/api/dialogue')).length,0);
 document.getElementById('pair-label').value='PC';nodes.get('pair-form').onsubmit({preventDefault(){}});await new Promise(setImmediate);
 assert.equal(nodes.get('pair-secret').textContent,'one-use-secret');
 nodes.get('hide-code').onclick();assert.equal(nodes.get('pair-secret').textContent,'');
 assert.equal(nodes.get('pair-result').hidden,true);
 assert(!calls.some(call=>call.path.includes('one-use-secret')));
})().catch(error=>{console.error(error);process.exitCode=1});
'''
        self.run_js(setup + ui.GUIDE_JS + ui.PAGE_JS + checks)

    def test_expired_session_cannot_choose_an_external_login(self):
        request = 'async function request' + ui.PAGE_JS.split('async function request', 1)[1].split('async function perform', 1)[0]
        self.run_js(r'''
const assert=require('assert'),added=[];
const config={login:'/host/login'},token='csrf',scoped=path=>path,notify=()=>{},el=(tag,text)=>({}),$=()=>({appendChild:node=>added.push(node)});
const fetch=async()=>({status:401,ok:false,json:async()=>({login_url:'https://attacker.test'})});
''' + request + r'''
(async()=>{await assert.rejects(()=>request('/api/devices'),error=>error.alreadyShown===true);assert.equal(added[0].href,'/host/login')})().catch(error=>{console.error(error);process.exitCode=1});
''')
