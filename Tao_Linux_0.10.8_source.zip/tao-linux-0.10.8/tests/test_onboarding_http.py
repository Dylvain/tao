"""Real owner HTTP flow, imports as context and a read-only machine inventory."""
import base64
import copy
import http.client
import io
import json
import threading
import zipfile
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from test_node import NodeHarness
import tao_dialogue as dialogue
import tao_onboarding_routes as onboarding_routes
import tao_worlds as worlds


def packet():
    return {'schema': 'tao.history_import.v1', 'id': 'http-history', 'title': 'Mon histoire',
            'sources': [{'id': 's1', 'label': 'Citation extérieure', 'kind': 'user_quote',
                         'text': 'Je voudrais apprendre la culture des orchidées.'}],
            'spaces': [{'key': 'jardin', 'parent_key': 'main', 'title': 'Mon jardin',
                        'description': 'Mes plantes', 'story': 'Comprendre mes orchidées.',
                        'source_ids': ['s1'], 'notes': [{'kind': 'question',
                        'text': 'Comment prendre soin des orchidées ?', 'source_ids': ['s1']}],
                        'needs': []}]}


def archive():
    return {'conversations': [{'id': 'chat-1', 'title': 'Informatique Python orchidées',
                              'messages': [{'id': 'human-1', 'role': 'user',
                                            'text': 'Je veux programmer un suivi orchidées dans Python.'},
                                           {'id': 'ai-1', 'role': 'assistant',
                                            'text': 'Exemple historique orchidées Python à vérifier.'}]}]}


def chatgpt_archive():
    def message(ident, role, text):
        return {'id': ident, 'author': {'role': role},
                'content': {'content_type': 'text', 'parts': [text]}}
    return [{'id': 'chat-zip', 'title': 'Projet orchidées', 'current_node': 'reply',
             'mapping': {
                 'root': {'parent': None, 'message': None},
                 'question': {'parent': 'root', 'message': message(
                     'question', 'user', 'Je veux automatiser le suivi de mes orchidées.')},
                 'reply': {'parent': 'question', 'message': message(
                     'reply', 'assistant', 'Voici une ancienne proposition à vérifier.')},
             }}]


def claude_archive():
    return [{'uuid': 'claude-zip', 'name': 'Projet orchidées', 'chat_messages': [
        {'uuid': 'claude-question', 'sender': 'human',
         'text': 'Je veux automatiser le suivi de mes orchidées.',
         'content': [{'type': 'text', 'text': 'Je veux automatiser le suivi de mes orchidées.'}]},
        {'uuid': 'claude-reply', 'sender': 'assistant',
         'text': 'Voici une ancienne proposition à vérifier.',
         'content': [{'type': 'text', 'text': 'Voici une ancienne proposition à vérifier.'}]},
    ]}]


def archive_zip(entries):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for name, value in entries:
            bundle.writestr(name, value if isinstance(value, bytes) else json.dumps(value))
    return base64.b64encode(stream.getvalue()).decode('ascii')


class OnboardingHTTPTests(NodeHarness):
    def setUp(self):
        super().setUp()
        self.n.TOKEN = 'owner-history-fixture'
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'poll_interval': .02}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.thread.join(timeout=3); self.server.server_close()
        super().tearDown()

    def request(self, path, body=None, owner=True, raw=False):
        headers = {'Content-Type': 'application/json'}
        if owner:
            headers['X-Tao-Token'] = self.n.TOKEN
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        try:
            connection.request('GET' if body is None else 'POST', path,
                               body if raw else None if body is None else json.dumps(body), headers)
            response = connection.getresponse()
            data = response.read().decode()
            return response.status, json.loads(data) if 'json' in response.getheader('Content-Type', '') else data
        finally:
            connection.close()

    def good(self, path, body=None):
        status, value = self.request(path, body)
        self.assertEqual(status, 200, value)
        return value

    def test_prepared_import_requires_owner_current_review_and_never_replays(self):
        data = packet(); before = self.n.STATE.read_bytes(); policy = self.n.policy()
        self.assertIn('Reprendre mes conversations', self.good('/onboarding'))
        self.assertEqual(self.request('/api/onboarding/preview', {'document': data}, owner=False)[0], 403)
        preview = self.good('/api/onboarding/preview', {'document': data})
        self.assertEqual(self.n.STATE.read_bytes(), before)
        request = {'document': data, 'review_digest': preview['review_digest']}
        self.assertEqual(self.request('/api/onboarding/apply', request)[0], 400)
        wrong = copy.deepcopy(request); wrong['confirmed'] = True
        wrong['document']['spaces'][0]['story'] = 'Autre histoire.'
        self.assertEqual(self.request('/api/onboarding/apply', wrong)[0], 400)
        request['confirmed'] = True
        result = self.good('/api/onboarding/apply', request)
        ident = result['spaces'][0]['id']
        self.assertEqual(self.n.policy(), policy)
        self.assertNotIn('dialogue', self.n.load_state())
        with worlds.using(ident):
            state = self.n.load_state()
            self.assertEqual(state['continuity']['notes'][0]['source'], 'external_history_import')
            self.assertEqual(state['continuity']['notes'][0]['status'], 'proposed')
        self.assertTrue(self.good('/api/onboarding/apply', request)['already_imported'])
        self.assertEqual(self.request('/api/onboarding/preview?world='+ident, {'document': data})[0], 400)

    def test_ambiguous_fields_and_authority_are_rejected(self):
        before = self.n.STATE.read_bytes()
        text = json.dumps({'document': packet()})[:-1] + ',"document": {}}'
        self.assertEqual(self.request('/api/onboarding/preview', text, raw=True)[0], 400)
        self.assertEqual(self.request('/api/onboarding/preview', {'document': packet(), 'policy': {}})[0], 400)
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertEqual(len(worlds.describe(self.n)['spaces']), 9)

    def test_environment_runs_no_program_and_never_claims_a_login(self):
        with patch.object(self.n.adaptation, 'executable', side_effect=lambda n, name: '/fixture/codex' if name == 'codex' else None), patch('subprocess.Popen', side_effect=AssertionError('No process expected')):
            value = self.good('/api/onboarding/environment')
        codex = next(row for row in value['tools'] if row['name'] == 'codex')
        self.assertTrue(codex['present']); self.assertIsNone(codex['authenticated'])
        self.assertFalse(value['execution_enabled'])
        self.assertNotIn('/fixture/codex', json.dumps(value))

    def test_native_archive_is_kept_in_its_world_and_used_as_unverified_context(self):
        original = archive()
        preview = self.good('/api/history/preview', {'archive': original})
        request = {'archive': original, 'review_digest': preview['review_digest'], 'confirmed': True,
                   'assignments': [{'conversation_id': x['conversation_id'], 'space_key': x['space_key']}
                                   for x in preview['assignments']]}
        receipt = self.good('/api/history/apply', request)
        found = None
        for row in receipt['spaces']:
            results = self.good('/api/history/search?world='+row['id']+'&q=orchid%C3%A9es')
            if results['excerpts']:
                found = row['id']
                break
        self.assertIsNotNone(found)
        self.assertEqual(self.good('/api/history/search?q=orchid%C3%A9es')['excerpts'], [])
        self.assertIn('Mes conversations importées', self.good('/history?world='+found))
        with worlds.using(found):
            state = self.n.load_state()
            dialogue.ensure(state)['messages'] = [{'id': 'now', 'role': 'user',
                                                   'text': 'Retrouve mon suivi orchidées Python.',
                                                   'source': 'human', 'at': self.n.now()}]
            self.n.atomic_json(self.n.STATE, state, backup=True)
            context = dialogue.snapshot(self.n, self.n.load_state())
            self.assertFalse(context['imported_history']['excerpts'])
            discussion = self.n.load_state()['dialogue']
            # Importing into an existing template preserves its recall choice.
            # The owner enables it through the same memory endpoint as the UI.
            self.good('/api/dialogue/memory?world='+found,
                      {'text': discussion['memory'], 'revision': discussion['revision'], 'include_archives': True})
            context = dialogue.snapshot(self.n, self.n.load_state())
            self.assertTrue(context['imported_history']['excerpts'])
            self.assertEqual(context['imported_history']['authority'], 'unverified_import')
            self.assertEqual([m['id'] for m in context['messages']], ['now'])
        self.assertTrue(self.good('/api/history/apply', request)['already_imported'])

    def test_chatgpt_and_claude_zips_are_previewed_without_extracting_attachments(self):
        encoded = archive_zip([('conversations.json', chatgpt_archive()),
                               ('attachments/ignored.txt', b'private attachment')])
        before = self.n.STATE.read_bytes()
        preview = self.good('/api/history/preview', {'archive_zip': encoded})
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertEqual(preview['assignments'][0]['conversation_id'], 'chat-zip')
        claude = archive_zip([('conversations.json', claude_archive()),
                              ('users.json', {'account': 'not imported'})])
        claude_preview = self.good('/api/history/preview', {'archive_zip': claude})
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertEqual(claude_preview['assignments'][0]['conversation_id'], 'claude-zip')
        request = {'archive_zip': encoded, 'review_digest': preview['review_digest'],
                   'confirmed': True,
                   'assignments': [{'conversation_id': row['conversation_id'],
                                    'space_key': row['space_key']}
                                   for row in preview['assignments']]}
        receipt = self.good('/api/history/apply', request)
        self.assertFalse(receipt['already_imported'])
        self.assertTrue(self.good('/api/history/apply', request)['already_imported'])

    def test_ambiguous_unsafe_and_invalid_zips_are_counterexamples_without_writes(self):
        before = self.n.STATE.read_bytes()
        cases = [
            {'archive_zip': 'not base64!'},
            {'archive_zip': archive_zip([('other.json', archive())])},
            {'archive_zip': archive_zip([('conversations.json', archive()),
                                         ('nested/conversations.json', archive())])},
            {'archive_zip': archive_zip([('../unsafe.txt', b'x'),
                                         ('conversations.json', archive())])},
            {'archive_zip': archive_zip([('conversations.json', b'{broken')])},
            {'archive_zip': archive_zip([('conversations.json',
                                          b'{"conversations": [], "conversations": []}')])},
        ]
        for value in cases:
            status, result = self.request('/api/history/preview', value)
            self.assertEqual(status, 400, result)
            self.assertEqual(self.n.STATE.read_bytes(), before)
        with patch.object(onboarding_routes, 'MAX_ZIP_BYTES', 8):
            status, result = self.request('/api/history/preview',
                                          {'archive_zip': archive_zip([('conversations.json', archive())])})
        self.assertEqual(status, 400, result)
        self.assertIn('trop grande', result['error'])
        self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_cli_review_then_apply(self):
        path = self.base/'history.json'; path.write_text(json.dumps(packet()))
        preview = json.loads(self.cli('onboarding', 'preview', str(path)).stdout)
        refused = self.cli('onboarding', 'apply', str(path), '--review-digest', preview['review_digest'], check=False)
        self.assertNotEqual(refused.returncode, 0)
        result = json.loads(self.cli('onboarding', 'apply', str(path), '--review-digest', preview['review_digest'], '--confirm').stdout)
        self.assertEqual(result['counts']['new_spaces'], 1)
