import json
from unittest.mock import patch
from test_node import NodeHarness
from test_ecology import HEALTHY
import tao_adaptation as adapt
import tao_learning as learning
import tao_ecology as ecology
import tao_ui as ui


class LearningTests(NodeHarness):
    def installed(self):
        self.n.work.save_context(self.n,'PRIVATE_WORK','PRIVATE_PRACTICE','PRIVATE_LIMITS')
        b=self.n.work.add_task(self.n,'PRIVATE_TASK')
        b=self.n.work.save_example(self.n,b['id'],'PRIVATE_EXAMPLE','PRIVATE_EXPECTED')
        s=self.n.load_state(); s['buffers'][b['id']]['work_task']['adaptation_id']='012345abcdef'
        self.n.atomic_json(self.n.STATE,s,backup=True)
        row={'schema':'tao.adaptation.v1','id':'012345abcdef','task_id':b['id'],'status':'installed',
             'task_revision':2,'context_revision':1,'experiment_id':'abcdef012345','message':'Installée',
             'created_at':self.n.now(),'operation':'apply'}
        adapt.save(self.n,row)
        w=adapt.atelier.Workshop(self.n)
        w.save({'id':row['experiment_id'],'status':'accepted','accepted_commit':'fixture-commit',
                'verification':{'ok':True,'candidate_commit':'fixture-commit','unchanged_during_tests':True},'runs':[]})
        return self.n.load_state()['buffers'][b['id']],row

    def record(self,b,row,outcome='success',case='Exemple initial',observed='Résultat réel observé',remaining=''):
        return learning.report(self.n,b['id'],row['id'],outcome,case,observed,remaining,
                               self.n.load_state().get('learning',{}).get('revision',0))

    def method(self,report):
        values={'title':'Une méthode générique','applicability':'Un brouillon sans destinataire',
                'method':'Lister les informations manquantes avant de répondre.',
                'counterexample':'Un message urgent impose une revue humaine.',
                'check':'Comparer les informations demandées à la liste attendue.'}
        return learning.create_method(self.n,report['id'],values,True,self.n.load_state()['learning']['revision'])

    def test_tests_and_installation_do_not_prove_usefulness(self):
        b,row=self.installed(); original_policy=self.n.POLICY.read_bytes()
        self.assertEqual(learning.assessment(self.n.load_state(),b['id'])['status'],'unobserved')
        row['status']='verified'; adapt.save(self.n,row)
        with self.assertRaises(ValueError): self.record(b,row)
        row['status']='installed'; adapt.save(self.n,row)
        r=self.record(b,row,'partial',remaining='Le brouillon ne respecte pas une règle.')
        self.assertFalse(r['verified_automatically']); self.assertEqual(r['source'],'human_report')
        s=self.n.load_state(); self.assertEqual(s['buffers'][b['id']]['status'],'open')
        self.assertFalse(s['buffers'][b['id']]['work_task']['execution_enabled'])
        self.assertEqual(original_policy,self.n.POLICY.read_bytes())
        self.assertEqual(learning.assessment(s,b['id'])['status'],'needs_work')
        self.assertIn('retours',self.n.evolution_plan(s)[0]['next_step'])
        with self.assertRaises(ValueError): self.method(r)

    def test_duplicate_case_corrections_preserve_history_without_inflating_success(self):
        b,row=self.installed(); first=self.record(b,row)
        self.assertEqual(self.record(b,row),first)
        self.record(b,row,observed='Même cas vérifié de nouveau')
        self.assertEqual(learning.assessment(self.n.load_state(),b['id'])['cases'],1)
        self.record(b,row,'failure',observed='Une erreur est finalement apparue.',remaining='Corriger ce cas.')
        s=self.n.load_state(); self.assertEqual(len(s['learning']['reports']),3)
        self.assertEqual(learning.assessment(s,b['id'])['counts']['success'],0)
        self.assertEqual(learning.assessment(s,b['id'])['counts']['failure'],1)
        self.assertEqual(s['learning']['reports'][0],first)

    def test_stale_tabs_changed_context_and_invalid_reports_leave_state_intact(self):
        b,row=self.installed(); self.record(b,row); before=self.n.STATE.read_bytes()
        with self.assertRaises(ValueError): learning.report(self.n,b['id'],row['id'],'success','Autre','Observation',revision=0)
        with self.assertRaises(ValueError): self.record(b,row,'success',remaining='Pas tout à fait réussi')
        with self.assertRaises(ValueError): self.record(b,row,'failure')
        with self.assertRaises(ValueError): self.record(b,row,outcome=[])
        self.assertEqual(before,self.n.STATE.read_bytes())
        self.n.work.save_context(self.n,'Nouvelles contraintes',revision=1)
        with self.assertRaises(ValueError): self.record(b,row,case='Nouveau cas')
        self.assertEqual(learning.assessment(self.n.load_state(),b['id'])['status'],'unobserved')
        self.assertEqual(len(self.n.load_state()['learning']['reports']),1)

    def test_new_failure_withdrawal_and_context_change_block_transmission(self):
        b,row=self.installed(); r=self.record(b,row); m=self.method(r)
        self.assertEqual(len(learning.select_for_birth(self.n,self.n.load_state(),[m['id']])),1)
        self.record(b,row,'failure',case='Autre cas',remaining='Une contrainte oubliée')
        s=self.n.load_state(); self.assertEqual(s['learning']['methods'][0]['status'],'needs_review')
        with self.assertRaises(ValueError): learning.select_for_birth(self.n,s,[m['id']])
        self.record(b,row,'success',case='Autre cas',observed='Correction vérifiée')
        m2=self.method(self.record(b,row,case='Troisième cas'))
        learning.suspend_method(self.n,m2['id'],self.n.load_state()['learning']['revision'])
        with self.assertRaises(ValueError): learning.select_for_birth(self.n,self.n.load_state(),[m2['id']])
        m3=self.method(r)
        self.n.work.save_example(self.n,b['id'],'Autre situation','Autre objectif',revision=2)
        with self.assertRaises(ValueError): learning.select_for_birth(self.n,self.n.load_state(),[m3['id']])

    def test_birth_only_copies_selected_fields_as_unverified_data(self):
        b,row=self.installed(); r=self.record(b,row,observed='PRIVATE_FIELD_RESULT'); m=self.method(r)
        with patch.object(self.n,'observe_environment',return_value=HEALTHY):
            bare=ecology.birth(self.n,self.base/'bare','Nouveau projet',8791)
            child=ecology.birth(self.n,self.base/'child','Autre projet',8792,[m['id']])
        no_memory=json.loads((self.base/'bare/state.json').read_text())
        self.assertNotIn('learning',no_memory)
        data=json.loads((self.base/'child/state.json').read_text())
        inherited=data['learning']['inherited'][0]
        self.assertEqual(inherited['status'],'inherited_unverified')
        self.assertEqual(inherited['receiver_reports'],[])
        self.assertFalse(inherited['executable']); self.assertEqual(data['learning']['reports'],[])
        self.assertEqual(child['selected_method_ids'],[m['id']])
        self.assertFalse(child['private_memory_inherited']);self.assertFalse(child['permissions_inherited'])
        for path in (self.base/'child').glob('*.json'):self.assertNotIn('PRIVATE_',path.read_text())
        self.assertEqual(learning.selected_inherited(data,[]),[])
        self.assertEqual(learning.selected_inherited(data,[m['id']])[0]['method'],m['method'])
        with self.assertRaises(ValueError): learning.select_for_birth(self.n,data,[m['id']])
        with self.assertRaises(ValueError): learning.select_for_birth(self.n,self.n.load_state(),[m['id'],m['id']])

    def test_next_preparation_reuses_failures_without_other_tasks_or_new_authority(self):
        b,row=self.installed(); self.record(b,row,'partial',remaining='PRIVATE_RESIDUAL')
        foreign=dict(row,id='111111111111',task_id='other-task',message='OTHER_TASK_SECRET')
        adapt.save(self.n,foreign)
        row.update(status='test_failed',operation='verify',message='Même défaut rencontré',summary='Proposition encore non validée')
        adapt.save(self.n,row)
        workshop=adapt.atelier.Workshop(self.n)
        experiment=workshop.load(row['experiment_id']);experiment['status']='test_failed';workshop.save(experiment)
        ef=workshop._file(row['experiment_id']).parent
        (ef/'tests.log').write_text('Un test échoue : entrée manquante')
        context=learning.preparation_context(self.n,self.n.load_state(),b['id'])
        self.assertNotIn('OTHER_TASK_SECRET',json.dumps(context))
        self.assertEqual(context['previous_attempts'][0]['stage'],'test_failed')
        self.assertIn('entrée manquante',context['previous_attempts'][0]['test_log_excerpt'])
        self.assertEqual(context['reported_outcomes'][0]['remaining'],'PRIVATE_RESIDUAL')
        with patch.object(adapt,'diagnose',return_value={'ready':True,'source':str(self.base)}),patch.object(adapt,'launch'):
            new=adapt.request(self.n,b['id'],'generate')
        self.assertEqual(new['payload']['experience'],context)
        self.assertEqual(new['payload']['inherited_methods'],[])
        self.assertFalse(new['duty_execution_authorized'])

    def test_capacity_does_not_delete_residuals_and_memory_has_no_basal_ai(self):
        b,row=self.installed(); self.record(b,row,'failure',remaining='Un cas rare à garder')
        with patch.object(learning,'MAX_REPORTS',1):
            before=self.n.STATE.read_bytes()
            with self.assertRaises(ValueError): self.record(b,row,case='Autre cas')
            self.assertEqual(before,self.n.STATE.read_bytes())
        with patch.object(self.n.urllib.request,'urlopen') as net,patch.object(adapt,'launch') as launch:
            s=self.n.cycle();net.assert_not_called();launch.assert_not_called()
        self.assertEqual(len(s['learning']['reports']),1)
        self.assertEqual(s['resource_profile']['external_ai_calls'],0)

    def test_interface_escapes_observations_and_keeps_one_clear_next_step(self):
        b,row=self.installed(); bad='<script>alert("x")</script>'
        self.record(b,row,observed=bad)
        page=self.n.dashboard(self.n.load_state())
        self.assertNotIn(bad,page); self.assertIn('&lt;script&gt;',page)
        self.assertIn('Est-ce que cette aide fonctionne pour toi ?',page)
        self.assertIn('Préparer la prochaine amélioration',page)
        self.assertIn('Préparer une méthode pour un descendant',page)
        self.assertIn('class="learning-report"',page)

    def test_rollback_prevents_claims_and_transmission_without_erasing_reports(self):
        b,row=self.installed(); r=self.record(b,row); m=self.method(r)
        w=adapt.atelier.Workshop(self.n); e=w.load(row['experiment_id'])
        e['status']='rolled_back';w.save(e)
        with self.assertRaises(ValueError): self.record(b,row,case='Après annulation')
        with self.assertRaises(ValueError): self.method(r)
        with self.assertRaises(ValueError): learning.select_for_birth(self.n,self.n.load_state(),[m['id']])
        page=self.n.dashboard(self.n.load_state())
        self.assertNotIn('class="learning-report"',page)
        self.assertIn('annulée',page)
        self.assertEqual(len(self.n.load_state()['learning']['reports']),1)

    def test_bounded_context_preserves_a_recent_negative_and_discloses_omissions(self):
        b,row=self.installed(); self.record(b,row,'failure',case='Rare',remaining='À ne pas oublier')
        for i in range(8): self.record(b,row,case='Cas '+str(i),observed='Utile')
        ctx=learning.preparation_context(self.n,self.n.load_state(),b['id'])
        self.assertEqual(len(ctx['reported_outcomes']),5)
        self.assertEqual(ctx['omitted_reports'],4)
        self.assertTrue(any(r['remaining']=='À ne pas oublier' for r in ctx['reported_outcomes']))
        self.assertEqual(learning.assessment(self.n.load_state(),b['id'])['status'],'needs_work')

    def test_discussion_drift_preserves_retrospective_report_without_qualifying_new_context(self):
        import tao_dialogue as dialogue
        b,row=self.installed(); s=self.n.load_state()
        row.update(dialogue_context_version=dialogue.ensure(s)['context_version'],
                   dialogue_story_digest=self.n.digest_bytes(self.n.json_bytes(self.n.story())),
                   continuity_revision=s.get('continuity',{}).get('revision',0))
        adapt.save(self.n,row)
        before_policy=self.n.POLICY.read_bytes()
        dialogue.save_memory(self.n,'Une nouvelle question à explorer',0)
        with self.assertRaises(ValueError): adapt.check_context(self.n,row)
        result=self.record(b,row,observed='Observation de la version installée sur le cas initial')
        self.assertTrue(result['context_changed'])
        self.assertFalse(result['verified_automatically'])
        self.assertIn('discussion',result['context_change_reason'])
        s=self.n.load_state()
        self.assertEqual(len(s['learning']['context_reports']),1)
        self.assertEqual(s['learning']['reports'],[])
        self.assertEqual(learning.current_reports(s,b['id']),[])
        self.assertEqual(learning.assessment(s,b['id'])['status'],'unobserved')
        context=learning.preparation_context(self.n,s,b['id'])
        self.assertEqual(context['reported_outcomes'],[])
        self.assertFalse(context['other_context_observations'][0]['same_context'])
        with self.assertRaises(ValueError): self.method(result)
        self.assertEqual(self.n.POLICY.read_bytes(),before_policy)
        self.n.work.save_example(self.n,b['id'],'Un autre exemple','Un autre résultat',revision=2)
        with self.assertRaises(ValueError): self.record(b,row,case='Exemple différent')
