"""The routing UI proposes next steps without turning them into permissions."""
import os
import shutil
import subprocess
from unittest.mock import patch

from test_node import NodeHarness
from test_mobile_ui import Page
import tao_adaptation as adaptation
import tao_dialogue as dialogue
import tao_ui as ui
import tao_learning as learning


class RoutingUITests(NodeHarness):
    def render_dialogue(self,state=None,codex=True):
        diagnostic={'ready':False,'codex_detected':codex,'blockers':[{'code':'source_missing','message':'Missing code','next':'Install'}]}
        with patch.object(adaptation,'diagnose',return_value=diagnostic):
            return ui.render_dialogue(self.n,state or self.n.load_state())

    def run_js(self,source):
        node=os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node:self.skipTest('Node optional: JavaScript behavior check')
        path=self.base/'routing-ui.js';path.write_text(source)
        result=subprocess.run([node,str(path)],capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_provider_readiness_is_visible_and_separate_from_workshop(self):
        missing=self.render_dialogue(codex=False)
        self.assertIn('L’assistant attend la connexion de Codex',missing)
        self.assertIn('Conserver ce message',missing)
        detected=self.render_dialogue(codex=True)
        self.assertIn('Codex est détecté',detected)
        self.assertIn('sans que l’atelier de code soit prêt',detected)
        self.assertIn('connexion et ses quotas seront vérifiés au prochain envoi',detected)
        self.assertIn('Envoyer à Tao',detected)
        self.assertNotIn('Missing code',detected)

    def test_intent_is_optional_and_present_in_composer(self):
        page=self.render_dialogue();parsed=Page(page)
        composer=next(form for form in parsed.forms if form['attributes'].get('id')=='dialogue-send')
        intent=next(attrs for tag,attrs in composer['fields'] if attrs.get('id')=='dialogue-intent')
        self.assertNotIn('required',intent)
        for value in ('auto','understand','learn','delegate','improve'):self.assertIn(f'<option value="{value}">',page)
        self.assertIn('il n’autorise aucune action à ta place',page)

    def test_routing_proposal_is_escaped_and_never_a_tool_form(self):
        trace={'human_intent':'delegate','route':{'intent':'Préparer mes réponses <script>sans action</script>','contributions':[
            {'function_id':'clarify','function_version':'1','title':'Clarifier <script>bad</script>','expected':'Préciser le résultat','reason':'Contexte <img src=x>','operators':['differentiate'],'source_ids':['human:1']},
            {'function_id':'conciliate','function_version':'1','title':'Comparer les contraintes','expected':'Préserver un accord','reason':'Deux points de vue','operators':['conciliate'],'source_ids':['human:2']} ]},
            'costs':{'cli_attempts':1,'measured_wall_seconds':2.125},'warnings':['À vérifier <script>']}
        page=ui.render_routing({'routing_trace':trace},latest=True)
        self.assertEqual(page.count('class="next-contribution"'),1)
        self.assertNotIn('<script>',page);self.assertNotIn('<img ',page)
        self.assertIn('&lt;script&gt;',page)
        self.assertIn('Pour cet échange : Préparer une délégation.',page)
        self.assertIn('Intention comprise : Préparer mes réponses &lt;script&gt;sans action&lt;/script&gt;',page)
        self.assertIn('human:1',page);self.assertIn('Coût de l’échange entier',page)
        self.assertNotIn('<form',page)
        self.assertIn('type="button" class="continue-route',page)
        self.assertIn('aucune action extérieure n’est lancée',page)
        old=ui.render_routing({'routing_trace':trace},latest=True,current=False)
        self.assertNotIn('class="continue-route',old)
        self.assertIn('contexte modifié depuis',old)

    def test_only_latest_blocked_question_has_explicit_retry(self):
        state=self.n.load_state();d=dialogue.ensure(state);d['revision']=7
        d['messages']=[{'id':'human','role':'user','text':'Ma question','job_id':'123456789abc','intent':'learn'}]
        for status in ('blocked','interrupted'):
            with patch.object(dialogue,'view',return_value={'id':'123456789abc','status':status,'message':'Préparation indisponible'}):
                page=self.render_dialogue(state)
            retry=next(form for form in Page(page).forms if form['attributes'].get('data-action')=='retry')
            self.assertEqual(retry['attributes']['data-id'],'123456789abc')
            self.assertEqual(retry['attributes']['data-revision'],'7')
            self.assertIn('Ta question reste conservée une seule fois',page)
            self.assertIn('Ton choix pour cet échange : Apprendre à faire',page)
        d['messages'].append({'id':'later','role':'user','text':'Extrait transmis','source':'human_selected_transfer','original_role':'assistant'})
        with patch.object(dialogue,'view',return_value={'id':'123456789abc','status':'blocked','message':'Bloqué'}):
            self.assertNotIn('data-action="retry"',self.render_dialogue(state))

    def adaptation_page(self,status,detail):
        row={'id':'123456789abc','status':status,'review_digest':'digest'}
        with patch.object(adaptation,'diagnose',return_value={'ready':True}),patch.object(adaptation,'current',return_value=row),patch.object(adaptation,'view',return_value=detail):
            return ui.render_adaptation(self.n,{'id':'task','work_task':{}})

    def test_obsolete_experiments_keep_review_but_never_offer_apply_or_verify(self):
        detail={'context_current':False,'context_error':'Mémoire corrigée','replacement_allowed':True,'patch':'change retained','log':'old test trace'}
        for status in ('review','verified','test_failed','install_failed'):
            page=self.adaptation_page(status,detail)
            self.assertNotIn('data-action="verify"',page);self.assertNotIn('data-action="apply"',page)
            self.assertEqual(page.count('data-action="generate"'),1)
            self.assertIn('Préparer à nouveau avec le contexte actuel',page)
            self.assertIn('change retained',page);self.assertIn('old test trace',page)
            blocked=self.adaptation_page(status,dict(detail,replacement_allowed=False,replacement_error='Vérifier l’installation précédente'))
            self.assertNotIn('data-action="generate"',blocked)
            self.assertIn('Vérifier l’installation précédente',blocked)

    def test_archival_is_explicit_and_does_not_restore_old_authority(self):
        page=self.adaptation_page('verified',{'archived':True,'context_current':False,'context_error':'Ancien contexte','replacement_allowed':True,'restore_allowed':True,'patch':'archive retained'})
        self.assertIn('data-action="restore"',page)
        self.assertNotIn('data-action="apply"',page);self.assertNotIn('data-action="verify"',page)
        self.assertIn('cet archivage n’annule pas une installation',page)
        self.assertIn('archive retained',page)
        active=self.adaptation_page('review',{'context_current':True,'archive_allowed':True})
        self.assertIn('data-action="archive"',active)
        denied=self.adaptation_page('review',{'context_current':True,'archive_allowed':False})
        self.assertNotIn('data-action="archive"',denied)

    def test_human_feedback_remains_available_after_cognitive_context_changes(self):
        with patch.object(learning,'report_context',return_value={'changed':True,'reason':'Discussion poursuivie'},create=True),patch.object(learning,'retained_experiment'):
            page=self.adaptation_page('installed',{'context_current':False,'context_error':'Discussion poursuivie'})
        self.assertIn('class="learning-report"',page)
        self.assertIn('ton retour sera conservé pour cet essai, sans valider la nouvelle situation',page)
        with patch.object(learning,'report_context',side_effect=ValueError('Exemple changé'),create=True),patch.object(learning,'retained_experiment'):
            changed=self.adaptation_page('installed',{'context_current':False})
        self.assertNotIn('class="learning-report"',changed)
        self.assertIn('Exemple changé',changed)
        with patch.object(learning,'report_context',return_value={'changed':False},create=True),patch.object(learning,'retained_experiment',side_effect=ValueError('Cette expérience a été annulée.')):
            rolled_back=self.adaptation_page('installed',{'context_current':True})
        self.assertIn('Cette expérience a été annulée.',rolled_back)
        self.assertNotIn('class="learning-report"',rolled_back)

    def test_other_context_reports_remain_visible_without_qualifying_current_situation(self):
        state=self.n.load_state()
        report={'task_id':'task','case':'Essai passé','outcome':'success','observed':'Ancien résultat <script>','remaining':'','at':'2026-09-28','context_changed':True,'context_change_reason':'La discussion a changé'}
        state['learning']={'revision':1,'reports':[],'context_reports':[report,dict(report,task_id='other',case='Autre tâche privée')],'methods':[]}
        page=ui.render_learning(state,{'id':'task'},{'id':'abc'})
        self.assertIn('Autre contexte — conservé, sans validation de la situation actuelle',page)
        self.assertIn('Essai passé',page);self.assertIn('Ancien résultat &lt;script&gt;',page)
        self.assertNotIn('Autre tâche privée',page)
        self.assertNotIn('cas nommé(s) dans ce contexte',page)
        self.assertNotIn('class="learning-method"',page)

    def test_submit_transmits_intent_and_retry_uses_existing_job(self):
        script=self.n.dashboard(self.n.load_state()).split('<script>')[-1].split('</script>')[0]
        submit=script.split('dialogueForm.onsubmit=',1)[1].split('\nconst memoryForm',1)[0]
        actions=script.split("for(const form of document.querySelectorAll('.dialogue-action'))",1)[1].split('\nfor(const panel',1)[0]
        self.run_js("""const assert=require('assert');let calls=[];const send=(path,data)=>calls.push({path,data});
const dialogueForm={dataset:{revision:'12'}},selectedFocus=null,crypto={randomUUID:()=> 'new-message-nonce'};
const retryForm={dataset:{action:'retry',id:'existing-job',revision:'12'},elements:{}};
const document={querySelector:id=>({value:id==='#dialogue-intent'?'delegate':'Mon besoin'}),querySelectorAll:()=>[retryForm]};
dialogueForm.onsubmit="""+submit+"""
assert.equal(calls.length,0);dialogueForm.onsubmit({preventDefault:()=>{}});assert.equal(calls[0].path,'/api/dialogue/send');assert.equal(calls[0].data.intent,'delegate');
for(const form of document.querySelectorAll('.dialogue-action'))"""+actions+"""
assert.equal(calls.length,1);retryForm.onsubmit({preventDefault:()=>{}});assert.equal(calls[1].path,'/api/dialogue/retry');assert.deepEqual(calls[1].data,{id:'existing-job',revision:12});
""")
