import hashlib
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / 'bootstrap'))
import tao_foundations as foundations
import tao_logic as logic


class LogicCatalogueTests(unittest.TestCase):
    def test_languages_share_stable_ids_and_types_without_aliasing_distinct_meanings(self):
        french, english = logic.catalog('fr'), logic.catalog('en')
        self.assertEqual(french['schema'], 'tao.logic.catalog.v1')
        self.assertEqual(french['version'], '2.0.0')
        self.assertEqual(french['status'], 'descriptive_not_executable')
        for section in ('terms', 'formalisms', 'relations', 'invariants'):
            fr_ids = [row['id'] for row in french[section]]
            self.assertEqual(fr_ids, [row['id'] for row in english[section]])
            self.assertEqual(len(fr_ids), len(set(fr_ids)))
        self.assertEqual([row['implementation'] for row in french['terms']],
                         [row['implementation'] for row in english['terms']])
        fr = {row['key']: row for row in french['terms']}
        en = {row['key']: row for row in english['terms']}
        self.assertEqual(fr['space']['label'], 'Espace')
        self.assertEqual(en['space']['label'], 'Space')
        self.assertIn('monde', fr['space']['aliases'])
        self.assertIn('world', en['space']['aliases'])
        self.assertNotIn('historical_buffer', fr)
        self.assertIn('conserve l’écart', fr['buffer']['definition'])

    def test_common_foundation_concepts_retain_their_ids(self):
        current = {row['key']: row for row in logic.catalog()['terms']}
        shared = set(current) & set(foundations.CONCEPTS)
        self.assertTrue({'story', 'objective', 'task', 'mission', 'resource', 'evidence'} <= shared)
        for key in shared:
            self.assertEqual(current[key]['id'], foundations.get_concept(key)['id'])

    def test_all_references_and_relations_resolve_without_external_authority(self):
        result = logic.catalog()
        ids = {row['id'] for row in result['terms']}
        formalism_ids = {row['id'] for row in result['formalisms']}
        for term in result['terms']:
            self.assertRegex(term['id'], r'^tao\.concept\.[a-z_]+$')
            self.assertEqual(term['id'], 'tao.concept.' + term['key'])
            self.assertIn(term['epistemic_status'], logic.EPISTEMIC_STATUSES)
            self.assertIn(term['implementation']['status'], logic.IMPLEMENTATION_STATUSES)
            self.assertTrue(term['implementation']['references'])
            self.assertTrue(set(term['formalism_ids']) <= formalism_ids)
            for ref in term['implementation']['references']:
                self.assertFalse(Path(ref).is_absolute())
                self.assertNotIn('..', Path(ref).parts)
                self.assertTrue((PROJECT / ref).is_file(), ref)
            if term['implementation']['status'] == 'implemented':
                self.assertTrue(any(ref.startswith('bootstrap/') and ref.endswith('.py')
                                    for ref in term['implementation']['references']))
        for row in result['relations']:
            self.assertIn(row['source'], ids)
            self.assertIn(row['target'], ids)
            self.assertTrue(row['description'].strip())

    def test_proposed_coordination_and_modes_are_not_reported_as_existing_engines(self):
        by_key = {row['key']: row for row in logic.catalog()['terms']}
        for key in ('contextual_self', 'invocation', 'mode', 'process', 'conversation_thread'):
            self.assertEqual(by_key[key]['epistemic_status'], 'proposed')
            self.assertEqual(by_key[key]['implementation']['status'], 'proposed')
            self.assertTrue(all(ref.startswith('docs/') for ref in by_key[key]['implementation']['references']))
        self.assertEqual(by_key['steward']['implementation']['status'], 'proposed')
        self.assertTrue(all(ref.startswith('docs/')
                            for ref in by_key['steward']['implementation']['references']))
        self.assertEqual(by_key['center']['implementation']['status'], 'partial')
        self.assertEqual(by_key['mandate']['implementation']['status'], 'partial')
        self.assertNotIn('runtime', logic.catalog())
        self.assertFalse(logic.catalog()['execution_enabled'])

    def test_aliases_are_localized_unique_and_do_not_make_roles_permissions(self):
        for locale in logic.LOCALES:
            owners = {}
            for row in logic.catalog(locale)['terms']:
                for alias in [row['label'], *row['aliases']]:
                    self.assertIsInstance(alias, str)
                    self.assertTrue(alias.strip())
                    normalized = alias.casefold().strip()
                    self.assertIn(owners.get(normalized), (None, row['id']))
                    owners[normalized] = row['id']
            for key in ('center', 'mode', 'contextual_self', 'steward', 'actor', 'space'):
                term = next(row for row in logic.catalog(locale)['terms'] if row['key'] == key)
                self.assertFalse({'permission', 'mandat', 'mandate', 'authority', 'autorité'} &
                                 {alias.casefold() for alias in [term['label'], *term['aliases']]})

    def test_formalisms_keep_assumptions_and_bounded_coordination_explicit(self):
        for locale in logic.LOCALES:
            result = logic.catalog(locale)
            for row in result['formalisms']:
                self.assertIn(row['epistemic_status'], logic.EPISTEMIC_STATUSES)
                self.assertLessEqual(len(row['expression']), 100)
                self.assertTrue(row['explanation'].strip())
                self.assertTrue(row['assumptions'])
                self.assertTrue(all(isinstance(text, str) and text.strip() for text in row['assumptions']))
            rows = {row['id'].rsplit('.', 1)[-1]: row for row in result['formalisms']}
            self.assertEqual(rows['budget']['epistemic_status'], 'math')
            for key in ('coordination', 'invocation', 'capabilities'):
                self.assertEqual(rows[key]['epistemic_status'], 'proposed')
            invariants = {row['id'].rsplit('.', 1)[-1] for row in result['invariants']}
            self.assertTrue({'bounded_coordination', 'no_role_authority', 'no_fixed_centres',
                             'visible_residual', 'no_universal_score'} <= invariants)

    def test_rooms_addresses_and_tools_preserve_distinct_scopes(self):
        for locale in logic.LOCALES:
            result = logic.catalog(locale)
            terms = {row['key']: row for row in result['terms']}
            self.assertEqual(terms['house']['implementation']['status'], 'partial')
            self.assertEqual(terms['space']['implementation']['status'], 'implemented')
            self.assertEqual(terms['address']['implementation']['status'], 'partial')
            self.assertEqual(terms['automation']['implementation']['status'], 'partial')
            for key in ('role', 'mission', 'contract', 'method'):
                self.assertEqual(terms[key]['id'], foundations.get_concept(key)['id'])
                self.assertIn('tao.logic.formalism.scoped_record', terms[key]['formalism_ids'])
            self.assertNotEqual(terms['tool']['id'], terms['connector']['id'])
            self.assertNotEqual(terms['method']['id'], terms['automation']['id'])
            formalisms = {row['id'].rsplit('.', 1)[-1]: row for row in result['formalisms']}
            self.assertEqual(formalisms['address']['expression'], 'L = (N, w, v, f, a)')
            self.assertEqual(formalisms['address_url']['epistemic_status'], 'proposed')
            self.assertIn('route(v)', formalisms['address_url']['expression'])
            self.assertEqual(formalisms['conversation_thread']['epistemic_status'], 'proposed')
            self.assertEqual(formalisms['conversation_thread']['expression'],
                             'identity(thread) = (N, w, thread_id)')
            invariants = {row['id'].rsplit('.', 1)[-1] for row in result['invariants']}
            self.assertTrue({'address_not_authority', 'room_scoped_records', 'tool_not_connector',
                             'description_not_execution', 'thread_not_authority'} <= invariants)

    def test_reading_catalogue_neither_consults_private_state_nor_starts_work(self):
        with patch('builtins.open') as opening, patch('subprocess.Popen') as processes, patch('socket.create_connection') as network:
            result = logic.catalog()
        opening.assert_not_called()
        processes.assert_not_called()
        network.assert_not_called()
        self.assertFalse(result['execution_enabled'])
        self.assertFalse({'state', 'history', 'token', 'user', 'permissions', 'jobs'} & set(result))

    def test_mutating_a_result_does_not_mutate_the_catalogue_or_other_locales(self):
        first = logic.catalog()
        expected = json.dumps(logic.catalog(), sort_keys=True)
        first['terms'][0]['implementation']['references'].clear()
        first['terms'][0]['formalism_ids'].clear()
        first['terms'][0]['definition'] = 'Forged permission'
        first['formalisms'][0]['assumptions'].clear()
        first['relations'][0]['source'] = 'unknown'
        first['invariants'].clear()
        first['canon']['modified'] = True
        self.assertEqual(json.dumps(logic.catalog(), sort_keys=True), expected)
        self.assertTrue(logic.catalog('en')['formalisms'][0]['assumptions'])

    def test_catalogue_is_bounded_json_and_rejects_unrecognized_locales(self):
        for locale in logic.LOCALES:
            result = logic.catalog(locale)
            self.assertLessEqual(len(result['terms']), 36)
            self.assertLessEqual(len(result['formalisms']), 13)
            self.assertLess(len(json.dumps(result, ensure_ascii=False).encode()), 50000)
            json.dumps(result, allow_nan=False)
        self.assertEqual(logic.catalog('fr-NC')['locale'], 'fr')
        self.assertEqual(logic.catalog('en_GB')['locale'], 'en')
        for value in (None, True, 1, [], {}, '', 'de', 'all', '../fr'):
            with self.subTest(locale=value), self.assertRaises(ValueError):
                logic.catalog(value)

    def test_the_descriptive_catalogue_does_not_change_the_canonical_theory(self):
        path = PROJECT / 'docs/theory.json'
        before = path.read_bytes()
        logic.catalog(); logic.catalog('en')
        self.assertEqual(path.read_bytes(), before)
        self.assertEqual(hashlib.sha256(before).hexdigest(),
                         '504cee4d51a4ceca4921313c8309b0b5a6d5cb635d0636571a5f6814a6e24c1e')
        self.assertEqual(logic.catalog()['canon']['version'], '4.3.0')


if __name__ == '__main__':
    unittest.main()
