"""Real HTTP and worker processes; only the external model is a local fixture."""
import concurrent.futures
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import ThreadingHTTPServer

from test_node import NodeHarness
from test_centers import definition
import tao_centers as centers
import tao_landmarks as landmarks


class WorldHttpTests(NodeHarness):
    def setUp(self):
        super().setUp()
        fake = self.base / 'bin'; fake.mkdir()
        codex = fake / 'codex'
        codex.write_text('#!' + sys.executable + '''
import json, os, sys, time
from pathlib import Path
root = Path(os.environ['TAO_ROOT'])
assert sys.argv[1:] == ['app-server']
def response(prompt):
    payload = json.loads(prompt.split('DONNÉES FOURNIES :\\n', 1)[1])
    world = os.environ.get('TAO_WORLD')
    assert world == payload['world']['id'], (world, payload['world'])
    Path('fixture-provider-trace.json').write_text(json.dumps({'env_world': world, 'context_world': payload['world']['id']}))
    (root / ('fixture-provider-entered-' + world)).write_text('entered')
    deadline = time.monotonic() + 15
    while (root / 'fixture-hold').exists():
        if time.monotonic() > deadline:
            raise RuntimeError('Fixture release missing')
        time.sleep(.02)
    source = next(m for m in reversed(payload['messages']) if m['role'] == 'user')
    if 'USE_TRANSFER_AS_SOURCE' in source['text']:
        source = next(m for m in payload['messages'] if m.get('source') == 'human_selected_transfer')
        quote = source['origin']['quote']
    else:
        quote = source['text']
    answer = {'reply': 'Réponse fictive pour le monde ' + world,
          'memory_suggestion': '', 'situation_map': None, 'proposal': None,
          'continuity': {'notes': [{'kind': 'context', 'text': 'Demande à comprendre dans le monde ' + world,
                                    'message_id': source['id'], 'quote': quote}],
                         'needs': [{'title': 'Un besoin fictif du monde ' + world,
                                    'current': 'Une demande racontée.', 'desired': 'Comprendre le cas.',
                                    'acceptance': 'Une observation déclarée.', 'next_step': 'Décrire un exemple.',
                                    'message_id': source['id'], 'quote': quote}]}}
    return json.dumps(answer)
for line in sys.stdin:
    message=json.loads(line)
    if message.get('id')==1:
        print(json.dumps({'id':1,'result':{}}),flush=True)
    elif message.get('id')==2:
        params=message['params'];assert params['sandbox']=='read-only' and params['approvalPolicy']=='never' and params['ephemeral']
        print(json.dumps({'id':2,'result':{'thread':{'id':'world-fixture-thread'}}}),flush=True)
    elif message.get('id')==3:
        raw=response(message['params']['input'][0]['text'])
        print(json.dumps({'method':'item/agentMessage/delta','params':{'delta':raw}}),flush=True)
        print(json.dumps({'method':'item/completed','params':{'item':{'type':'agentMessage','text':raw}}}),flush=True)
        print(json.dumps({'method':'turn/completed','params':{'turn':{'status':'completed','items':[]}}}),flush=True)
''', encoding='utf-8')
        codex.chmod(0o700)
        self.n.atomic_json(self.n.ROOT / 'source.json', {
            'executables': {'codex': str(codex)},
            'path_env': str(fake) + os.pathsep + os.environ.get('PATH', '')})
        self.n.TOKEN = 'fixture-http-world-token'
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
        self.thread.start()
        self.base_url = 'http://127.0.0.1:' + str(self.server.server_port)

    def tearDown(self):
        (self.root / 'fixture-hold').unlink(missing_ok=True)
        # No detached fixture worker should outlive its private test directory.
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            running = []
            for path in (self.root / 'dialogue').glob('*/job.json'):
                row = self.n.load_json(path)
                if row.get('status') in ('queued', 'running'):
                    running.append(row)
            if not running:
                break
            time.sleep(.02)
        self.server.shutdown(); self.thread.join(timeout=3); self.server.server_close()
        super().tearDown()

    def request(self, endpoint, world='main', payload=None, token=True):
        url = self.base_url + endpoint + ('&' if '?' in endpoint else '?') + urllib.parse.urlencode({'world': world})
        headers = {}
        if token:
            headers['X-Tao-Token'] = self.n.TOKEN
        if payload is not None:
            headers['Content-Type'] = 'application/json'
        request = urllib.request.Request(url, data=None if payload is None else json.dumps(payload).encode(), headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=4) as response:
                return response.status, response.read().decode()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read().decode()

    def get(self, endpoint='/state', world='main'):
        status, body = self.request(endpoint, world)
        self.assertEqual(status, 200, body)
        return json.loads(body)

    def post(self, endpoint, payload, world='main'):
        status, body = self.request(endpoint, world, payload)
        self.assertEqual(status, 200, body)
        return json.loads(body)

    def child(self, title='Un monde fictif'):
        revision = self.get()['world']['revision']
        return self.post('/api/worlds/create', {'title': title, 'revision': revision})['id']

    def say(self, text, world, nonce):
        revision = self.get(world=world)['dialogue'].get('revision', 0)
        return self.post('/api/dialogue/send', {'text': text, 'revision': revision, 'nonce': nonce}, world)

    def wait_answer(self, job, world):
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            row = self.get('/api/dialogue?id=' + job['id'], world)
            if row['status'] == 'answered':
                return row
            self.assertIn(row['status'], ('queued', 'running'), row)
            time.sleep(.03)
        self.fail('Le worker fictif n’a pas répondu : ' + str(row))

    def test_http_state_and_mutations_are_scoped_with_csrf_and_world_validation(self):
        child = self.child(); sibling = self.child('Un autre monde fictif')
        assignments = [('main', 'PRIVATE_MAIN_FIXTURE'), (child, 'PRIVATE_CHILD_FIXTURE'),
                       (sibling, 'PRIVATE_SIBLING_FIXTURE')]
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            list(pool.map(lambda item: self.post('/api/dialogue/memory', {'text': item[1], 'revision': 0}, item[0]), assignments))
        self.post('/api/story', {'text': 'PRIVATE_CHILD_STORY'}, child)
        self.post('/api/work/context', {'description': 'PRIVATE_CHILD_WORK', 'revision': 0}, child)
        for world, own in assignments:
            state = self.get(world=world); rendered = json.dumps(state)
            self.assertEqual(state['dialogue']['memory'], own)
            self.assertEqual(state['world']['current']['id'], world)
            for other_world, private in assignments:
                if other_world != world:
                    self.assertNotIn(private, rendered)
            if world != child:
                self.assertNotIn('PRIVATE_CHILD_STORY', rendered)
                self.assertNotIn('PRIVATE_CHILD_WORK', rendered)
        status, _ = self.request('/api/dialogue/memory', child, {'text': 'FORBIDDEN', 'revision': 1}, token=False)
        self.assertEqual(status, 403)
        for invalid in ('../../main', 'ffffffffffff', ''):
            status, _ = self.request('/state', invalid)
            self.assertGreaterEqual(status, 400)
        status, _ = self.request('/state?world=main', child)
        self.assertEqual(status, 400)
        self.assertEqual(self.get(world=child)['dialogue']['memory'], 'PRIVATE_CHILD_FIXTURE')

    def test_http_center_message_resolves_only_the_referenced_landmark_version(self):
        center = centers.create(self.n, definition('Tickets HTTP'), revision=0)
        landmark = landmarks.create(
            self.n, 'tao.concept.task', 'Ticket HTTP',
            'Entrée explicitement choisie via la route propriétaire.', revision=0)
        reference = {'kind': 'landmark', 'id': landmark['id'],
                     'revision': landmark['revision']}
        job = self.post('/api/dialogue/send', {
            'text': 'Prépare une sortie à relire.', 'revision': 0,
            'nonce': 'center-http-input-001',
            'focus': {'kind': 'center', 'id': center['id'],
                      'revision': center['revision']},
            'input_reference': reference,
        })
        context = self.n.load_json(self.n.ROOT / 'dialogue' / job['id'] / 'context.json')
        self.assertEqual(context['selected_input']['ref'], reference)
        self.assertEqual(context['selected_input']['context']['text'], landmark['text'])
        self.assertEqual(context['selected_input']['authority'], 'context_only')
        self.assertFalse(context['selected_input']['execution_enabled'])

    def test_real_worker_keeps_origin_world_and_archived_memory_needs_remain_scoped(self):
        child = self.child()
        self.post('/api/dialogue/memory', {'text': 'PRIVATE_MAIN_CONTEXT', 'revision': 0})
        self.post('/api/dialogue/memory', {'text': 'PRIVATE_CHILD_CONTEXT', 'revision': 0}, child)
        (self.root / 'fixture-hold').write_text('wait')
        job = self.say('Comprendre le jardin fictif de ce monde enfant.', child, 'world-http-child-001')
        deadline = time.monotonic() + 10
        while not (self.root / ('fixture-provider-entered-' + child)).exists():
            self.assertLess(time.monotonic(), deadline, self.get('/api/dialogue?id=' + job['id'], child))
            time.sleep(.02)
        # Requests in the principal space cannot move the running worker there.
        self.assertEqual(self.get()['dialogue']['messages'], [])
        self.post('/api/dialogue/memory', {'text': 'PRIVATE_MAIN_CHANGED_WHILE_CHILD_RUNS', 'revision': 1})
        status, body = self.request('/dialogue/context?id=' + job['id'], child)
        self.assertEqual(status, 200, body)
        payload = json.loads(body)
        self.assertEqual(payload['world']['id'], child)
        self.assertIn('PRIVATE_CHILD_CONTEXT', body); self.assertNotIn('PRIVATE_MAIN_CONTEXT', body)
        for endpoint in ('/api/dialogue?id=', '/dialogue/context?id='):
            status, error = self.request(endpoint + job['id'])
            self.assertGreaterEqual(status, 400); self.assertNotIn('PRIVATE_CHILD_CONTEXT', error)
        (self.root / 'fixture-hold').unlink()
        answer = self.wait_answer(job, child)
        trace = json.loads((self.root / 'dialogue' / job['id'] / 'fixture-provider-trace.json').read_text())
        self.assertEqual(trace, {'env_world': child, 'context_world': child})
        state = self.get(world=child); reply = state['dialogue']['messages'][-1]
        self.assertEqual(reply['id'], answer['reply_id'])
        self.assertEqual(len(state['continuity']['notes']), 1)
        self.assertEqual(len(reply['captured']['need_ids']), 1)
        need_id = reply['captured']['need_ids'][0]
        self.assertEqual(self.get()['dialogue']['messages'], [])
        self.assertFalse(self.get()['continuity'].get('notes'))
        revision = state['dialogue']['revision']
        archived = self.post('/api/dialogue/new', {'revision': revision}, child)
        status, body = self.request('/dialogue/archive?id=' + archived['archive_id'], child)
        self.assertEqual(status, 200); self.assertIn('jardin fictif', body)
        status, body = self.request('/dialogue/archive?id=' + archived['archive_id'])
        self.assertGreaterEqual(status, 400); self.assertNotIn('jardin fictif', body)
        state = self.get(world=child)
        self.assertEqual(state['dialogue']['messages'], [])
        self.assertEqual(state['dialogue']['memory'], 'PRIVATE_CHILD_CONTEXT')
        self.assertEqual(len(state['continuity']['notes']), 1)
        self.assertIn(need_id, [b['id'] for b in state['buffers']])
        second = self.say('On reprend ce besoin du jardin fictif ?', child, 'world-http-child-002')
        self.wait_answer(second, child)
        _, raw_context = self.request('/dialogue/context?id=' + second['id'], child)
        next_context = json.loads(raw_context)
        self.assertEqual(next_context['memory_selected_by_user'], 'PRIVATE_CHILD_CONTEXT')
        self.assertTrue(next_context['continuity']['notes'])
        self.assertTrue(any(row['id'] == need_id for row in next_context['continuity']['needs']))
        self.assertNotIn('PRIVATE_MAIN_CHANGED_WHILE_CHILD_RUNS', raw_context)
        state = self.get(world=child)
        args = {'id': need_id, 'action': 'resolve', 'revision': state['continuity']['revision'],
                'evidence': 'Cas fictif observé : le résultat prévu est atteint.'}
        status, _ = self.request('/api/continuity/need', 'main', args)
        self.assertGreaterEqual(status, 400)
        closed = self.post('/api/continuity/need', args, child)
        self.assertEqual(closed['status'], 'resolved')
        self.assertEqual(closed['evidence'][0]['source'], 'human_report')
        self.assertFalse(closed['dialogue_need']['execution_enabled'])
        _, exported = self.request('/continuity/export', child)
        self.assertIn('Cas fictif observé', exported)
        _, main_exported = self.request('/continuity/export')
        self.assertNotIn('Cas fictif observé', main_exported)

    def test_http_assistant_transfer_keeps_attribution_through_next_model_context(self):
        child = self.child()
        answer = self.wait_answer(self.say('Comprendre un exemple fictif à transmettre.', child, 'world-transfer-child-001'), child)
        child_state = self.get(world=child)
        reply = next(m for m in child_state['dialogue']['messages'] if m['id'] == answer['reply_id'])
        transferred = self.post('/api/worlds/transfer', {'target_id': 'main', 'text': 'Voici un extrait choisi.',
            'source_quote': reply['text'], 'source_message_id': reply['id'],
            'revision': child_state['world']['revision']}, child)
        main_state = self.get(); carried = main_state['dialogue']['messages'][-1]
        self.assertEqual(carried['id'], transferred['message_id'])
        self.assertEqual(carried['role'], 'user')
        self.assertEqual(carried['original_role'], 'assistant')
        self.assertEqual(carried['origin']['world_id'], child)
        self.assertEqual(carried['origin']['message_id'], reply['id'])
        self.assertFalse(carried['execution_enabled'])
        job = self.say('USE_TRANSFER_AS_SOURCE : examinons cet extrait.', 'main', 'world-transfer-main-001')
        self.wait_answer(job, 'main')
        _, raw_context = self.request('/dialogue/context?id=' + job['id'])
        context = json.loads(raw_context)
        source = next(m for m in context['messages'] if m['id'] == carried['id'])
        self.assertEqual(source['original_role'], 'assistant')
        self.assertEqual(source['origin']['world_id'], child)
        state = self.get(); response = state['dialogue']['messages'][-1]
        self.assertEqual(state['continuity']['notes'], [])
        self.assertEqual(response['captured']['note_ids'], [])
        self.assertEqual(response['captured']['need_ids'], [])
        self.assertTrue(response['captured']['warnings'])
        self.assertEqual(len(self.get(world=child)['continuity']['notes']), 1)
