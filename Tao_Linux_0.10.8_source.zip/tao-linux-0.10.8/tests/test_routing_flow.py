"""Intent/routing and retry through real HTTP and detached worker processes.

Only Codex's provider output and Tailscale's incoming identity headers are
fixtures. These tests do not qualify a real account, phone, VPN, or model.
"""
import http.client
import json
import os
import sys
import threading
import time
import urllib.parse
from http.server import ThreadingHTTPServer

from test_node import NodeHarness
from test_mobile import free_port
import tao_mobile as mobile


class RoutingFlowTests(NodeHarness):
    def setUp(self):
        super().setUp()
        fake = self.base / 'bin'; fake.mkdir()
        provider = fake / 'codex'
        provider.write_text('#!' + sys.executable + '''
import json, os, sys
from pathlib import Path
root = Path(os.environ['TAO_ROOT'])
assert sys.argv[1:] == ['app-server']
def response(prompt):
    payload = json.loads(prompt.split('DONNÉES FOURNIES :\\n', 1)[1])
    assert payload['world']['id'] == os.environ['TAO_WORLD']
    Path('fixture-routing-call.json').write_text(json.dumps({'args': sys.argv, 'payload': payload}, ensure_ascii=False))
    with (root / 'fixture-routing-calls.jsonl').open('a') as out:
        out.write(json.dumps({'world': os.environ['TAO_WORLD'], 'directory': str(Path.cwd())}) + '\\n')
    mode_path = root / 'fixture-provider-mode'
    mode = mode_path.read_text().strip() if mode_path.exists() else 'valid'
    if mode == 'invalid_response':
        return 'this is not valid JSON'
    source = next(m for m in reversed(payload['messages']) if m['role'] == 'user')
    route = {'intent': 'Apprendre à partir de la situation racontée.',
             'contributions': [{'function_id': 'explain', 'reason': 'La personne veut pratiquer.',
                                'expected': 'Pouvoir expliquer avec ses propres mots.', 'source_ids': [source['id']]},
                               {'function_id': 'clarify_need', 'reason': 'Vérifier son besoin réel.',
                                'expected': 'Un exemple concret de compréhension.', 'source_ids': [source['id']]}]}
    if mode == 'invalid_source':
        route['contributions'][0]['source_ids'] = ['private-message-from-another-world']
    answer = {'reply': 'Réponse pédagogique fictive, conservée même si le routage est refusé.',
              'memory_suggestion': '', 'situation_map': None, 'proposal': None,
              'continuity': {'notes': [], 'needs': []}, 'routing': route}
    return json.dumps(answer, ensure_ascii=False)
for line in sys.stdin:
    message=json.loads(line)
    if message.get('id')==1:
        print(json.dumps({'id':1,'result':{}}),flush=True)
    elif message.get('id')==2:
        params=message['params'];assert params['sandbox']=='read-only' and params['approvalPolicy']=='never' and params['ephemeral']
        print(json.dumps({'id':2,'result':{'thread':{'id':'routing-fixture-thread'}}}),flush=True)
    elif message.get('id')==3:
        raw=response(message['params']['input'][0]['text'])
        print(json.dumps({'method':'item/agentMessage/delta','params':{'delta':raw}}),flush=True)
        print(json.dumps({'method':'item/completed','params':{'item':{'type':'agentMessage','text':raw}}}),flush=True)
        print(json.dumps({'method':'turn/completed','params':{'turn':{'status':'completed','items':[]}}}),flush=True)
''', encoding='utf-8')
        provider.chmod(0o700)
        self.n.atomic_json(self.root / 'source.json', {
            'executables': {'codex': str(provider)},
            'path_env': str(fake) + os.pathsep + os.environ.get('PATH', '')})
        self.n.TOKEN = 'routing-local-token'
        self.node = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        self.node.daemon_threads = True
        self.node.session_id = 'routing-fixture-node'
        policy = self.n.policy(); policy['http_port'] = self.node.server_port
        self.n.policy = lambda: dict(policy)
        self.node_thread = threading.Thread(target=self.node.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
        self.node_thread.start()
        self.n.atomic_json(self.root / 'session.json', {'id': self.node.session_id, 'port': self.node.server_port,
                                                      'token': self.n.TOKEN})
        self.mobile_port = free_port()
        mobile.configure(self.n, 'https://routing-fixture.private.ts.net', 'owner@example.test', self.mobile_port)
        self.handle = mobile.start(self.n)
        self.cookie = None
        code = mobile.pair(self.n, 'Téléphone simulé')['code']
        status, body, headers = self.request('/mobile/pair', {'code': code}, scoped=False)
        self.assertEqual(status, 200, body)
        self.cookie = headers['Set-Cookie'].split(';', 1)[0]

    def tearDown(self):
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            jobs = [self.n.load_json(path) for path in (self.root / 'dialogue').glob('*/job.json')]
            if not any(row.get('status') in ('queued', 'running') for row in jobs):
                break
            time.sleep(.03)
        mobile.stop(self.handle)
        self.node.shutdown(); self.node_thread.join(timeout=3); self.node.server_close()
        super().tearDown()

    def request(self, path, payload=None, world='main', headers=None, scoped=True):
        if scoped:
            path += ('&' if '?' in path else '?') + urllib.parse.urlencode({'world': world})
        outgoing = {'Host': 'routing-fixture.private.ts.net', 'Tailscale-User-Login': 'owner@example.test'}
        if self.cookie:
            outgoing['Cookie'] = self.cookie
        body = None
        if payload is not None:
            body = json.dumps(payload).encode()
            outgoing.update({'Origin': 'https://routing-fixture.private.ts.net', 'Content-Type': 'application/json',
                             'X-Tao-Token': 'mobile-ui-token'})
        for key, value in (headers or {}).items():
            if value is None:
                outgoing.pop(key, None)
            else:
                outgoing[key] = value
        connection = http.client.HTTPConnection('127.0.0.1', self.mobile_port, timeout=5)
        try:
            connection.request('POST' if body is not None else 'GET', path, body, outgoing)
            response = connection.getresponse()
            return response.status, response.read().decode(), dict(response.getheaders())
        finally:
            connection.close()

    def get(self, path='/state', world='main'):
        status, body, _ = self.request(path, world=world)
        self.assertEqual(status, 200, body)
        return json.loads(body)

    def post(self, path, payload, world='main'):
        status, body, _ = self.request(path, payload, world)
        self.assertEqual(status, 200, body)
        return json.loads(body)

    def child(self, title='Mon apprentissage'):
        state = self.get()
        return self.post('/api/worlds/create', {'title': title, 'parent_id': 'main',
                         'revision': state['world']['revision']})['id']

    def say(self, text, world='main', nonce='routing-fixture-0001', intent='learn'):
        revision = self.get(world=world)['dialogue'].get('revision', 0)
        return self.post('/api/dialogue/send', {'text': text, 'revision': revision, 'nonce': nonce,
                                              'intent': intent}, world)

    def finished(self, job, world='main', expected='answered'):
        deadline = time.monotonic() + 20
        row = job
        while time.monotonic() < deadline:
            row = self.get('/api/dialogue?id=' + job['id'], world)
            if row['status'] not in ('queued', 'running'):
                self.assertEqual(row['status'], expected, row)
                return row
            time.sleep(.03)
        self.fail('Le worker fictif n’a pas terminé : ' + str(row))

    def calls(self):
        path = self.root / 'fixture-routing-calls.jsonl'
        return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []

    def frozen(self, ident):
        return self.n.load_json(self.root / 'dialogue' / ident / 'context.json')

    def test_mobile_learning_intent_trace_and_sources_are_scoped_without_extra_execution(self):
        child = self.child()
        self.post('/api/dialogue/memory', {'text': 'PRIVATE_MAIN_MEMORY', 'revision': 0})
        self.post('/api/dialogue/memory', {'text': 'PRIVATE_CHILD_MEMORY', 'revision': 0}, child)
        policy_before = self.n.POLICY.read_bytes()
        job = self.finished(self.say('Je veux apprendre à expliquer cette histoire moi-même.', child), child)
        state = self.get(world=child)
        messages = state['dialogue']['messages']
        self.assertEqual([message['role'] for message in messages], ['user', 'assistant'])
        self.assertEqual(messages[0]['intent'], 'learn')
        trace = messages[1]['routing_trace']
        self.assertEqual(trace['world_id'], child)
        self.assertEqual(trace['human_intent'], 'learn')
        self.assertEqual(trace['source_message_id'], messages[0]['id'])
        self.assertEqual(trace['job_id'], job['id'])
        self.assertEqual(trace['permissions'], 'none')
        self.assertEqual(trace['result'], 'reply_unverified')
        self.assertFalse(trace['execution_enabled'])
        self.assertEqual(trace['costs']['scope'], 'whole_dialogue_turn')
        self.assertEqual(trace['costs']['cli_attempts'], 1)
        for unmeasured in ('tokens', 'money', 'electricity_joules'):
            self.assertIsNone(trace['costs'][unmeasured])
        contributions = trace['route']['contributions']
        self.assertEqual([item['function_id'] for item in contributions], ['explain', 'clarify_need'])
        for item in contributions:
            self.assertEqual(item['source_ids'], [messages[0]['id']])
            self.assertFalse(item['execution_enabled'])
            self.assertEqual(item['status'], 'proposed')
        frozen = self.frozen(job['id'])
        self.assertEqual(frozen['routing']['human_intent'], 'learn')
        self.assertIn('PRIVATE_CHILD_MEMORY', json.dumps(frozen))
        self.assertNotIn('PRIVATE_MAIN_MEMORY', json.dumps(frozen))
        self.assertEqual(len(self.calls()), 1)
        self.assertEqual(self.calls()[0]['world'], child)
        self.assertEqual(self.n.POLICY.read_bytes(), policy_before)
        self.assertFalse(list((self.root / 'adaptations').glob('*/job.json')))
        self.assertFalse(any(buffer.get('work_task') for buffer in state['buffers']))
        status, body, _ = self.request('/dialogue/export', world=child)
        self.assertEqual(status, 200, body)
        self.assertIn('explain', body)
        self.assertIn(messages[0]['id'], body)
        status, body, _ = self.request('/dialogue/export')
        self.assertEqual(status, 200)
        self.assertNotIn(messages[1]['text'], body)
        self.assertNotEqual(self.request('/dialogue/context?id=' + job['id'])[0], 200)
        archive = self.post('/api/dialogue/new', {'revision': state['dialogue']['revision']}, child)
        status, body, _ = self.request('/dialogue/archive?id=' + archive['archive_id'], world=child)
        self.assertEqual(status, 200, body)
        self.assertIn('tao.routing.trace.v1', body)
        self.assertIn(messages[0]['id'], body)
        self.assertNotEqual(self.request('/dialogue/archive?id=' + archive['archive_id'])[0], 200)
        self.assertEqual(len(self.calls()), 1)

    def test_invalid_routing_source_preserves_the_answer_without_dispatch(self):
        (self.root / 'fixture-provider-mode').write_text('invalid_source')
        self.finished(self.say('Aide-moi à comprendre sans agir.'))
        reply = self.get()['dialogue']['messages'][-1]
        self.assertIn('Réponse pédagogique fictive', reply['text'])
        self.assertIsNone(reply['routing_trace']['route'])
        self.assertTrue(reply['routing_trace']['warnings'])
        self.assertFalse(reply['routing_trace']['execution_enabled'])
        self.assertEqual(len(self.calls()), 1)
        self.assertFalse(list((self.root / 'adaptations').glob('*/job.json')))

    def test_retry_uses_current_frozen_context_and_preserves_one_human_message_and_intent(self):
        (self.root / 'fixture-provider-mode').write_text('invalid_response')
        failed = self.finished(self.say('Apprenons à structurer mon objectif.'), expected='blocked')
        before = self.get()['dialogue']
        self.assertEqual(len(before['messages']), 1)
        original = before['messages'][0]
        self.assertEqual(original['intent'], 'learn')
        frozen_before = self.frozen(failed['id'])
        self.post('/api/dialogue/memory', {'text': 'Je souhaite pratiquer par un exemple.', 'revision': before['revision']})
        revision = self.get()['dialogue']['revision']
        (self.root / 'fixture-provider-mode').write_text('valid')
        retried = self.post('/api/dialogue/retry', {'id': failed['id'], 'revision': revision})
        answered = self.finished(retried)
        repeated = self.post('/api/dialogue/retry', {'id': failed['id'], 'revision': revision})
        self.assertEqual(repeated['id'], answered['id'])
        after = self.get()['dialogue']
        humans = [message for message in after['messages'] if message['role'] == 'user']
        self.assertEqual(len(humans), 1)
        self.assertEqual(humans[0]['id'], original['id'])
        self.assertEqual(humans[0]['text'], original['text'])
        self.assertEqual(humans[0]['intent'], 'learn')
        self.assertEqual(after['messages'][-1]['routing_trace']['human_intent'], 'learn')
        self.assertEqual(self.frozen(failed['id']), frozen_before)
        self.assertNotEqual(answered['id'], failed['id'])
        fresh = self.frozen(answered['id'])
        self.assertEqual(fresh['routing']['human_intent'], 'learn')
        self.assertEqual(fresh['memory_selected_by_user'], 'Je souhaite pratiquer par un exemple.')
        self.assertEqual(len(self.calls()), 2)
        self.assertEqual(len(list((self.root / 'dialogue').glob('*/job.json'))), 2)

    def test_retry_refuses_cross_world_stale_revision_and_missing_mobile_csrf(self):
        child = self.child()
        (self.root / 'fixture-provider-mode').write_text('invalid_response')
        failed = self.finished(self.say('Apprendre dans mon espace.', child), child, 'blocked')
        before = self.get(world=child)['dialogue']
        payload = {'id': failed['id'], 'revision': before['revision']}
        self.assertEqual(self.request('/api/dialogue/retry', payload, child,
                                      headers={'X-Tao-Token': None})[0], 403)
        self.assertNotEqual(self.request('/api/dialogue/retry', payload, 'main')[0], 200)
        self.assertEqual(self.request('/api/dialogue/retry', dict(payload, revision=0), child)[0], 400)
        self.assertEqual(self.get(world=child)['dialogue'], before)
        self.assertEqual(len(self.calls()), 1)
        self.assertEqual(len(list((self.root / 'dialogue').glob('*/job.json'))), 1)
