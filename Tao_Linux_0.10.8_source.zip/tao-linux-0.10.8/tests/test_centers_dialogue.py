"""Explicit center-focused dialogue may retain inert proposals, never actions."""
import json
from unittest.mock import patch

from test_node import NodeHarness
from test_ecology import HEALTHY
from test_centers import definition
import tao_adaptation as adaptation
import tao_centers as centers
import tao_centers_app as centers_app
import tao_dialogue as dialogue
import tao_landmarks as landmarks


def answer(**extra):
    value = {'reply': 'Voici une proposition à relire.', 'memory_suggestion': '',
             'situation_map': None, 'proposal': None, 'continuity': {'notes': [], 'needs': []},
             'routing': None, 'reusable_proposal': None, 'landmark_proposals': [],
             'center_proposal': None, 'center_revision': None,
             'center_link': None, 'organ_proposal': None, 'center_action': None,
             'center_output': None}
    value.update(extra)
    return value


def organ(**changes):
    value = {
        'name': 'Boîte de demandes',
        'role': 'input',
        'interface': 'Une interface choisie et disponible sur la machine',
        'operation': 'Recevoir les éléments explicitement sélectionnés',
        'input': 'Un élément externe choisi par le propriétaire.',
        'output': 'Une entrée x attribuée et bornée pour ce centre.',
        'translation': 'Conserver le texte, la référence et les critères utiles sans inventer les champs absents.',
        'requested_effects': ['read', 'network'],
        'requirements': ['Interface réellement disponible',
                         'Compte configuré séparément par le propriétaire'],
        'purpose': 'Éviter la recopie avant de préparer une sortie à relire.',
        'acceptance': 'Un élément choisi produit l’entrée attendue sans effet extérieur.',
        'boundaries': 'Aucun secret, commande, accès implicite ou traitement automatique.',
    }
    value.update(changes)
    return value


def legacy_gitlab_adapter(**changes):
    value = {
        'provider': 'gitlab',
        'capability': 'issues.read',
        'source': 'Un projet GitLab choisi explicitement par le propriétaire.',
        'selection': 'Les tickets ouverts portant le label prêt-pour-tao.',
        'mapping': 'Titre, description, labels et critères deviennent l’entrée x du centre.',
        'purpose': 'Éviter la recopie avant de préparer une proposition à relire.',
        'acceptance': 'Un ticket choisi est aperçu sans écriture et produit l’entrée attendue.',
        'boundaries': 'Aucun token dans le dialogue, aucune écriture, aucun polling automatique.',
    }
    value.update(changes)
    return value


class CenterDialogueTests(NodeHarness):
    def respond(self, text, focus, response, nonce, input_reference=None):
        revision = self.n.load_state().get('dialogue', {}).get('revision', 0)
        with patch.object(adaptation, 'executable', return_value='/fixture/codex'), \
                patch.object(dialogue, 'launch'):
            job = dialogue.send(self.n, text, revision, nonce, focus,
                                input_reference=input_reference)

        def run(node, exe, job_row, cwd, prompt, timeout, cancelled):
            self.assertIn('fabrique locale et l’intendance des centres', prompt)
            self.assertIn('Aucun centre, lien, outil ou accès', prompt)
            self.assertIn('organ_proposal', prompt)
            self.assertIn('center_action', prompt)
            self.assertIn('aucun mandat récurrent', prompt)
            self.assertIn('privilégier un fournisseur', prompt)
            self.assertIn('aucun compte, secret, permission, connecteur', prompt)
            self.assertIn('process décrit les étapes métier', prompt)
            self.assertIn('Un agent spécialisé est lui aussi un organe', prompt)
            self.assertNotIn('provider="gitlab"', prompt)
            (cwd / 'response.json').write_text(json.dumps(response))
            return {'ok': True}

        with patch.object(adaptation, 'executable', return_value='/fixture/codex'), \
                patch.object(dialogue, 'run_provider', side_effect=run), \
                patch.object(self.n, 'observe_environment', return_value=HEALTHY):
            result = dialogue.worker(self.n, job['id'])
        self.assertEqual(result['status'], 'answered')
        return self.n.load_state()['dialogue']['messages'][-1]

    def test_factory_review_then_center_output_are_explicit_inert_turns(self):
        factory = {'kind': 'center_factory', 'id': 'new', 'revision': 0}
        message = self.respond('Je reçois des tickets et je veux relire un patch.', factory,
                               answer(center_proposal=definition()), 'center-factory-001')
        capture = message['center_capture']['proposal']
        self.assertEqual(capture['status'], 'review')
        self.assertEqual(centers.view(self.n)['centers'], [])
        projected = centers_app.presentation(self.n, self.n.load_state())
        proposal = projected['messages'][-1]['center_capture']['proposal']
        self.assertEqual(proposal['status'], 'review')
        self.assertEqual(proposal['definition']['title'], 'Projet client')
        accepted = centers.decide_proposal(
            self.n, message['id'], 'proposal', 'accept',
            self.n.load_state()['dialogue']['revision'])
        row = next(item for item in centers.view(self.n)['centers']
                   if item['id'] == accepted['center_id'])
        self.assertEqual(row['origin'], 'ai')
        self.assertFalse(row['execution_enabled'])
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        output = {'output': 'Patch candidat, non appliqué.',
                  'process': ['Relire le ticket', 'Préparer le diff'],
                  'benefit': 'Une base à vérifier', 'residual': 'Tests réels non lancés'}
        message = self.respond('Ticket 42 : corriger le libellé.', focus,
                               answer(center_output=output), 'center-output-001')
        capture = message['center_capture']['output']
        self.assertEqual(capture['status'], 'review')
        current = centers.view(self.n)['centers'][0]
        self.assertEqual(current['trials'][0]['status'], 'review')
        self.assertFalse(current['trials'][0]['execution_enabled'])
        self.assertEqual(current['trials'][0]['input'], 'Ticket 42 : corriger le libellé.')
        projected = centers_app.presentation(self.n, self.n.load_state(), selected_id=current['id'])
        self.assertEqual(projected['messages'][-1]['text'], 'Voici une proposition à relire.')

    def test_explicit_landmark_is_frozen_as_input_without_becoming_human_evidence(self):
        row = centers.create(self.n, definition('Tickets'), revision=0)
        landmark = landmarks.create(
            self.n, 'tao.concept.task', 'Ticket 42',
            'Corriger le libellé sans pousser ni fusionner.', revision=0)
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        input_reference = {'kind': 'landmark', 'id': landmark['id'],
                           'revision': landmark['revision']}
        output = {'output': 'Patch candidat, non appliqué.',
                  'process': ['Relire le ticket', 'Préparer le diff'],
                  'benefit': 'Une base à vérifier', 'residual': 'Tests réels non lancés'}
        message = self.respond(
            'Prépare une sortie pour cette entrée.', focus,
            answer(center_output=output), 'center-landmark-input-001', input_reference)

        state = self.n.load_state()
        human = next(item for item in state['dialogue']['messages'] if item['role'] == 'user')
        self.assertEqual(human['input_reference'], input_reference)
        self.assertEqual(human['input_context']['context']['text'], landmark['text'])
        self.assertEqual(human['input_context']['authority'], 'context_only')
        self.assertFalse(human['input_context']['execution_enabled'])
        payload = self.n.load_json(self.n.ROOT / 'dialogue' /
                                   human['job_id'] / 'context.json')
        self.assertEqual(payload['selected_input']['ref'], input_reference)
        self.assertEqual(payload['selected_input']['context']['title'], 'Ticket 42')
        self.assertEqual(payload['messages'][-1]['text'],
                         'Prépare une sortie pour cette entrée.')
        self.assertNotIn(landmark['text'],
                         [source['text'] for source in landmarks.sources(payload)])
        trial = centers.view(self.n)['centers'][0]['trials'][0]
        self.assertIn('tao.concept.task', trial['input'])
        self.assertIn('Ticket 42', trial['input'])
        self.assertIn(landmark['text'], trial['input'])
        self.assertNotIn('Prépare une sortie', trial['input'])
        self.assertEqual(message['center_capture']['output']['status'], 'review')
        projected = centers_app.presentation(self.n, state, selected_id=row['id'])
        selected = next(item for item in projected['messages'] if item['role'] == 'user')
        self.assertEqual(selected['input_context']['context']['title'], 'Ticket 42')

    def test_center_input_nonce_is_bound_and_stale_or_archived_landmarks_are_refused(self):
        row = centers.create(self.n, definition('Tickets'), revision=0)
        first = landmarks.create(self.n, 'tao.concept.task', 'Ticket A',
                                 'Premier ticket explicite.', revision=0)
        second = landmarks.create(
            self.n, 'tao.concept.task', 'Ticket B', 'Second ticket explicite.',
            revision=self.n.load_state()['continuity']['landmarks']['revision'])
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        first_ref = {'kind': 'landmark', 'id': first['id'], 'revision': first['revision']}
        with patch.object(adaptation, 'executable', return_value=None):
            job = dialogue.send(self.n, 'Préparer ce ticket.', 0,
                                'center-input-nonce-001', focus,
                                input_reference=first_ref)
            again = dialogue.send(self.n, 'Préparer ce ticket.', 0,
                                  'center-input-nonce-001', focus,
                                  input_reference=first_ref)
        self.assertEqual(job['id'], again['id'])
        second_ref = {'kind': 'landmark', 'id': second['id'], 'revision': second['revision']}
        with self.assertRaisesRegex(ValueError, 'autre entrée'):
            dialogue.send(self.n, 'Préparer ce ticket.', 0,
                          'center-input-nonce-001', focus,
                          input_reference=second_ref)

        fresh = landmarks.create(
            self.n, 'tao.concept.task', 'Ticket à archiver', 'Cas retiré.',
            revision=self.n.load_state()['continuity']['landmarks']['revision'])
        stale_ref = {'kind': 'landmark', 'id': fresh['id'], 'revision': fresh['revision']}
        updated = landmarks.update(self.n, fresh['id'], fresh['title'],
                                   'Contenu corrigé.', fresh['revision'])
        with self.assertRaisesRegex(ValueError, 'changé|Recharge|révision'):
            dialogue.send(self.n, 'Ancienne version.', 1,
                          'center-input-stale-001', focus,
                          input_reference=stale_ref)
        archived = landmarks.archive(self.n, updated['id'], updated['revision'])
        archived_ref = {'kind': 'landmark', 'id': archived['id'],
                        'revision': archived['revision']}
        with self.assertRaisesRegex(ValueError, 'Restaurer'):
            dialogue.send(self.n, 'Repère archivé.', 1,
                          'center-input-archived-001', focus,
                          input_reference=archived_ref)
        self.assertEqual(len(self.n.load_state()['dialogue']['messages']), 1)

    def test_intendance_link_requires_exact_owner_decision_and_can_be_rejected(self):
        first = centers.create(self.n, definition('Tickets'), revision=0)
        second = centers.create(self.n, definition('Validation'),
                                revision=centers.view(self.n)['revision'])
        focus = {'kind': 'center', 'id': first['id'], 'revision': first['revision']}
        proposed = {'source_id': first['id'], 'target_id': second['id'],
                    'translation': 'Patch candidat → demande de validation',
                    'purpose': 'Faire vérifier la sortie sans transmettre les permissions.'}
        message = self.respond('Relie ce centre à la validation.', focus,
                               answer(center_link=proposed), 'center-link-reject')
        self.assertEqual(message['center_capture']['link']['status'], 'review')
        self.assertEqual(centers.view(self.n)['links'], [])
        rejected = centers.decide_proposal(
            self.n, message['id'], 'link', 'reject',
            self.n.load_state()['dialogue']['revision'])
        self.assertEqual(rejected['status'], 'rejected_by_owner')
        self.assertEqual(centers.view(self.n)['links'], [])

        message = self.respond('Propose à nouveau cette liaison.', focus,
                               answer(center_link=proposed), 'center-link-accept')
        accepted = centers.decide_proposal(
            self.n, message['id'], 'link', 'accept',
            self.n.load_state()['dialogue']['revision'])
        self.assertEqual(accepted['status'], 'accepted')
        link = centers.view(self.n)['links'][0]
        self.assertEqual(link['source_id'], first['id'])
        self.assertEqual(link['target_id'], second['id'])
        self.assertFalse(link['automatic_dispatch'])
        self.assertFalse(link['execution_enabled'])

    def test_center_revision_is_previewed_then_applied_exactly(self):
        row = centers.create(self.n, definition('Tickets'), revision=0)
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        revised = definition('Tickets relus')
        revised['output'] = 'Une proposition bornée avec ses preuves et ses inconnues.'
        message = self.respond('Précise le contrat de ce centre.', focus,
                               answer(center_revision=revised), 'center-revision-001')
        self.assertEqual(message['center_capture']['revision']['status'], 'review')
        self.assertEqual(centers.view(self.n)['centers'][0]['definition']['title'], 'Tickets')
        projected = centers_app.presentation(self.n, self.n.load_state(), selected_id=row['id'])
        self.assertEqual(projected['messages'][-1]['center_capture']['revision']['status'], 'review')
        centers.decide_proposal(self.n, message['id'], 'revision', 'accept',
                                self.n.load_state()['dialogue']['revision'])
        current = centers.view(self.n)['centers'][0]
        self.assertEqual(current['definition']['title'], 'Tickets relus')
        self.assertEqual(current['definition']['output'], revised['output'])
        self.assertEqual(len(current['history']), 1)
        self.assertFalse(current['execution_enabled'])

    def test_center_chat_prepares_provider_neutral_organ_without_implementing_it(self):
        row = centers.create(self.n, definition('Tickets'), revision=0)
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        message = self.respond('Prépare une entrée depuis mon outil de demandes.', focus,
                               answer(organ_proposal=organ()),
                               'center-organ-001')
        capture = message['center_capture']['organ']
        self.assertEqual(capture['status'], 'review')
        self.assertEqual(capture['organ_schema'], centers.ORGAN_SCHEMA)
        self.assertFalse(capture['credentials_configured'])
        self.assertFalse(capture['connection_tested'])
        self.assertFalse(capture['automatic_dispatch'])
        self.assertFalse(capture['automatic_polling'])
        self.assertFalse(capture['execution_enabled'])
        self.assertEqual(centers.view(self.n)['centers'][0]['prepared_adapters'], [])
        projected = centers_app.presentation(self.n, self.n.load_state(), selected_id=row['id'])
        organ_capture = projected['messages'][-1]['center_capture']['organ']
        self.assertEqual(organ_capture['status'], 'review')
        self.assertEqual(organ_capture['name'], 'Boîte de demandes')

        with patch('subprocess.Popen') as process:
            accepted = centers.decide_proposal(
                self.n, message['id'], 'organ', 'accept',
                self.n.load_state()['dialogue']['revision'])
        process.assert_not_called()
        self.assertEqual(accepted['status'], 'accepted')
        current = centers.view(self.n)['centers'][0]
        self.assertEqual(len(current['prepared_adapters']), 1)
        prepared = current['prepared_adapters'][0]
        self.assertEqual(prepared['schema'], centers.ORGAN_SCHEMA)
        self.assertFalse(prepared['legacy'])
        self.assertEqual(prepared['operation'], organ()['operation'])
        self.assertEqual(prepared['requested_effects'], ['read', 'network'])
        self.assertTrue(prepared['current_contract'])
        self.assertFalse(prepared['credentials_configured'])
        self.assertFalse(prepared['connection_tested'])
        self.assertFalse(prepared['automatic_dispatch'])
        self.assertFalse(prepared['automatic_polling'])
        self.assertFalse(prepared['execution_enabled'])
        focused = centers.focus(self.n, self.n.load_state(), focus)
        self.assertEqual(focused['center']['prepared_adapters'][0]['name'], 'Boîte de demandes')
        self.assertLess(len(self.n.json_bytes(focused)), 24000)
        raw_center = self.n.load_state()['centers']['centers'][row['id']]
        self.assertNotIn('adapters', raw_center)
        self.assertNotIn('organs', raw_center)
        projected = centers_app.presentation(self.n, self.n.load_state(), selected_id=row['id'])
        self.assertEqual(projected['centers'][0]['prepared_adapters'][0]['name'],
                         'Boîte de demandes')
        self.assertFalse(projected['centers'][0]['prepared_adapters'][0]['execution_enabled'])

    def test_executable_data_is_rejected_and_stale_organ_creates_no_binding(self):
        unsafe = organ()
        unsafe['command'] = 'run-anything'
        invalid = dialogue.validated_reply(json.dumps(answer(
            organ_proposal=unsafe)))
        self.assertIsNone(invalid['organ_proposal'])
        self.assertTrue(invalid['center_warnings'])

        row = centers.create(self.n, definition('Tickets'), revision=0)
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        message = self.respond('Prépare ce couplage.', focus,
                               answer(organ_proposal=organ()),
                               'center-organ-stale')
        centers.create(self.n, definition('Changement concurrent'),
                       revision=centers.view(self.n)['revision'])
        with self.assertRaisesRegex(ValueError, 'Actualise|changé|révision'):
            centers.decide_proposal(self.n, message['id'], 'organ', 'accept',
                                    self.n.load_state()['dialogue']['revision'])
        current = next(item for item in centers.view(self.n)['centers']
                       if item['id'] == row['id'])
        self.assertEqual(current['prepared_adapters'], [])
        self.assertEqual(message['center_capture']['organ']['status'], 'review')

    def test_former_provider_plan_is_preserved_and_projected_as_an_inert_organ(self):
        unsupported = dialogue.validated_reply(json.dumps(answer(
            adapter_proposal=legacy_gitlab_adapter(capability='issues.write'))))
        self.assertIsNone(unsupported['adapter_proposal'])
        self.assertTrue(unsupported['center_warnings'])
        row = centers.create(self.n, definition('Tickets'), revision=0)
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        message = self.respond(
            'Ancienne réponse conservée.', focus,
            answer(adapter_proposal=legacy_gitlab_adapter()), 'center-legacy-adapter')
        raw = message['center_capture']['adapter']
        self.assertEqual(raw['provider'], 'gitlab')
        self.assertNotIn('organ_schema', raw)
        centers.decide_proposal(self.n, message['id'], 'adapter', 'accept',
                                self.n.load_state()['dialogue']['revision'])
        projected = centers.view(self.n)['centers'][0]['prepared_adapters'][0]
        self.assertTrue(projected['legacy'])
        self.assertEqual(projected['name'], 'gitlab · issues.read')
        self.assertEqual(projected['role'], 'input')
        self.assertEqual(projected['requested_effects'], ['read'])
        self.assertFalse(projected['execution_enabled'])

    def test_stale_structural_proposal_is_not_applied(self):
        row = centers.create(self.n, definition('Tickets'), revision=0)
        focus = {'kind': 'center', 'id': row['id'], 'revision': row['revision']}
        revised = definition('Tickets après changement')
        message = self.respond('Prépare une révision.', focus,
                               answer(center_revision=revised), 'center-revision-stale')
        centers.create(self.n, definition('Changement concurrent'),
                       revision=centers.view(self.n)['revision'])
        with self.assertRaisesRegex(ValueError, 'Actualise|changé|révision'):
            centers.decide_proposal(self.n, message['id'], 'revision', 'accept',
                                    self.n.load_state()['dialogue']['revision'])
        current = next(item for item in centers.view(self.n)['centers']
                       if item['id'] == row['id'])
        self.assertEqual(current['definition']['title'], 'Tickets')
        self.assertEqual(message['center_capture']['revision']['status'], 'review')

    def test_link_not_touching_selected_center_is_rejected_without_mutation(self):
        first = centers.create(self.n, definition('Premier'), revision=0)
        second = centers.create(self.n, definition('Deuxième'),
                                revision=centers.view(self.n)['revision'])
        third = centers.create(self.n, definition('Troisième'),
                               revision=centers.view(self.n)['revision'])
        focus = {'kind': 'center', 'id': first['id'], 'revision': first['revision']}
        message = self.respond('Relie les deux autres sans me concerner.', focus,
            answer(center_link={'source_id': second['id'], 'target_id': third['id'],
                                'translation': 'Sortie → entrée',
                                'purpose': 'Contourner le centre sélectionné.'}),
            'center-link-outside')
        capture = message['center_capture']['link']
        self.assertEqual(capture['status'], 'rejected')
        self.assertTrue(capture['warnings'])
        self.assertEqual(centers.view(self.n)['links'], [])

    def test_malformed_center_data_keeps_the_conversation_and_no_candidate(self):
        malformed = definition()
        malformed['process'] = []
        response = dialogue.validated_reply(json.dumps(answer(center_proposal=malformed)))
        self.assertEqual(response['reply'], 'Voici une proposition à relire.')
        self.assertIsNone(response['center_proposal'])
        self.assertTrue(response['center_warnings'])
        legacy = answer()
        for key in ('center_proposal', 'center_revision', 'center_link',
                    'organ_proposal', 'adapter_proposal', 'center_output'):
            legacy.pop(key, None)
        old = dialogue.validated_reply(json.dumps(legacy))
        self.assertIsNone(old['center_proposal'])
        self.assertIsNone(old['center_revision'])
        self.assertIsNone(old['center_link'])
        self.assertIsNone(old['organ_proposal'])
        self.assertIsNone(old['adapter_proposal'])
        self.assertIsNone(old['center_output'])

    def test_malformed_action_arguments_keep_the_reply_and_create_no_action(self):
        proposed = {
            'connector_id': 'a' * 32, 'tool': 'echo',
            'arguments_json': '{"value":"premier","value":"second"}',
            'purpose': 'Préparer un appel.', 'expected': 'Une réponse externe.',
            'risk': 'Effet du serveur local.', 'rollback': 'Conserver le refus.',
        }
        response = dialogue.validated_reply(json.dumps(answer(center_action=proposed)))
        self.assertEqual(response['reply'], 'Voici une proposition à relire.')
        self.assertIsNone(response['center_action'])
        self.assertTrue(response['center_warnings'])
        self.assertIn('JSON invalides', response['center_warnings'][0])
