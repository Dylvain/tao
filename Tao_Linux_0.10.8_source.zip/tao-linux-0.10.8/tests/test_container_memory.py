from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from test_node import NodeHarness
import tao_ecology as ecology

GIB=1024**3


class ContainerMemoryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)

    def write(self,name,value):
        path=self.root/name;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(str(value),encoding='ascii')

    def effective(self,total=32*GIB,available=20*GIB):
        return ecology.effective_memory(total,available,self.root)

    def test_without_memory_controller_retains_bounded_host_observation(self):
        self.assertEqual(self.effective(),{'memory_total':32*GIB,'memory_available':20*GIB,'memory_scope':'host'})
        self.assertEqual(self.effective(GIB,2*GIB)['memory_available'],GIB)
        unknown=self.effective(True,-1)
        self.assertIsNone(unknown['memory_total']);self.assertIsNone(unknown['memory_available'])

    def test_v2_uses_namespace_limit_and_usage_instead_of_host_capacity(self):
        self.write('memory.max',GIB);self.write('memory.current',GIB//4)
        result=self.effective()
        self.assertEqual(result,{'memory_total':GIB,'memory_available':3*GIB//4,'memory_scope':'cgroup_v2'})
        self.assertEqual(self.effective(32*GIB,GIB//10)['memory_available'],GIB//10)
        self.write('memory.current',2*GIB)
        self.assertEqual(self.effective()['memory_available'],0)

    def test_total_and_headroom_are_bounded_by_both_host_and_finite_quota(self):
        self.write('memory.max',2*GIB);self.write('memory.current',3*GIB//2)
        result=self.effective(GIB,3*GIB//4)
        self.assertEqual(result['memory_total'],GIB)
        self.assertEqual(result['memory_available'],GIB//2)
        self.assertIsNone(self.effective(None,None)['memory_available'])
        self.assertEqual(self.effective(None,None)['memory_total'],2*GIB)
        self.write('memory.max',0)
        self.assertEqual(self.effective()['memory_total'],0)
        self.assertEqual(self.effective()['memory_available'],0)

    def test_missing_or_invalid_usage_under_finite_limit_stays_unknown(self):
        self.write('memory.max',GIB)
        self.assertIsNone(self.effective()['memory_available'])
        for value in ('-1','max','', 'oops','1.5','2'*129):
            with self.subTest(value=value):
                self.write('memory.current',value);result=self.effective()
                self.assertIsNone(result['memory_available'])
                self.assertEqual(result['memory_total'],GIB)
                self.assertEqual(result['memory_scope'],'cgroup_v2_unknown')
        (self.root/'memory.current').unlink();(self.root/'memory.current').mkdir()
        self.assertIsNone(self.effective()['memory_available'])

    def test_invalid_v2_limit_cannot_silently_fall_back_to_host_or_v1(self):
        self.write('memory/memory.limit_in_bytes',GIB)
        self.write('memory/memory.usage_in_bytes',0)
        for value in ('-2','oops','', '1.2', '1'*129):
            with self.subTest(value=value):
                self.write('memory.max',value);result=self.effective()
                self.assertIsNone(result['memory_available'])
                self.assertEqual(result['memory_scope'],'cgroup_v2_unknown')

    def test_v1_fallback_handles_finite_pressure_and_unknown_usage(self):
        self.write('memory/memory.limit_in_bytes',GIB)
        self.write('memory/memory.usage_in_bytes',GIB-GIB//20)
        result=self.effective()
        self.assertEqual(result,{'memory_total':GIB,'memory_available':GIB//20,'memory_scope':'cgroup_v1'})
        self.assertIn('memory_low',ecology.constraints(dict(result,disk_free=50,disk_total=100)))
        (self.root/'memory/memory.usage_in_bytes').unlink()
        result=self.effective();self.assertIsNone(result['memory_available'])
        self.assertIn('memory_unknown',ecology.constraints(dict(result,disk_free=50,disk_total=100)))

    def test_unlimited_controllers_do_not_replace_host_capacity_with_a_sentinel(self):
        self.write('memory.max','max')
        self.assertEqual(self.effective()['memory_scope'],'host')
        (self.root/'memory.max').unlink()
        for limit in ('-1','9223372036854771712'):
            with self.subTest(limit=limit):
                self.write('memory/memory.limit_in_bytes',limit)
                self.assertEqual(self.effective(),{'memory_total':32*GIB,'memory_available':20*GIB,'memory_scope':'host'})


class ContainerMemoryBudgetTests(NodeHarness):
    def test_container_pressure_and_unreadable_usage_block_before_budget_reservation(self):
        root=self.base/'cgroup';root.mkdir();(root/'memory.max').write_text(str(GIB))
        for usage in (str(GIB-GIB//20),'unreadable'):
            with self.subTest(usage=usage):
                (root/'memory.current').write_text(usage)
                observed=ecology.effective_memory(32*GIB,20*GIB,root)
                observed.update(disk_free=80,disk_total=100,battery=None)
                before=self.n.STATE.read_bytes()
                with patch.object(self.n,'observe_environment',return_value=observed):
                    with self.assertRaises(ValueError):ecology.reserve(self.n,'container-pressure','dialogue')
                self.assertEqual(before,self.n.STATE.read_bytes())
                self.assertEqual(self.n.load_state()['metabolism']['receipts'],[])
