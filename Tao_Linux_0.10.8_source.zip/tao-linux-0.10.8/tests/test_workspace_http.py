"""Exercise empty inheritance, scoped user records and inert trend HTTP flows."""
import http.client
import json
import threading
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from test_node import NodeHarness


class WorkspaceHTTPTests(NodeHarness):
    def setUp(self):
        super().setUp()
        self.n.TOKEN = 'workspace-owner-fixture'
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.thread.join(timeout=3)
        if hasattr(self.server, 'tao_connection'):
            self.server.tao_connection.close()
        self.server.server_close()
        super().tearDown()

    def request(self, path, body=None, owner=True, origin=None, raw=False):
        headers = {'Content-Type': 'application/json'}
        if owner:
            headers['X-Tao-Token'] = self.n.TOKEN
        if origin:
            headers['Origin'] = origin
        client = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=10)
        try:
            client.request('GET' if body is None else 'POST', path,
                           body if raw else None if body is None else json.dumps(body), headers)
            response = client.getresponse(); text = response.read().decode()
            return response.status, json.loads(text) if 'json' in response.getheader('Content-Type', '') else text
        finally:
            client.close()

    def good(self, path, body=None):
        code, value = self.request(path, body)
        self.assertEqual(code, 200, value)
        return value

    def space(self, key):
        return next(row['world_id'] for row in self.good('/api/foundations')['areas'] if row['key'] == key)

    def test_fresh_navigation_is_empty_and_gets_run_no_model_or_login(self):
        with patch('subprocess.Popen', side_effect=AssertionError('No process on arrival')):
            home = self.good('/')
            self.assertIn('Centre principal', home)
            self.assertIn('tao.center.interface.v1', home)
            self.assertIn('id="tao-root"', home)
            self.assertIn('src="/assets/tao-center.js"', home)
            self.assertNotIn('id="house-map"', home)
            overview = self.good('/api/foundations')
            self.assertEqual(len(overview['areas']), 8)
            for row in overview['areas']:
                self.assertTrue(row['world_id'])
                data = self.good('/api/landmarks?world=' + row['world_id'])
                self.assertEqual(data['items'], [])
                self.assertIn('Mes pièces', self.good('/explore?world=' + row['world_id']))
            self.assertEqual(self.good('/api/connection/status')['connected'], None)
            self.assertIn('Modèle pour discuter', self.good('/connect'))
        with self.n.worlds.using(self.space('money')):
            story = self.n.story()
            self.assertEqual(story['text'], '')
            self.assertEqual(story['authority'], 'template_context')

    def test_localized_labels_keep_same_ids_and_existing_dialogue_is_available(self):
        fr = self.good('/api/foundations?lang=fr')
        en = self.good('/api/foundations?lang=en')
        self.assertEqual([x['world_id'] for x in fr['areas']], [x['world_id'] for x in en['areas']])
        self.assertEqual([x['id'] for x in fr['concepts']], [x['id'] for x in en['concepts']])
        self.assertIn('My rooms', self.good('/explore?lang=en'))
        self.assertIn('dialogue-send', self.good('/?view=dialogue'))
        self.assertNotEqual(self.request('/explore?lang=fr&lang=en')[0], 200)
        self.assertNotEqual(self.request('/explore?type=unknown')[0], 200)
        self.assertNotEqual(self.request('/explore?type=role&type=contract')[0], 200)
        self.assertNotEqual(self.request('/?type=role')[0], 200)

    def test_owner_cards_stay_scoped_and_cannot_be_forged_by_other_world(self):
        work, money = self.space('work'), self.space('money')
        body = {'action':'create','concept_id':'tao.concept.role','title':'Support',
                'text':'PRIVATE_WORK_ROLE','revision':0}
        path = '/api/landmarks?world=' + work
        before = self.n.STATE.read_bytes()
        self.assertEqual(self.request(path, body, owner=False)[0], 403)
        self.assertEqual(self.request(path, body, origin='https://outside.invalid')[0], 403)
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.good(path, body)
        own = self.good(path); item = own['items'][0]
        self.assertIn('PRIVATE_WORK_ROLE', json.dumps(own))
        for target in ('main', money):
            self.assertNotIn('PRIVATE_WORK_ROLE', json.dumps(self.good('/api/landmarks?world='+target)))
            self.assertNotIn('PRIVATE_WORK_ROLE', self.good('/explore?world='+target))
        attempted = {'action':'update','id':item['id'],'title':'Changed','text':'Hijacked','revision':item['revision']}
        self.assertEqual(self.request('/api/landmarks?world='+money, attempted)[0], 400)
        self.assertEqual(self.request(path, body)[0], 400)
        self.assertNotIn('Hijacked', json.dumps(self.good(path)))

    def test_guide_and_catalog_are_localized_inert_and_scoped(self):
        work = self.space('work')
        before = self.n.STATE.read_bytes()
        with patch('subprocess.Popen', side_effect=AssertionError('No process in guide')):
            for locale in ('fr', 'en'):
                page = self.good('/guide?world=' + work + '&lang=' + locale)
                self.assertIn('lang="' + locale + '"', page)
                self.assertIn('world=' + work, page)
                catalog = self.good('/api/logic?world=' + work + '&lang=' + locale)
                self.assertEqual(catalog['schema'], 'tao.logic.catalog.v1')
                self.assertFalse(catalog['execution_enabled'])
                self.assertEqual(catalog['status'], 'descriptive_not_executable')
            self.assertEqual(self.good('/api/logic'), self.good('/api/logic?world=' + work))
        self.assertEqual(self.n.STATE.read_bytes(), before)
        for path in ('/guide?lang=xx', '/guide?lang=fr&lang=en',
                     '/api/logic?lang=xx', '/api/logic?lang=fr&lang=en', '/api/logic?run=true'):
            self.assertNotEqual(self.request(path)[0], 200)
        self.assertEqual(self.request('/api/logic', {})[0], 400)
        self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_ambiguous_or_privilege_fields_are_refused(self):
        world = self.space('personal')
        path = '/api/landmarks?world='+world
        raw = '{"action":"create","action":"archive"}'
        self.assertEqual(self.request(path, raw, raw=True)[0], 400)
        body = {'action':'create','concept_id':'tao.concept.task','title':'A task',
                'text':'Do something','revision':0,'execution_enabled':True}
        self.assertEqual(self.request(path, body)[0], 400)
        self.assertFalse(self.n.policy()['self_modify_code'])

    def test_model_bounds_are_explicit_inert_and_unknown_without_measurements(self):
        before = self.n.STATE.read_bytes()
        body = {'schema':'tao.integrability.request.v1','quantity':'Budget déclaré','unit':'XPF',
                'time_unit':'day','samples':[{'t':0,'value':100},{'t':2,'value':120},{'t':5,'value':180}],
                'bounds':{'state':{'max':200},'trend':{'max_abs':15}}}
        result = self.good('/api/integrability/evaluate', body)
        by_key = {row['key']:row for row in result['orders']}
        self.assertEqual(by_key['state']['status'], 'within_model_bounds')
        self.assertEqual(by_key['trend']['status'], 'exceeds')
        self.assertEqual(by_key['trend_change']['status'], 'unknown')
        self.assertFalse(result['execution_enabled'])
        self.assertEqual(self.n.STATE.read_bytes(), before)
        body['samples'] = []
        unknown = self.good('/api/integrability/evaluate', body)
        self.assertEqual(unknown['orders'][0]['status'], 'insufficient_data')
        self.assertIn('Understand a trend', self.good('/trends?lang=en'))

    def test_connection_actions_are_owner_only_and_no_parameters_can_choose_program(self):
        for action in ('check', 'start', 'cancel'):
            path = '/api/connection/' + action
            self.assertEqual(self.request(path, {}, owner=False)[0], 403)
            self.assertEqual(self.request(path, {'executable':'arbitrary'})[0], 400)
        with patch('tao_host_ai.HostAI.status', return_value={}) as check:
            self.good('/api/connection/check', {})
            check.assert_called_once()
        self.assertFalse(self.good('/api/connection/status')['history_imported'])
