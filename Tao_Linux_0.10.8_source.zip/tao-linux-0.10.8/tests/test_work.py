import json
from unittest.mock import patch
from test_node import NodeHarness
import tao_work as work
import tao_workshop as workshop


class WorkTests(NodeHarness):
    def context(self):
        return work.save_context(self.n, 'Je traite des demandes de maintenance.',
                                 'Continuer à programmer.', 'Me laisser envoyer les réponses.')

    def test_context_survives_cycles_without_replacing_story_or_permissions(self):
        self.n.set_story('Mon histoire existante')
        before=self.n.load_state(); policy=self.n.POLICY.read_bytes()
        self.assertNotIn('work_context',before)
        first=self.context()
        with patch.object(self.n.urllib.request,'urlopen') as external:
            s=self.n.cycle(); external.assert_not_called()
        self.assertEqual(s['id'],before['id'])
        self.assertEqual(s['work_context'],first)
        self.assertEqual(self.n.story()['text'],'Mon histoire existante')
        self.assertEqual(self.n.POLICY.read_bytes(),policy)
        self.assertEqual(s['resource_profile']['external_ai_calls'],0)
        self.assertEqual(first['authority'],'description_only')

    def test_revision_protects_other_tabs_and_retains_previous_preferences(self):
        first=self.context()
        with self.assertRaises(ValueError):
            work.save_context(self.n,'Effacement depuis un onglet périmé')
        second=work.save_context(self.n,'Mon travail évolue','Apprendre Python','Ne rien envoyer',1)
        self.assertEqual(second['history'][0],{k:v for k,v in first.items() if k!='history'})
        self.assertEqual(second['revision'],2)
        for index in range(12):
            second=work.save_context(self.n,'Révision suivante',revision=second['revision'])
        self.assertEqual(len(second['history']),10)

    def test_task_example_is_not_a_resolution_or_permission_to_run_code(self):
        self.context(); b=work.add_task(self.n,'Préparer les réponses de support')
        self.assertEqual(b['kind'],'work')
        again=work.add_task(self.n,'Préparer les réponses de support')
        self.assertEqual(b,again)
        updated=work.save_example(self.n,b['id'],'Un client signale une page vide.',
                                  'Un brouillon qui demande URL et étapes.','Aucun envoi automatique.')
        self.assertEqual(updated['status'],'open')
        self.assertEqual(updated['work_task']['example']['status'],'unverified')
        self.assertFalse(updated['work_task']['execution_enabled'])
        self.assertNotIn('evidence',updated['work_task'])
        with self.assertRaises(ValueError):
            work.save_example(self.n,b['id'],'Autre','Autre',revision=1)
        with patch('tao_workshop.git') as git:
            with self.assertRaises(ValueError): workshop.Workshop(self.n).prepare(self.base,b['id'])
            git.assert_not_called()
        # Even the old workshop only selected kind=user, so a downgrade cannot
        # turn this newly described duty into a code-generation candidate.
        self.assertEqual([b for b in self.n.open_buffers(self.n.load_state()) if b['kind']=='user'],[])
        self.assertIn('implémenter',self.n.evolution_plan()[0]['next_step'])
        self.assertIn('Aucun envoi automatique.',work.brief(self.n.load_state()))

    def test_invalid_intake_leaves_state_unchanged(self):
        before=self.n.STATE.read_bytes()
        for args in [(None,),('   ',),('x'*8001,),('Valide',False)]:
            with self.assertRaises(ValueError): work.save_context(self.n,*args)
        with self.assertRaises(ValueError): work.add_task(self.n,'Sans contexte')
        self.assertEqual(before,self.n.STATE.read_bytes())
        self.context(); b=work.add_task(self.n,'Tâche')
        before=self.n.STATE.read_bytes()
        for bid,situation,expected in [(b['id'],'','Résultat'),(b['id'],'Exemple',[]),('../bad','Exemple','Résultat')]:
            with self.assertRaises(ValueError): work.save_example(self.n,bid,situation,expected)
        self.assertEqual(before,self.n.STATE.read_bytes())

    def test_first_screen_and_followup_escape_all_personal_text(self):
        page=self.n.dashboard(self.n.load_state())
        self.assertIn('Discutons et avançons.',page)
        self.assertLess(page.index('id="work-context"'),page.index('id="advanced"'))
        self.assertIn('<details id="advanced">',page)
        attack='<script>alert("example")</script>'
        work.save_context(self.n,attack,attack,attack)
        b=work.add_task(self.n,attack)
        page=self.n.dashboard(self.n.load_state())
        self.assertIn('Donne-moi un exemple',page)
        work.save_example(self.n,b['id'],attack,attack,attack)
        page=self.n.dashboard(self.n.load_state())
        self.assertNotIn(attack,page)
        self.assertIn('&lt;script&gt;',page)
        self.assertIn('Préparer cette aide',page)
