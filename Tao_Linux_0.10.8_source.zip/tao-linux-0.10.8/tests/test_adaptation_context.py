"""Stale candidates remain reviewable; explicit recovery never inherits authority."""
import fcntl
import subprocess
from unittest.mock import patch

from test_node import NodeHarness
from test_ecology import HEALTHY
import tao_adaptation as adapt
import tao_dialogue as dialogue
import tao_workshop as workshop
import tao_worlds as worlds
import tao_foundations as foundations
import tao_landmarks as landmarks
import tao_ui as ui


class AdaptationContextTests(NodeHarness):
    def setUp(self):
        super().setUp()
        self.resources=patch.object(self.n,'observe_environment',return_value=HEALTHY)
        self.resources.start();self.addCleanup(self.resources.stop)

    def task(self,suffix=''):
        revision=self.n.load_state().get('work_context',{}).get('revision',0)
        self.n.work.save_context(self.n,'Une aide locale fictive','Continuer à comprendre','Aucun envoi',revision=revision)
        task=self.n.work.add_task(self.n,'Préparer une petite amélioration'+suffix)
        task=self.n.work.save_example(self.n,task['id'],'Un cas fictif','Un résultat vérifiable')
        s=self.n.load_state();dialogue.ensure(s)
        s['buffers'][task['id']]['work_task']['dialogue_context']={'source_reply':'fixture','authority':'context_only'}
        self.n.atomic_json(self.n.STATE,s,backup=True)
        return task

    def queue(self,task):
        with patch.object(adapt,'diagnose',return_value={'ready':True,'source':str(self.base)}),patch.object(adapt,'launch'):
            return adapt.request(self.n,task['id'],'generate')

    def candidate(self,status='review',experiment_status=None,suffix=''):
        task=self.task(suffix);row=self.queue(task)
        row.update(status=status,operation='verify' if status=='verified' else 'generate',
                   review_digest='reviewed-exact-candidate',experiment_id='012345abcdef')
        adapt.save(self.n,row)
        folder=workshop.Workshop(self.n)._file(row['experiment_id']).parent
        workshop.Workshop(self.n).save({'id':row['experiment_id'],'status':experiment_status or status,
            'attempts':1,'runs':[],'candidate':str(folder/'candidate'),'source_repo':str(self.base),
            'buffer_id':task['id'],'base_commit':'fixture-base'})
        (folder/'tests.log').write_text('Preuve locale conservée')
        (adapt.path(self.n,row['id']).parent/'review.diff').write_text('diff --git fixture')
        return task,row

    def change_discussion(self):
        s=self.n.load_state();d=dialogue.ensure(s)
        d['messages'].append({'id':'followup','role':'user','text':'Explique ce changement.','source':'human','at':self.n.now()})
        d['revision']+=1;d['context_version']+=1
        self.n.atomic_json(self.n.STATE,s,backup=True)

    def test_review_remains_visible_but_stale_context_never_authorizes_test_or_install(self):
        task,row=self.candidate()
        current=adapt.view(self.n,row['id'])
        self.assertTrue(current['context_current']);self.assertIsNone(current['context_error'])
        self.change_discussion()
        stale=adapt.view(self.n,row['id'])
        self.assertFalse(stale['context_current']);self.assertIn('discussion',stale['context_error'])
        self.assertIn('diff --git fixture',stale['patch']);self.assertTrue(stale['replacement_allowed'])
        before=adapt.path(self.n,row['id']).read_bytes()
        with patch.object(adapt,'launch') as launch:
            with self.assertRaisesRegex(ValueError,'discussion'):
                adapt.request(self.n,task['id'],'verify',row['id'],row['review_digest'],True)
            with self.assertRaisesRegex(ValueError,'discussion'):
                adapt.request(self.n,task['id'],'apply',row['id'],row['review_digest'],True)
        launch.assert_not_called();self.assertEqual(adapt.path(self.n,row['id']).read_bytes(),before)

    def test_changed_landmarks_block_candidate_actions_even_without_other_continuity_change(self):
        task,row=self.candidate()
        self.assertEqual(row['context_binding'],'tao.adaptation.context.v2')
        self.assertEqual(row['payload']['landmarks']['items'],[])
        revision=self.n.load_state().get('continuity',{}).get('revision',0)
        landmarks.create(self.n,'question','À vérifier','Cette contrainte est-elle toujours actuelle ?',0)
        self.assertEqual(self.n.load_state()['continuity']['revision'],revision)
        with patch.object(adapt,'launch') as launch:
            with self.assertRaisesRegex(ValueError,'repères'):
                adapt.request(self.n,task['id'],'verify',row['id'],row['review_digest'],True)
            with self.assertRaisesRegex(ValueError,'repères'):
                adapt.request(self.n,task['id'],'apply',row['id'],row['review_digest'],True)
        launch.assert_not_called();self.assertFalse(adapt.view(self.n,row['id'])['context_current'])

    def test_parent_metadata_or_archive_changes_block_worker_without_changing_policy(self):
        parent=worlds.create(self.n,'Parent',revision=worlds.describe(self.n)['revision'])['id']
        child=worlds.create(self.n,'Enfant',parent_id=parent,revision=worlds.describe(self.n)['revision'])['id']
        before_policy=self.n.POLICY.read_bytes()
        with worlds.using(child):
            task=self.task();row=self.queue(task)
            self.assertEqual([entry['id'] for entry in row['payload']['world_scope']['path']],['main',parent,child])
            foundations.update(self.n,parent,worlds.describe(self.n)['revision'],description='Le cadre a changé')
            with patch.object(adapt,'prepare') as prepare:
                with self.assertRaisesRegex(ValueError,'parents'):
                    adapt.worker(self.n,row['id'],'generate')
            prepare.assert_not_called()
            row.update(status='blocked');adapt.save(self.n,row)
            fresh=self.queue(task)
            foundations.archive(self.n,parent,worlds.describe(self.n)['revision'])
            with self.assertRaisesRegex(ValueError,'parents'):
                adapt.check_context(self.n,fresh,require_binding=True)
        self.assertEqual(self.n.POLICY.read_bytes(),before_policy)

    def test_unrelated_space_metadata_and_cards_do_not_stale_an_adaptation(self):
        sibling=worlds.create(self.n,'Autre espace',revision=worlds.describe(self.n)['revision'])['id']
        task,row=self.candidate()
        foundations.update(self.n,sibling,worlds.describe(self.n)['revision'],title='Autre nom')
        with worlds.using(sibling): landmarks.create(self.n,'question','Privé','Question de cet autre espace.',0)
        adapt.check_context(self.n,row,require_binding=True)
        self.assertTrue(adapt.view(self.n,row['id'])['context_current'])
        self.assertNotIn(sibling,str(row['payload']['world_scope']))

    def test_legacy_candidate_is_readable_but_requires_new_preparation_before_execution(self):
        task,row=self.candidate()
        for field in ('context_binding','world_scope_digest','landmarks_revision'):row.pop(field)
        adapt.save(self.n,row);before=adapt.path(self.n,row['id']).read_bytes()
        # Retrospective reports may still assess the old task under its old guards.
        adapt.check_context(self.n,row)
        details=adapt.view(self.n,row['id'])
        self.assertFalse(details['context_current']);self.assertIn('Ancienne préparation',details['context_error'])
        self.assertIn('diff --git fixture',details['patch'])
        with patch.object(adapt,'launch') as launch:
            with self.assertRaisesRegex(ValueError,'Ancienne préparation'):
                adapt.request(self.n,task['id'],'verify',row['id'],row['review_digest'],True)
        launch.assert_not_called();self.assertEqual(adapt.path(self.n,row['id']).read_bytes(),before)
        fresh=self.queue(task)
        adapt.check_context(self.n,fresh,require_binding=True)
        self.assertEqual(adapt.path(self.n,row['id']).read_bytes(),before)

    def test_incomplete_new_context_binding_never_falls_back_to_legacy(self):
        task,row=self.candidate();row.pop('world_scope_digest')
        with self.assertRaisesRegex(ValueError,'incomplète'):adapt.check_context(self.n,row)

    def test_context_is_rechecked_after_runtime_inspection_before_source_integration(self):
        task,row=self.candidate('verified')
        row.update(status='queued',operation='apply',started_epoch=self.n.epoch(),
                   authorized_review_digest=self.n.digest_bytes(b'candidate diff'))
        adapt.save(self.n,row)
        workshop_api=workshop.Workshop(self.n)
        experiment=workshop_api.load(row['experiment_id'])
        experiment['verification']={'candidate_commit':'fixture-commit'};workshop_api.save(experiment)
        def inspect_runtime(*args):
            foundations.update(self.n,worlds.current(),worlds.describe(self.n)['revision'],description='Cadre revu après inspection')
            return {'installer':'fixture','files':{},'node_version':'fixture'}
        with patch.object(workshop.Workshop,'diff',return_value='candidate diff'), \
             patch.object(adapt,'verified_runtime',side_effect=inspect_runtime), \
             patch.object(workshop.Workshop,'accept') as accept:
            result=adapt.worker(self.n,row['id'],'apply')
        self.assertEqual(result['status'],'blocked');self.assertIn('parents',result['message'])
        accept.assert_not_called()

    def test_explicit_replacement_uses_current_context_and_preserves_old_proof(self):
        task,row=self.candidate('verified');self.change_discussion()
        old_job=adapt.path(self.n,row['id']).read_bytes()
        old_experiment=workshop.Workshop(self.n)._file(row['experiment_id']).read_bytes()
        fresh=self.queue(task)
        self.assertNotEqual(fresh['id'],row['id'])
        self.assertEqual(fresh['dialogue_context_version'],self.n.load_state()['dialogue']['context_version'])
        self.assertEqual(fresh['status'],'queued');self.assertNotIn('authorized_review_digest',fresh)
        self.assertFalse(fresh['duty_execution_authorized']);adapt.check_context(self.n,fresh)
        self.assertEqual(self.n.load_state()['buffers'][task['id']]['work_task']['adaptation_id'],fresh['id'])
        self.assertEqual(adapt.path(self.n,row['id']).read_bytes(),old_job)
        self.assertEqual(workshop.Workshop(self.n)._file(row['experiment_id']).read_bytes(),old_experiment)
        self.assertFalse(adapt.view(self.n,row['id'])['context_current'])

    def test_late_worker_cannot_run_after_another_attempt_replaced_its_expired_queue(self):
        task=self.task();old=self.queue(task)
        old['started_epoch']=self.n.epoch()-30;adapt.save(self.n,old)
        fresh=self.queue(task)
        with patch.object(adapt,'prepare') as prepare,patch.object(workshop,'run_bounded') as provider:
            with self.assertRaisesRegex(ValueError,'Lancement périmé'):
                adapt.worker(self.n,old['id'],'generate')
        prepare.assert_not_called();provider.assert_not_called()
        self.assertEqual(adapt.status(self.n,adapt.load(self.n,old['id']))['status'],'interrupted')
        self.assertEqual(self.n.load_state()['buffers'][task['id']]['work_task']['adaptation_id'],fresh['id'])
        self.assertEqual(self.n.load_state()['metabolism']['adaptive_attempts'],0)

    def test_expired_queue_never_restarts_implicitly_even_when_it_is_still_the_current_task(self):
        task=self.task();row=self.queue(task);row['started_epoch']=self.n.epoch()-30;adapt.save(self.n,row)
        before=adapt.path(self.n,row['id']).read_bytes()
        with patch.object(adapt,'prepare') as prepare:
            with self.assertRaisesRegex(ValueError,'Lancement périmé'):
                adapt.worker(self.n,row['id'],'generate')
        prepare.assert_not_called();self.assertEqual(adapt.path(self.n,row['id']).read_bytes(),before)

    def test_worker_reloads_metadata_after_lock_attempt_including_busy_failure(self):
        task=self.task();row=self.queue(task)
        real_flock=fcntl.flock
        for busy in (False,True):
            with self.subTest(busy=busy):
                row.update(status='queued',archived=False,started_epoch=self.n.epoch());adapt.save(self.n,row)
                captured={}
                def before_workshop_lock(file,flags):
                    if str(getattr(file,'name','')).endswith('workshop.lock') and flags==fcntl.LOCK_EX|fcntl.LOCK_NB:
                        latest=adapt.load(self.n,row['id']);latest.update(status='interrupted',archived=True)
                        adapt.save(self.n,latest);captured['archived']=adapt.path(self.n,row['id']).read_bytes()
                        if busy:raise BlockingIOError('fixture busy')
                    return real_flock(file,flags)
                with patch.object(fcntl,'flock',side_effect=before_workshop_lock),patch.object(adapt,'prepare') as prepare:
                    with self.assertRaisesRegex(ValueError,'Restaurer cet essai'):
                        adapt.worker(self.n,row['id'],'generate')
                prepare.assert_not_called()
                self.assertEqual(adapt.path(self.n,row['id']).read_bytes(),captured['archived'])

    def test_uncertain_accepted_installation_cannot_be_replaced_or_archived(self):
        task,row=self.candidate('install_failed','accepted');row['operation']='apply';adapt.save(self.n,row)
        self.change_discussion();before=self.n.STATE.read_bytes()
        details=adapt.view(self.n,row['id'])
        self.assertFalse(details['context_current']);self.assertFalse(details['replacement_allowed'])
        self.assertFalse(details['archive_allowed']);self.assertIn('installation',details['replacement_error'])
        with self.assertRaisesRegex(ValueError,'installation'):
            self.queue(task)
        with self.assertRaisesRegex(ValueError,'installation'):
            adapt.request(self.n,task['id'],'archive',row['id'])
        self.assertEqual(self.n.STATE.read_bytes(),before)
        self.assertFalse(adapt.load(self.n,row['id']).get('archived',False))

    def test_launch_failure_preserves_review_and_requires_explicit_test_retry(self):
        for state in ('review','test_failed'):
            with self.subTest(state=state):
                task,row=self.candidate(state,suffix=state)
                experiment=workshop.Workshop(self.n)._file(row['experiment_id'])
                before_experiment=experiment.read_bytes()
                before_patch=(adapt.path(self.n,row['id']).parent/'review.diff').read_bytes()
                with patch.object(adapt,'launch',side_effect=OSError('Fixture lanceur indisponible')):
                    result=adapt.request(self.n,task['id'],'verify',row['id'],row['review_digest'],True)
                self.assertEqual(result['status'],state)
                self.assertIn('Lancement non confirmé',result['message'])
                self.assertNotIn('authorized_review_digest',result)
                self.assertEqual(experiment.read_bytes(),before_experiment)
                self.assertEqual((adapt.path(self.n,row['id']).parent/'review.diff').read_bytes(),before_patch)
                with patch.object(adapt,'diagnose',return_value={'ready':True}):
                    page=ui.render_adaptation(self.n,self.n.load_state()['buffers'][task['id']])
                self.assertIn('data-action="verify"',page)
                self.assertNotIn('data-action="apply"',page)
                with patch.object(workshop.Workshop,'verify') as verify:
                    with self.assertRaisesRegex(ValueError,'Lancement périmé'):
                        adapt.worker(self.n,row['id'],'verify')
                verify.assert_not_called()
                with patch.object(adapt,'launch') as launch:
                    with self.assertRaisesRegex(ValueError,'Confirmer'):
                        adapt.request(self.n,task['id'],'verify',row['id'],row['review_digest'],False)
                    with self.assertRaisesRegex(ValueError,'relire'):
                        adapt.request(self.n,task['id'],'verify',row['id'],'different',True)
                    launch.assert_not_called()
                    retried=adapt.request(self.n,task['id'],'verify',row['id'],row['review_digest'],True)
                    launch.assert_called_once()
                self.assertEqual(retried['id'],row['id'])
                self.assertEqual(retried['status'],'queued')
                # Complete the fictitious queue before the next subcase.
                retried['status']='review';adapt.save(self.n,retried)

    def test_apply_launch_failure_keeps_accepted_candidate_recoverable(self):
        for state,experiment_state in (('verified','verified'),('install_failed','accepted')):
            for failure in (OSError('Fixture lanceur indisponible'),subprocess.TimeoutExpired('fixture-launcher',1)):
                with self.subTest(state=state,failure=type(failure).__name__):
                    task,row=self.candidate(state,experiment_state,suffix=state+type(failure).__name__)
                    if state=='install_failed':
                        row['operation']='apply';adapt.save(self.n,row)
                    experiment=workshop.Workshop(self.n)._file(row['experiment_id'])
                    before_experiment=experiment.read_bytes()
                    with patch.object(adapt,'launch',side_effect=failure):
                        result=adapt.request(self.n,task['id'],'apply',row['id'],row['review_digest'],True)
                    self.assertEqual(result['status'],state)
                    self.assertNotIn('authorized_review_digest',result)
                    self.assertEqual(experiment.read_bytes(),before_experiment)
                    detail=adapt.view(self.n,row['id'])
                    self.assertTrue(detail['context_current'])
                    if experiment_state=='accepted':
                        self.assertFalse(detail['replacement_allowed'])
                        self.assertFalse(detail['archive_allowed'])
                    with patch.object(adapt,'diagnose',return_value={'ready':True}):
                        page=ui.render_adaptation(self.n,self.n.load_state()['buffers'][task['id']])
                    self.assertIn('data-action="apply"',page)
                    with patch.object(adapt,'verified_runtime') as install:
                        with self.assertRaisesRegex(ValueError,'Lancement périmé'):
                            adapt.worker(self.n,row['id'],'apply')
                    install.assert_not_called()
                    with patch.object(adapt,'launch') as launch:
                        with self.assertRaisesRegex(ValueError,'Confirmer'):
                            adapt.request(self.n,task['id'],'apply',row['id'],row['review_digest'],False)
                        launch.assert_not_called()
                        retried=adapt.request(self.n,task['id'],'apply',row['id'],row['review_digest'],True)
                        launch.assert_called_once()
                    self.assertEqual(retried['id'],row['id'])
                    self.assertEqual(retried['status'],'queued')
                    self.assertEqual(experiment.read_bytes(),before_experiment)
                    retried['status']=state;adapt.save(self.n,retried)

    def test_recovered_launch_never_bypasses_changed_context(self):
        for operation,state,experiment_state in (('verify','review','review'),('apply','install_failed','accepted')):
            with self.subTest(operation=operation):
                task,row=self.candidate(state,experiment_state,suffix=operation)
                with patch.object(adapt,'launch',side_effect=OSError('Fixture lanceur indisponible')):
                    adapt.request(self.n,task['id'],operation,row['id'],row['review_digest'],True)
                self.change_discussion()
                before=adapt.path(self.n,row['id']).read_bytes()
                with patch.object(adapt,'launch') as launch:
                    with self.assertRaisesRegex(ValueError,'discussion'):
                        adapt.request(self.n,task['id'],operation,row['id'],row['review_digest'],True)
                launch.assert_not_called()
                self.assertEqual(adapt.path(self.n,row['id']).read_bytes(),before)
                with patch.object(adapt,'diagnose',return_value={'ready':True}):
                    page=ui.render_adaptation(self.n,self.n.load_state()['buffers'][task['id']])
                self.assertNotIn('data-action="verify"',page)
                self.assertNotIn('data-action="apply"',page)
                self.assertIn('Le contexte de cet essai a changé',page)

    def test_zero_budget_blocks_without_allocating_job_or_candidate_or_losing_current(self):
        task,row=self.candidate('verified');before=self.n.STATE.read_bytes()
        self.n.atomic_json(self.n.POLICY,{'adaptation_runs_per_day':0})
        with patch.object(adapt,'launch') as launch:
            with self.assertRaisesRegex(ValueError,'essais du jour'):
                self.queue(task)
        launch.assert_not_called();self.assertEqual(self.n.STATE.read_bytes(),before)
        self.assertEqual(len(list((self.root/'adaptations').glob('*/job.json'))),1)
        self.assertEqual(list((self.root/'workshop').glob('*/candidate')),[])
        self.assertEqual(self.n.load_state()['metabolism']['adaptive_attempts'],0)

    def test_fresh_resource_constraints_block_before_allocation(self):
        task=self.task()
        for changes in ({'disk_free':1},{'memory_available':None},{'battery':[{'capacity':1,'status':'Discharging'}]}):
            with self.subTest(changes=changes),patch.object(self.n,'observe_environment',return_value=dict(HEALTHY,**changes)):
                with self.assertRaisesRegex(ValueError,'Préparation différée'):self.queue(task)
        self.assertEqual(list((self.root/'adaptations').glob('*/job.json')),[])
        self.assertNotIn('adaptation_id',self.n.load_state()['buffers'][task['id']]['work_task'])

    def test_budget_is_checked_again_when_worker_starts(self):
        task=self.task();row=self.queue(task)
        self.n.atomic_json(self.n.POLICY,{'adaptation_runs_per_day':0})
        with patch.object(adapt,'prepare') as prepare,patch.object(workshop,'run_bounded') as provider:
            blocked=adapt.worker(self.n,row['id'],'generate')
        self.assertEqual(blocked['status'],'blocked');prepare.assert_not_called();provider.assert_not_called()
        self.assertEqual(list((self.root/'workshop').glob('*/candidate')),[])
        self.assertEqual(self.n.load_state()['metabolism']['adaptive_attempts'],0)

    def test_non_git_or_dirty_sources_do_not_create_clone_or_spend_budget(self):
        task=self.task();row=self.queue(task)
        with patch.object(adapt,'prepare') as prepare:
            blocked=adapt.worker(self.n,row['id'],'generate')
        prepare.assert_not_called();self.assertEqual(blocked['status'],'blocked');self.assertIn('dépôt Git',blocked['message'])
        repo=self.base/'repo';repo.mkdir();(repo/'fixture.txt').write_text('initial')
        workshop.git(repo,'init');workshop.git(repo,'add','.');workshop.git(repo,*workshop.identity_args(),'commit','-m','Fixture')
        adapt.source_preflight(repo)
        (repo/'fixture.txt').write_text('modification à conserver')
        row=self.queue(task);row['source_repo']=str(repo);adapt.save(self.n,row)
        with patch.object(adapt,'prepare') as prepare:
            blocked=adapt.worker(self.n,row['id'],'generate')
        prepare.assert_not_called();self.assertIn('changements',blocked['message'])
        self.assertEqual((repo/'fixture.txt').read_text(),'modification à conserver')
        self.assertEqual(list((self.root/'workshop').glob('*/candidate')),[])
        self.assertEqual(self.n.load_state()['metabolism']['adaptive_attempts'],0)

    def test_diagnostic_only_claims_local_prerequisites_and_never_invokes_provider_or_git(self):
        self.n.atomic_json(self.root/'source.json',{'path':str(self.base)})
        with patch.object(adapt,'executable',return_value='/fixture/codex'),patch.object(workshop,'git') as git:
            result=adapt.diagnose(self.n)
        self.assertTrue(result['ready']);git.assert_not_called()
        self.assertEqual(result['qualification'],'local_prerequisites_only')
        self.assertEqual(result['authentication'],'checked_by_next_explicit_run')
        self.assertEqual(result['resources_and_budget'],'checked_before_generation')

    def test_archiving_and_restoring_preserve_files_context_and_authorizations(self):
        task,row=self.candidate('verified');self.change_discussion()
        diff=adapt.path(self.n,row['id']).parent/'review.diff';original=diff.read_bytes()
        experiment_file=workshop.Workshop(self.n)._file(row['experiment_id'])
        archived=adapt.request(self.n,task['id'],'archive',row['id'])
        self.assertTrue(archived['archived']);self.assertEqual(archived['status'],'verified')
        self.assertTrue(self.n.load_json(experiment_file)['archived'])
        self.assertEqual(diff.read_bytes(),original);self.assertEqual(adapt.active_count(self.n),0)
        self.assertEqual(self.n.load_state()['buffers'][task['id']]['work_task']['adaptation_id'],row['id'])
        restored=adapt.request(self.n,task['id'],'restore',row['id'])
        self.assertFalse(restored['archived']);self.assertFalse(self.n.load_json(experiment_file)['archived'])
        self.assertEqual(restored['review_digest'],row['review_digest']);self.assertEqual(diff.read_bytes(),original)
        self.assertFalse(adapt.view(self.n,row['id'])['context_current'])
        with self.assertRaisesRegex(ValueError,'discussion'):
            adapt.request(self.n,task['id'],'apply',row['id'],row['review_digest'],True)

    def test_archive_refuses_running_or_locked_workshop_without_partial_change(self):
        task,row=self.candidate('review');jobfile=adapt.path(self.n,row['id'])
        experiment_file=workshop.Workshop(self.n)._file(row['experiment_id'])
        before=(jobfile.read_bytes(),experiment_file.read_bytes())
        with open(self.root/'workshop.lock','a+') as other:
            fcntl.flock(other,fcntl.LOCK_EX|fcntl.LOCK_NB)
            with self.assertRaisesRegex(ValueError,'atelier est en cours'):
                adapt.request(self.n,task['id'],'archive',row['id'])
        self.assertEqual((jobfile.read_bytes(),experiment_file.read_bytes()),before)
        row.update(status='queued',started_epoch=self.n.epoch(),pid=None);adapt.save(self.n,row)
        with self.assertRaisesRegex(ValueError,'Attendre la fin'):
            adapt.request(self.n,task['id'],'archive',row['id'])
        self.assertEqual(experiment_file.read_bytes(),before[1])

    def test_failed_second_metadata_write_restores_linked_experiment(self):
        task,row=self.candidate('review')
        experiment_file=workshop.Workshop(self.n)._file(row['experiment_id'])
        before=experiment_file.read_bytes()
        with patch.object(adapt,'save',side_effect=OSError('fixture write failure')):
            with self.assertRaises(OSError):adapt.request(self.n,task['id'],'archive',row['id'])
        self.assertEqual(experiment_file.read_bytes(),before)
        self.assertFalse(adapt.load(self.n,row['id']).get('archived',False))

    def test_archive_and_restore_reconcile_disagreed_flags_without_deleting_either_side(self):
        task,row=self.candidate('review');w=workshop.Workshop(self.n)
        # A crash after the first file, or a direct CLI action, can leave only
        # the experiment archived. Restoring the already-active job repairs it.
        w.archive(row['experiment_id'])
        for index in range(99):adapt.save(self.n,dict(row,id=f'{index:012x}',experiment_id=None,task_id='other',status='blocked'))
        self.assertEqual(adapt.active_count(self.n),100)
        restored=adapt.request(self.n,task['id'],'restore',row['id'])
        self.assertFalse(restored['archived']);self.assertFalse(w.load(row['experiment_id'])['archived'])
        self.assertEqual(adapt.active_count(self.n),100)
        # In the other direction, don't return early just because the job has
        # already been marked archived: reconcile the experiment too.
        restored['archived']=True;adapt.save(self.n,restored)
        repaired=adapt.request(self.n,task['id'],'archive',row['id'])
        self.assertTrue(repaired['archived']);self.assertTrue(w.load(row['experiment_id'])['archived'])
        self.assertEqual(w.load(row['experiment_id'])['status'],'review')
        self.assertTrue((adapt.path(self.n,row['id']).parent/'review.diff').is_file())

    def test_archived_job_does_not_count_but_restore_respects_global_capacity(self):
        task,row=self.candidate('review');adapt.request(self.n,task['id'],'archive',row['id'])
        for index in range(100):
            other=dict(row,id=f'{index:012x}',task_id='other',experiment_id=None,status='blocked')
            adapt.save(self.n,other)
        self.assertEqual(adapt.active_count(self.n),100)
        before=workshop.Workshop(self.n)._file(row['experiment_id']).read_bytes()
        with self.assertRaisesRegex(ValueError,'100 adaptations actives'):
            adapt.request(self.n,task['id'],'restore',row['id'])
        self.assertTrue(adapt.load(self.n,row['id'])['archived'])
        self.assertEqual(workshop.Workshop(self.n)._file(row['experiment_id']).read_bytes(),before)
        adapt.request(self.n,'other','archive','000000000000')
        restored=adapt.request(self.n,task['id'],'restore',row['id'])
        self.assertFalse(restored['archived']);self.assertEqual(adapt.active_count(self.n),100)

    def test_new_generation_keeps_archived_attempt_and_world_authority(self):
        task,row=self.candidate('review');adapt.request(self.n,task['id'],'archive',row['id'])
        old=adapt.path(self.n,row['id']).read_bytes();fresh=self.queue(task)
        self.assertNotEqual(fresh['id'],row['id']);self.assertEqual(adapt.path(self.n,row['id']).read_bytes(),old)
        world=worlds.create(self.n,'Autre espace','main','',0)['id']
        with worlds.using(world):
            with self.assertRaisesRegex(ValueError,'autre espace'):adapt.view(self.n,row['id'])
            with self.assertRaisesRegex(ValueError,'autre espace'):
                adapt.request(self.n,task['id'],'restore',row['id'])
