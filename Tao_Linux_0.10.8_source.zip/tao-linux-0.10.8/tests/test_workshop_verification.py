"""Regression cases for reviewed-tree integrity and bounded process cleanup."""
import py_compile
import sys
import time
from pathlib import Path
from unittest.mock import patch

from test_node import NodeHarness
import tao_workshop as workshop


class WorkshopVerificationTests(NodeHarness):
    def prepare(self, script, tests=None):
        repo=self.base/'repo';repo.mkdir();(repo/'scripts').mkdir()
        (repo/'value.txt').write_text('before\n')
        (repo/'.gitignore').write_text('*.pyc\n__pycache__/\n')
        (repo/'scripts/verify.sh').write_text(script)
        if tests:
            (repo/'tests').mkdir();(repo/'tests/test_value.py').write_text(tests)
        workshop.git(repo,'init');workshop.git(repo,'add','.')
        workshop.git(repo,*workshop.identity_args(),'commit','-m','Fictitious verification baseline')
        buffer=self.n.add_buffer('Un écart fictif','Un résultat fictif','Un test réel')
        w=workshop.Workshop(self.n);experiment=w.prepare(repo,buffer['id'])
        candidate=Path(experiment['candidate']);(candidate/'value.txt').write_text('after\n')
        return repo,w,experiment,candidate

    def test_ignored_sourceless_module_cannot_replace_unittest_or_fake_green_tests(self):
        repo,w,e,candidate=self.prepare('set -eu\npython3 -m unittest discover -s tests -q\n',
            'import unittest\nclass Regression(unittest.TestCase):\n def test_red(self): self.assertEqual(1, 2)\n')
        marker=self.base/'unreviewed-code-executed'
        source=self.base/'compile-only.py'
        source.write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text("unreviewed")\n')
        py_compile.compile(str(source),cfile=str(candidate/'unittest.pyc'),doraise=True)
        diff=w.diff(e['id'])
        self.assertNotIn('unittest.pyc',diff)
        checked=w.verify(e['id'],True)
        self.assertEqual(checked['status'],'test_failed')
        self.assertFalse(marker.exists())
        self.assertTrue((candidate/'unittest.pyc').is_file())
        proof=checked['verification'];test_tree=Path(proof['test_checkout'])
        self.assertNotEqual(test_tree,candidate)
        self.assertFalse((test_tree/'unittest.pyc').exists())
        self.assertEqual(workshop.git(test_tree,'rev-parse','HEAD'),proof['candidate_commit'])
        self.assertEqual(workshop.git(candidate,'rev-parse','HEAD'),proof['candidate_commit'])
        self.assertEqual(proof['checkout_origin'],'recorded_candidate_commit')
        self.assertIn('AssertionError',(candidate.parent/'tests.log').read_text())
        with self.assertRaises(ValueError):w.accept(e['id'])
        self.assertEqual((repo/'value.txt').read_text(),'before\n')

    def test_repeated_verification_uses_fresh_commits_and_preserves_prior_checkouts(self):
        repo,w,e,candidate=self.prepare('set -eu\ntest "$(cat value.txt)" = after\n')
        first=w.verify(e['id'],True);first_tree=Path(first['verification']['test_checkout'])
        self.assertEqual(first['status'],'verified')
        # Output from the prior test tree must never become input to the next.
        (first_tree/'untracked-test-output').write_text('keep prior proof')
        second=w.verify(e['id'],True);second_tree=Path(second['verification']['test_checkout'])
        self.assertEqual(second['status'],'verified')
        self.assertNotEqual(first_tree,second_tree)
        self.assertTrue((first_tree/'untracked-test-output').is_file())
        self.assertFalse((second_tree/'untracked-test-output').exists())
        w.accept(e['id']);self.assertEqual((repo/'value.txt').read_text(),'after\n')

    def test_test_checkout_change_cannot_qualify_unchanged_generation_tree(self):
        repo,w,e,candidate=self.prepare('set -eu\nprintf mutated > value.txt\n')
        checked=w.verify(e['id'],True)
        self.assertEqual(checked['status'],'test_failed')
        self.assertFalse(checked['verification']['unchanged_during_tests'])
        self.assertEqual((candidate/'value.txt').read_text(),'after\n')
        self.assertEqual((repo/'value.txt').read_text(),'before\n')

    def test_generator_directory_mutation_during_tests_invalidates_the_receipt(self):
        repo,w,e,candidate=self.prepare('set -eu\ntest "$(cat value.txt)" = after\n')
        actual=workshop.run_bounded
        def mutate(*args,**kwargs):
            (candidate/'value.txt').write_text('changed during test')
            return actual(*args,**kwargs)
        with patch.object(workshop,'run_bounded',side_effect=mutate):checked=w.verify(e['id'],True)
        self.assertEqual(checked['status'],'test_failed')
        self.assertFalse(checked['verification']['unchanged_during_tests'])
        with self.assertRaises(ValueError):w.accept(e['id'])


class ProcessGroupCleanupTests(NodeHarness):
    def test_children_with_closed_output_are_stopped_after_success_even_when_term_ignored(self):
        for ignore_term in (False,True):
            with self.subTest(ignore_term=ignore_term):
                marker=self.base/('late-'+str(ignore_term));ready=self.base/('ready-'+str(ignore_term))
                pid_file=self.base/('pid-'+str(ignore_term))
                child=('import signal, time\nfrom pathlib import Path\n'+
                       ('signal.signal(signal.SIGTERM,signal.SIG_IGN)\n' if ignore_term else '')+
                       'Path('+repr(str(ready))+').write_text("ready")\n'+
                       'time.sleep(1)\nPath('+repr(str(marker))+').write_text("too late")\n')
                parent=('import subprocess, sys, time\nfrom pathlib import Path\n'+
                        'p=subprocess.Popen([sys.executable,"-c",'+repr(child)+'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)\n'+
                        'Path('+repr(str(pid_file))+').write_text(str(p.pid))\n'+
                        'while not Path('+repr(str(ready))+').exists(): time.sleep(.01)\n')
                result=workshop.run_bounded([sys.executable,'-c',parent],self.base,self.base/'process.log',2)
                # Observe the child's actual effect, rather than /proc entries
                # which may belong to a different process namespace or a reused
                # PID after its death. The fixture exits by itself after 1 s.
                time.sleep(1.05)
                self.assertTrue(result['ok']);self.assertTrue(result['residual_group_terminated'])
                self.assertLess(result['duration_seconds'],2.5)
                self.assertFalse(marker.exists())

    def test_simple_completion_does_not_claim_residual_processes(self):
        result=workshop.run_bounded([sys.executable,'-c','print("finished")'],self.base,self.base/'normal.log',2)
        self.assertTrue(result['ok']);self.assertFalse(result['residual_group_terminated'])
