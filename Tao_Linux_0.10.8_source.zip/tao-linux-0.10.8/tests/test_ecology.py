import json, os, subprocess, sys
from pathlib import Path
from unittest.mock import patch
from test_node import NodeHarness
import tao_ecology as ecology
import tao_workshop as workshop

HEALTHY={'disk_free':80,'disk_total':100,'memory_available':70,'memory_total':100,'battery':None}


class EcologyTests(NodeHarness):
    def test_additive_migration_and_real_measurements(self):
        old=self.n.load_state(); old.pop('lineage',None); old.pop('metabolism',None)
        old['private_extension']={'keep':True}; old['node_version']='0.5.3'
        self.n.atomic_json(self.n.STATE,old,backup=True)
        with patch.object(self.n.urllib.request,'urlopen') as network:
            new=self.n.cycle(); view=ecology.snapshot(self.n,new)
            network.assert_not_called()
        self.assertEqual(new['id'],old['id']); self.assertEqual(new['private_extension'],{'keep':True})
        self.assertEqual(view['lineage']['species_status'],'unclassified')
        self.assertEqual(view['metabolism']['measured_cycles'],1)
        self.assertGreater(view['metabolism']['basal_cpu_seconds'],0)
        self.assertTrue(all(value is None for value in view['unmeasured'].values()))
        self.assertEqual(new['resource_profile']['external_ai_calls'],0)

    def test_reservation_refund_failure_and_idempotency(self):
        self.n.atomic_json(self.n.POLICY,{'adaptation_runs_per_day':2,'adaptation_seconds_per_day':100})
        with patch.object(self.n,'observe_environment',return_value=HEALTHY):
            first=ecology.reserve(self.n,'experiment1')
            self.assertEqual(first['timeout_seconds'],93)
            with self.assertRaises(ValueError): ecology.reserve(self.n,'experiment2')
            ecology.settle(self.n,first['id'],4.5,False)
            with self.assertRaises(ValueError): ecology.settle(self.n,first['id'],0,True)
            second=ecology.reserve(self.n,'experiment2')
            self.assertEqual(second['timeout_seconds'],88.5)
            ecology.settle(self.n,second['id'],2,True)
            with self.assertRaises(ValueError): ecology.reserve(self.n,'experiment3')
        m=self.n.load_state()['metabolism']
        self.assertEqual(m['daily_budget']['charged_seconds'],6.5)
        self.assertEqual(m['adaptive_attempts'],2)
        self.assertEqual([r['status'] for r in m['receipts']],['failed','completed'])

    def test_crash_and_backwards_clock_never_recharge_budget(self):
        self.n.atomic_json(self.n.POLICY,{'adaptation_runs_per_day':1})
        with patch.object(self.n,'observe_environment',return_value=HEALTHY):
            with patch.object(self.n,'now',return_value='2026-09-28T23:59:00Z'):
                receipt=ecology.reserve(self.n,'crashed')
            with patch.object(self.n,'now',return_value='2026-09-27T10:00:00Z'):
                with self.assertRaises(ValueError): ecology.reserve(self.n,'clock_back')
            with patch.object(self.n,'now',return_value='2026-09-29T00:00:00Z'):
                other=ecology.reserve(self.n,'new_day')
                ecology.settle(self.n,receipt['id'],10,False)
        m=self.n.load_state()['metabolism']
        self.assertEqual(m['daily_budget']['charged_seconds'],other['charged_seconds'])
        self.assertEqual(m['daily_budget']['day_utc'],'2026-09-29')

    def test_resource_pressure_blocks_before_spending(self):
        for changes in [{'disk_free':2},{'memory_available':3},{'memory_available':None},
                        {'battery':[{'capacity':4,'status':'Discharging'}]}]:
            with self.subTest(changes=changes), patch.object(self.n,'observe_environment',return_value=dict(HEALTHY,**changes)):
                with self.assertRaises(ValueError): ecology.reserve(self.n,'blocked')
        self.assertEqual(self.n.load_state()['metabolism']['adaptive_attempts'],0)
        self.assertEqual(ecology.constraints(dict(HEALTHY,battery=[{'capacity':4,'status':'Charging'}])),[])

    def test_disabled_budget_prevents_provider_invocation(self):
        self.n.atomic_json(self.n.POLICY,{'adaptation_runs_per_day':0})
        w=workshop.Workshop(self.n); folder=w._file('012345abcdef').parent; folder.mkdir(parents=True)
        (folder/'prompt.txt').write_text('test')
        w.save({'id':'012345abcdef','status':'prepared','attempts':0,'candidate':str(folder),'runs':[]})
        with patch('tao_workshop.shutil.which',return_value='/unused/codex'), patch('tao_workshop.run_bounded') as run:
            with self.assertRaises(ValueError): w.run('012345abcdef')
            run.assert_not_called()
        self.assertEqual(w.load('012345abcdef')['status'],'prepared')

    def test_birth_is_independent_dormant_and_has_no_private_inheritance(self):
        self.n.set_story('PRIVATE_PARENT_HISTORY')
        self.n.add_buffer('PRIVATE_PARENT_BUFFER','Private goal','Private proof')
        self.n.work.save_context(self.n,'PRIVATE_WORK_CONTEXT','PRIVATE_LEARNING','PRIVATE_BOUNDARIES')
        self.n.work.add_task(self.n,'PRIVATE_WORK_TASK')
        self.n.atomic_json(self.n.POLICY,{'commons_read':True,'adaptation_runs_per_day':9})
        self.n.atomic_json(self.n.HERITAGE,{'builtin':[{'content':'PRIVATE_LEARNED_RECIPE'}],'remote':[]})
        # Code is inherited, but reusable private work and external authority are not.
        for relative in ('reuse/main.json','bridge/main/state-v1.json','connectors/main.json'):
            private=self.root/relative; private.parent.mkdir(parents=True,exist_ok=True)
            private.write_text('{"private":"PRIVATE_DURABLE_TOOLS"}')
        destination=self.base/'child'
        with patch.object(self.n,'observe_environment',return_value=HEALTHY):
            born=ecology.birth(self.n,destination,'Aider mon projet de jardin',8791)
        self.assertFalse((destination/'session.json').exists())
        self.assertEqual(self.n.digest_bytes((destination/'runtime/theory.canonical.json').read_bytes()),self.n.THEORY['sha256'])
        self.assertFalse(born['private_memory_inherited'])
        for directory in ('reuse','bridge','connectors'): self.assertFalse((destination/directory).exists())
        for module in ('tao_reuse.py','tao_bridge.py','tao_connectors.py','tao_tools.py','tao_tools_ui.py',
                       'tao_centers_app.py','tao_backup.py','tao-center.js','tao-center.css'):
            self.assertTrue((destination/'runtime'/module).is_file())
        data=(destination/'state.json').read_text()
        child=json.loads(data); parent=self.n.load_state()
        self.assertNotEqual(child['id'],parent['id']); self.assertEqual(child['lineage']['parent_id'],parent['id'])
        self.assertEqual(child['lineage']['generation'],1); self.assertEqual(child['buffers'],{})
        self.assertEqual(json.loads((destination/'story.json').read_text())['text'],'Aider mon projet de jardin')
        for path in destination.glob('*.json'): self.assertNotIn('PRIVATE_',path.read_text())
        self.assertFalse(json.loads((destination/'policy.json').read_text())['commons_read'])
        frozen_parent=self.n.STATE.read_bytes()
        result=subprocess.run([sys.executable,str(destination/'runtime/tao_node.py'),'cycle'],
            env=dict(os.environ,TAO_ROOT=str(destination)),capture_output=True,text=True,timeout=10)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(self.n.STATE.read_bytes(),frozen_parent)
        self.assertEqual(json.loads(result.stdout)['id'],child['id'])
        grand=self.base/'grandchild'
        result=subprocess.run([sys.executable,str(destination/'runtime/tao_node.py'),'birth',str(grand),
            '--purpose','Étudier les semis','--port','8792'],env=dict(os.environ,TAO_ROOT=str(destination)),
            capture_output=True,text=True,timeout=10)
        self.assertEqual(result.returncode,0,result.stderr)
        grand_state=json.loads((grand/'state.json').read_text())
        self.assertEqual(grand_state['lineage']['generation'],2)
        self.assertEqual(grand_state['lineage']['founder_id'],parent['id'])

    def test_birth_never_overwrites_or_uses_parent_port(self):
        occupied=self.base/'occupied'; occupied.mkdir(); (occupied/'keep').write_text('preserve')
        for dest,port in [(occupied,8791),(self.base/'empty-child',8790),(self.root/'child',8791)]:
            with self.subTest(destination=dest), self.assertRaises(ValueError):
                ecology.birth(self.n,dest,'Purpose',port)
        self.assertEqual((occupied/'keep').read_text(),'preserve')
        self.assertFalse((self.base/'empty-child').exists())
        self.assertNotIn('offspring',self.n.load_state())
