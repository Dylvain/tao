"""Hosted access through real HTTP, with a local node and fictitious credentials."""
import concurrent.futures
from contextlib import contextmanager
import hashlib
import http.client
import json
import os
import re
import socket
import threading
import time
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from test_node import NodeHarness
import tao_host as host

ORIGIN = 'https://fixture.example.test'
CODE = 'a-test-activation-code-never-used-outside-tests-123456'
PASSWORD = 'A fictitious long password 123!'
WORKER_TOKEN = 'fictitious-worker-credential-never-used-123456'


def page_token(page):
    legacy = re.search(r'const token=("[^"]+");', page)
    if legacy:
        return json.loads(legacy.group(1))
    modern = re.search(r'<script id="tao-bootstrap" type="application/json">(.*?)</script>', page, re.S)
    if modern:
        return json.loads(modern.group(1))['token']
    raise AssertionError('Jeton de page absent')


class HostTests(NodeHarness):
    def test_authenticated_backup_boundary_forwards_core_without_credentials(self):
        self.activate()
        marker = self.n.add_buffer('Sauvegarde hébergée', 'Conserver', 'Présent')
        status, body, _ = self.request('/api/backup/export?world=main', {'scope': 'core'})
        self.assertEqual(status, 200, body)
        exported = json.loads(body)
        self.assertIn(marker['id'], exported['bundle']['state']['buffers'])
        self.assertNotIn(self.n.TOKEN, body)
        status, body, _ = self.request('/api/backup/inspect?world=main', {'bundle': exported['bundle']})
        self.assertEqual(status, 200, body)
        self.assertEqual(json.loads(body)['schema'], 'tao.portable.core.preview.v1')
        self.assertGreater(host.MAX_BACKUP_BODY, host.MAX_RESPONSE)

    def test_workspace_pages_replace_upstream_credentials(self):
        self.activate()
        for path in ('/explore?lang=en', '/connect', '/trends'):
            status, page, _ = self.request(path)
            self.assertEqual(status, 200, page)
            self.assertNotIn(self.n.TOKEN, page)
            self.assertIn('const token='+json.dumps(self.token)+';', page)

    def test_durable_tools_require_login_and_accept_bounded_large_input(self):
        import tao_reuse as reuse
        self.assertEqual(self.request('/tools', authenticated=False)[0], 401)
        self.assertEqual(self.request('/api/tools', authenticated=False)[0], 401)
        self.activate()
        status, page, _ = self.request('/tools')
        self.assertEqual(status, 200, page)
        self.assertNotIn(self.n.TOKEN, page)
        self.assertIn('const token='+json.dumps(self.token)+';', page)
        row = reuse.propose(self.n, reuse.template('csv.audit'))
        row = reuse.qualify(self.n, row['id'], row['revision'])
        row = reuse.activate(self.n, row['id'], row['revision'], row['qualification']['review_digest'])
        payload = {'id': row['id'], 'revision': row['revision'], 'inputs': {'csv': 'id,title,url\n1,'+'x'*40000+',/\n'}}
        status, body, _ = self.request('/api/reuse/run?world=main', payload)
        self.assertEqual(status, 200, body)
        self.assertEqual(json.loads(body)['model_calls'], 0)
        self.assertEqual(self.request('/api/connectors/register', {})[0], 400)

    def setUp(self):
        super().setUp()
        self.env_patch = patch.dict(os.environ, {'TAO_HOST_SETUP_SHA256': hashlib.sha256(CODE.encode()).hexdigest()})
        self.env_patch.start();self.addCleanup(self.env_patch.stop)
        self.n.TOKEN = 'private-node-token-only'
        self.node = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        self.node.daemon_threads = True;self.node.session_id = 'host-test-node'
        policy = self.n.policy();policy['http_port'] = self.node.server_port
        self.n.policy = lambda: dict(policy)
        self.node_thread = threading.Thread(target=self.node.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
        self.node_thread.start()
        self.n.atomic_json(self.root/'session.json', {'id': self.node.session_id, 'port': self.node.server_port, 'token': self.n.TOKEN})
        self.n.set_story('PRIVATE_HOST_STORY');self.n.cycle()
        self.auth_root = self.base/'host-auth'
        self.gateway = host.HostServer(('127.0.0.1', 0), self.n, ORIGIN, self.auth_root)
        self.start_gateway()
        self.cookie = None;self.token = None

    def start_gateway(self):
        self.thread = threading.Thread(target=self.gateway.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.gateway.shutdown();self.thread.join(timeout=3);self.gateway.server_close()
        self.node.shutdown();self.node_thread.join(timeout=3);self.node.server_close()
        super().tearDown()

    def request(self, path='/', value=None, headers=None, authenticated=True, method=None):
        body = json.dumps(value).encode() if value is not None else None
        outgoing = {'Host': ORIGIN.removeprefix('https://')}
        if authenticated and self.cookie:outgoing['Cookie'] = self.cookie
        if value is not None:
            outgoing.update({'Origin': ORIGIN, 'Content-Type': 'application/json', 'X-Tao-Token': self.token or 'host-auth'})
        for key, item in (headers or {}).items():
            if item is None:outgoing.pop(key, None)
            else:outgoing[key] = item
        connection = http.client.HTTPConnection('127.0.0.1', self.gateway.server_port, timeout=5)
        try:
            connection.request(method or ('POST' if value is not None else 'GET'), path, body, outgoing)
            response = connection.getresponse()
            return response.status, response.read().decode(), dict(response.getheaders())
        finally:connection.close()

    def activate(self):
        status, body, headers = self.request('/host/setup', {'code': CODE, 'password': PASSWORD, 'label': 'Mon téléphone fictif'}, authenticated=False)
        self.assertEqual(status, 200, body)
        self.cookie = headers['Set-Cookie'].split(';', 1)[0]
        status, body, _ = self.request('/')
        self.assertEqual(status, 200, body)
        self.assertNotIn(self.n.TOKEN, body)
        self.token = page_token(body)
        return headers['Set-Cookie']

    def device_request(self, value, path='/api/devices/worker', headers=None):
        outgoing = {'Origin': None, 'X-Tao-Token': None}
        if path.split('?', 1)[0] == '/api/devices/worker':outgoing['Authorization'] = 'Bearer '+WORKER_TOKEN
        outgoing.update(headers or {})
        return self.request(path, value, outgoing, authenticated=False)

    @contextmanager
    def device_upstream(self):
        """Record the exact gateway-to-node request without simulating auth."""
        class Response:
            status = 200
            body = b'{"ok":true}'
            content_type = 'application/json; charset=utf-8'
            def read(self, limit):return self.body[:limit]
            def getheader(self, key, default=None):return self.content_type if key.lower() == 'content-type' else default
        class Connection:
            def __init__(self):self.calls = [];self.reply = Response()
            def request(self, *args, **kwargs):self.calls.append((args, kwargs))
            def getresponse(self):return self.reply
            def close(self):pass
        fake = Connection();original = host.http.client.HTTPConnection
        def factory(address, port=None, *args, **kwargs):
            if port == self.node.server_port:return fake
            return original(address, port, *args, **kwargs)
        with patch.object(host.http.client, 'HTTPConnection', side_effect=factory):yield fake

    def test_unauthenticated_reads_and_ai_routes_never_reveal_private_state(self):
        for path in ['/state', '/dialogue/export', '/dialogue/handoff', '/continuity/export', '/theory',
                     '/host/account', '/host/ai', '/host/ai/status', '/api/adaptation?id=abcdef012345',
                     '/devices', '/api/devices', '/api/devices/enrol', '/api/devices/worker']:
            status, body, _ = self.request(path)
            self.assertEqual(status, 401, path);self.assertNotIn('PRIVATE_HOST_STORY', body)
            self.assertEqual(json.loads(body)['login_url'], '/host/login')
        for path in ['/', '/?world=main', '/host/login', '/host/setup']:
            status, body, _ = self.request(path)
            self.assertEqual(status, 200);self.assertIn('Code de première activation', body)
            self.assertNotIn(CODE, body);self.assertNotIn(self.n.TOKEN, body)

    def test_health_is_actual_node_health_and_exposes_only_boolean(self):
        for hostname in [ORIGIN.removeprefix('https://'), 'healthcheck.railway.app']:
            status, body, _ = self.request('/health', headers={'Host': hostname})
            self.assertEqual(status, 200, body);self.assertEqual(json.loads(body), {'ok': True})
        for path in ['/state', '/health?world=main', '/host/login']:
            self.assertEqual(self.request(path, headers={'Host': 'healthcheck.railway.app'})[0], 403)
        self.assertEqual(self.request('/health', headers={'Host': 'evil.example'})[0], 403)
        self.node.shutdown();self.node_thread.join(timeout=3);self.node.server_close()
        status, body, _ = self.request('/health')
        self.assertEqual(status, 503);self.assertEqual(json.loads(body), {'ok': False})

    def test_setup_once_password_and_sessions_are_hashed_and_cookie_is_secure(self):
        cookie = self.activate()
        for flag in ['Secure', 'HttpOnly', 'SameSite=Strict', 'Path=/']:self.assertIn(flag, cookie)
        data = (self.auth_root/'host-auth.json').read_text();row = json.loads(data)
        for secret in [CODE, PASSWORD, self.cookie.split('=', 1)[1]]:self.assertNotIn(secret, data)
        self.assertEqual((self.auth_root/'host-auth.json').stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.auth_root.stat().st_mode & 0o777, 0o700)
        self.assertEqual(row['password']['rounds'], 600000)
        self.assertEqual(self.request('/host/setup', {'code': CODE, 'password': PASSWORD}, authenticated=False)[0], 409)
        _, page, _ = self.request('/host/login', authenticated=False)
        self.assertNotIn('Code de première activation', page)
        self.assertIn('PRIVATE_HOST_STORY', self.request('/state')[1])
        self.assertNotEqual(self.token, self.n.TOKEN)
        other = host.HostAuth(self.base/'another-auth')
        other.setup(CODE, PASSWORD, 'Autre fixture')
        self.assertNotEqual(other.load()['password']['salt'], row['password']['salt'])
        self.assertNotEqual(other.load()['password']['hash'], row['password']['hash'])

    def test_simultaneous_setup_uses_persistent_lock_and_retains_single_owner(self):
        first = self.gateway.auth;second = host.HostAuth(self.auth_root)
        def attempt(auth):
            try:return auth.setup(CODE, PASSWORD, 'Appareil concurrent')
            except host.AccessError as error:return error.status
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(attempt, [first, second]))
        self.assertEqual(sum(isinstance(value, str) for value in results), 1)
        self.assertIn(409, results);self.assertEqual(len(first.load()['sessions']), 1)

    def test_wrong_code_or_short_password_never_activates_and_setup_hash_must_be_valid(self):
        self.assertEqual(self.request('/host/setup', {'code': 'x'*50, 'password': PASSWORD})[0], 403)
        self.assertEqual(self.request('/host/setup', {'code': CODE, 'password': 'short'})[0], 400)
        self.assertFalse(self.gateway.auth.configured())
        with patch.dict(os.environ, {'TAO_HOST_SETUP_SHA256': 'not-a-hash'}):
            with self.assertRaises(ValueError):host.HostAuth(self.base/'bad-config')
        # Correcting the deployment variable must recover a never-initialized
        # installation; this is different from a lost existing owner record.
        repaired = host.HostAuth(self.base/'bad-config')
        self.assertFalse(repaired.configured())
        self.assertIn('Revenir à la connexion', host.login_page(False))
        self.assertIn('résultat de la connexion n’est pas confirmé', host.login_page(False))

    def test_host_origin_csrf_and_content_type_are_checked_before_writes(self):
        self.activate()
        for headers in [{'Host': 'evil.example'}, {'Host': '127.0.0.1'}, {'Origin': None},
                        {'Origin': 'https://evil.example'}, {'X-Tao-Token': None}, {'X-Tao-Token': self.n.TOKEN},
                        {'X-Tao-Token': 'not-the-session-token'}]:
            self.assertEqual(self.request('/api/story', {'text': 'Never written'}, headers)[0], 403, headers)
        self.assertEqual(self.request('/api/story', {'text': 'Never written'}, {'Content-Type': 'text/plain'})[0], 415)
        self.assertEqual(self.request('/api/story', {'text': 'Never written'}, authenticated=False)[0], 401)
        self.assertEqual(self.n.story()['text'], 'PRIVATE_HOST_STORY')
        self.assertEqual(self.request('/api/stop', {})[0], 403);self.assertFalse(self.n.STOP.is_set())

    def test_authenticated_proxy_refreshes_local_token_without_exposing_it(self):
        self.activate()
        self.n.TOKEN = 'rotated-private-node-token'
        self.n.atomic_json(self.root/'session.json', {'id': 'fresh-node', 'port': self.node.server_port, 'token': self.n.TOKEN})
        with patch.object(self.n, 'set_story', wraps=self.n.set_story) as write:
            status, body, _ = self.request('/api/story', {'text': 'Une mise à jour depuis le téléphone'})
        self.assertEqual(status, 200, body);self.assertEqual(write.call_count, 1)
        status, page, _ = self.request('/')
        self.assertEqual(status, 200);self.assertNotIn(self.n.TOKEN, page)
        self.assertEqual(page_token(page), self.token)
        self.assertEqual(self.n.story()['text'], 'Une mise à jour depuis le téléphone')

    def test_world_scoping_and_limits_survive_proxy(self):
        self.activate()
        status, body, _ = self.request('/api/worlds/create', {'title': 'Famille', 'parent_id': 'main', 'description': '', 'revision': 0})
        self.assertEqual(status, 200, body);ident = json.loads(body)['id']
        self.assertEqual(self.request('/api/story?world='+ident, {'text': 'Histoire familiale privée'})[0], 200)
        self.assertIn('PRIVATE_HOST_STORY', self.request('/state')[1])
        self.assertNotIn('PRIVATE_HOST_STORY', self.request('/state?world='+ident)[1])
        self.assertEqual(self.request('/api/story', {'text': 'x'*33000})[0], 413)
        # Handoff alone may reach the node at the larger bounded size. Its
        # schema remains the node's responsibility and is not bypassed.
        with patch.object(host.HostHandler, 'forward', autospec=True) as forward:
            forward.side_effect = lambda handler, body=None: handler.json(200, {'bytes': len(body)})
            status, body, _ = self.request('/api/dialogue/handoff?world=main', {'document': 'x'*40000, 'revision': 0})
        self.assertEqual(status, 200, body);self.assertGreater(json.loads(body)['bytes'], 32768)
        self.assertEqual(self.request('/api/dialogue/handoff', {'document': 'x'*host.MAX_HANDOFF})[0], 413)

    def test_logout_rotation_revoke_and_expiration_have_immediate_effect_for_new_requests(self):
        self.activate();old_cookie = self.cookie;old_token = self.token
        status, body, headers = self.request('/host/login', {'password': PASSWORD, 'label': 'Session renouvelée'})
        self.assertEqual(status, 200, body);self.cookie = headers['Set-Cookie'].split(';', 1)[0]
        self.assertEqual(self.request('/state', headers={'Cookie': old_cookie})[0], 401)
        _, page, _ = self.request('/');self.token = page_token(page)
        self.assertNotEqual(self.token, old_token)
        self.assertEqual(self.request('/api/story', {'text': 'No'}, {'X-Tao-Token': old_token})[0], 403)
        self.assertEqual(self.request('/host/logout', {})[0], 200)
        self.assertEqual(self.request('/state')[0], 401)
        status, body, headers = self.request('/host/login', {'password': PASSWORD}, authenticated=False)
        self.assertEqual(status, 200, body);self.cookie = headers['Set-Cookie'].split(';', 1)[0]
        _, page, _ = self.request('/');self.token = page_token(page)
        self.assertEqual(self.request('/host/revoke', {'id': 'all'})[0], 200)
        self.assertEqual(self.request('/state')[0], 401)
        token = self.gateway.auth.login(PASSWORD, 'Session expirée')
        session = self.gateway.auth.session(token)
        with patch.object(host.time, 'time', return_value=session['expires_at']):
            self.assertIsNone(self.gateway.auth.session(token))

    def test_session_survives_restart_but_missing_corrupt_auth_does_not_reopen_setup(self):
        self.activate();port = self.gateway.server_port
        self.gateway.shutdown();self.thread.join(timeout=3);self.gateway.server_close()
        with patch.dict(os.environ, {'TAO_HOST_SETUP_SHA256': ''}):
            self.gateway = host.HostServer(('127.0.0.1', port), self.n, ORIGIN, self.auth_root)
        self.start_gateway()
        self.assertEqual(self.request('/state')[0], 200)
        original = (self.auth_root/'host-auth.json').read_bytes()
        (self.auth_root/'host-auth.json').write_text('{corrupt')
        self.assertEqual(self.request('/state')[0], 503)
        self.assertEqual(self.request('/host/setup', {'code': CODE, 'password': PASSWORD})[0], 503)
        (self.auth_root/'host-auth.json').unlink()
        with self.assertRaises(ValueError):host.HostAuth(self.auth_root)
        (self.auth_root/'host-auth.json').write_bytes(original);(self.auth_root/'host-auth.json').chmod(0o600)

    def test_session_cap_and_bounded_failed_login_attempts(self):
        self.activate();auth = self.gateway.auth
        for index in range(host.MAX_SESSIONS-1):auth.login(PASSWORD, 'Appareil '+str(index))
        with self.assertRaisesRegex(host.AccessError, 'Huit'):auth.login(PASSWORD, 'Un appareil de trop')
        auth.attempts.clear()
        with patch.object(host, '_derive', return_value='0'*64) as derive:
            for _ in range(host.AUTH_ATTEMPTS):
                self.assertEqual(self.request('/host/login', {'password': 'Wrong password value'}, authenticated=False)[0], 403)
            self.assertEqual(self.request('/host/login', {'password': 'Wrong password value'}, authenticated=False)[0], 429)
        self.assertEqual(derive.call_count, host.AUTH_ATTEMPTS)

    def test_ai_callback_requires_session_and_current_csrf(self):
        calls = []
        class AI:
            def route(self, handler):
                calls.append((handler.command, handler.path, handler.body_value, handler.auth_session['id']))
                handler.json(200, {'ok': True, 'browser_token': handler.browser_token()});return True
        self.gateway.ai = AI()
        self.assertEqual(self.request('/host/ai/status')[0], 401)
        self.assertEqual(self.request('/host/ai/start', {})[0], 401);self.assertEqual(calls, [])
        self.activate()
        self.assertEqual(self.request('/host/ai/start', {}, {'X-Tao-Token': 'wrong'})[0], 403)
        status, body, _ = self.request('/host/ai/start', {'explicit': True})
        self.assertEqual(status, 200);self.assertEqual(json.loads(body)['browser_token'], self.token)
        self.assertEqual(calls[0][2], {'explicit': True});self.assertEqual(len(calls), 1)

    def raw_request(self, extra, path='/api/story', body=b'{}'):
        data = ('POST '+path+' HTTP/1.1\r\nHost: fixture.example.test\r\nOrigin: '+ORIGIN+'\r\n'
                'X-Tao-Token: '+self.token+'\r\nContent-Type: application/json\r\nCookie: '+self.cookie+'\r\n'+extra+'\r\n').encode()
        with socket.create_connection(('127.0.0.1', self.gateway.server_port), timeout=5) as sock:
            sock.sendall(data+body);response = sock.recv(4096)
        return int(response.split(b' ', 2)[1])

    def test_ambiguous_framing_and_duplicate_security_headers_are_rejected(self):
        self.activate()
        for header, expected in [('Content-Length: 2\r\nContent-Length: 2\r\n', 400),
                                 ('Content-Length: 2\r\nTransfer-Encoding: chunked\r\n', 400),
                                 ('Content-Length: 2\r\nHost: fixture.example.test\r\n', 403),
                                 ('Content-Length: 2\r\nOrigin: '+ORIGIN+'\r\n', 403),
                                 ('Content-Length: 2\r\nX-Tao-Token: duplicate\r\n', 403)]:
            self.assertEqual(self.raw_request(header), expected)
        self.assertEqual(self.raw_request('Content-Length: 2\r\n', 'http://evil.example/api/story'), 400)
        self.assertEqual(self.n.story()['text'], 'PRIVATE_HOST_STORY')
        self.assertEqual(self.request('/state', method='HEAD')[0], 405)

    def test_anonymous_partial_request_has_absolute_deadline_and_concurrency_is_bounded(self):
        with patch.object(host, 'REQUEST_TIMEOUT', .08):
            with socket.create_connection(('127.0.0.1', self.gateway.server_port), timeout=2) as sock:
                sock.sendall(b'GET /host/login HTTP/1.1\r\nHost: fixture.example.test\r\n')
                start = time.monotonic()
                self.assertEqual(sock.recv(1024), b'')
                self.assertLess(time.monotonic()-start, 1)
        acquired = []
        # Wait only for the just-expired request thread to return its slot.
        deadline = time.monotonic()+1
        while len(acquired) < 16 and time.monotonic() < deadline:
            if self.gateway.slots.acquire(timeout=.02):acquired.append(True)
        self.assertEqual(len(acquired), 16)
        try:
            self.assertFalse(self.gateway.slots.acquire(blocking=False))
            with socket.create_connection(('127.0.0.1', self.gateway.server_port), timeout=2) as sock:
                sock.sendall(b'GET /host/login HTTP/1.1\r\nHost: fixture.example.test\r\n\r\n')
                try:self.assertEqual(sock.recv(1024), b'')
                except ConnectionResetError:pass
        finally:
            for _ in acquired:self.gateway.slots.release()

    def test_proxy_never_follows_redirect_or_leaks_token_or_retries_uncertain_write(self):
        self.activate()
        class Response:
            status = 302
            def read(self, limit):return b'fixture'
            def getheader(self, key, default=None):return 'text/plain'
        class Connection:
            def __init__(self):self.calls = 0;self.reply = Response()
            def request(self, *args, **kwargs):self.calls += 1
            def getresponse(self):return self.reply
            def close(self):pass
        fake = Connection()
        # Direct handler-independent upstream injection while the outer HTTP
        # client keeps its original constructor.
        original = host.http.client.HTTPConnection
        def factory(address, port=None, *args, **kwargs):
            if port == self.node.server_port:return fake
            return original(address, port, *args, **kwargs)
        with patch.object(host.http.client, 'HTTPConnection', side_effect=factory):
            self.assertEqual(self.request('/state')[0], 502)
            fake.reply.status = 200;fake.reply.read = lambda limit:self.n.TOKEN.encode()
            status, body, _ = self.request('/state')
            self.assertEqual(status, 502);self.assertNotIn(self.n.TOKEN, body)
            fake.getresponse = lambda: (_ for _ in ()).throw(OSError('private-error-details'))
            before = fake.calls
            status, body, _ = self.request('/api/story', {'text': 'Unknown result'})
            self.assertEqual(status, 503);self.assertIn('inconnu', body)
            self.assertNotIn('private-error-details', body);self.assertEqual(fake.calls-before, 1)

    def test_worker_ingress_needs_owner_activation_but_not_owner_session(self):
        enrol = {'code': 'fictitious-pairing-code-'+'a'*32, 'token': WORKER_TOKEN,
                 'label': 'Linux fictif', 'machine_id': 'a'*32}
        self.assertEqual(self.device_request(enrol, '/api/devices/enrol')[0], 403)
        self.activate()
        with self.device_upstream() as fake:
            for path, value in [('/api/devices/enrol', enrol), ('/api/devices/worker', {'action': 'poll', 'request_id': 'b'*32})]:
                status, body, headers = self.device_request(value, path, {'Cookie': self.cookie, 'X-Tao-Token': 'ignored-owner-csrf'})
                self.assertEqual(status, 200, body)
                args, outgoing = fake.calls[-1]
                self.assertEqual(args, ('POST', path));self.assertEqual(json.loads(outgoing['body']), value)
                expected = {'Host': '127.0.0.1:'+str(self.node.server_port), 'Content-Type': 'application/json'}
                if path.endswith('/worker'):expected['Authorization'] = 'Bearer '+WORKER_TOKEN
                self.assertEqual(outgoing['headers'], expected)
                self.assertNotIn('Set-Cookie', headers);self.assertNotIn(self.n.TOKEN, body)
        self.assertEqual(self.n.story()['text'], 'PRIVATE_HOST_STORY')

    def test_worker_credentials_cannot_access_owner_routes_or_bypass_origin_boundary(self):
        self.activate()
        with self.device_upstream() as fake:
            for path in ['/api/devices/worker?', '/api/devices/worker?world=main', '/api/devices/enrol?world=main']:
                self.assertEqual(self.device_request({'action': 'poll'}, path)[0], 403, path)
            for origin in ['', ORIGIN, 'null', 'https://evil.example']:
                self.assertEqual(self.device_request({'action': 'poll'}, headers={'Origin': origin})[0], 403)
            for authority in ['evil.example', 'healthcheck.railway.app', '127.0.0.1']:
                self.assertEqual(self.device_request({'action': 'poll'}, headers={'Host': authority})[0], 403)
            for authorization in [None, '', 'Basic '+WORKER_TOKEN, 'Bearer short', 'Bearer '+WORKER_TOKEN+' trailing']:
                self.assertEqual(self.device_request({'action': 'poll'}, headers={'Authorization': authorization})[0], 401)
            self.assertEqual(self.device_request({}, '/api/devices/enrol', {'Authorization': 'Bearer '+WORKER_TOKEN})[0], 403)
            for path in ['/api/story', '/api/devices/jobs', '/api/devices/worker/', '/api/devices/worker/extra']:
                self.assertEqual(self.device_request({'action': 'poll'}, path)[0], 403, path)
            self.assertEqual(fake.calls, [])
        for path in ['/state', '/api/devices/worker']:
            self.assertEqual(self.request(path, headers={'Authorization': 'Bearer '+WORKER_TOKEN}, authenticated=False)[0], 401)

    def test_worker_body_limits_are_specific_to_worker_route(self):
        self.activate()
        def oversized(path, length):
            # The gateway rejects the declared size before reading a body.
            # Sending a megabyte after that rejection races its closed socket.
            connection = http.client.HTTPConnection('127.0.0.1', self.gateway.server_port, timeout=5)
            try:
                connection.putrequest('POST', path, skip_host=True)
                connection.putheader('Host', ORIGIN.removeprefix('https://'))
                connection.putheader('Content-Type', 'application/json')
                connection.putheader('Content-Length', str(length))
                if path.endswith('/worker'):
                    connection.putheader('Authorization', 'Bearer '+WORKER_TOKEN)
                connection.endheaders()
                response = connection.getresponse(); response.read()
                return response.status
            finally: connection.close()
        with self.device_upstream() as fake:
            self.assertEqual(self.device_request({'action': 'report', 'patch': 'x'*40000})[0], 200)
            self.assertEqual(len(fake.calls), 1)
            self.assertEqual(oversized('/api/devices/enrol', host.MAX_BODY+1), 413)
            self.assertEqual(oversized('/api/devices/worker', host.MAX_DEVICE_BODY+1), 413)
            self.assertEqual(self.device_request({'action': 'poll'}, headers={'Content-Type': 'text/plain'})[0], 415)
            self.assertEqual(len(fake.calls), 1)

    def test_worker_duplicate_headers_and_ambiguous_framing_never_reach_node(self):
        self.activate()
        def raw(extra, body=b'{}'):
            request = ('POST /api/devices/worker HTTP/1.1\r\nHost: fixture.example.test\r\n'
                       'Authorization: Bearer '+WORKER_TOKEN+'\r\nContent-Type: application/json\r\n'+extra+'\r\n').encode()
            with socket.create_connection(('127.0.0.1', self.gateway.server_port), timeout=5) as sock:
                sock.sendall(request+body);response = sock.recv(4096)
            return int(response.split(b' ', 2)[1])
        with self.device_upstream() as fake:
            for extra, expected in [('Content-Length: 2\r\nAuthorization: Bearer '+WORKER_TOKEN+'\r\n', 401),
                                    ('Content-Length: 2\r\nOrigin:\r\nOrigin:\r\n', 403),
                                    ('Content-Length: 2\r\nContent-Length: 2\r\n', 400),
                                    ('Content-Length: 2\r\nTransfer-Encoding: chunked\r\n', 400),
                                    ('Content-Length: 2\r\nHost: fixture.example.test\r\n', 403)]:
                self.assertEqual(raw(extra), expected, extra)
            self.assertEqual(raw('Content-Length: 2\r\n', b'[]'), 400)
            self.assertEqual(raw('Content-Length: 2\r\n', b'\xff\xff'), 400)
            self.assertEqual(fake.calls, [])

    def test_worker_response_is_json_only_without_redirect_secret_echo_or_retry(self):
        self.activate()
        with self.device_upstream() as fake:
            fake.reply.status = 302
            self.assertEqual(self.device_request({'action': 'poll'})[0], 502)
            fake.reply.status = 200;fake.reply.content_type = 'text/html'
            self.assertEqual(self.device_request({'action': 'poll'})[0], 502)
            fake.reply.content_type = 'application/json'
            for invalid in [b'not-json', b'[]']:
                fake.reply.body = invalid
                self.assertEqual(self.device_request({'action': 'poll'})[0], 502)
            for secret in [self.n.TOKEN, WORKER_TOKEN]:
                # Escaping the first ASCII character still cannot leak it.
                fake.reply.body = ('{"error":"\\u%04x%s"}' % (ord(secret[0]), secret[1:])).encode()
                status, body, _ = self.device_request({'action': 'poll'})
                self.assertEqual(status, 502, body);self.assertNotIn(secret, body)
            code = 'fictitious-pairing-code-to-hide-'+'b'*32
            fake.reply.body = json.dumps({'error': code}).encode()
            status, body, _ = self.device_request({'code': code, 'token': WORKER_TOKEN}, '/api/devices/enrol')
            self.assertEqual(status, 502, body);self.assertNotIn(code, body)
            fake.getresponse = lambda: (_ for _ in ()).throw(OSError('private-worker-error-details'))
            before = len(fake.calls)
            status, body, _ = self.device_request({'action': 'report', 'request_id': 'b'*32})
            self.assertEqual(status, 503);self.assertIn('inconnu', body)
            self.assertNotIn('private-worker-error-details', body);self.assertEqual(len(fake.calls)-before, 1)
