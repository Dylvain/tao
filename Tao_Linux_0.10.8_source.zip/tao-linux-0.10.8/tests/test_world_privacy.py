import copy
import json

from test_node import NodeHarness
import tao_continuity as continuity
import tao_dialogue as dialogue
import tao_worlds as worlds


class WorldPrivacyTests(NodeHarness):
    def setUp(self):
        super().setUp()
        self.work = worlds.create(self.n, 'Travail', revision=0)['id']
        self.family = worlds.create(self.n, 'Famille', revision=1)['id']

    def human_message(self, text):
        s = self.n.load_state()
        d = dialogue.ensure(s)
        row = {'id': 'source-message', 'role': 'user', 'text': text,
               'source': 'human', 'at': self.n.now()}
        d['messages'].append(row)
        self.n.atomic_json(self.n.STATE, s, backup=True)
        return row

    def test_private_theory_and_buffer_derivatives_never_enter_child_exports(self):
        s = self.n.load_state()
        s['theory_proposals'] = [{'reason': 'MAIN_PRIVATE_THEORY'}]
        s['development']['internalization_candidates'] = [{'source_buffer': 'MAIN_PRIVATE_BUFFER'}]
        s['observer_model']['specialization_candidates'] = [{'kind': 'MAIN_PRIVATE_SPECIALIZATION'}]
        s['last_evidence'] = {'details': 'MAIN_PRIVATE_EVIDENCE'}
        self.n.atomic_json(self.n.STATE, s, backup=True)
        before = self.n.load_raw_state()
        with worlds.using(self.work):
            child = self.n.load_state()
            public = self.n.public_state(child)
            lens = self.n.write_lens_snapshot(child)
            self.assertEqual(self.n.theory.proposals(self.n), [])
            self.assertNotIn('MAIN_PRIVATE', json.dumps([child, public, lens]))
            child['theory_proposals'] = [{'reason': 'WORK_PRIVATE_THEORY'}]
            child['development']['internalization_candidates'] = [{'source_buffer': 'WORK_PRIVATE_BUFFER'}]
            child['metabolism']['dialogue_attempts'] = 3
            self.n.atomic_json(self.n.STATE, child, backup=True)
        after = self.n.load_raw_state()
        for field in ('theory_proposals', 'development', 'observer_model', 'last_evidence'):
            self.assertEqual(after[field], before[field])
        self.assertEqual(after['metabolism']['dialogue_attempts'], 3)
        with worlds.using(self.family):
            self.assertNotIn('WORK_PRIVATE', json.dumps(self.n.load_state()))

    def test_child_cycle_has_own_derivatives_and_keeps_global_observations(self):
        self.n.cycle()
        before = self.n.load_raw_state()
        with worlds.using(self.work):
            child = self.n.cycle()
            self.assertEqual(child['observer_model']['status'], 'observer_hypothesis')
            self.assertIn('environment', child['observation'])
        after = self.n.load_raw_state()
        self.assertEqual(after['cycles'], before['cycles'] + 1)
        self.assertEqual(after['metabolism']['measured_cycles'], before['metabolism']['measured_cycles'] + 1)
        for field in ('development', 'observer_model', 'last_evidence'):
            self.assertEqual(after[field], before[field])
        self.assertEqual(after['worlds']['spaces'][self.work]['last_evidence']['cycle'], after['cycles'])

    def test_retransfer_never_carries_hidden_earlier_quotation(self):
        public = 'Une observation utile.'
        private = 'DETAIL_A_NE_PAS_RETRANSMETTRE'
        source = self.human_message(public + ' ' + private)
        first = worlds.transfer(self.n, self.work, 'Un exemple à discuter.', source['text'], source['id'], 2)
        with worlds.using(self.work):
            second = worlds.transfer(self.n, self.family, 'Seulement cette observation.', public, first['message_id'], 3)
        with worlds.using(self.family):
            message = self.n.load_state()['dialogue']['messages'][-1]
            self.assertEqual(message['id'], second['message_id'])
            self.assertNotIn(private, json.dumps(message))
            self.assertEqual(message['origin']['quote'], public)
            self.assertEqual(message['origin']['world_id'], 'main')
            self.assertEqual(message['original_role'], 'user')
            extraction = {'notes': [{'kind': 'context', 'text': 'Conserver cette piste.',
                                    'message_id': message['id'], 'quote': public}], 'needs': []}
            continuity.validate_extraction(extraction, [message])
        self.assertIn(private, json.dumps(self.n.load_raw_state()['dialogue']))

    def test_transfer_wrapper_cannot_become_an_original_human_quotation(self):
        source = self.human_message('Une observation utile.')
        first = worlds.transfer(self.n, self.work, 'Une reformulation à vérifier.', source['text'], source['id'], 2)
        with worlds.using(self.work):
            worlds.transfer(self.n, self.family, 'À examiner.', 'Une reformulation à vérifier.', first['message_id'], 3)
        with worlds.using(self.family):
            message = self.n.load_state()['dialogue']['messages'][-1]
            self.assertEqual(message['origin']['quote'], '')
            extraction = {'notes': [{'kind': 'context', 'text': 'À vérifier.',
                                    'message_id': message['id'], 'quote': 'Une reformulation à vérifier.'}], 'needs': []}
            with self.assertRaises(ValueError):
                continuity.validate_extraction(extraction, [message])

    def test_presentation_is_local_and_does_not_change_business_context(self):
        with worlds.using(self.work):
            s = self.n.load_state()
            dialogue.ensure(s)
            self.n.atomic_json(self.n.STATE, s, backup=True)
            before = copy.deepcopy(self.n.load_state())
            signature = dialogue.signature(self.n, before)
            result = worlds.save_presentation(self.n, 'problems', 0)
            after = self.n.load_state()
            self.assertEqual(result['view'], 'problems')
            self.assertEqual(result['revision'], 1)
            self.assertEqual(after['buffers'], before['buffers'])
            self.assertEqual(after['dialogue'], before['dialogue'])
            self.assertEqual(dialogue.signature(self.n, after), signature)
            self.assertEqual(worlds.save_presentation(self.n, 'problems', 1), result)
        self.assertNotIn('presentation', self.n.load_state())
        with worlds.using(self.family):
            self.assertNotIn('presentation', self.n.load_state())

    def test_presentation_rejects_stale_revision_and_unknown_view_without_changes(self):
        with worlds.using(self.work):
            worlds.save_presentation(self.n, 'objectives', 0)
            before = self.n.load_raw_state()
            for view, revision in [('solutions', 0), ('execute_everything', 1), (None, 1)]:
                with self.assertRaises(ValueError):
                    worlds.save_presentation(self.n, view, revision)
                self.assertEqual(self.n.load_raw_state(), before)
            result = worlds.save_presentation(self.n, 'solutions', 1)
            self.assertEqual(result['revision'], 2)
