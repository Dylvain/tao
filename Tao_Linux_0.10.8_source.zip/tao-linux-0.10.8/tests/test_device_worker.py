import argparse
import copy
import hashlib
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import tao_device_worker as worker


def durable(path, data):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_suffix('.tmp')
    with temp.open('wb') as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())
    os.chmod(temp, 0o600); os.replace(temp, path)


class Broker:
    def __init__(self):
        self.calls = []
        self.work = None
        self.fail_enrol = False
        self.fail_report = False
        self.fail_poll_after_claim = False
        self.claims = {}
        self.reports = []

    def __call__(self, server, route, payload, token=None):
        self.calls.append(copy.deepcopy((server, route, payload, token)))
        if route.endswith('enrol'):
            if self.fail_enrol:
                self.fail_enrol = False
                raise worker.TransportError('Network unavailable')
            return {'device_id': 'd' * 32, 'status': 'pending', 'world_id': 'main'}
        if payload['action'] == 'poll':
            self.claims.setdefault(payload['request_id'], self.work)
            result = self.claims[payload['request_id']]
            if self.fail_poll_after_claim:
                self.fail_poll_after_claim = False
                raise worker.TransportError('Lost claim response')
            return {'device_id': 'd' * 32, 'status': 'approved', 'work': copy.deepcopy(result)}
        self.reports.append(copy.deepcopy(payload))
        if self.fail_report:
            self.fail_report = False
            raise worker.TransportError('Lost acknowledgement')
        self.work = None
        return {'accepted': True, 'status': payload['result']['status']}


class DeviceWorkerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        self.repo = self.folder / 'source'; self.repo.mkdir()
        self.tools = self.folder / 'tools'; self.tools.mkdir()
        (self.repo / 'scripts').mkdir()
        (self.repo / 'app.py').write_text('value = 0\n')
        # This known fixture is the only intentionally executed candidate test.
        (self.repo / 'scripts' / 'verify.sh').write_text("#!/bin/bash\nset -eu\ntest \"$(cat app.py)\" = 'value = 1'\n")
        self.git('init', '-q')
        self.git('add', '.')
        self.git('-c', 'user.name=Test', '-c', 'user.email=test@local', 'commit', '-qm', 'base')
        self.base = self.git('rev-parse', 'HEAD')
        self.codex = self.tools / 'codex'
        self.codex.write_text('#!' + sys.executable + '\n' +
                              "import json, os, pathlib, sys\n" +
                              "assert sys.argv[1:]==['exec','--sandbox','workspace-write','-']\n" +
                              "prompt=sys.stdin.read(); assert 'de nouvelles permissions' in prompt\n" +
                              "assert 'TAO_HOST_SETUP_SHA256' not in os.environ\n" +
                              "assert 'OPENAI_API_KEY' not in os.environ\n" +
                              "pathlib.Path('app.py').write_text('value = 1\\n')\n" +
                              "print('PROVIDER_RAW_SECRET_NOT_FOR_REPORT')\n")
        self.codex.chmod(0o700)
        self.env = patch.dict(os.environ, {'PATH': str(self.tools) + os.pathsep + os.environ['PATH'],
                              'TAO_HOST_SETUP_SHA256': 'private-host', 'OPENAI_API_KEY': 'private-key'})
        self.env.start(); self.addCleanup(self.env.stop)
        self.broker = Broker()
        self.n = SimpleNamespace(ROOT=self.folder / 'node', durable_bytes=durable)
        self.w = worker.Worker(self.n, self.broker)

    def git(self, *args):
        result = subprocess.run(['git', '-C', str(self.repo), *args], stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, check=True)
        return result.stdout.decode().strip()

    def connect(self, tests=False):
        return self.w.connect('https://tao.example', self.repo, 'Linux choisi', tests, code='CODE-1234')

    def work(self, phase='generate', **changes):
        value = {'id': 'a' * 32, 'phase': phase, 'lease_id': ('b' if phase == 'generate' else 'c') * 32,
                 'base_commit': self.base, 'world_id': 'main', 'residual': 'Le résultat vaut zéro.',
                 'goal': 'Obtenir un.', 'acceptance': 'La commande de vérification réussit.',
                 'timeout_seconds': 10}
        value.update(changes)
        return value

    def generate(self, tests=False):
        self.connect(tests)
        self.broker.work = self.work()
        self.assertEqual(self.w.run(once=True)['status'], 'review')
        return self.broker.reports[-1]['result']

    def test_enrol_network_loss_preserves_same_token_and_private_profile(self):
        self.broker.fail_enrol = True
        with self.assertRaises(worker.TransportError):
            self.connect()
        first = self.w.profile()
        self.assertEqual(first['status'], 'enrolling')
        status = self.connect()
        self.assertEqual(status['status'], 'pending')
        second = self.w.profile()
        self.assertEqual(first['machine_id'], second['machine_id'])
        self.assertEqual(first['token'], second['token'])
        self.assertEqual((self.w.root / 'profile.json').stat().st_mode & 0o777, 0o600)
        self.assertNotIn(first['token'], json.dumps(status))
        self.assertNotIn('CODE-1234', (self.w.root / 'profile.json').read_text())
        with self.assertRaisesRegex(ValueError, 'connexion existe'):
            self.w.connect('https://other.example', self.repo, 'Linux choisi', code='CODE-1234')

    def test_generation_and_explicit_exact_verification_keep_source_unchanged(self):
        source_before = (self.repo / 'app.py').read_bytes()
        result = self.generate(tests=True)
        self.assertTrue(result['ok'])
        self.assertEqual(result['patch_sha256'], hashlib.sha256(result['patch'].encode()).hexdigest())
        self.assertIn('+value = 1', result['patch'])
        self.assertNotIn('PROVIDER_RAW_SECRET', json.dumps(self.broker.reports))
        self.assertNotIn(str(self.repo), json.dumps(self.broker.reports))
        candidate = self.w.root / 'jobs' / ('a' * 32) / 'candidate'
        self.assertEqual(worker.text_git(candidate, 'remote'), '')
        self.assertNotEqual((candidate / '.git' / 'objects').stat().st_ino,
                            (self.repo / '.git' / 'objects').stat().st_ino)
        self.broker.work = self.work('verify', review_digest=result['patch_sha256'], patch=result['patch'])
        self.assertEqual(self.w.run(once=True)['status'], 'verified')
        self.assertEqual(self.broker.reports[-1]['result']['status'], 'verified')
        self.assertEqual((self.repo / 'app.py').read_bytes(), source_before)
        self.assertEqual(self.git('rev-parse', 'HEAD'), self.base)
        self.assertEqual(self.git('status', '--porcelain'), '')
        self.assertFalse((self.repo / 'runtime').exists())

    def test_verify_requires_local_flag_and_rejects_changed_candidate(self):
        result = self.generate(tests=False)
        self.broker.work = self.work('verify', review_digest=result['patch_sha256'])
        with patch.object(worker.workshop, 'run_bounded') as execute:
            self.assertEqual(self.w.run(once=True)['status'], 'failed')
            execute.assert_not_called()
        # A separate node proves digest failure even when tests are locally allowed.
        second = worker.Worker(SimpleNamespace(ROOT=self.folder / 'node2', durable_bytes=durable), self.broker)
        second.connect('https://tao.example', self.repo, 'Linux choisi', True, code='CODE-1234')
        self.broker.claims.clear(); self.broker.work = self.work()
        second.run(once=True)
        generated = self.broker.reports[-1]['result']
        candidate = second.root / 'jobs' / ('a' * 32) / 'candidate'
        (candidate / 'app.py').write_text('value = 666\n')
        self.broker.work = self.work('verify', review_digest=generated['patch_sha256'])
        with patch.object(worker.workshop, 'run_bounded') as execute:
            self.assertEqual(second.run(once=True)['status'], 'failed')
            execute.assert_not_called()

    def test_stale_or_dirty_source_prevents_execution(self):
        self.connect()
        self.broker.work = self.work(base_commit='0' * 40)
        with patch.object(worker.workshop, 'run_bounded') as execute:
            self.assertEqual(self.w.run(once=True)['status'], 'failed')
            execute.assert_not_called()
        self.broker.work = self.work(id='e' * 32)
        (self.repo / 'app.py').write_text('local work\n')
        with patch.object(worker.workshop, 'run_bounded') as execute:
            self.assertEqual(self.w.run(once=True)['status'], 'failed')
            execute.assert_not_called()
        self.assertEqual((self.repo / 'app.py').read_text(), 'local work\n')

    def test_lost_claim_reuses_nonce_and_lost_report_replays_data_not_execution(self):
        self.connect()
        self.broker.work = self.work()
        self.broker.fail_poll_after_claim = True
        with self.assertRaises(worker.TransportError):
            self.w.run(once=True)
        nonce = self.broker.calls[-1][2]['request_id']
        self.broker.fail_report = True
        with self.assertRaises(worker.TransportError):
            self.w.run(once=True)
        polls = [call[2] for call in self.broker.calls if call[2].get('action') == 'poll']
        self.assertEqual([p['request_id'] for p in polls], [nonce, nonce])
        report = copy.deepcopy(self.broker.reports[-1])
        restarted = worker.Worker(self.n, self.broker)
        with patch.object(worker.workshop, 'run_bounded') as execute:
            self.assertEqual(restarted.run(once=True)['status'], 'reported')
            execute.assert_not_called()
        self.assertEqual(self.broker.reports[-1], report)

    def test_uncertain_started_receipt_is_interrupted_never_executed_again(self):
        self.connect()
        work = self.work()
        path = self.w.root / 'jobs' / work['id'] / 'generate.json'
        self.w.save(path, {'schema': 'tao.device.receipt.v1', 'state': 'started', 'work': work})
        with patch.object(worker.workshop, 'run_bounded') as execute:
            self.assertEqual(self.w.run(once=True)['status'], 'reported')
            execute.assert_not_called()
        result = self.broker.reports[-1]['result']
        self.assertEqual(result['status'], 'interrupted')
        self.assertFalse(result['ok'])
        self.assertEqual(self.w.read(path)['state'], 'reported')
        before = len(self.broker.calls)
        self.assertEqual(self.w.run(once=True)['status'], 'recovery_required')
        self.assertEqual(len(self.broker.calls), before)
        self.assertTrue(self.w.status()['recovery_required'])
        with self.assertRaises(ValueError):
            self.w.resume()
        self.w.resume(after_inspection=True)
        self.assertFalse(self.w.status()['recovery_required'])
        self.assertEqual(self.w.run(once=True)['status'], 'approved')

    def test_local_test_permission_can_change_without_replacing_identity(self):
        self.connect()
        previous = self.w.profile()
        self.assertTrue(self.w.permissions(True)['allow_tests'])
        self.assertFalse(self.w.permissions(False)['allow_tests'])
        self.assertEqual(self.w.profile()['token'], previous['token'])
        self.assertEqual(self.w.profile()['machine_id'], previous['machine_id'])
        self.assertEqual(self.w.profile()['device_id'], previous['device_id'])

    def test_terminal_report_rejection_is_preserved_without_blocking_next_job(self):
        self.connect()
        self.broker.work = self.work()
        original = self.broker
        def reject(server, route, payload, token=None):
            if payload.get('action') == 'report':
                raise worker.TransportError('Lease expired', 409)
            return original(server, route, payload, token)
        self.w.transport = reject
        self.w.run(once=True)
        row = self.w.read(self.w.root / 'jobs' / ('a' * 32) / 'generate.json')
        self.assertEqual(row['state'], 'report_rejected')
        self.assertEqual(row['rejection_http_status'], 409)
        self.assertEqual(row['result']['status'], 'review')
        self.w.transport = original
        self.broker.work = self.work(id='e' * 32)
        self.assertEqual(self.w.run(once=True)['status'], 'review')

    def test_ignored_generation_files_are_not_executed_in_reviewed_test_tree(self):
        (self.repo / '.gitignore').write_text('generated/\n')
        (self.repo / 'scripts' / 'verify.sh').write_text('#!/bin/bash\nset -eu\nbash generated/check.sh\n')
        self.git('add', '.'); self.git('-c', 'user.name=Test', '-c', 'user.email=test@local', 'commit', '-qm', 'test fixture')
        self.base = self.git('rev-parse', 'HEAD')
        self.codex.write_text('#!' + sys.executable + '\n' +
                              "from pathlib import Path\nPath('app.py').write_text('value = 1\\n')\n" +
                              "Path('generated').mkdir()\nPath('generated/check.sh').write_text('exit 0\\n')\n")
        result = self.generate(tests=True)
        self.assertNotIn('generated/check.sh', result['patch'])
        self.broker.work = self.work('verify', review_digest=result['patch_sha256'])
        self.assertEqual(self.w.run(once=True)['status'], 'failed')
        folder = self.w.root / 'jobs' / ('a' * 32)
        self.assertTrue((folder / 'candidate' / 'generated' / 'check.sh').exists())
        self.assertFalse((folder / 'verification' / 'generated' / 'check.sh').exists())

    def test_hup_unwinds_runner_and_restores_handler(self):
        self.connect()
        self.broker.work = self.work()
        original = signal.getsignal(signal.SIGHUP)
        def interrupted(*args, **kwargs):
            os.kill(os.getpid(), signal.SIGHUP)
        with patch.object(worker.workshop, 'run_bounded', side_effect=interrupted):
            with self.assertRaises(KeyboardInterrupt):
                self.w.run(once=True)
        self.assertEqual(signal.getsignal(signal.SIGHUP), original)
        row = self.w.read(self.w.root / 'jobs' / ('a' * 32) / 'generate.json')
        self.assertEqual(row['state'], 'started')

    def test_repeated_received_work_is_reported_without_reexecution(self):
        self.generate()
        self.broker.work = self.work()
        with patch.object(worker.workshop, 'run_bounded') as execute:
            self.assertEqual(self.w.run(once=True)['status'], 'reported')
            execute.assert_not_called()
        self.broker.work = self.work(lease_id='f' * 32)
        with self.assertRaisesRegex(ValueError, 'autre contrat'):
            self.w.run(once=True)

    def test_binary_or_oversized_patch_is_not_reported_as_review(self):
        self.connect()
        self.broker.work = self.work()
        self.codex.write_text('#!' + sys.executable + "\nfrom pathlib import Path\nPath('new.bin').write_bytes(b'\\0\\1\\2')\n")
        self.assertEqual(self.w.run(once=True)['status'], 'failed')
        self.assertEqual(self.broker.reports[-1]['result']['patch'], '')
        self.assertEqual(self.git('status', '--porcelain'), '')

    def test_invalid_contract_ids_paths_and_commands_fail_before_execution(self):
        self.connect()
        for change in ({'id': '../escape'}, {'world_id': '../../main'}, {'base_commit': '-bad'},
                       {'lease_id': '\nsecret'}, {'timeout_seconds': 601},
                       {'timeout_seconds': True}, {'command': 'echo unsafe'}):
            self.broker.claims.clear()
            self.broker.work = self.work(**change)
            with self.assertRaises(ValueError), patch.object(worker.workshop, 'run_bounded') as execute:
                self.w.run(once=True)
            execute.assert_not_called()
        self.assertEqual(self.broker.reports, [])

    def test_symlink_repository_and_second_worker_are_refused(self):
        linked = self.folder / 'linked'; linked.symlink_to(self.repo, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'symbolique'):
            self.w.connect('https://tao.example', linked, code='CODE-1234')
        self.connect()
        with self.w.lock():
            with self.assertRaisesRegex(ValueError, 'déjà'):
                worker.Worker(self.n, self.broker).run(once=True)

    def test_diagnosis_keeps_browser_path_on_other_os_and_does_not_invoke_provider(self):
        with patch.object(worker.platform, 'system', return_value='Other OS'), \
                patch.object(worker.shutil, 'which', return_value=None), \
                patch.object(worker.workshop, 'run_bounded') as execute:
            result = worker.diagnose()
            self.assertFalse(result['runner_supported'])
            self.assertTrue(result['browser_access'])
            self.assertIsNone(result['provider_connected'])
            self.assertIn('navigateur', result['next_step'])
            with self.assertRaisesRegex(ValueError, 'Linux'):
                self.w.run(once=True)
            execute.assert_not_called()

    def test_cli_does_not_accept_credentials_as_arguments(self):
        parser = argparse.ArgumentParser()
        worker.add_parser(parser.add_subparsers(dest='cmd'))
        result = parser.parse_args(['device', 'connect', '--server', 'https://tao.example', '--repo', str(self.repo)])
        self.assertFalse(result.allow_tests)
        self.assertNotIn('code', vars(result))
        self.assertNotIn('token', vars(result))
        with self.assertRaises(ValueError):
            self.w.run(once=True, interval=1)

    def test_actual_http_broker_worker_generation_review_and_verify(self):
        from test_node import NodeHarness
        harness = NodeHarness(); harness.setUp(); self.addCleanup(harness.tearDown)
        node = harness.n
        node.TOKEN = 'owner-integration-fixture'
        server = ThreadingHTTPServer(('127.0.0.1', 0), node.Handler)
        server.daemon_threads = True
        thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
        thread.start()
        def close():
            server.shutdown(); thread.join(3); server.server_close()
        self.addCleanup(close)
        address = 'http://127.0.0.1:' + str(server.server_port)
        def owner(path, data=None):
            connection = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=5)
            try:
                connection.request('GET' if data is None else 'POST', path,
                                   None if data is None else json.dumps(data),
                                   {'Content-Type': 'application/json', 'X-Tao-Token': node.TOKEN})
                response = connection.getresponse()
                result = json.loads(response.read())
                self.assertEqual(response.status, 200, result)
                return result
            finally:
                connection.close()
        pairing = owner('/api/devices/pair', {'label': 'Linux choisi', 'revision': 0})
        actual = worker.Worker(self.n)  # Default urllib transport, not the test Broker.
        enrolled = actual.connect(address, self.repo, 'Linux choisi', False, code=pairing['code'])
        self.assertEqual(enrolled['status'], 'pending')
        self.assertEqual(actual.run(once=True)['status'], 'pending')
        owner('/api/devices/device', {'id': enrolled['device_id'], 'action': 'approve',
                                      'revision': owner('/api/devices')['revision']})
        self.assertEqual(actual.run(once=True)['status'], 'approved')
        buffer = node.add_buffer('Le résultat vaut zéro.', 'Obtenir un.', 'La commande de vérification réussit.')
        job = owner('/api/devices/jobs', {'device_id': enrolled['device_id'], 'buffer_id': buffer['id'],
                      'revision': owner('/api/devices')['revision'],
                      'expected_snapshot': {'residual': buffer['residual'], 'goal': buffer['desired'],
                                            'acceptance': buffer['acceptance']}})
        with patch.object(worker.workshop, 'run_bounded', wraps=worker.workshop.run_bounded) as bounded:
            result = actual.run(once=True)
            self.assertEqual(result['status'], 'review')
            self.assertEqual(bounded.call_count, 1)
        detail = owner('/api/devices/job?id=' + job['id'])
        self.assertEqual(detail['status'], 'review')
        self.assertIn('+value = 1', detail['patch'])
        self.assertNotIn(str(self.repo), json.dumps(detail))
        owner('/api/devices/job', {'id': job['id'], 'action': 'verify',
              'revision': detail['revision'], 'review_digest': detail['review_digest'], 'confirmed': True})
        with patch.object(worker.workshop, 'run_bounded') as bounded:
            self.assertIsNone(actual.run(once=True)['work'])
            bounded.assert_not_called()
        self.assertEqual(owner('/api/devices/job?id=' + job['id'])['status'], 'verify_queued')
        actual.permissions(True)
        self.assertEqual(actual.run(once=True)['status'], 'verified')
        final = owner('/api/devices/job?id=' + job['id'])
        self.assertEqual(final['status'], 'verified')
        self.assertTrue(final['verification_result']['ok'])
        self.assertEqual(final['verification_result']['patch_sha256'], final['review_digest'])
        self.assertFalse(final['automatic_apply'])
        self.assertEqual(self.git('rev-parse', 'HEAD'), self.base)
        self.assertEqual(self.git('status', '--porcelain'), '')
        self.assertEqual((self.repo / 'app.py').read_text(), 'value = 0\n')
        self.assertEqual(node.load_state()['buffers'][buffer['id']]['status'], 'open')


class DeviceWorkerTransportTests(unittest.TestCase):
    def test_origin_validation_rejects_userinfo_nonlocal_http_and_url_parts(self):
        for url in ('http://tao.example', 'https://user:pass@tao.example', 'https://tao.example/path',
                    'https://tao.example?token=secret', 'https://tao.example#fragment',
                    'https://tao.example\nheader', 'https://tao.example:65536',
                    'https://tao.example\\@evil.invalid', 'http://127.0.0.1.evil.invalid'):
            with self.assertRaises(ValueError, msg=url):
                worker.origin(url)
        self.assertEqual(worker.origin('https://tao.example/'), 'https://tao.example')
        self.assertEqual(worker.origin('http://127.0.0.1:1234'), 'http://127.0.0.1:1234')

    def test_redirect_never_forwards_token_or_replays_post(self):
        received = []
        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                received.append((self.path, self.headers.get('Authorization')))
                self.send_response(307); self.send_header('Location', '/stolen'); self.end_headers()
            def log_message(self, *args):
                pass
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        try:
            token = 'a' * 43
            with self.assertRaises(worker.TransportError) as caught:
                worker.request('http://127.0.0.1:' + str(server.server_port), '/api/devices/worker',
                               {'action': 'poll'}, token)
            self.assertEqual(caught.exception.status, 307)
            self.assertEqual(received, [('/api/devices/worker', 'Bearer ' + token)])
            self.assertNotIn(token, str(caught.exception))
            with self.assertRaises(ValueError):
                worker.request('http://127.0.0.1:' + str(server.server_port), '/api/devices/worker',
                               {}, token + '\nInjected: header')
            self.assertEqual(len(received), 1)
        finally:
            server.shutdown(); server.server_close(); thread.join(2)
