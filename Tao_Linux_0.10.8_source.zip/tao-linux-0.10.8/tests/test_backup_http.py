"""Owner-only HTTP surface for browser-encrypted portable backups."""
import http.client
import json
import threading
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from test_node import NodeHarness


class BackupHTTPTests(NodeHarness):
    def setUp(self):
        super().setUp()
        self.n.TOKEN = 'owner-backup-fixture'
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), self.n.Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'poll_interval': .02}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.thread.join(timeout=3); self.server.server_close()
        super().tearDown()

    def request(self, path, body=None, owner=True, raw=False):
        headers = {'Content-Type': 'application/json'}
        if owner: headers['X-Tao-Token'] = self.n.TOKEN
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        try:
            payload = body if raw else (None if body is None else json.dumps(body))
            connection.request('GET' if body is None else 'POST', path, payload, headers)
            response = connection.getresponse(); data = response.read()
            return response.status, json.loads(data)
        finally:
            connection.close()

    def good(self, path, body):
        status, value = self.request(path, body)
        self.assertEqual(status, 200, value)
        return value

    def test_export_inspect_restore_and_rollback_are_exact_owner_actions(self):
        self.assertEqual(self.request('/api/backup/export?world=main')[0], 404)
        self.assertEqual(self.request('/api/backup/export?world=main', {'scope': 'core'}, owner=False)[0], 403)
        self.assertEqual(self.request('/api/backup/export?world=main', {'scope': 'all'})[0], 400)
        with patch('subprocess.Popen') as process:
            exported = self.good('/api/backup/export?world=main', {'scope': 'core'})
        process.assert_not_called()
        self.assertEqual(exported['bundle']['schema'], 'tao.portable.core.v1')

        marker = self.n.add_buffer('Après export', 'Restaurable', 'Revenu après annulation')
        preview = self.good('/api/backup/inspect?world=main', {'bundle': exported['bundle']})
        bad = dict(bundle=exported['bundle'], review_digest='0' * 64,
                   expected_current_digest=preview['expected_current_digest'], confirmed=True)
        before = self.n.STATE.read_bytes()
        self.assertEqual(self.request('/api/backup/restore?world=main', bad)[0], 400)
        self.assertEqual(self.n.STATE.read_bytes(), before)

        restored = self.good('/api/backup/restore?world=main', dict(
            bundle=exported['bundle'], review_digest=preview['review_digest'],
            expected_current_digest=preview['expected_current_digest'], confirmed=True))
        self.assertNotIn(marker['id'], self.n.load_raw_state()['buffers'])
        self.good('/api/backup/rollback?world=main', {
            'after_digest': restored['after_digest'], 'confirmed': True})
        self.assertIn(marker['id'], self.n.load_raw_state()['buffers'])

    def test_unknown_duplicate_and_child_scoped_requests_fail_closed(self):
        exported = self.good('/api/backup/export?world=main', {'scope': 'core'})
        self.assertEqual(self.request('/api/backup/unknown?world=main', {'bundle': {}})[0], 404)
        duplicate = '{"scope":"core","scope":"core"}'
        self.assertEqual(self.request('/api/backup/export?world=main', duplicate, raw=True)[0], 400)
        child = next(key for key in self.n.load_raw_state()['worlds']['spaces'] if key != 'main')
        self.assertEqual(self.request('/api/backup/inspect?world=' + child,
                                      {'bundle': exported['bundle']})[0], 400)


if __name__ == '__main__':
    import unittest
    unittest.main()
