"""Dialogue → inert candidate; reusable execution always stays explicit."""
import copy
import json
import os
import shutil
import subprocess
from unittest.mock import patch

from test_node import NodeHarness
from test_ecology import HEALTHY
import tao_adaptation as adaptation
import tao_dialogue as dialogue
import tao_reuse as reuse
import tao_ui as ui
import tao_worlds as worlds


def provider_candidate(definition=None):
    definition = definition or reuse.template('text.template')
    return dict(title=definition['title'], description=definition['description'],
                operation=definition['operation'],
                config_json=json.dumps(definition['config']),
                cases_json=json.dumps(definition['cases']))


def answer(candidate=None):
    return {'reply': 'Voici ce que nous pouvons garder.', 'memory_suggestion': '',
            'situation_map': None, 'proposal': None, 'reusable_proposal': candidate}


class DialogueReuseTests(NodeHarness):
    def respond(self, value, change_context=False):
        with patch.object(adaptation, 'executable', return_value='/fixture/codex'), patch.object(dialogue, 'launch'):
            job = dialogue.send(self.n, 'Préparer un brouillon de suivi', 0, 'fixture-reuse-01')

        def run(node, exe, job_row, cwd, prompt, timeout, cancelled):
            self.assertIn('Une proposition est conservée comme candidate', prompt)
            (cwd / 'response.json').write_text(json.dumps(value))
            if change_context:
                self.n.set_story('Une autre direction pendant la réponse')
            return {'ok': True}

        with patch.object(adaptation, 'executable', return_value='/fixture/codex'), \
                patch.object(dialogue, 'run_provider', side_effect=run), \
                patch.object(self.n, 'observe_environment', return_value=HEALTHY):
            return dialogue.worker(self.n, job['id'])

    def active(self, title='Suivi local', private='EXAMPLE_PRIVATE'):
        definition = reuse.template('text.template')
        definition['title'] = title
        definition['provenance'] = private
        row = reuse.propose(self.n, definition)
        row = reuse.qualify(self.n, row['id'], row['revision'])
        return reuse.activate(self.n, row['id'], row['revision'], row['qualification']['review_digest'])

    def test_model_candidate_is_attributed_without_execution_or_authority(self):
        policy = self.n.policy()
        job = self.respond(answer(provider_candidate()))
        self.assertEqual(job['status'], 'answered')
        recipes = reuse.catalog(self.n)['recipes']
        self.assertEqual(len(recipes), 1)
        recipe = recipes[0]
        self.assertEqual((recipe['status'], recipe['origin']), ('candidate', 'ai'))
        self.assertIsNone(recipe['qualification'])
        self.assertIsNone(recipe['activation'])
        self.assertEqual(recipe['receipts'], [])
        self.assertEqual(self.n.policy(), policy)
        reply = self.n.load_state()['dialogue']['messages'][-1]
        self.assertEqual(reply['reusable_capture']['id'], recipe['id'])
        self.assertIn(job['reply_id'], recipe['definition']['provenance'])
        self.assertIn('Aides réutilisables', self.n.dashboard(self.n.load_state()))
        self.assertIn('#recipe-' + recipe['id'], self.n.dashboard(self.n.load_state()))

    def test_invalid_recipe_never_discards_valid_reply_or_executes_code(self):
        candidate = provider_candidate()
        candidate['config_json'] = json.dumps({'command': 'touch forbidden'})
        job = self.respond(answer(candidate))
        self.assertEqual(job['status'], 'answered')
        reply = self.n.load_state()['dialogue']['messages'][-1]
        self.assertEqual(reply['text'], answer()['reply'])
        self.assertEqual(reply['reusable_capture']['status'], 'rejected')
        self.assertTrue(reply['reusable_capture']['warnings'])
        self.assertEqual(reuse.catalog(self.n)['recipes'], [])
        raw = dialogue.file(self.n, job['id']).parent / 'response.json'
        self.assertIn('touch forbidden', raw.read_text())
        self.assertIn('Aide non retenue', self.n.dashboard(self.n.load_state()))

    def test_malformed_optional_candidate_keeps_reply_and_old_answers_still_work(self):
        for candidate in ('not an object', {'command': 'exec'}, dict(provider_candidate(), config_json='[')):
            response = dialogue.validated_reply(json.dumps(answer(candidate)))
            self.assertEqual(response['reply'], answer()['reply'])
            self.assertIsNone(response['reusable_proposal'])
            self.assertTrue(response['reusable_warnings'])
        legacy = answer()
        legacy.pop('reusable_proposal')
        self.assertIsNone(dialogue.validated_reply(json.dumps(legacy))['reusable_proposal'])

    def test_context_changed_candidate_is_deferred_without_losing_reply(self):
        job = self.respond(answer(provider_candidate()), change_context=True)
        self.assertEqual(job['status'], 'answered')
        reply = self.n.load_state()['dialogue']['messages'][-1]
        self.assertEqual(reply['reusable_capture']['status'], 'deferred')
        self.assertEqual(reuse.catalog(self.n)['recipes'], [])

    def test_replayed_capture_is_idempotent_and_full_register_keeps_reply(self):
        validated = dialogue.validated_reply(json.dumps(answer(provider_candidate())))
        first = dialogue.retain_reusable_proposal(self.n, copy.deepcopy(validated), 'reply:fixture', True)
        again = dialogue.retain_reusable_proposal(self.n, copy.deepcopy(validated), 'reply:fixture', True)
        self.assertEqual(first['id'], again['id'])
        self.assertEqual(len(reuse.catalog(self.n)['recipes']), 1)
        with patch.object(reuse, 'propose', side_effect=ValueError('Capacité atteinte')):
            job = self.respond(answer(provider_candidate()))
        self.assertEqual(job['status'], 'answered')
        self.assertEqual(self.n.load_state()['dialogue']['messages'][-1]['reusable_capture']['status'], 'rejected')

    def test_context_contains_only_bounded_active_summaries_in_current_world(self):
        self.active('MAIN_PRIVATE')
        child = worlds.create(self.n, 'Travail', revision=0)
        with worlds.using(child['id']):
            candidate = reuse.template('csv.audit')
            candidate['title'] = 'CANDIDATE_PRIVATE'
            reuse.propose(self.n, candidate)
            for i in range(8):
                self.active('Suivi travail ' + str(i))
            with patch.object(reuse, 'run') as run, patch.object(dialogue, 'run_provider') as model:
                context = dialogue.reusable_context(self.n, 'Suivi travail')
            run.assert_not_called()
            model.assert_not_called()
            self.assertEqual(context['active_count'], 8)
            self.assertEqual(len(context['active_recipes']), 6)
            self.assertEqual(context['omitted_active_recipes'], 2)
            self.assertLessEqual(len(context['suggestions']), 3)
            serialized = json.dumps(context)
            for hidden in ('MAIN_PRIVATE', 'CANDIDATE_PRIVATE', 'EXAMPLE_PRIVATE', 'cases', 'receipts'):
                self.assertNotIn(hidden, serialized)
            self.assertEqual(context['world_id'], child['id'])
            self.assertFalse(context['execution_enabled'])
        self.assertEqual(dialogue.reusable_context(self.n, 'Suivi')['active_count'], 1)

    def test_corrupt_registry_does_not_block_discussion_context(self):
        with patch.object(reuse, 'catalog', side_effect=ValueError('Registre illisible')):
            context = dialogue.snapshot(self.n, self.n.load_state())
        self.assertEqual(context['reusable_tools']['status'], 'unavailable')
        self.assertEqual(context['reusable_tools']['active_recipes'], [])

    def test_candidate_link_is_world_scoped_and_html_escaped(self):
        child = worlds.create(self.n, 'Travail', revision=0)
        with worlds.using(child['id']):
            definition = reuse.template('text.template')
            definition['title'] = '<img src=x onerror=alert(1)>'
            job = self.respond(answer(provider_candidate(definition)))
            reply = self.n.load_state()['dialogue']['messages'][-1]
            page = self.n.dashboard(self.n.load_state())
            self.assertNotIn('<img src=x', page)
            self.assertIn('&lt;img src=x', page)
            self.assertIn('/tools?world=' + child['id'] + '#recipe-' + reply['reusable_capture']['id'], page)
            self.assertEqual(job['status'], 'answered')

    def test_browser_lookup_discards_stale_results_and_only_suggests_active_rows(self):
        node = os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node:
            self.skipTest('Node optional for browser helper verification')
        script = self.base / 'lookup.js'
        script.write_text(ui.REUSE_SUGGESTIONS_JS + r'''
const assert=require('node:assert/strict');
(async()=>{
 const requests=[],shown=[];
 const lookup=createReuseSuggestions(query=>new Promise((resolve,reject)=>requests.push({query,resolve,reject})),value=>shown.push(value));
 const first=lookup('old'),second=lookup('new');
 requests[1].resolve([{id:'aaaaaaaaaaaa',title:'<img onerror=alert(1)>',status:'active'},{id:'bbbbbbbbbbbb',title:'Candidate',status:'candidate'}]);await second;
 assert.equal(shown.length,1);assert.equal(shown[0].rows.length,1);assert.equal(shown[0].rows[0].title,'<img onerror=alert(1)>');
 requests[0].resolve([{id:'cccccccccccc',title:'Old',status:'active'}]);await first;assert.equal(shown.length,1);
 const pending=lookup('later');await lookup('');requests[2].resolve([{id:'dddddddddddd',title:'Later',status:'active'}]);await pending;assert.equal(shown.at(-1).status,'empty');
 const bounded=lookup('x'.repeat(2000));assert.equal(requests[3].query.length,1000);requests[3].reject(Error('offline'));await bounded;assert.equal(shown.at(-1).status,'unavailable');
})().catch(error=>{console.error(error);process.exitCode=1});
''')
        result = subprocess.run([node, str(script)], capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        page = self.n.dashboard(self.n.load_state())
        self.assertIn('link.textContent=row.title.slice(0,160)', page)
        self.assertIn("scoped('/api/reuse/suggest?q='", page)
        self.assertLess(page.index('id="reuse-suggestions"'), page.index('id="dialogue-intent"'))
