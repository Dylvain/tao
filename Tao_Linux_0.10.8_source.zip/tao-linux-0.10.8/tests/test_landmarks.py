import copy
import json
from unittest.mock import patch

from test_node import NodeHarness
from test_ecology import HEALTHY
import tao_adaptation as adapt
import tao_dialogue as talk
import tao_foundations as foundations
import tao_landmarks as landmarks
import tao_worlds as worlds


class LandmarkTests(NodeHarness):
    def create(self, concept='income', text='Je reçois 300000 XPF chaque mois.', title='Salaire'):
        return landmarks.create(self.n, concept, title, text, landmarks.view(self.n)['revision'])

    def payload(self, text='Je reçois 300000 XPF chaque mois.'):
        return {'world': {'id': worlds.current()},
                'messages': [{'id': 'human-1', 'role': 'user', 'text': text}]}

    def proposal(self, payload=None, concept='income'):
        supplied = landmarks.sources(self.payload() if payload is None else payload)
        return {'concept_id': 'tao.concept.' + concept, 'source_id': supplied[0]['source_id'],
                'quote': supplied[0]['text']}, supplied

    def assimilate(self, payload=None, concept='income'):
        proposal, supplied = self.proposal(payload, concept)
        with self.n.LOCK:
            s = self.n.load_state()
            result = landmarks.assimilate(self.n, s, [proposal], supplied, 'reply-fixture')
            self.n.atomic_json(self.n.STATE, s, backup=True)
        return result

    def test_blank_slots_have_meaning_but_no_personal_data_or_writes(self):
        before = self.n.STATE.read_bytes()
        result = landmarks.view(self.n)
        self.assertEqual(result['items'], [])
        self.assertEqual(len(result['slots']), 15)
        self.assertTrue(all(slot['count'] == 0 for slot in result['slots']))
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertNotIn('landmarks', self.n.load_state())
        self.assertNotIn('landmarks', self.n.load_state().get('continuity', {}))
        english = landmarks.view(self.n, locale='en')
        self.assertEqual([s['concept_id'] for s in result['slots']], [s['concept_id'] for s in english['slots']])
        self.assertNotEqual(result['slots'][0]['label'], english['slots'][0]['label'])

    def test_human_changes_keep_immutable_quote_and_saved_revisions(self):
        row = self.create(); original = copy.deepcopy(row['provenance'])
        updated = landmarks.update(self.n, row['id'], 'Salaire corrigé', 'Le montant actuel reste à vérifier.', 1)
        self.assertEqual(updated['provenance'], original)
        self.assertEqual(updated['history'][0]['text'], row['text'])
        self.assertEqual(updated['verification'], 'human_edit_unverified')
        before = self.n.STATE.read_bytes()
        with self.assertRaises(ValueError): landmarks.update(self.n, row['id'], 'Ancien', 'Écraser la correction.', 1)
        self.assertEqual(self.n.STATE.read_bytes(), before)
        archived = landmarks.archive(self.n, row['id'], 2)
        restored = landmarks.restore(self.n, row['id'], archived['revision'])
        self.assertEqual(restored['status'], 'active')
        self.assertEqual(len(restored['history']), 3)
        self.assertEqual(restored['provenance'], original)

    def test_ai_classifies_exact_quotes_without_making_financial_facts(self):
        policy = self.n.policy(); result = self.assimilate()
        row = landmarks.view(self.n)['items'][0]
        self.assertEqual(row['text'], self.payload()['messages'][0]['text'])
        self.assertEqual(row['status'], 'proposed')
        self.assertEqual(row['origin'], 'ai')
        self.assertEqual(row['verification'], 'ai_classification_unverified')
        self.assertFalse(row['execution_enabled'])
        self.assertEqual(row['provenance'][0]['role'], 'user')
        self.assertEqual(self.n.load_state()['buffers'], {})
        self.assertEqual(self.n.policy(), policy)
        self.assertEqual(result['ids'], [row['id']])
        reviewed = landmarks.review(self.n, row['id'], 1)
        self.assertEqual(reviewed['verification'], 'human_reviewed_not_independently_verified')
        self.assertFalse(reviewed['execution_enabled'])

    def test_hallucinated_quote_source_or_command_rejected_without_partial_state(self):
        proposal, sources = self.proposal()
        for changed in (dict(proposal, quote='Je reçois 900000 XPF chaque mois.'),
                        dict(proposal, source_id='message:unknown'), dict(proposal, command='pay'),
                        dict(proposal, concept_id='tao.concept.authorization'),
                        dict(proposal, quote=''), dict(proposal, source_id=[])):
            with self.subTest(proposal=changed):
                s = self.n.load_state(); before = copy.deepcopy(s)
                with self.assertRaises(ValueError): landmarks.assimilate(self.n, s, [proposal, changed], sources, 'reply')
                self.assertEqual(s, before)
        with self.assertRaises(ValueError): landmarks.validate_proposals([proposal] * 6, sources)

    def test_foreign_or_ambiguous_sources_are_refused(self):
        proposal, sources = self.proposal()
        with self.assertRaises(ValueError):
            landmarks.validate_proposals([proposal], [dict(sources[0], world_id='aaaaaaaaaaaa')])
        with self.assertRaises(ValueError):
            landmarks.validate_proposals([proposal], sources + [dict(sources[0], text='Different words')])
        with self.assertRaises(ValueError): landmarks.sources(dict(self.payload(), world={'id': 'bbbbbbbbbbbb'}))

    def test_imported_assistant_excerpt_keeps_unverified_role_and_exact_source(self):
        payload = {'world': {'id': worlds.current()}, 'messages': [], 'imported_history': {'excerpts': [{
            'archive_id': 'archive-example', 'conversation_id': 'conversation-example',
            'message_id': 'assistant-example', 'offset': 200, 'role': 'assistant',
            'source_role': 'assistant', 'text': 'Une ancienne IA supposait 100000 XPF de dépenses.'}]}}
        self.assimilate(payload, 'expense')
        row = landmarks.view(self.n)['items'][0]; source = row['provenance'][0]
        self.assertEqual(source['role'], 'assistant')
        self.assertEqual(source['authority'], 'unverified_import')
        self.assertEqual(source['conversation_id'], 'conversation-example')
        self.assertEqual(source['message_id'], 'assistant-example')
        self.assertEqual(source['offset'], 200)
        self.assertEqual(row['status'], 'proposed')
        self.assertEqual(self.n.load_state().get('dialogue', {}).get('messages', []), [])
        # A different recall window must not duplicate the same exact quote.
        payload['imported_history']['excerpts'][0]['offset'] = 300
        self.assimilate(payload, 'expense')
        self.assertEqual(len(landmarks.view(self.n)['items']), 1)

    def test_rejected_and_human_edited_proposals_are_never_reactivated(self):
        self.assimilate(); row = landmarks.view(self.n)['items'][0]
        row = landmarks.update(self.n, row['id'], 'À examiner', 'Le montant est inconnu.', 1)
        row = landmarks.archive(self.n, row['id'], row['revision'])
        self.assimilate(); again = landmarks.view(self.n)['items'][0]
        self.assertEqual(again, row)
        restored = landmarks.restore(self.n, row['id'], row['revision'])
        self.assertEqual(restored['status'], 'proposed')
        self.assertEqual(restored['text'], 'Le montant est inconnu.')

    def test_human_reclassification_retains_original_type_and_source(self):
        self.assimilate(); row = landmarks.view(self.n)['items'][0]
        changed = landmarks.update(self.n, row['id'], 'Une estimation à examiner', row['text'], 1, concept_id='question')
        self.assertEqual(changed['concept_id'], 'tao.concept.question')
        self.assertEqual(changed['history'][0]['concept_id'], 'tao.concept.income')
        self.assertEqual(changed['provenance'], row['provenance'])
        self.assertEqual(changed['status'], 'proposed')
        self.assimilate()
        self.assertEqual(landmarks.view(self.n)['items'], [changed])

    def test_world_scope_does_not_inherit_or_mutate_parent_cards(self):
        parent = self.create(); registry = worlds.describe(self.n)
        child = worlds.create(self.n, 'Espace privé test', revision=registry['revision'])
        child_id = child['id']
        with worlds.using(child_id):
            self.assertEqual(landmarks.view(self.n)['items'], [])
            with self.assertRaises(ValueError): landmarks.update(self.n, parent['id'], 'X', 'Y', 1)
            own = self.create(text='Cette dépense appartient seulement à cet espace.')
            self.n.cycle()
        self.assertEqual([row['id'] for row in landmarks.view(self.n)['items']], [parent['id']])
        with worlds.using(child_id):
            self.assertEqual([row['id'] for row in landmarks.view(self.n)['items']], [own['id']])
            with self.assertRaises(ValueError):
                landmarks.merge(self.n, [parent['id'], own['id']], 'Fusion', 'Un mélange interdit.', 1)

    def test_merge_preserves_source_ancestry_originals_and_rejects_stale_plan(self):
        a = self.create(); b = self.create(text='La source du revenu reste mon contrat.')
        before = self.n.STATE.read_bytes()
        with self.assertRaises(ValueError):
            landmarks.merge(self.n, [a['id'], b['id']], 'Revenu', 'Une synthèse.', 1)
        self.assertEqual(self.n.STATE.read_bytes(), before)
        result = landmarks.merge(self.n, [a['id'], b['id']], 'Revenu', 'Une synthèse humaine.', 2)
        registry = landmarks.view(self.n)
        self.assertEqual(len(registry['items']), 3)
        self.assertEqual(result['merged_from'], [a['id'], b['id']])
        self.assertEqual(result['verification'], 'human_composition_unverified')
        self.assertEqual([item['quote'] for item in result['provenance']], [a['text'], b['text']])
        self.assertEqual([item['via_landmark_ids'] for item in result['provenance']], [[a['id']], [b['id']]])
        for original in registry['items'][:2]:
            self.assertEqual(original['status'], 'archived')
            self.assertEqual(original['merged_into'], result['id'])
            self.assertEqual(original['history'][0]['status'], 'active')
        restored = landmarks.restore(self.n, a['id'], 2)
        self.assertEqual(restored['text'], a['text'])
        self.assertEqual(restored['status'], 'active')

    def test_different_types_and_duplicate_ids_cannot_be_merged(self):
        a = self.create(); b = self.create('contract', 'Un contrat rapporté.', 'Contrat')
        before = self.n.STATE.read_bytes()
        for ids in ([a['id'], b['id']], [a['id'], a['id']]):
            with self.assertRaises(ValueError): landmarks.merge(self.n, ids, 'X', 'Y', 2)
        self.assertEqual(before, self.n.STATE.read_bytes())

    def test_archived_world_is_readable_but_card_mutation_and_extraction_stop(self):
        child = worlds.create(self.n, 'Espace à archiver', revision=worlds.describe(self.n)['revision'])
        with worlds.using(child['id']): own = self.create()
        foundations.archive(self.n, child['id'], worlds.describe(self.n)['revision'])
        with worlds.using(child['id']):
            self.assertEqual(len(landmarks.view(self.n)['items']), 1)
            before = self.n.STATE.read_bytes()
            for operation in (lambda: self.create(), lambda: landmarks.update(self.n, own['id'], 'X', 'Y', 1),
                              lambda: landmarks.archive(self.n, own['id'], 1)):
                with self.assertRaises(ValueError): operation()
            proposal, sources = self.proposal(); s = self.n.load_state()
            result = landmarks.assimilate(self.n, s, [proposal], sources, 'reply')
            self.assertEqual(result['ids'], []); self.assertTrue(result['warnings'])
            self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_context_is_bounded_scoped_and_archived_cards_are_omitted(self):
        for i in range(10): self.create('question', 'Une question ' + str(i) + ' sur le contexte. ' + 'é' * 1000, str(i))
        current = landmarks.view(self.n)['items'][0]
        landmarks.archive(self.n, current['id'], current['revision'])
        data = landmarks.context(self.n, self.n.load_state(), 'contexte')
        self.assertEqual(len(data['items']), 8); self.assertEqual(data['omitted_items'], 1)
        self.assertNotIn(current['id'], [row['id'] for row in data['items']])
        self.assertTrue(all(row['text_truncated'] for row in data['items']))
        self.assertTrue(all(row['sources'] for row in data['items']))
        self.assertFalse(data['execution_enabled'])

    def test_disabling_continuity_prevents_new_ai_landmarks(self):
        s = self.n.load_state(); talk.continuity.ensure(s)['enabled'] = False
        self.n.atomic_json(self.n.STATE, s, backup=True)
        self.assertEqual(self.assimilate()['ids'], [])
        self.assertEqual(landmarks.view(self.n)['items'], [])

    def test_revision_capacity_never_discards_a_prior_version(self):
        row = self.create(); before = self.n.STATE.read_bytes()
        with patch.object(landmarks, 'MAX_HISTORY', 0):
            with self.assertRaises(ValueError): landmarks.update(self.n, row['id'], 'X', 'Y', 1)
        self.assertEqual(self.n.STATE.read_bytes(), before)
        with patch.object(landmarks, 'MAX_ITEMS', 1):
            with self.assertRaises(ValueError): self.create()
        self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_additive_state_survives_cycle_and_does_not_change_buffers_or_authority(self):
        row = self.create(); s = self.n.load_state(); old_id = s['id']
        s['node_version'] = '0.9.1'; s['private_unknown_extension'] = {'keep': True}
        self.n.atomic_json(self.n.STATE, s, backup=True)
        with patch.object(self.n, 'observe_environment', return_value=HEALTHY): self.n.cycle()
        after = self.n.load_state()
        self.assertEqual(after['id'], old_id)
        self.assertEqual(after['continuity']['landmarks']['items'], [row])
        self.assertNotIn('landmarks', after)
        self.assertEqual(after['private_unknown_extension'], {'keep': True})
        self.assertFalse(self.n.policy()['self_modify_code'])

    def test_existing_continuity_edit_preserves_nested_cards_and_unknown_top_level(self):
        row = self.create(); s = self.n.load_state()
        unknown = {'unrecognized': 'Not an old registry to reinterpret.'}
        s['landmarks'] = copy.deepcopy(unknown)
        self.n.atomic_json(self.n.STATE, s, backup=True)
        talk.continuity.save_settings(self.n, False, s['continuity']['revision'])
        after = self.n.load_state()
        self.assertEqual(after['continuity']['landmarks']['items'], [row])
        self.assertEqual(after['landmarks'], unknown)
        self.assertEqual(landmarks.view(self.n)['items'], [row])

    def test_malformed_nested_registry_is_refused_not_reinitialized(self):
        s = self.n.load_state(); talk.continuity.ensure(s)['landmarks'] = {'broken': True}
        self.n.atomic_json(self.n.STATE, s, backup=True)
        before = self.n.STATE.read_bytes()
        with self.assertRaises(ValueError): landmarks.view(self.n)
        with self.assertRaises(ValueError): landmarks.create(self.n, 'income', 'X', 'Y', 0)
        self.assertEqual(self.n.STATE.read_bytes(), before)


class LandmarkDialogueTests(NodeHarness):
    def reply(self, changed=None, mutate=None):
        with patch.object(adapt, 'executable', return_value='/fixture/codex'), patch.object(talk, 'launch'):
            job = talk.send(self.n, 'Je reçois 300000 XPF chaque mois.', 0, 'landmark-fixture-1')
        def run(node, exe, job_row, cwd, prompt, timeout, cancelled):
            payload = self.n.load_json(cwd / 'context.json')
            self.assertIn('landmarks', payload)
            supplied = landmarks.sources(payload)
            proposal = {'concept_id': 'tao.concept.income', 'source_id': supplied[0]['source_id'], 'quote': supplied[0]['text']}
            answer = {'reply': 'Ce montant est rapporté, à vérifier.', 'memory_suggestion': '',
                      'situation_map': None, 'proposal': None, 'landmark_proposals': [proposal]}
            if changed: changed(answer)
            (cwd / 'response.json').write_text(json.dumps(answer))
            if mutate: mutate()
            return {'ok': True}
        with patch.object(adapt, 'executable', return_value='/fixture/codex'), \
             patch.object(talk, 'run_provider', side_effect=run), \
             patch.object(self.n, 'observe_environment', return_value=HEALTHY):
            return talk.worker(self.n, job['id'])

    def test_one_dialogue_retains_inert_landmark_with_reply(self):
        job = self.reply(); self.assertEqual(job['status'], 'answered')
        s = self.n.load_state(); row = s['continuity']['landmarks']['items'][0]
        self.assertEqual(s['dialogue']['messages'][-1]['landmark_capture']['ids'], [row['id']])
        self.assertEqual(s['buffers'], {})
        focus = talk.resolve_focus(self.n, s, {'kind': 'landmark', 'id': row['id'], 'revision': 1})
        self.assertFalse(focus['execution_enabled']); self.assertEqual(focus['context']['text'], row['text'])
        landmarks.review(self.n, row['id'], 1)
        with self.assertRaises(ValueError): talk.reply(self.n, self.n.load_state(), job['reply_id'])

    def test_bad_proposal_does_not_silence_conversation_or_save_fake_amount(self):
        def changed(answer): answer['landmark_proposals'][0]['quote'] = 'Je reçois 999999 XPF chaque mois.'
        job = self.reply(changed); self.assertEqual(job['status'], 'answered')
        self.assertEqual(landmarks.view(self.n)['items'], [])
        self.assertTrue(self.n.load_state()['dialogue']['messages'][-1]['landmark_capture']['warnings'])

    def test_legacy_response_without_proposals_still_answers(self):
        job = self.reply(lambda answer: answer.pop('landmark_proposals'))
        self.assertEqual(job['status'], 'answered')
        self.assertEqual(landmarks.view(self.n)['items'], [])

    def test_changed_card_context_defers_ai_proposals(self):
        def mutate(): landmarks.create(self.n, 'question', 'À clarifier', 'Le montant concerne quelle période ?', 0)
        job = self.reply(mutate=mutate); self.assertEqual(job['status'], 'answered')
        self.assertEqual(len(landmarks.view(self.n)['items']), 1)
        captured = self.n.load_state()['dialogue']['messages'][-1]['landmark_capture']
        self.assertEqual(captured['ids'], []); self.assertTrue(captured['warnings'])

    def test_world_rename_during_reply_defers_both_notes_and_landmarks(self):
        def include_note(answer):
            answer['continuity'] = {'notes': [{'kind': 'context', 'text': 'Un montant rapporté.',
                'message_id': self.n.load_state()['dialogue']['messages'][-1]['id'],
                'quote': 'Je reçois 300000 XPF chaque mois.'}], 'needs': []}
        def rename():
            foundations.update(self.n, worlds.current(), worlds.describe(self.n)['revision'], title='Contexte renommé')
        job = self.reply(include_note, rename); self.assertEqual(job['status'], 'answered')
        s = self.n.load_state(); message = s['dialogue']['messages'][-1]
        self.assertEqual(landmarks.view(self.n)['items'], [])
        self.assertEqual(s.get('continuity', {}).get('notes', []), [])
        self.assertTrue(message['captured']['warnings'])
        with self.assertRaises(ValueError): talk.reply(self.n, s, job['reply_id'])

    def test_archiving_ancestor_during_reply_changes_context_without_revoking_permissions(self):
        parent = worlds.create(self.n, 'Parent', revision=worlds.describe(self.n)['revision'])['id']
        child = worlds.create(self.n, 'Enfant', parent_id=parent, revision=worlds.describe(self.n)['revision'])['id']
        before_policy = self.n.POLICY.read_bytes()
        with worlds.using(child):
            def archive_parent(): foundations.archive(self.n, parent, worlds.describe(self.n)['revision'])
            job = self.reply(mutate=archive_parent)
            self.assertEqual(job['status'], 'answered')
            self.assertEqual(landmarks.view(self.n)['items'], [])
            self.assertTrue(self.n.load_state()['dialogue']['messages'][-1]['captured']['warnings'])
            scope = talk.world_scope(self.n, self.n.load_state())
            self.assertTrue(scope['effective_archived'])
            self.assertEqual([row['id'] for row in scope['path']], ['main', parent, child])
        self.assertEqual(self.n.POLICY.read_bytes(), before_policy)

    def test_unrelated_space_changes_do_not_invalidate_current_reply(self):
        sibling = worlds.create(self.n, 'Sans rapport', revision=worlds.describe(self.n)['revision'])['id']
        def rename_sibling():
            foundations.update(self.n, sibling, worlds.describe(self.n)['revision'], description='Autre périmètre')
        job = self.reply(mutate=rename_sibling)
        self.assertEqual(job['status'], 'answered')
        self.assertEqual(len(landmarks.view(self.n)['items']), 1)
        self.assertEqual(self.n.load_state()['dialogue']['messages'][-1]['landmark_capture']['warnings'], [])
        scope = talk.snapshot(self.n, self.n.load_state())['world_scope']
        self.assertNotIn(sibling, str(scope))

    def test_parent_description_and_reparenting_change_scoped_signature(self):
        parent = worlds.create(self.n, 'Parent', revision=worlds.describe(self.n)['revision'])['id']
        child = worlds.create(self.n, 'Enfant', parent_id=parent, revision=worlds.describe(self.n)['revision'])['id']
        with worlds.using(child):
            original = talk.signature(self.n, self.n.load_state())
            foundations.update(self.n, parent, worlds.describe(self.n)['revision'], description='Une précision pertinente')
            changed = talk.signature(self.n, self.n.load_state())
            self.assertNotEqual(original, changed)
            foundations.update(self.n, child, worlds.describe(self.n)['revision'], parent_id='main')
            self.assertNotEqual(changed, talk.signature(self.n, self.n.load_state()))

    def test_source_inventory_is_recomputed_after_context_truncation(self):
        s = self.n.load_state(); d = talk.ensure(s)
        d['messages'] = [{'id': str(i), 'role': 'user', 'text': str(i) + 'é' * 5990} for i in range(35)]
        payload = talk.snapshot(self.n, s)
        self.assertLessEqual(len(self.n.json_bytes(payload)), talk.MAX_CONTEXT)
        expected = {'message:' + row['id'] for row in payload['messages']}
        self.assertEqual({row['source_id'] for row in payload['landmark_sources']}, expected)
        self.assertGreater(payload['omitted_messages'], 0)
