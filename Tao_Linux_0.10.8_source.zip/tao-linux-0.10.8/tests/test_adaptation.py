import json, os, shutil, socket, subprocess, sys, time, urllib.request
from pathlib import Path
from unittest.mock import patch
from test_node import NodeHarness, PROJECT
import tao_adaptation as adapt
import tao_workshop as atelier


class AdaptationTests(NodeHarness):
    def task(self):
        self.n.work.save_context(self.n,'Support fictif','Continuer à apprendre','Aucun envoi')
        b=self.n.work.add_task(self.n,'Préparer une réponse fictive')
        return self.n.work.save_example(self.n,b['id'],'Demande fictive','Brouillon relu')

    def test_missing_capabilities_are_visible_without_implicit_provider_call(self):
        b=self.task()
        with patch.object(adapt.shutil,'which',return_value=None),patch.object(adapt.subprocess,'Popen') as launch:
            d=adapt.diagnose(self.n)
            self.assertEqual({r['code'] for r in d['blockers']},{'codex_missing','git_missing','source_missing'})
            with self.assertRaises(ValueError): adapt.request(self.n,b['id'],'generate')
            launch.assert_not_called()
            page=self.n.dashboard(self.n.load_state())
            self.assertIn('Installation et connexion de Codex',page)
        self.assertNotIn('adaptation_id',self.n.load_state()['buffers'][b['id']]['work_task'])

    def ready(self):
        self.n.atomic_json(self.n.ROOT/'source.json',{'path':str(self.base)})
        return patch.object(adapt,'executable',return_value='/fixture/codex')

    def test_single_operation_and_context_change_require_new_candidate(self):
        b=self.task()
        with self.ready(),patch.object(adapt,'launch') as launch:
            row=adapt.request(self.n,b['id'],'generate')
            with self.assertRaises(ValueError): adapt.request(self.n,b['id'],'generate')
            launch.assert_called_once()
        row.update(status='review',review_digest='reviewed');adapt.save(self.n,row)
        with self.assertRaises(ValueError): adapt.request(self.n,b['id'],'verify',row['id'],'reviewed')
        self.n.work.save_context(self.n,'Nouveau besoin',revision=1)
        with self.assertRaises(ValueError): adapt.request(self.n,b['id'],'verify',row['id'],'reviewed',True)
        self.assertEqual(adapt.load(self.n,row['id'])['status'],'review')

    def test_cancel_marker_and_interrupted_process_do_not_forge_success(self):
        b=self.task()
        with self.ready(),patch.object(adapt,'launch'):
            row=adapt.request(self.n,b['id'],'generate')
        adapt.request(self.n,b['id'],'cancel',row['id'])
        self.assertTrue((adapt.path(self.n,row['id']).parent/'cancel').exists())
        row.update(pid=99999999,process_start='missing',status='running')
        self.assertEqual(adapt.status(self.n,row)['status'],'interrupted')
        result=atelier.run_bounded([sys.executable,'-c','import time; time.sleep(10)'],self.base,self.base/'cancel.log',20,cancel=lambda:True)
        self.assertEqual(result['reason'],'cancelled');self.assertFalse(result['ok'])

    def test_restart_uses_an_independent_systemd_unit_only_when_configured(self):
        self.n.atomic_json(self.n.ROOT/'source.json',{'systemd_user':True,'path_env':'/usr/bin:/bin'})
        row={'id':'012345abcdef'}
        with patch.object(adapt.shutil,'which',return_value='/usr/bin/systemd-run'),patch.object(adapt.subprocess,'run') as run:
            run.return_value.returncode=0
            adapt.launch(self.n,row,'apply')
            args=run.call_args.args[0]
            self.assertIn('--user',args);self.assertIn('--service-type=exec',args)
            self.assertIn('--setenv=TAO_ROOT='+str(self.root),args)
            self.assertEqual(args[-3:],['adapt-worker',row['id'],'apply'])

    def test_full_http_candidate_review_tests_install_and_restart(self):
        # Real HTTP, subprocess worker, Git clone, tests, installer and restart.
        # Only the AI generation is simulated, with a tiny observable change.
        repo=self.base/'repo';repo.mkdir()
        shutil.copytree(PROJECT/'bootstrap',repo/'bootstrap',ignore=shutil.ignore_patterns('__pycache__'))
        (repo/'docs').mkdir();shutil.copyfile(PROJECT/'docs/theory.json',repo/'docs/theory.json')
        for name in ['MANIFEST.json','VERSION.json','.gitignore']:shutil.copyfile(PROJECT/name,repo/name)
        (repo/'scripts').mkdir()
        (repo/'scripts/verify.sh').write_text("set -eu\npython3 -c \"from pathlib import Path; assert '# fixture adaptation' in Path('bootstrap/tao_ui.py').read_text()\"\n")
        atelier.git(repo,'init');atelier.git(repo,'add','.')
        atelier.git(repo,*atelier.identity_args(),'commit','-m','Fixture baseline')
        fake=self.base/'bin';fake.mkdir();codex=fake/'codex'
        codex.write_text('#!'+sys.executable+'''\nimport json, sys
from pathlib import Path
def dialogue(prompt):
    assert 'APPRENTISSAGE_FICTIF' in prompt
    assert 'Premier récit fictif' in prompt
    return {'reply':'Clarifions le besoin fictif <script>bad</script>.','memory_suggestion':'','situation_map':{'reported':['Un récit fictif'],'hypotheses':[],'objectives':['Construire une aide locale'],'constraints':['Aucun envoi'],'people':[],'next_steps':['Relire la proposition']},
          'proposal':{'title':'Une aide fictive','situation':'Un exemple fictif','expected':'Un commentaire vérifiable','boundaries':'Aucun service externe'}}
if sys.argv[1:]==['app-server']:
    for line in sys.stdin:
        message=json.loads(line)
        if message.get('id')==1:
            print(json.dumps({'id':1,'result':{}}),flush=True)
        elif message.get('id')==2:
            params=message['params'];assert params['sandbox']=='read-only' and params['approvalPolicy']=='never' and params['ephemeral']
            print(json.dumps({'id':2,'result':{'thread':{'id':'fixture-dialogue-thread'}}}),flush=True)
        elif message.get('id')==3:
            prompt=message['params']['input'][0]['text'];raw=json.dumps(dialogue(prompt))
            print(json.dumps({'method':'item/agentMessage/delta','params':{'delta':raw}}),flush=True)
            print(json.dumps({'method':'item/completed','params':{'item':{'type':'agentMessage','text':raw}}}),flush=True)
            print(json.dumps({'method':'turn/completed','params':{'turn':{'status':'completed','items':[]}}}),flush=True)
    sys.exit(0)
prompt=sys.stdin.read()
assert sys.argv[1:4]==['exec','--sandbox','workspace-write']
assert 'Ne contacte aucun service professionnel' in prompt
p=Path('bootstrap/tao_ui.py');p.write_text(p.read_text()+'\\n# fixture adaptation\\n')
Path(sys.argv[sys.argv.index('--output-last-message')+1]).write_text('Changement fictif à vérifier <script>bad</script>.')
''');codex.chmod(0o700)
        home=self.base/'home';home.mkdir()
        env=dict(self.env,HOME=str(home),XDG_CONFIG_HOME=str(home/'.config'),PATH=str(fake)+os.pathsep+os.environ.get('PATH',''))
        with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        self.n.atomic_json(self.n.POLICY,{'http_port':port})
        install=subprocess.run([sys.executable,str(repo/'bootstrap/install.py')],env=env,capture_output=True,text=True,timeout=20)
        self.assertEqual(install.returncode,0,install.stderr)
        base=f'http://127.0.0.1:{port}'
        def get(suffix='/?view=dialogue'):
            with urllib.request.urlopen(base+suffix,timeout=3) as response:return response.read().decode()
        def post(payload,endpoint='/api/adaptation'):
            token=json.loads(get().split('const token=')[1].split(';')[0])
            request=urllib.request.Request(base+endpoint,data=json.dumps(payload).encode(),headers={'X-Tao-Token':token,'Content-Type':'application/json'})
            with urllib.request.urlopen(request,timeout=3) as response:return json.load(response)
        def wait(ident,expected,endpoint='/api/adaptation?id='):
            deadline=time.monotonic()+25;last=None
            while time.monotonic()<deadline:
                try:
                    last=json.loads(get(endpoint+ident))
                    if last['status']==expected:return last
                    if last['status'] not in adapt.BUSY:self.fail(str(last))
                except OSError:pass
                time.sleep(.1)
            self.fail('No final status: '+str(last))
        try:
            before=json.loads(get('/health'))['session']
            post({'text':'APPRENTISSAGE_FICTIF','revision':0},'/api/dialogue/memory')
            first=post({'text':'Premier récit fictif','revision':1,'nonce':'http-fixture-first'},'/api/dialogue/send')
            wait(first['id'],'answered','/api/dialogue?id=')
            self.assertEqual(self.n.load_state()['buffers'],{})
            second=post({'text':'Peux-tu préparer une aide ?','revision':3,'nonce':'http-fixture-next'},'/api/dialogue/send')
            answer=wait(second['id'],'answered','/api/dialogue?id=')
            self.assertIn('Clarifions le besoin fictif',get())
            self.assertIn('Notre vue de la situation',get())
            self.assertIn('APPRENTISSAGE_FICTIF',get('/dialogue/context?id='+second['id']))
            self.assertNotIn('<script>bad</script>',get())
            adopted=post({'id':answer['reply_id']},'/api/dialogue/prepare')
            b=self.n.load_state()['buffers'][adopted['task_id']]
            row={'id':adopted['adaptation_id']}
            review=wait(row['id'],'review')
            self.assertIn('fixture adaptation',review['patch'])
            self.assertNotIn('fixture adaptation',(repo/'bootstrap/tao_ui.py').read_text())
            self.assertNotIn('TAO_RESULT',review['patch'])
            self.assertNotIn('<script>bad</script>',get())
            # A changed candidate after review must be refused before tests.
            candidate=Path(atelier.Workshop(self.n).load(review['experiment_id'])['candidate'])
            original=(candidate/'bootstrap/tao_ui.py').read_text()
            (candidate/'bootstrap/tao_ui.py').write_text(original+'# unseen change\n')
            post({'task_id':b['id'],'id':row['id'],'action':'verify','review_digest':review['review_digest'],'confirmed':True})
            blocked=wait(row['id'],'blocked');self.assertIn('changé',blocked['message'])
            # A new candidate is explicitly requested after that refusal.
            row=post({'task_id':b['id'],'action':'generate'});review=wait(row['id'],'review')
            post({'task_id':b['id'],'id':row['id'],'action':'verify','review_digest':review['review_digest'],'confirmed':True})
            verified=wait(row['id'],'verified')
            post({'task_id':b['id'],'id':row['id'],'action':'apply','review_digest':verified['review_digest'],'confirmed':True})
            installed=wait(row['id'],'installed')
            self.assertNotEqual(json.loads(get('/health'))['session'],before)
            self.assertTrue(adapt.installed_matches(self.n,repo))
            self.assertIn('fixture adaptation',(repo/'bootstrap/tao_ui.py').read_text())
            self.assertEqual(self.n.load_state()['buffers'][b['id']]['status'],'open')
            self.assertFalse(self.n.load_state()['buffers'][b['id']]['work_task']['execution_enabled'])
            self.assertFalse(installed['duty_execution_authorized'])
            self.assertIn('Est-ce que cette aide fonctionne pour toi ?',get())
            report=post({'task_id':b['id'],'adaptation_id':row['id'],'outcome':'success',
                         'case':'Parcours fictif','observed':'Le changement attendu est visible.','revision':0},'/api/learning/report')
            self.assertEqual(report['source'],'human_report')
            values={'title':'Méthode fictive','applicability':'Un cas de test','method':'Comparer la sortie attendue.',
                    'counterexample':'Hors de ce cas, réévaluer.','check':'Rejouer un exemple local.'}
            method=post({'report_id':report['id'],'values':values,'confirmed':True,'revision':1},'/api/learning/method')
            self.assertEqual(method['status'],'approved_for_transfer')
            withdrawn=post({'id':method['id'],'revision':2},'/api/learning/withdraw')
            self.assertEqual(withdrawn['status'],'withdrawn')
            self.assertEqual(self.n.load_state()['buffers'][b['id']]['status'],'open')
            revision=self.n.load_state()['dialogue']['revision']
            archived=post({'revision':revision},'/api/dialogue/new')
            self.assertIn('Premier récit fictif',get('/dialogue/archive?id='+archived['archive_id']))
            self.assertIn('APPRENTISSAGE_FICTIF',get('/dialogue/export'))
            self.assertNotIn('Premier récit fictif',get('/dialogue/export'))
        finally:
            subprocess.run([str(home/'.local/bin/tao'),'stop'],env=env,capture_output=True,timeout=10)
