"""Real daemon and mobile gateway; Tailscale transport headers are simulated.

No test opens a public/LAN listener, changes Tailscale configuration, or calls AI.
The CLI fixture accepts only its two read-only status commands.
"""
import http.client
import json
import os
import socket
import subprocess
import sys
import time

from test_node import NodeHarness, NODE


ORIGIN = 'https://fixture.private.ts.net:8443'
OWNER = 'fixture-owner@example.test'


def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


class MobileIntegrationTests(NodeHarness):
    def test_durable_recipe_runs_through_paired_phone_without_model(self):
        import tao_reuse as reuse
        row = reuse.propose(self.n, reuse.template('csv.audit'))
        row = reuse.qualify(self.n, row['id'], row['revision'])
        row = reuse.activate(self.n, row['id'], row['revision'], row['qualification']['review_digest'])
        self.configure(); self.start_daemon(); self.associate()
        status, _, _ = self.request('/tools', gateway=True, cookie=False)
        self.assertEqual(status, 401)
        status, page, _ = self.request('/tools?world=main', gateway=True)
        self.assertEqual(status, 200, page); self.assertIn('Mes aides', page)
        node_token = self.n.load_json(self.root/'session.json')['token']
        self.assertNotIn(node_token, page)
        self.assertNotIn(node_token, self.request('/', gateway=True)[1])
        value = self.successful_json('/api/reuse/run?world=main',
            {'id': row['id'], 'revision': row['revision'], 'inputs': {'csv': 'id,title,url\n1,'+'x'*40000+',/\n'}}, gateway=True)
        self.assertEqual(value['model_calls'], 0)
        self.n.set_story(node_token)
        status, body, _ = self.request('/state', gateway=True)
        self.assertEqual(status, 502); self.assertNotIn(node_token, body)

    def setUp(self):
        super().setUp()
        self.process = None
        self.node_port = free_port()
        self.gateway_port = free_port()
        while self.gateway_port == self.node_port:
            self.gateway_port = free_port()
        self.cookie = None
        self.n.atomic_json(self.n.POLICY, {'http_port': self.node_port})

    def tearDown(self):
        self.stop_daemon()
        super().tearDown()

    def stop_daemon(self):
        if self.process is None:
            return
        if self.process.poll() is None:
            self.process.terminate()
        try:
            self.process.communicate(timeout=8)
        except subprocess.TimeoutExpired:
            self.process.kill(); self.process.communicate(timeout=3)
            self.fail('Le daemon de test ne s’est pas arrêté.')
        finally:
            self.process = None

    def request(self, path, data=None, gateway=False, token=None, cookie=True):
        headers = {}
        if gateway:
            headers.update({'Host': ORIGIN.removeprefix('https://'),
                            'Tailscale-User-Login': OWNER})
            if cookie and self.cookie:
                headers['Cookie'] = self.cookie
        if data is not None:
            headers.update({'Content-Type': 'application/json',
                            'X-Tao-Token': token or 'fixture-browser-token'})
            headers['Origin'] = ORIGIN if gateway else 'http://127.0.0.1:' + str(self.node_port)
        conn = http.client.HTTPConnection('127.0.0.1', self.gateway_port if gateway else self.node_port, timeout=3)
        try:
            conn.request('POST' if data is not None else 'GET', path,
                         None if data is None else json.dumps(data).encode(), headers)
            response = conn.getresponse()
            return response.status, response.read().decode(), dict(response.getheaders())
        finally:
            conn.close()

    def successful_json(self, path, data=None, gateway=False, token=None):
        status, body, _ = self.request(path, data, gateway, token)
        self.assertEqual(status, 200, body)
        return json.loads(body)

    def configure(self):
        result = self.cli('mobile', 'configure', '--origin', ORIGIN, '--owner', OWNER,
                          '--port', str(self.gateway_port))
        return json.loads(result.stdout)

    def start_daemon(self, ready=True):
        self.process = subprocess.Popen([sys.executable, str(NODE), 'daemon'], env=self.env,
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                out, err = self.process.communicate()
                self.fail('Daemon terminé au démarrage : ' + out.decode() + err.decode())
            try:
                status, raw, _ = self.request('/health')
                health = json.loads(raw)
                if status == 200 and health.get('ok') and health.get('mobile', {}).get('ready') is ready:
                    return health
            except (OSError, ValueError, http.client.HTTPException):
                pass
            time.sleep(.03)
        self.fail('Le daemon ne publie pas la santé attendue.')

    def associate(self):
        invitation = json.loads(self.cli('mobile', 'pair', '--name', 'Téléphone fictif').stdout)
        status, body, headers = self.request('/mobile/pair', {'code': invitation['code']}, gateway=True, cookie=False)
        self.assertEqual(status, 200, body)
        self.cookie = headers['Set-Cookie'].split(';', 1)[0]
        self.assertIn('Secure', headers['Set-Cookie'])
        self.assertIn('HttpOnly', headers['Set-Cookie'])
        self.assertIn('SameSite=Strict', headers['Set-Cookie'])
        return self.cookie

    def test_real_daemon_gateway_world_and_cookie_survive_node_token_rotation(self):
        self.configure(); first_health = self.start_daemon()
        self.assertEqual(first_health['mobile'], {'enabled': True, 'ready': True})
        session_one = self.n.load_json(self.root / 'session.json')
        status, _, _ = self.request('/state', gateway=True, cookie=False)
        self.assertEqual(status, 401)
        cookie = self.associate()
        initial = self.successful_json('/state', gateway=True)
        child = self.successful_json('/api/worlds/create',
            {'title': 'Monde mobile fictif', 'revision': initial['world']['revision']}, gateway=True)['id']
        suffix = '?world=' + child
        self.successful_json('/api/dialogue/memory' + suffix,
            {'text': 'PRIVATE_CHILD_MOBILE_MEMORY', 'revision': 0}, gateway=True)
        self.successful_json('/api/story' + suffix, {'text': 'PRIVATE_CHILD_MOBILE_STORY'}, gateway=True)
        mobile_child = self.successful_json('/state' + suffix, gateway=True)
        local_child = self.successful_json('/state' + suffix)
        self.assertEqual(mobile_child['dialogue']['memory'], 'PRIVATE_CHILD_MOBILE_MEMORY')
        self.assertEqual(local_child['dialogue'], mobile_child['dialogue'])
        self.assertEqual(local_child['story'], mobile_child['story'])
        self.assertNotIn('PRIVATE_CHILD_MOBILE_MEMORY', json.dumps(self.successful_json('/state', gateway=True)))
        self.assertEqual(self.request('/api/stop', {}, gateway=True)[0], 403)
        self.stop_daemon()
        self.assertFalse((self.root / 'mobile-listener.json').exists())
        second_health = self.start_daemon()
        session_two = self.n.load_json(self.root / 'session.json')
        self.assertNotEqual(first_health['session'], second_health['session'])
        self.assertNotEqual(session_one['token'], session_two['token'])
        self.assertEqual(self.cookie, cookie)
        restored = self.successful_json('/state' + suffix, gateway=True)
        self.assertEqual(restored['dialogue']['memory'], 'PRIVATE_CHILD_MOBILE_MEMORY')
        # A page left open on the phone still sends its old X-Tao-Token. The
        # gateway authenticates its durable cookie then forwards the new local
        # token; it must not make that old token valid on the PC listener.
        updated = self.successful_json('/api/dialogue/memory' + suffix,
            {'text': 'PRIVATE_CHILD_MEMORY_AFTER_RESTART', 'revision': restored['dialogue']['revision']},
            gateway=True, token=session_one['token'])
        self.assertEqual(updated['memory'], 'PRIVATE_CHILD_MEMORY_AFTER_RESTART')
        status, _, _ = self.request('/api/story', {'text': 'Must not overwrite'}, token=session_one['token'])
        self.assertEqual(status, 403)
        self.assertEqual(self.successful_json('/state' + suffix)['dialogue']['memory'],
                         'PRIVATE_CHILD_MEMORY_AFTER_RESTART')
        self.assertEqual(len(json.loads(self.cli('mobile', 'status').stdout)['sessions']), 1)

    def test_gateway_port_collision_preserves_pc_and_reports_mobile_not_ready(self):
        with socket.socket() as occupied:
            occupied.bind(('127.0.0.1', 0)); occupied.listen()
            self.gateway_port = occupied.getsockname()[1]
            self.configure(); health = self.start_daemon(ready=False)
            self.assertTrue(health['ok'])
            self.assertEqual(health['mobile'], {'enabled': True, 'ready': False})
            status = json.loads(self.cli('mobile', 'status').stdout)
            self.assertFalse(status['running']); self.assertTrue(status['restart_required'])
            state = self.successful_json('/state')
            failure = next(row for row in state['buffers'] if row['id'] == 'interface.mobile')
            self.assertEqual(failure['status'], 'open')
            session = self.n.load_json(self.root / 'session.json')
            story = self.successful_json('/api/story', {'text': 'PC remains operational'}, token=session['token'])
            self.assertEqual(story['text'], 'PC remains operational')
            self.assertIsNone(self.process.poll())

    def tailscale_fixture(self, state, serve):
        folder = self.base / 'tailscale-fixture'; folder.mkdir(exist_ok=True)
        (folder / 'status.json').write_text(json.dumps(state))
        (folder / 'serve.json').write_text(json.dumps(serve))
        script = folder / 'tailscale'
        script.write_text('#!' + sys.executable + '''
import json, sys
from pathlib import Path
root = Path(__file__).parent
arguments = sys.argv[1:]
with (root / 'calls.jsonl').open('a') as output:
    output.write(json.dumps(arguments) + '\\n')
if arguments == ['status', '--json']:
    print((root / 'status.json').read_text())
elif arguments == ['serve', 'status', '--json']:
    print((root / 'serve.json').read_text())
else:
    raise SystemExit('Forbidden fixture command: ' + repr(arguments))
''')
        script.chmod(0o700)
        self.env['PATH'] = str(folder) + os.pathsep + os.environ.get('PATH', '')
        return folder

    def setup(self, check=True):
        return self.cli('mobile', 'setup', '--port', str(self.gateway_port), '--https-port', '8443', check=check)

    def tailscale_state(self):
        return {'BackendState': 'Running', 'Self': {'DNSName': 'fixture.private.ts.net.', 'UserID': 42},
                'User': {'42': {'LoginName': OWNER}}}

    def calls(self, folder):
        return [json.loads(line) for line in (folder / 'calls.jsonl').read_text().splitlines()]

    def test_setup_accepts_null_serve_status_and_only_reads_tailscale(self):
        folder = self.tailscale_fixture(self.tailscale_state(), None)
        result = json.loads(self.setup().stdout)
        self.assertEqual(result['origin'], ORIGIN)
        self.assertEqual(result['owner_login'], OWNER)
        self.assertFalse(result['network_changed'])
        self.assertEqual(self.calls(folder), [['status', '--json'], ['serve', 'status', '--json']])
        self.assertIn('tailscale serve --bg --https=8443 http://127.0.0.1:' + str(self.gateway_port), result['next_steps'])
        self.assertFalse((self.root / 'session.json').exists())

    def test_setup_accepts_matching_private_serve_without_reconfiguring_it(self):
        authority = ORIGIN.removeprefix('https://')
        serve = {'TCP': {'8443': {'HTTPS': True}}, 'Web': {authority: {'Handlers': {
            '/': {'Proxy': 'http://127.0.0.1:' + str(self.gateway_port)}}}}, 'AllowFunnel': {}}
        folder = self.tailscale_fixture(self.tailscale_state(), serve)
        self.setup(); saved = (self.root / 'mobile.json').read_bytes()
        result = json.loads(self.setup().stdout)
        self.assertFalse(result['network_changed'])
        self.assertEqual((self.root / 'mobile.json').read_bytes(), saved)
        self.assertEqual(self.calls(folder), [['status', '--json'], ['serve', 'status', '--json']] * 2)

    def test_setup_https_443_accepts_explicit_port_in_existing_serve_key(self):
        serve = {'TCP': {'443': {'HTTPS': True}}, 'Web': {'fixture.private.ts.net:443': {'Handlers': {
            '/': {'Proxy': 'http://127.0.0.1:' + str(self.gateway_port)}}}}, 'AllowFunnel': {}}
        folder = self.tailscale_fixture(self.tailscale_state(), serve)
        args = ('mobile', 'setup', '--port', str(self.gateway_port), '--https-port', '443')
        first = json.loads(self.cli(*args).stdout)
        saved = (self.root / 'mobile.json').read_bytes()
        second = json.loads(self.cli(*args).stdout)
        self.assertEqual(first['origin'], 'https://fixture.private.ts.net')
        self.assertEqual(second['origin'], first['origin'])
        self.assertEqual((self.root / 'mobile.json').read_bytes(), saved)
        self.assertEqual(self.calls(folder), [['status', '--json'], ['serve', 'status', '--json']] * 2)

    def test_setup_rejects_conflicting_service_and_preserves_existing_mobile_config(self):
        self.configure(); before = (self.root / 'mobile.json').read_bytes()
        authority = ORIGIN.removeprefix('https://')
        serve = {'TCP': {'8443': {'HTTPS': True}}, 'Web': {authority: {'Handlers': {
            '/': {'Proxy': 'http://127.0.0.1:12345'}}}}, 'AllowFunnel': {}}
        folder = self.tailscale_fixture(self.tailscale_state(), serve)
        result = self.setup(check=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('déjà un autre accès', json.loads(result.stderr)['error'])
        self.assertEqual((self.root / 'mobile.json').read_bytes(), before)
        self.assertEqual(self.calls(folder), [['status', '--json'], ['serve', 'status', '--json']])

    def test_setup_rejects_null_node_status_without_creating_configuration(self):
        folder = self.tailscale_fixture(None, {})
        result = self.setup(check=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Connecter Tailscale', json.loads(result.stderr)['error'])
        self.assertFalse((self.root / 'mobile.json').exists())
        self.assertEqual(self.calls(folder), [['status', '--json']])
