import copy, json, os, sys
from unittest.mock import patch
from test_node import NodeHarness
from test_ecology import HEALTHY
import tao_dialogue as talk
import tao_adaptation as adapt
import tao_ecology as ecology

ANSWER={'reply':'On peut clarifier ton objectif avant d’agir. <script>inert</script>',
        'memory_suggestion':'Je veux continuer à apprendre.','situation_map':{k:['Élément fictif <script>inert</script>'] for k in talk.MAP_FIELDS},
        'proposal':{'title':'Mon aide fictive','situation':'Une situation fictive',
                    'expected':'Un résultat local vérifiable','boundaries':'Aucun envoi à autrui'}}

class DialogueTests(NodeHarness):
    def queued(self,text='Aide-moi à comprendre ce besoin',nonce='fixture-nonce-001'):
        revision=self.n.load_state().get('dialogue',{}).get('revision',0)
        with patch.object(adapt,'executable',return_value='/fixture/codex'),patch.object(talk,'launch'):
            return talk.send(self.n,text,revision,nonce)

    def answer(self,value=None,cancel=False):
        row=self.queued()
        def run(node,exe,job,cwd,prompt,timeout,cancelled):
            self.assertEqual(exe,'/fixture/codex')
            self.assertIs(node,self.n);self.assertEqual(job['id'],row['id'])
            self.assertIn('Distingue observation, hypothèse',prompt)
            (cwd/'response.json').write_text(json.dumps(ANSWER if value is None else value))
            if requested_cancel: self.n.durable_bytes(cwd/'cancel',b'cancel')
            return {'ok':True}
        requested_cancel=cancel
        with patch.object(adapt,'executable',return_value='/fixture/codex'),patch.object(talk,'run_provider',side_effect=run),patch.object(self.n,'observe_environment',return_value=HEALTHY):
            return talk.worker(self.n,row['id'])

    def test_missing_provider_preserves_message_without_claiming_a_response(self):
        with patch.object(adapt,'executable',return_value=None),patch.object(talk,'launch') as launch:
            row=talk.send(self.n,'Un récit privé',0,'fixture-nonce-001')
            launch.assert_not_called()
        self.assertEqual(row['status'],'blocked')
        self.assertEqual(len(self.n.load_state()['dialogue']['messages']),1)
        self.assertIn('Codex est absent',row['message'])
        self.assertNotIn('dialogue_attempts',self.n.load_state()['metabolism'])

    def test_duplicate_message_is_idempotent_and_concurrent_revision_is_refused(self):
        first=self.queued();again=talk.send(self.n,'Aide-moi à comprendre ce besoin',0,'fixture-nonce-001')
        self.assertEqual(first['id'],again['id'])
        with self.assertRaises(ValueError):talk.send(self.n,'Un autre texte',1,'fixture-nonce-001')
        with self.assertRaises(ValueError):talk.send(self.n,'Un autre texte',0,'fixture-nonce-002')
        with self.assertRaises(ValueError):talk.send(self.n,'Un autre texte',1,'fixture-nonce-002')
        self.assertEqual(len(self.n.load_state()['dialogue']['messages']),1)

    def test_explicit_model_is_validated_carried_to_provider_and_kept_as_context(self):
        with patch.object(adapt,'executable',return_value='/fixture/codex'),patch.object(talk,'launch'):
            row=talk.send(self.n,'Un tour avec choix explicite',0,'fixture-model-001',model='gpt-5.6-sol')
        self.assertEqual(talk.load(self.n,row['id'])['model'],'gpt-5.6-sol')
        self.assertEqual(talk.view(self.n,row['id'])['model'],'gpt-5.6-sol')
        with self.assertRaisesRegex(ValueError,'autre modèle'):
            talk.send(self.n,'Un tour avec choix explicite',0,'fixture-model-001',model='gpt-6-astra')
        with self.assertRaisesRegex(ValueError,'Modèle invalide'):
            talk.model_choice('--dangerously-bypass-approvals-and-sandbox')
        def provider(node,exe,job,cwd,prompt,timeout,cancelled):
            self.assertEqual(job['model'],'gpt-5.6-sol')
            (cwd/'response.json').write_text(json.dumps(ANSWER))
            return {'ok':True}
        with patch.object(adapt,'executable',return_value='/fixture/codex'), \
                patch.object(talk,'run_provider',side_effect=provider), \
                patch.object(self.n,'observe_environment',return_value=HEALTHY):
            result=talk.worker(self.n,row['id'])
        self.assertEqual(result['status'],'answered')
        self.assertEqual(self.n.load_state()['dialogue']['messages'][-1]['model'],'gpt-5.6-sol')

    def test_stream_preview_exposes_only_recognized_assistant_reply_deltas(self):
        path=self.base/'provider.jsonl'
        events=[
            {'method':'error','params':{'message':'diagnostic {"reply":"NE_PAS_MONTRER"}'}},
            {'method':'item/reasoning/delta','params':{'delta':'raison privée'}},
            {'method':'item/agentMessage/delta','params':{'delta':'{"reply":"Bon'}},
            {'method':'item/agentMessage/delta','params':{'delta':'jour\\ncentre'}},
        ]
        path.write_text('\n'.join(json.dumps(event) for event in events)+'\nligne cassée')
        self.assertEqual(talk.stream_preview(path),'Bonjour\ncentre')
        self.assertNotIn('NE_PAS_MONTRER',talk.stream_preview(path))
        completed={'method':'item/completed','params':{'item':{'type':'agentMessage','text':json.dumps(dict(ANSWER,reply='Réponse finale'))}}}
        with path.open('a') as stream:stream.write('\n'+json.dumps(completed))
        self.assertEqual(talk.stream_preview(path),'Réponse finale')

        # Counterexample for the former 256 KiB preview: verbose, ignored
        # protocol events may precede a perfectly valid assistant delta.
        padding=json.dumps({'method':'item/reasoning/delta','params':{'delta':'r'*1000}})+'\n'
        path.write_text(padding*300+json.dumps({
            'method':'item/agentMessage/delta',
            'params':{'delta':'{"reply":"Toujours visible après la trace"}'}}))
        self.assertGreater(path.stat().st_size,262145)
        self.assertEqual(talk.stream_preview(path),'Toujours visible après la trace')

    def test_timeout_keeps_partial_reply_and_reports_the_observed_failure(self):
        row=self.queued('Lis mes tickets sans inventer une exécution')
        def timeout(node,exe,job,cwd,prompt,limit,cancelled):
            event={'method':'item/agentMessage/delta',
                   'params':{'delta':'{"reply":"Début utile avant interruption'}}
            (cwd/'provider.log').write_text(json.dumps(event))
            return {'ok':False,'reason':'timeout','error':None,
                    'duration_seconds':180.12,'output_bytes':550406}
        with patch.object(adapt,'executable',return_value='/fixture/codex'), \
                patch.object(talk,'run_provider',side_effect=timeout), \
                patch.object(self.n,'observe_environment',return_value=HEALTHY):
            result=talk.worker(self.n,row['id'])
        self.assertEqual(result['status'],'blocked')
        self.assertIn('répondait encore après 180 s',result['message'])
        self.assertNotIn('quota',result['message'].lower())
        self.assertEqual(len(self.n.load_state()['dialogue']['messages']),1)
        view=talk.view(self.n,row['id'])
        self.assertEqual(view['partial_text'],'Début utile avant interruption')
        self.assertTrue(view['retryable'])
        self.assertEqual(view['failure_reason'],'timeout')
        self.assertEqual(view['provider_output_bytes'],550406)
        self.assertEqual(view['dialogue_revision'],1)

    def test_legacy_generic_error_is_only_reclassified_from_its_timeout_receipt(self):
        row=self.queued('Une ancienne tentative')
        job=talk.load(self.n,row['id'])
        job.update(status='blocked',message='Codex n’a pas terminé sa réponse. Vérifier sa connexion (codex login), ses quotas et sa version ; le journal reste local.')
        talk.save(self.n,job)
        folder=talk.file(self.n,row['id']).parent
        folder.joinpath('provider.log').write_text(json.dumps({
            'method':'item/agentMessage/delta','params':{'delta':'{"reply":"Ancien brouillon"}'}}))
        state=self.n.load_state();metabolism=ecology.ensure(state)['metabolism']
        metabolism['receipts'].append({'id':'legacy-receipt','experiment':'dialogue:'+row['id'],
            'scope':'dialogue','status':'failed','timeout_seconds':180,'measured_seconds':180.12})
        self.n.atomic_json(self.n.STATE,state,backup=True)

        view=talk.view(self.n,row['id'])
        self.assertEqual(view['failure_reason'],'timeout')
        self.assertIn('limite locale après 180 s',view['message'])
        self.assertNotIn('quota',view['message'].lower())
        self.assertEqual(view['partial_text'],'Ancien brouillon')

        metabolism['receipts'][-1]['measured_seconds']=12
        self.n.atomic_json(self.n.STATE,state,backup=True)
        unknown=talk.view(self.n,row['id'])
        self.assertIsNone(unknown['failure_reason'])
        self.assertIn('quotas',unknown['message'])

    def test_app_server_protocol_streams_then_retains_the_exact_completed_json(self):
        folder=self.base/'provider-run';folder.mkdir()
        fake=self.base/'fake-codex'
        raw=json.dumps(dict(ANSWER,reply='Texte diffusé puis validé.'),ensure_ascii=False)
        fake.write_text('''#!/usr/bin/env python3
import json,sys
raw='''+repr(raw)+'''
for line in sys.stdin:
    message=json.loads(line)
    if message.get('id')==1:
        print(json.dumps({'id':1,'result':{'serverInfo':{'name':'fixture'}}}),flush=True)
    elif message.get('id')==2:
        params=message['params']
        if params.get('sandbox')!='read-only' or params.get('approvalPolicy')!='never' or not params.get('ephemeral'):
            print(json.dumps({'id':2,'error':{'message':'unsafe fixture params'}}),flush=True)
        else:
            print(json.dumps({'id':2,'result':{'thread':{'id':'thread-fixture'}}}),flush=True)
    elif message.get('id')==3:
        for part in (raw[:24],raw[24:]):
            print(json.dumps({'method':'item/agentMessage/delta','params':{'delta':part}}),flush=True)
        print(json.dumps({'method':'item/completed','params':{'item':{'type':'agentMessage','text':raw}}}),flush=True)
        print(json.dumps({'method':'turn/completed','params':{'turn':{'status':'completed','items':[]}}}),flush=True)
''')
        fake.chmod(0o700)
        result=talk.run_provider(self.n,str(fake),{'model':'gpt-5.6-sol'},folder,'prompt fixture',5,lambda:False)
        self.assertTrue(result['ok'],result)
        self.assertEqual(json.loads((folder/'response.json').read_text())['reply'],'Texte diffusé puis validé.')
        self.assertEqual(talk.stream_preview(folder/'provider.log'),'Texte diffusé puis validé.')
        self.assertEqual((folder/'provider.log').stat().st_mode&0o777,0o600)

    def test_response_is_data_until_human_retains_or_prepares_it(self):
        before=self.n.policy();row=self.answer();s=self.n.load_state()
        self.assertEqual(row['status'],'answered');self.assertEqual(s['dialogue']['memory'],'')
        self.assertEqual(s['buffers'],{});self.assertEqual(before,self.n.policy())
        self.assertEqual(s['dialogue']['messages'][-1]['source'],'codex_unverified')
        page=self.n.dashboard(s)
        self.assertNotIn('<script>inert</script>',page);self.assertIn('&lt;script&gt;inert',page)
        talk.remember(self.n,row['reply_id'])
        self.assertEqual(self.n.load_state()['dialogue']['memory'],ANSWER['memory_suggestion'])
        with self.assertRaises(ValueError):talk.prepare(self.n,row['reply_id'])

    def test_invalid_model_output_and_late_cancellation_never_create_authority(self):
        row=self.answer(dict(ANSWER,command='touch forbidden'))
        self.assertEqual(row['status'],'blocked');self.assertEqual(len(self.n.load_state()['dialogue']['messages']),1)
        talk.new_discussion(self.n,1)
        row=self.answer(cancel=True)
        self.assertEqual(row['status'],'cancelled');self.assertEqual(len(self.n.load_state()['dialogue']['messages']),1)
        self.assertEqual(self.n.load_state()['buffers'],{})

    def test_explicit_preparation_creates_one_task_and_changed_memory_stops_apply(self):
        row=self.answer();self.n.atomic_json(self.n.ROOT/'source.json',{'path':str(self.base)})
        with patch.object(adapt,'executable',return_value='/fixture/codex'),patch.object(adapt,'launch') as launch:
            result=talk.prepare(self.n,row['reply_id']);again=talk.prepare(self.n,row['reply_id'])
            self.assertTrue(result['prepared']);self.assertEqual(result['task_id'],again['task_id']);launch.assert_called_once()
        s=self.n.load_state();b=s['buffers'][result['task_id']]
        self.assertFalse(b['work_task']['execution_enabled']);self.assertEqual(b['status'],'open')
        job=adapt.load(self.n,result['adaptation_id']);adapt.check_context(self.n,job)
        self.n.set_story('Une autre direction')
        with self.assertRaises(ValueError):adapt.check_context(self.n,job)
        job['dialogue_story_digest']=self.n.digest_bytes(self.n.json_bytes(self.n.story()))
        talk.save_memory(self.n,'Une nouvelle contrainte',s['dialogue']['revision'])
        with self.assertRaises(ValueError):adapt.check_context(self.n,job)
        with self.assertRaises(ValueError):talk.new_discussion(self.n,self.n.load_state()['dialogue']['revision'])

    def test_changed_story_or_work_preferences_invalidate_proposal(self):
        row=self.answer();self.n.set_story('Nouvelle histoire')
        with self.assertRaises(ValueError):talk.reply(self.n,self.n.load_state(),row['reply_id'])
        s=self.n.load_state();m=s['dialogue']['messages'][-1];m['signature']=talk.signature(self.n,s)
        self.n.atomic_json(self.n.STATE,s,backup=True)
        self.n.work.save_context(self.n,'Nouvelles contraintes')
        with self.assertRaises(ValueError):talk.prepare(self.n,row['reply_id'])

    def test_memory_revision_archive_integrity_and_no_automatic_resending(self):
        talk.save_memory(self.n,'À garder',0)
        with self.assertRaises(ValueError):talk.save_memory(self.n,'Écrasement périmé',0)
        self.answer();prior=copy.deepcopy(self.n.load_state()['dialogue'])
        row=talk.new_discussion(self.n,prior['revision']);s=self.n.load_state()
        self.assertEqual(s['dialogue']['messages'],[]);self.assertEqual(s['dialogue']['memory'],'À garder')
        archive=talk.read_archive(self.n,row['archive_id']);self.assertEqual(archive['dialogue']['messages'],prior['messages'])
        self.assertIn(ANSWER['reply'],talk.export(archive));self.assertNotIn(ANSWER['reply'],json.dumps(talk.snapshot(self.n,s),ensure_ascii=False))
        p=talk.archive_file(self.n,row['archive_id']);self.assertEqual(p.stat().st_mode&0o777,0o600)
        changed=json.loads(p.read_text());changed['dialogue']['memory']='tampered';p.write_text(json.dumps(changed))
        with self.assertRaises(ValueError):talk.read_archive(self.n,row['archive_id'])
        with self.assertRaises(ValueError):talk.read_archive(self.n,'../../policy')

    def test_context_is_bounded_and_counts_omissions_without_erasing_history(self):
        s=self.n.load_state();d=talk.ensure(s);d['memory']='Contrainte à garder'
        d['messages']=[{'id':str(i),'role':'user','text':str(i)+'é'*5990,'at':self.n.now()} for i in range(35)]
        payload=talk.snapshot(self.n,s)
        self.assertLessEqual(len(self.n.json_bytes(payload)),talk.MAX_CONTEXT)
        self.assertEqual(payload['omitted_messages']+len(payload['messages']),35)
        self.assertEqual(payload['messages'][-1]['id'],'34');self.assertEqual(len(d['messages']),35)
        self.assertEqual(payload['memory_selected_by_user'],'Contrainte à garder')
        self.assertIn('aucun accès',payload['capabilities']['past_chatgpt_conversations'])

    def test_zero_dialogue_budget_prevents_invocation_and_baseline_never_asks_ai(self):
        row=self.queued();self.n.atomic_json(self.n.POLICY,{'dialogue_runs_per_day':0})
        with patch.object(adapt,'executable',return_value='/fixture/codex'),patch.object(talk,'run_provider') as run,patch.object(self.n,'observe_environment',return_value=HEALTHY):
            result=talk.worker(self.n,row['id']);self.n.cycle();run.assert_not_called()
        self.assertEqual(result['status'],'blocked');self.assertIn('daily_attempts_exhausted',result['message'])
        self.assertEqual(len(self.n.load_state()['dialogue']['messages']),1)

    def test_dialogue_and_adaptation_budgets_settle_independently(self):
        with patch.object(self.n,'observe_environment',return_value=HEALTHY):
            a=ecology.reserve(self.n,'code');d=ecology.reserve(self.n,'chat','dialogue')
        self.assertEqual(d['timeout_seconds'],180);self.assertEqual(a['timeout_seconds'],600)
        ecology.settle(self.n,d['id'],2,True)
        s=self.n.load_state();m=s['metabolism']
        self.assertEqual(m['dialogue_daily_budget']['charged_seconds'],2)
        self.assertEqual(m['daily_budget']['charged_seconds'],607)
        # Old receipts have no scope and must still settle as adaptation.
        m['receipts'][0].pop('scope');self.n.atomic_json(self.n.STATE,s,backup=True)
        ecology.settle(self.n,a['id'],3,False)
        self.assertEqual(self.n.load_state()['metabolism']['daily_budget']['charged_seconds'],3)
        with self.assertRaises(ValueError):ecology.settle(self.n,d['id'],0,True)

    def test_retention_limits_preserve_data_and_archive_requires_idle_worker(self):
        row=self.queued();before=self.n.STATE.read_bytes()
        with self.assertRaises(ValueError):talk.new_discussion(self.n,1)
        self.assertEqual(before,self.n.STATE.read_bytes())
        job=talk.load(self.n,row['id']);job['status']='blocked';talk.save(self.n,job)
        s=self.n.load_state();d=s['dialogue'];d['messages']*=400
        self.n.atomic_json(self.n.STATE,s,backup=True);before=self.n.STATE.read_bytes()
        with self.assertRaises(ValueError):talk.send(self.n,'Suite',1,'fixture-nonce-002')
        self.assertEqual(before,self.n.STATE.read_bytes())
        talk.new_discussion(self.n,1)
        self.assertEqual(len(talk.read_archive(self.n,self.n.load_state()['dialogue']['archives'][0]['id'])['dialogue']['messages']),400)

    def test_child_never_inherits_dialogue_or_its_private_budget(self):
        talk.save_memory(self.n,'PRIVATE_DIALOGUE_MEMORY',0);self.answer()
        with patch.object(self.n,'observe_environment',return_value=HEALTHY):
            ecology.birth(self.n,self.base/'child','Un projet fictif',8791)
        child=self.base/'child';self.assertNotIn('dialogue',json.loads((child/'state.json').read_text()))
        self.assertFalse((child/'dialogue').exists());self.assertFalse((child/'dialogue-archives').exists())
        self.assertNotIn('dialogue_attempts',json.loads((child/'state.json').read_text())['metabolism'])
        self.assertTrue((child/'runtime/tao_dialogue.py').is_file())

    def test_recall_finds_old_passages_and_archives_require_explicit_choice(self):
        s=self.n.load_state();d=talk.ensure(s)
        d['messages']=[{'id':'old','role':'user','text':'Le projet potager utilise un arrosage manuel.','at':self.n.now()}]
        d['messages'] += [{'id':str(i),'role':'user','text':'Un autre sujet', 'at':self.n.now()} for i in range(24)]
        d['messages'].append({'id':'now','role':'user','text':'Reprenons le potager et son arrosage', 'at':self.n.now()})
        self.n.atomic_json(self.n.STATE,s,backup=True)
        recalled=talk.snapshot(self.n,s)['recall']['passages']
        self.assertEqual(len(recalled),1);self.assertEqual(recalled[0]['message_id'],'old')
        self.assertEqual(recalled[0]['authority'],'historical_context_only')
        archived=talk.new_discussion(self.n,0)
        s=self.n.load_state();d=s['dialogue'];d['messages']=[{'id':'later','role':'user','text':'Quel arrosage au potager ?', 'at':self.n.now()}]
        self.n.atomic_json(self.n.STATE,s,backup=True)
        self.assertEqual(talk.snapshot(self.n,s)['recall']['passages'],[])
        talk.save_memory(self.n,'',1,True)
        payload=talk.snapshot(self.n,self.n.load_state())
        self.assertTrue(payload['archives_enabled']);self.assertTrue(payload['recall']['passages'])
        self.assertTrue(all(x['source']=='archive:'+archived['archive_id'] for x in payload['recall']['passages']))
        talk.save_memory(self.n,'',2,False)
        self.assertEqual(talk.snapshot(self.n,self.n.load_state())['recall']['passages'],[])

    def test_map_is_attributed_bounded_and_never_becomes_the_users_objective(self):
        row=self.answer();s=self.n.load_state();m=s['dialogue']['messages'][-1]
        self.assertEqual(m['situation_map'],ANSWER['situation_map'])
        self.assertNotIn('work_context',s)
        page=self.n.dashboard(s);self.assertIn('Notre vue de la situation',page)
        self.assertNotIn('<script>inert</script>',page)
        prior=talk.snapshot(self.n,s)['previous_map'];self.assertEqual(prior['status'],'ai_hypothesis')
        malformed=copy.deepcopy(ANSWER);malformed['situation_map']['objectives']=['Objectif']*4
        with self.assertRaises(ValueError):talk.validated_reply(json.dumps(malformed))
        malformed['situation_map']['objectives']=[{'command':'run'}]
        with self.assertRaises(ValueError):talk.validated_reply(json.dumps(malformed))
