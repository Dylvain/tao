"""Hosted links and explicit, bounded memory handoff from a phone browser."""
import os
import shutil
import subprocess
from unittest.mock import patch

from test_node import NodeHarness
from test_mobile_ui import Page
import tao_adaptation as adaptation
import tao_ui as ui
import tao_worlds as worlds


class HostedUITests(NodeHarness):
    def page(self,flag='1',codex=True):
        with patch.dict(os.environ,{'TAO_HOSTED':flag}),patch.object(adaptation,'diagnose',return_value={'ready':False,'codex_detected':codex,'blockers':[]}):
            return self.n.dashboard(self.n.load_state())

    def run_js(self,source,syntax=False):
        node=os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node:self.skipTest('Node optional: browser behavior check')
        path=self.base/'hosted-ui.js';path.write_text(source)
        result=subprocess.run([node,*(['--check'] if syntax else []),str(path)],capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_hosted_page_offers_browser_connection_without_claiming_authentication(self):
        for codex in (True,False):
            page=self.page(codex=codex);parsed=Page(page)
            self.assertIn('href="/host/ai"',page);self.assertIn('href="/host/account"',page)
            self.assertNotIn('href="/host/logout',page)
            self.assertIn('La présence de Codex ne confirme pas la connexion de ton compte',page)
            self.assertIn('indépendante de ton PC',page)
            self.assertIn('fichiers et moyens du serveur',page)
            self.assertIn('installations séparées ne sont pas synchronisées',page)
            self.assertNotIn('dans ton terminal',page)
            self.assertEqual(len(parsed.ids),len(set(parsed.ids)))
            self.assertTrue(all(not form['attributes'].get('action','').startswith('/host/') for form in parsed.forms))

    def test_local_mode_stays_local_unless_flag_is_exactly_one(self):
        for flag in ('','0','true'):
            page=self.page(flag=flag)
            self.assertNotIn('href="/host/',page)
            self.assertIn('Tao sur Linux',page)
            self.assertIn('Cet ordinateur doit rester accessible',page)
            self.assertIn('Codex doit être installé sur cet hôte',page)
            self.assertIn('href="/connect?world=main"',page)

    def test_expired_hosted_session_uses_fixed_login_and_preserves_drafts(self):
        page=self.page();script=page.split('<script>')[-1].split('</script>')[0]
        self.run_js(script,syntax=True)
        login=script.split('function loginRequired',1)[1].split('function retryNotice',1)[0]
        self.run_js("const assert=require('assert');let preserved=0;const target={appendChild:link=>assert.equal(link.href,'/host/login')};const keepAllDrafts=()=>preserved++;const message=()=>target;const document={createElement:()=>({})};function loginRequired"+login+";loginRequired({login_url:'https://attacker.invalid/'});assert.equal(preserved,1);")

    def test_handoff_export_is_world_scoped_while_host_account_is_global(self):
        child=worlds.create(self.n,'Travail',revision=0)
        with worlds.using(child['id']):
            page=self.page()
        self.assertIn('href="/dialogue/handoff?world='+child['id']+'"',page)
        self.assertIn('href="/host/account"',page)
        self.assertNotIn('/host/account?world=',page)
        parsed=Page(page);form=next(f for f in parsed.forms if f['attributes'].get('id')=='dialogue-handoff')
        field=next(attrs for _,attrs in form['fields'] if attrs.get('id')=='handoff-file')
        self.assertEqual(field['type'],'file');self.assertEqual(field['accept'],'.json,application/json')
        self.assertIn('sans remplacer la mémoire déjà présente',page)
        self.assertIn('mémoire déjà enregistré',page)

    def test_file_validation_is_bounded_and_does_not_modify_the_document(self):
        self.run_js(ui.HANDOFF_JS+r'''
const assert=require('assert');
(async()=>{
const original={schema:'tao.handoff.v1',text:'Choisi par moi',source:{world_id:'main'}};
const text=JSON.stringify(original),file={size:new TextEncoder().encode(text).byteLength,text:async()=>text};
assert.deepEqual(await handoffDocument(file,4),{document:original,revision:4});
for(const invalid of [undefined,{size:262145,text:async()=>text},{size:1,text:async()=>'{broken'},{size:2,text:async()=>'[]'}])await assert.rejects(()=>handoffDocument(invalid,4));
const escaped=JSON.stringify({text:'\u0000'.repeat(60000)});
await assert.rejects(()=>handoffDocument({size:100,text:async()=>escaped},4));
assert.equal(await file.text(),text);
})().catch(error=>{console.error(error);process.exitCode=1});
''')

    def test_invalid_file_never_sends_or_clears_selection(self):
        script=self.page().split('<script>')[-1].split('</script>')[0]
        handler=script.split("const handoffForm=document.querySelector('#dialogue-handoff');",1)[1].split("const newDialogue=",1)[0]
        self.run_js(ui.HANDOFF_JS+r'''
const assert=require('assert');let calls=[],currentSubmission=null,notice='';
const selected={size:2,text:async()=>'{broken'},input={files:[selected]},button={disabled:false};
const handoffForm={dataset:{revision:'9'},querySelector:()=>button};
const document={querySelector:()=>input},send=async(path,data)=>calls.push({path,data}),message=text=>notice=text;
'''+handler+r'''
(async()=>{
assert.equal(calls.length,0);await handoffForm.onsubmit({preventDefault:()=>{}});
assert.equal(calls.length,0);assert.equal(input.files[0],selected);assert.equal(button.disabled,false);assert(notice.includes('Aucun import envoyé'));
selected.text=async()=>JSON.stringify({schema:'tao.handoff.v1',text:'Mémoire'});
await handoffForm.onsubmit({preventDefault:()=>{}});assert.equal(calls.length,1);assert.equal(calls[0].path,'/api/dialogue/handoff');assert.equal(calls[0].data.revision,9);assert.equal(currentSubmission,handoffForm);assert.equal(input.files[0],selected);
})().catch(error=>{console.error(error);process.exitCode=1});
''')
