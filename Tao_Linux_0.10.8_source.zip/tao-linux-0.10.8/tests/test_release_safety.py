"""Release regressions: only reviewed source bytes may leave the private tree."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import zipfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('release_safety_builder', ROOT / 'scripts/build_release.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)


class ReleaseSafetyTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.root = self.base / 'source'
        self.root.mkdir()
        self.allowlist = json.loads((ROOT / builder.ALLOWLIST).read_bytes())
        for name in self.allowlist['files']:
            destination = self.root / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / name, destination)
        # The safety fixtures remain independent of an in-progress version bump.
        version = json.loads((self.root / 'VERSION.json').read_bytes())
        version['node_version'] = version['genesis_version'] = builder.VERSION
        (self.root / 'VERSION.json').write_text(json.dumps(version))
        self.patch = mock.patch.object(builder, 'ROOT', self.root)
        self.patch.start()
        self.addCleanup(self.patch.stop)

    def build(self, **kwargs):
        with contextlib.redirect_stdout(io.StringIO()):
            return builder.build(**kwargs)

    def write_allowlist(self, files):
        value = dict(self.allowlist, files=files)
        (self.root / builder.ALLOWLIST).write_text(json.dumps(value))

    def output_bytes(self):
        dist = self.root / 'dist'
        names = [f'TAO_LINUX_{builder.VERSION}.run', f'Tao_Linux_{builder.VERSION}_source.zip',
                 'SHA256SUMS', 'release.json']
        return {name: (dist / name).read_bytes() for name in names}

    def test_unlisted_top_level_and_nested_secrets_are_never_opened_or_archived(self):
        marker = b'PRIVATE_FIXTURE_' + os.urandom(24).hex().encode('ascii')
        secret_names = ['.env', 'docs/private-fixture.json', 'bootstrap/private-broken.py',
                        'reuse/main.json', 'bridge/main/state-v1.json', 'connectors/main.json']
        for name in secret_names:
            (self.root / name).parent.mkdir(parents=True, exist_ok=True)
            (self.root / name).write_bytes(marker)
        (self.root / 'docs/private-link').symlink_to(self.base / 'outside-secret')
        (self.base / 'outside-secret').write_bytes(marker)
        self.assertFalse((self.root / '.git').exists())
        actual_open = os.open
        actual_read_bytes = Path.read_bytes

        def guarded_open(path, *args, **kwargs):
            if os.fsdecode(path).split('/')[-1] in {Path(name).name for name in secret_names}:
                self.fail('Builder opened an unlisted private file')
            return actual_open(path, *args, **kwargs)

        def guarded_read_bytes(path):
            if str(path.relative_to(self.root)) in secret_names:
                self.fail('Builder read an unlisted private file')
            return actual_read_bytes(path)

        with mock.patch.object(os, 'open', side_effect=guarded_open), mock.patch.object(Path, 'read_bytes', guarded_read_bytes):
            manifest = self.build()
        archive = self.root / 'dist' / f'Tao_Linux_{builder.VERSION}_source.zip'
        with zipfile.ZipFile(archive) as zipped:
            prefix = f'tao-linux-{builder.VERSION}/'
            self.assertEqual(set(zipped.namelist()), {prefix + name for name in self.allowlist['files']})
            for name in zipped.namelist():
                self.assertNotIn(marker, zipped.read(name))
        self.assertEqual(set(manifest), {'schema', 'version', 'update', 'files'})
        self.assertEqual(manifest['schema'], 'tao.release.v2')
        self.assertEqual(manifest['update']['state_migrations'], [])
        self.assertEqual(manifest['update']['install_mode'], 'explicit')

    def test_extracted_sources_without_git_rebuild_identically(self):
        first = self.build()
        data = self.output_bytes()
        extracted = self.base / 'extracted'
        with zipfile.ZipFile(self.root / 'dist' / f'Tao_Linux_{builder.VERSION}_source.zip') as archive:
            archive.extractall(extracted)
        root = extracted / f'tao-linux-{builder.VERSION}'
        self.assertFalse((root / '.git').exists())
        result = subprocess.run([sys.executable, str(root / 'scripts/build_release.py')],
                                cwd=root, capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), first)
        for name, content in data.items():
            self.assertEqual((root / 'dist' / name).read_bytes(), content)

    def test_missing_file_preserves_complete_previous_release(self):
        self.build()
        before = self.output_bytes()
        (self.root / 'README.md').unlink()
        with self.assertRaisesRegex(ValueError, 'Source absente'):
            self.build()
        self.assertEqual(self.output_bytes(), before)

    def test_all_paths_checked_before_source_contents_are_read(self):
        (self.root / 'README.md').unlink()
        with mock.patch.object(builder, '_read_source', wraps=builder._read_source) as read:
            with self.assertRaises(ValueError):
                self.build()
        self.assertEqual([call.args[2] for call in read.call_args_list], [builder.ALLOWLIST])
        self.assertFalse((self.root / 'dist').exists())

    def test_symlink_file_parent_or_source_root_is_refused(self):
        original = self.root / 'README.md'
        outside = self.base / 'readme'
        original.rename(outside)
        original.symlink_to(outside)
        with self.assertRaises(ValueError):
            self.build()
        original.unlink()
        outside.rename(original)
        parent = self.root / 'bootstrap'
        outside = self.base / 'bootstrap'
        parent.rename(outside)
        parent.symlink_to(outside, target_is_directory=True)
        with self.assertRaises(ValueError):
            self.build()
        parent.unlink()
        outside.rename(parent)
        root_link = self.base / 'source-link'
        root_link.symlink_to(self.root, target_is_directory=True)
        with mock.patch.object(builder, 'ROOT', root_link), self.assertRaises(ValueError):
            self.build()
        self.assertFalse((self.root / 'dist').exists())

    def test_nonregular_source_is_refused_without_blocking(self):
        (self.root / 'README.md').unlink()
        os.mkfifo(self.root / 'README.md')
        with self.assertRaisesRegex(ValueError, 'Fichier régulier'):
            self.build()
        self.assertFalse((self.root / 'dist').exists())

    def test_invalid_duplicate_absolute_traversal_and_glob_paths_are_refused(self):
        for name in ['README.md', '/tmp/secret', '../secret', 'docs/../secret',
                     'docs//secret', './README.md', 'C:\\secret', 'docs/*.md',
                     'docs/?', 'docs/[x]', 'docs/secret\n']:
            with self.subTest(name=name):
                self.write_allowlist(self.allowlist['files'] + [name])
                with self.assertRaises(ValueError):
                    self.build()
                self.assertFalse((self.root / 'dist').exists())
        self.write_allowlist([name for name in self.allowlist['files'] if name != builder.ALLOWLIST])
        with self.assertRaises(ValueError):
            self.build()

    def test_duplicate_json_keys_are_refused(self):
        (self.root / builder.ALLOWLIST).write_text('{"schema_version":1,"files":[],"files":[]}')
        with self.assertRaisesRegex(ValueError, 'dupliquée'):
            self.build()

    def test_oversized_or_invalid_python_file_preserves_previous_release(self):
        self.build()
        before = self.output_bytes()
        with mock.patch.object(builder, 'MAX_FILE_BYTES', 10), self.assertRaises(ValueError):
            self.build()
        self.assertEqual(self.output_bytes(), before)
        with mock.patch.object(builder, 'MAX_TOTAL_BYTES', 10), self.assertRaises(ValueError):
            self.build()
        self.assertEqual(self.output_bytes(), before)
        (self.root / 'bootstrap/tao_node.py').write_text('this is not valid Python !!!')
        with self.assertRaises(SyntaxError):
            self.build()
        self.assertEqual(self.output_bytes(), before)

    def test_symlink_output_directory_and_file_are_refused(self):
        outside = self.base / 'outside-dist'
        outside.mkdir()
        (self.root / 'dist').symlink_to(outside, target_is_directory=True)
        with self.assertRaises(OSError):
            self.build()
        self.assertEqual(list(outside.iterdir()), [])
        (self.root / 'dist').unlink()
        self.build()
        target = self.root / 'dist/release.json'
        target.unlink()
        victim = self.base / 'victim'
        victim.write_bytes(b'preserved')
        target.symlink_to(victim)
        with self.assertRaisesRegex(ValueError, 'Destination non régulière'):
            self.build()
        self.assertEqual(victim.read_bytes(), b'preserved')

    @unittest.skipUnless(shutil.which('git'), 'Git not installed')
    def test_strict_git_rejects_changed_staged_and_untracked_sources(self):
        def git(*args):
            return subprocess.run(['git', '-C', str(self.root), *args], check=True,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        git('init', '-q')
        git('add', '--', *self.allowlist['files'])
        git('-c', 'user.name=Release Fixture', '-c', 'user.email=fixture@example.invalid',
            '-c', 'commit.gpgsign=false', 'commit', '-qm', 'Reviewed fixture')
        self.build(strict_git=True)
        before = self.output_bytes()
        validator = self.root / 'bootstrap/tao_theory.py'
        validator_bytes = validator.read_bytes()
        marker = self.base / 'unexpected-validator-execution'
        validator.write_bytes(validator_bytes + ('\nPath(' + repr(str(marker)) + ').touch()\n').encode('utf-8'))
        with self.assertRaisesRegex(ValueError, 'différente de HEAD'):
            self.build(strict_git=True)
        self.assertFalse(marker.exists())
        validator.write_bytes(validator_bytes)
        readme = self.root / 'README.md'
        original = readme.read_bytes()
        readme.write_bytes(original + b'\nchanged')
        with self.assertRaisesRegex(ValueError, 'différente de HEAD'):
            self.build(strict_git=True)
        git('add', 'README.md')
        readme.write_bytes(original)
        with self.assertRaisesRegex(ValueError, 'différente de HEAD'):
            self.build(strict_git=True)
        git('reset', '-q', 'HEAD', '--', 'README.md')
        git('rm', '--cached', 'README.md')
        with self.assertRaisesRegex(ValueError, 'non suivie'):
            self.build(strict_git=True)
        self.assertEqual(self.output_bytes(), before)

    def test_strict_git_requires_repository_but_default_build_does_not(self):
        self.assertFalse((self.root / '.git').exists())
        with self.assertRaises(ValueError):
            self.build(strict_git=True)
        self.assertFalse((self.root / 'dist').exists())
        self.build()


if __name__ == '__main__':
    unittest.main()
