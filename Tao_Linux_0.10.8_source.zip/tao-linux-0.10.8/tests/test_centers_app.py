"""The modern shell is a read-only projection over existing center contracts."""
import json
import re
from unittest.mock import patch

from test_node import NodeHarness
from test_centers import definition
import tao_centers as centers
import tao_centers_app as app
import tao_dialogue as dialogue
import tao_adaptation as adaptation


class CenterAppTests(NodeHarness):
    def test_empty_shell_is_inert_free_and_has_no_center_limit(self):
        before = self.n.STATE.read_bytes()
        with patch.object(dialogue, 'launch') as launch:
            value = app.presentation(self.n, self.n.load_state(), 'fr')
            page = app.render(self.n, self.n.load_state(), 'fr')
        launch.assert_not_called()
        self.assertEqual(self.n.STATE.read_bytes(), before)
        self.assertEqual(value['schema'], 'tao.center.interface.v1')
        self.assertEqual(value['focus']['kind'], 'center_factory')
        self.assertEqual(value['centers'], [])
        self.assertEqual(value['product'], {'billingEnabled': False, 'centerLimit': None})
        self.assertIn('/assets/tao-center.css', page)
        self.assertIn('/assets/tao-center.js', page)
        self.assertIn('rel="manifest" href="/app.webmanifest" crossorigin="use-credentials"', page)
        self.assertIn('/assets/tao-icon-192.png', page)
        self.assertNotIn('checkout', page.lower())
        self.assertNotIn('subscribe', page.lower())

    def test_only_the_selected_center_thread_is_embedded_and_html_is_inert(self):
        first = centers.create(self.n, definition('Premier'), revision=0)
        second = centers.create(self.n, definition('Second'),
                                revision=centers.view(self.n)['revision'])
        state = self.n.load_state(); thread = dialogue.ensure(state)
        thread['messages'] = [
            {'id': 'human-a', 'role': 'user', 'text': '</script><b>entrée A</b>',
             'job_id': 'aaaaaaaaaaaa',
             'focus': {'kind': 'center', 'id': first['id'], 'revision': first['revision']}},
            {'id': 'reply:aaaaaaaaaaaa', 'role': 'assistant', 'text': 'sortie A',
             'job_id': 'aaaaaaaaaaaa'},
            {'id': 'human-b', 'role': 'user', 'text': 'entrée B',
             'job_id': 'bbbbbbbbbbbb',
             'focus': {'kind': 'center', 'id': second['id'], 'revision': second['revision']}},
        ]
        page = app.render(self.n, state, 'fr', first['id'])
        raw = re.search(r'<script id="tao-bootstrap" type="application/json">(.*?)</script>',
                        page, re.S).group(1)
        payload = json.loads(raw)
        self.assertEqual([row['text'] for row in payload['messages']],
                         ['</script><b>entrée A</b>', 'sortie A'])
        self.assertNotIn('</script><b>', raw)
        self.assertNotIn('entrée B', raw)
        self.assertEqual(payload['selectedCenterId'], first['id'])

    def test_unknown_center_and_locale_fail_closed(self):
        with self.assertRaisesRegex(ValueError, 'existe pas'):
            app.presentation(self.n, self.n.load_state(), 'fr', 'aaaaaaaaaaaa')
        with self.assertRaisesRegex(ValueError, 'Langue'):
            app.presentation(self.n, self.n.load_state(), 'de')

    def test_blocked_latest_center_reply_is_restored_for_explicit_retry(self):
        center = centers.create(self.n, definition('Travail'), revision=0)
        focus = {'kind': 'center', 'id': center['id'], 'revision': center['revision']}
        with patch.object(adaptation, 'executable', return_value='/fixture/codex'), \
                patch.object(dialogue, 'launch'):
            row = dialogue.send(self.n, 'Une entrée', 0, 'center-job-fixture', focus=focus)
        job = dialogue.load(self.n, row['id'])
        job.update(status='blocked', message='Codex répondait encore après 180 s.',
                   failure_reason='timeout')
        dialogue.save(self.n, job)
        folder = dialogue.file(self.n, row['id']).parent
        folder.joinpath('provider.log').write_text(json.dumps({
            'method': 'item/agentMessage/delta',
            'params': {'delta': '{"reply":"Brouillon conservé"}'},
        }))

        value = app.presentation(self.n, self.n.load_state(), 'fr', center['id'])
        self.assertEqual(value['initialJob']['id'], row['id'])
        self.assertEqual(value['initialJob']['status'], 'blocked')
        self.assertEqual(value['initialJob']['partial_text'], 'Brouillon conservé')
        self.assertTrue(value['initialJob']['retryable'])


if __name__ == '__main__':
    import unittest
    unittest.main()
