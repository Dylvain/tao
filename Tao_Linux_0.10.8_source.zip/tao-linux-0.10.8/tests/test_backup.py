"""Portable core backups preserve failed cases and require exact owner review."""
import copy
import json
from unittest.mock import patch

from test_node import NodeHarness
import tao_backup as backup
import tao_worlds as worlds


class BackupTests(NodeHarness):
    def test_export_is_inert_bounded_and_states_its_incomplete_scope(self):
        before = self.n.STATE.read_bytes()
        result = backup.export(self.n)
        self.assertEqual(self.n.STATE.read_bytes(), before)
        bundle = result['bundle']
        self.assertEqual(bundle['schema'], backup.SCHEMA)
        self.assertEqual(bundle['scope']['included'], ['state.json'])
        self.assertIn('dialogue and imported-history archive files', bundle['scope']['excluded'])
        self.assertNotIn('_integrity', bundle['state'])
        preview = backup.inspect(self.n, bundle)
        self.assertEqual(preview['review_digest'], backup._digest(bundle))
        self.assertEqual(preview['summary']['spaces'], len(bundle['state']['worlds']['spaces']))
        self.assertTrue(result['filename'].endswith('.tao-backup'))

    def test_restore_and_immediate_rollback_keep_both_exact_states(self):
        old = backup.export(self.n)['bundle']
        added = self.n.add_buffer('Résidu après la copie', 'Le conserver', 'Le retrouver après retour')
        changed_bytes = self.n.STATE.read_bytes()
        preview = backup.inspect(self.n, old)
        restored = backup.restore(self.n, old, preview['review_digest'],
                                  preview['expected_current_digest'], confirmed=True)
        self.assertNotIn(added['id'], self.n.load_raw_state()['buffers'])
        self.assertTrue((self.root / 'portable-restore.prev.json').is_file())
        rolled = backup.rollback(self.n, restored['after_digest'], confirmed=True)
        self.assertTrue(rolled['rolled_back'])
        self.assertIn(added['id'], self.n.load_raw_state()['buffers'])
        # JSON is reserialized with a fresh integrity field, but the verified
        # state retained before restoration is exactly the changed state.
        previous = self.n.checked_state(self.root / 'state.prev.json')
        self.assertEqual(changed_bytes, self.n.STATE.read_bytes())
        self.assertNotIn(added['id'], previous['buffers'])

    def test_bad_review_stale_state_and_invalid_bundle_never_replace_current(self):
        bundle = backup.export(self.n)['bundle']
        original = self.n.STATE.read_bytes()
        preview = backup.inspect(self.n, bundle)
        with self.assertRaisesRegex(ValueError, 'changé depuis sa relecture'):
            backup.restore(self.n, bundle, '0' * 64,
                           preview['expected_current_digest'], confirmed=True)
        self.assertEqual(self.n.STATE.read_bytes(), original)

        self.n.add_buffer('Nouveau', 'Conserver', 'Toujours présent')
        changed = self.n.STATE.read_bytes()
        with self.assertRaisesRegex(ValueError, 'Tao a changé'):
            backup.restore(self.n, bundle, preview['review_digest'],
                           preview['expected_current_digest'], confirmed=True)
        self.assertEqual(self.n.STATE.read_bytes(), changed)

        forged = copy.deepcopy(bundle)
        forged['state']['_world_view'] = 'main'
        forged['state_sha256'] = backup._digest(forged['state'])
        with self.assertRaisesRegex(ValueError, 'projection'):
            backup.inspect(self.n, forged)
        self.assertEqual(self.n.STATE.read_bytes(), changed)

    def test_rollback_refuses_later_changes_and_preserves_previous_copy(self):
        bundle = backup.export(self.n)['bundle']
        self.n.add_buffer('Différence courante', 'La garder', 'Présente')
        preview = backup.inspect(self.n, bundle)
        result = backup.restore(self.n, bundle, preview['review_digest'],
                                preview['expected_current_digest'], confirmed=True)
        previous = (self.root / 'portable-restore.prev.json').read_bytes()
        self.n.add_buffer('Après restauration', 'La garder aussi', 'Présente')
        current = self.n.STATE.read_bytes()
        with self.assertRaisesRegex(ValueError, 'a changé depuis la restauration'):
            backup.rollback(self.n, result['after_digest'], confirmed=True)
        self.assertEqual(self.n.STATE.read_bytes(), current)
        self.assertEqual((self.root / 'portable-restore.prev.json').read_bytes(), previous)

    def test_restore_is_main_only_and_refuses_running_ai(self):
        bundle = backup.export(self.n)['bundle']
        child = next(key for key in self.n.load_raw_state()['worlds']['spaces'] if key != 'main')
        with worlds.using(child), self.assertRaisesRegex(ValueError, 'centre principal'):
            backup.inspect(self.n, bundle)
        preview = backup.inspect(self.n, bundle)
        before = self.n.STATE.read_bytes()
        with patch('tao_dialogue.active', return_value={'status': 'running'}), \
                self.assertRaisesRegex(ValueError, 'réponse IA'):
            backup.restore(self.n, bundle, preview['review_digest'],
                           preview['expected_current_digest'], confirmed=True)
        self.assertEqual(self.n.STATE.read_bytes(), before)

    def test_strict_request_parser_rejects_duplicates_nonfinite_and_depth(self):
        for raw in (b'{"bundle":{},"bundle":{}}', b'{"value":NaN}',
                    json.dumps({'x': [[[[[[[[[[1]]]]]]]]]]}).encode()):
            with self.subTest(raw=raw[:30]):
                if b'[[[' in raw:
                    with patch.object(backup, 'MAX_JSON_DEPTH', 4), self.assertRaises(ValueError):
                        backup.request_json(raw)
                else:
                    with self.assertRaises(ValueError): backup.request_json(raw)


if __name__ == '__main__':
    import unittest
    unittest.main()
