import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from gaia import catalogue


class GaiaCatalogueTests(unittest.TestCase):
    def setUp(self):
        self.data = catalogue.load()

    def test_seed_guides_are_attributed_manual_guidance_not_success_claims(self):
        self.assertEqual({row["id"] for row in self.data["entries"]}, {
            "clarify-need", "connect-capabilities", "integrate-reviewed-experiment",
        })
        self.assertEqual({row["category"] for row in self.data["entries"]}, catalogue.CATEGORIES)
        for row in self.data["entries"]:
            self.assertEqual(row["status"], "curated_initial_guidance")
            self.assertIs(row["executable"], False)
            self.assertEqual(row["origin"]["kind"], "local_maintainer")
            self.assertEqual(row["permissions"], {"read": "none", "execution": "not_granted"})
            self.assertTrue(row["expected_evidence"])
            self.assertTrue(row["counterexample"])
        self.assertEqual(catalogue.validate(self.data), self.data)

    def test_export_contains_only_selected_public_guide_without_private_context(self):
        with tempfile.TemporaryDirectory() as directory:
            private = Path(directory) / "private.json"
            private.write_text('{"memory":"PRIVATE-CONTEXT-SENTINEL"}', encoding="utf-8")
            with patch.dict("os.environ", {"TAO_ROOT": directory, "HOME": directory}):
                raw = catalogue.export_entry("clarify-need")
        exported = json.loads(raw)
        self.assertEqual(set(exported), {"schema_version", "catalogue_id", "catalogue_version", "entry"})
        self.assertEqual(exported["entry"], catalogue.entry("clarify-need"))
        self.assertNotIn(b"PRIVATE-CONTEXT-SENTINEL", raw)
        self.assertNotIn(b"connect-capabilities", raw)
        self.assertNotIn(b"integrate-reviewed-experiment", raw)
        contaminated = copy.deepcopy(self.data)
        contaminated["private_context"] = "PRIVATE-CONTEXT-SENTINEL"
        with self.assertRaises(ValueError):
            catalogue.export_entry("clarify-need", contaminated)

    def test_reads_and_exports_do_not_mutate_the_source_or_other_reads(self):
        path = Path(catalogue.__file__).with_name("catalogue.json")
        before = path.read_bytes()
        selected = catalogue.entry("clarify-need", self.data)
        selected["steps"][0] = "Une modification locale du lecteur."
        detached = catalogue.validate(self.data)
        detached["entries"].clear()
        catalogue.export_entry("clarify-need", self.data)
        self.assertEqual(path.read_bytes(), before)
        self.assertEqual(catalogue.load(), self.data)
        self.assertNotEqual(selected, catalogue.entry("clarify-need", self.data))

    def test_unknown_fields_and_execution_permissions_fail_closed(self):
        mutations = [
            lambda d: d.update(webhook="example"),
            lambda d: d["entries"][0].update(command="example"),
            lambda d: d["entries"][0]["permissions"].update(write="none"),
            lambda d: d["entries"][0]["permissions"].update(execution="granted"),
            lambda d: d["entries"][0]["permissions"].update(read="account_required"),
            lambda d: d["entries"][0]["origin"].update(url="example"),
            lambda d: d["entries"][0].update(executable=True),
            lambda d: d["entries"][0].update(status="empirically_proven"),
            lambda d: d["entries"][0]["origin"].update(kind="community_member"),
        ]
        for mutate in mutations:
            data = copy.deepcopy(self.data)
            mutate(data)
            with self.subTest(data=data):
                with self.assertRaises(ValueError):
                    catalogue.validate(data)

    def test_duplicate_identity_and_malformed_identifiers_are_rejected(self):
        data = copy.deepcopy(self.data)
        repeated = copy.deepcopy(data["entries"][0])
        repeated["version"] = "1.0.1"
        data["entries"].append(repeated)
        with self.assertRaises(ValueError):
            catalogue.validate(data)
        for bad_id in ("../private", "Clarify", "a--b", "", "a" * 65, 1):
            data = copy.deepcopy(self.data)
            data["entries"][0]["id"] = bad_id
            with self.subTest(identifier=bad_id):
                with self.assertRaises(ValueError):
                    catalogue.validate(data)
                with self.assertRaises(ValueError):
                    catalogue.entry(bad_id)
        with self.assertRaises(ValueError):
            catalogue.export_entry("absent")

    def test_versions_and_required_shapes_are_strict(self):
        mutations = [
            lambda d: d.update(schema_version=True),
            lambda d: d.update(schema_version=2),
            lambda d: d.update(catalogue_version="01.0.0"),
            lambda d: d.update(catalogue_id="unreviewed.catalogue"),
            lambda d: d.update(entries=[]),
            lambda d: d["entries"][0].pop("counterexample"),
            lambda d: d["entries"][0].update(version="1.0"),
            lambda d: d["entries"][0].update(category="unreviewed"),
            lambda d: d["entries"][0].update(steps="a single string"),
            lambda d: d["entries"][0].update(expected_evidence=[]),
            lambda d: d["entries"][0].update(executable=0),
        ]
        for mutate in mutations:
            data = copy.deepcopy(self.data)
            mutate(data)
            with self.subTest(data=data):
                with self.assertRaises(ValueError):
                    catalogue.validate(data)

    def test_links_markup_code_and_invisible_controls_are_rejected_as_prose(self):
        examples = [
            "Lire https://unreviewed.example/private", "Lire www.example.test",
            "<script>alert(1)</script>", "`commande`", "$(commande)",
            "eval('commande')", "fetch('resource')", "bash -c commande",
            "javascript:commande", "ligne\nsuivante", "invisible\u202edirection",
            "espace final ", "", {"code": "commande"},
        ]
        for value in examples:
            data = copy.deepcopy(self.data)
            data["entries"][0]["steps"][0] = value
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    catalogue.validate(data)

    def test_field_collection_and_total_byte_limits_are_enforced(self):
        data = copy.deepcopy(self.data)
        data["entries"][0]["steps"][0] = "x" * (catalogue.MAX_TEXT + 1)
        with self.assertRaises(ValueError):
            catalogue.validate(data)
        data = copy.deepcopy(self.data)
        data["entries"][0]["steps"] = ["Une étape."] * 13
        with self.assertRaises(ValueError):
            catalogue.validate(data)
        data = copy.deepcopy(self.data)
        data["entries"] = []
        for number in range(catalogue.MAX_ENTRIES):
            row = copy.deepcopy(self.data["entries"][0])
            row["id"] = "guide-" + str(number)
            row["steps"] = ["é" * catalogue.MAX_TEXT] * 12
            data["entries"].append(row)
        with self.assertRaisesRegex(ValueError, "byte limit"):
            catalogue.validate(data)
        data["entries"].append(copy.deepcopy(data["entries"][0]))
        with self.assertRaisesRegex(ValueError, "bounded"):
            catalogue.validate(data)

    def test_file_loader_rejects_duplicate_keys_bad_encoding_depth_and_oversize(self):
        raw = json.dumps(self.data, ensure_ascii=False).encode("utf-8")
        malformed = [
            raw.replace(b'"schema_version": 1', b'"schema_version": 1, "schema_version": 1', 1),
            raw.replace(b'"read": "none"', b'"read": "none", "read": "none"', 1),
            b"\xff", b"[" * 2000 + b"]" * 2000,
            b" " * (catalogue.MAX_BYTES + 1), b"{}",
        ]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "catalogue.json"
            for payload in malformed:
                path.write_bytes(payload)
                with self.subTest(length=len(payload)):
                    with self.assertRaises(ValueError):
                        catalogue.load(path)
            path.write_bytes(raw)
            self.assertEqual(catalogue.load(path), self.data)


if __name__ == "__main__":
    unittest.main()
