"""Validate and read Gaia's small public catalogue using only local JSON.

These versioned guides are human-readable data, never executable instructions.
There is no submission, network, runtime, private-memory or installation API.
Published (id, version) pairs are immutable editorial identities: a changed guide
must receive a new version during repository review. Returned dictionaries are
detached copies, so editing a reading or export cannot mutate the source.
"""

import json
import re
import unicodedata
from pathlib import Path


SCHEMA_VERSION = 1
MAX_BYTES = 131072
MAX_ENTRIES = 40
MAX_TEXT = 1000
STATUS = "curated_initial_guidance"
CATEGORIES = frozenset({"comprehension", "connection", "integration"})
CATALOGUE_FIELDS = frozenset({
    "schema_version", "catalogue_id", "catalogue_version", "title",
    "description", "status", "entries",
})
ENTRY_FIELDS = frozenset({
    "id", "version", "category", "title", "summary", "applicability", "limits",
    "steps", "expected_evidence", "counterexample", "permissions", "origin",
    "status", "executable",
})
_IDENTIFIER = re.compile(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*\Z")
_VERSION = re.compile(r"(?:0|[1-9][0-9]{0,3})\.(?:0|[1-9][0-9]{0,3})\.(?:0|[1-9][0-9]{0,3})\Z")
# Prose is deliberately restricted: no links, markup, code fences, shell
# interpolation or obvious executable snippets. This is an editorial format,
# not a sanitizer that turns untrusted code into something safe to execute.
_NON_PROSE = re.compile(
    r"[<>`{}]|(?:[a-z][a-z0-9+.-]*://)|(?:\bwww\.)|"
    r"(?:\b(?:javascript|data|file|mailto):)|(?:\$\()|(?:&&)|(?:\|\|)|"
    r"(?:\b(?:eval|exec|__import__|fetch)\s*\()|"
    r"(?:\b(?:curl|wget|sudo|bash|sh|powershell|cmd)\s+(?:-|/))",
    re.IGNORECASE,
)


def _object(value, fields, label):
    if type(value) is not dict or set(value) != fields:
        raise ValueError("%s must contain exactly its declared fields" % label)


def _text(value, label, maximum=MAX_TEXT):
    if type(value) is not str or not value or value != value.strip() or len(value) > maximum:
        raise ValueError("%s must be nonempty bounded plain text" % label)
    if any(unicodedata.category(char).startswith("C") for char in value) or _NON_PROSE.search(value):
        raise ValueError("%s must be plain prose without links, markup or executable snippets" % label)


def _texts(value, label, maximum_items):
    if type(value) is not list or not 1 <= len(value) <= maximum_items:
        raise ValueError("%s must be a bounded nonempty list" % label)
    for item in value:
        _text(item, label)


def _identifier(value, label):
    if type(value) is not str or len(value) > 64 or not _IDENTIFIER.fullmatch(value):
        raise ValueError("%s is not a catalogue identifier" % label)


def _version(value, label):
    if type(value) is not str or not _VERSION.fullmatch(value):
        raise ValueError("%s must be a bounded three-part version" % label)


def _validate_entry(value):
    _object(value, ENTRY_FIELDS, "entry")
    _identifier(value["id"], "entry.id")
    _version(value["version"], "entry.version")
    if type(value["category"]) is not str or value["category"] not in CATEGORIES:
        raise ValueError("entry.category is not supported")
    _text(value["title"], "entry.title", 120)
    _text(value["summary"], "entry.summary", 400)
    for name, limit in (("applicability", 6), ("limits", 6), ("steps", 12), ("expected_evidence", 6)):
        _texts(value[name], "entry." + name, limit)
    _text(value["counterexample"], "entry.counterexample")
    _object(value["permissions"], {"read", "execution"}, "entry.permissions")
    if value["permissions"] != {"read": "none", "execution": "not_granted"}:
        raise ValueError("reading must require no permission and grant no execution")
    _object(value["origin"], {"kind", "source", "note"}, "entry.origin")
    if value["origin"]["kind"] != "local_maintainer" or value["origin"]["source"] != "tao_repository":
        raise ValueError("entry.origin must identify the initial local maintainer guidance")
    _text(value["origin"]["note"], "entry.origin.note")
    if value["status"] != STATUS or value["executable"] is not False:
        raise ValueError("entries must remain nonexecutable initial guidance")


def validate(data):
    """Return a detached catalogue, or raise ValueError for unsupported data.

    Schema 1 is the first public catalogue format. Unknown schema versions are
    rejected, never migrated silently. It does not change Tao's private schema.
    """
    _object(data, CATALOGUE_FIELDS, "catalogue")
    if type(data["schema_version"]) is not int or data["schema_version"] != SCHEMA_VERSION:
        raise ValueError("unsupported catalogue schema_version")
    if data["catalogue_id"] != "gaia.initial-guides":
        raise ValueError("unsupported catalogue_id")
    _version(data["catalogue_version"], "catalogue_version")
    _text(data["title"], "catalogue.title", 120)
    _text(data["description"], "catalogue.description")
    if data["status"] != STATUS:
        raise ValueError("catalogue must identify initial curated guidance")
    entries = data["entries"]
    if type(entries) is not list or not 1 <= len(entries) <= MAX_ENTRIES:
        raise ValueError("catalogue.entries must be a bounded nonempty list")
    seen = set()
    for row in entries:
        _validate_entry(row)
        if row["id"] in seen:
            raise ValueError("duplicate catalogue entry id: " + row["id"])
        seen.add(row["id"])
    encoded = json.dumps(data, ensure_ascii=False, allow_nan=False).encode("utf-8")
    if len(encoded) > MAX_BYTES:
        raise ValueError("catalogue exceeds byte limit")
    return json.loads(encoded)


def unique_object(pairs):
    """Reject duplicate JSON object keys before schema validation."""
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def load(path=None):
    """Read at most MAX_BYTES from the bundled catalogue or an explicit file.

    The default is anchored beside this module; it never consults a runtime,
    home directory, credentials, environment variables or remote source.
    """
    target = Path(path) if path is not None else Path(__file__).with_name("catalogue.json")
    with target.open("rb") as source:
        raw = source.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError("catalogue exceeds byte limit")
    try:
        data = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_object)
    except (UnicodeError, RecursionError) as exc:
        raise ValueError("catalogue must be bounded UTF-8 JSON") from exc
    return validate(data)


def entry(entry_id, data=None):
    """Select exactly one public guide by ID; unknown IDs are an error."""
    _identifier(entry_id, "entry id")
    catalogue = load() if data is None else validate(data)
    for row in catalogue["entries"]:
        if row["id"] == entry_id:
            return row
    raise ValueError("unknown catalogue entry: " + entry_id)


def export_entry(entry_id, data=None):
    """Return only one selected public guide as portable plain JSON bytes.

    The envelope carries catalogue provenance, not local state or permissions.
    This is an inert reading copy, not a runtime import or an authorization.
    """
    catalogue = load() if data is None else validate(data)
    selected = entry(entry_id, catalogue)
    envelope = {
        "schema_version": SCHEMA_VERSION,
        "catalogue_id": catalogue["catalogue_id"],
        "catalogue_version": catalogue["catalogue_version"],
        "entry": selected,
    }
    return (json.dumps(envelope, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")
