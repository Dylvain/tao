"""Gaia's public, inert catalogue. Separate from every private Tao runtime."""
