import importlib.util, json, os, shutil, socket, subprocess, sys, tempfile, time, unittest, urllib.error, urllib.request
from pathlib import Path
from unittest import mock
ROOT=Path(__file__).resolve().parents[1]

class InstallTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run([sys.executable,str(ROOT/'scripts/build_release.py')],check=True,stdout=subprocess.DEVNULL)
        subprocess.run([sys.executable,str(ROOT/'scripts/build_linux_desktop.py')],check=True,stdout=subprocess.DEVNULL)
    def test_temporary_home_never_touches_live_user_manager(self):
        spec=importlib.util.spec_from_file_location('installer',ROOT/'bootstrap/install.py')
        installer=importlib.util.module_from_spec(spec); spec.loader.exec_module(installer)
        with tempfile.TemporaryDirectory() as td, mock.patch.dict(os.environ,{'HOME':td}):
            with mock.patch.object(Path,'is_socket',return_value=True), mock.patch.object(installer.shutil,'which',return_value='/usr/bin/systemctl'):
                with mock.patch.object(installer.subprocess,'run') as run:
                    self.assertFalse(installer.user_systemd_available(Path(td)/'.tao/genesis'))
                    run.assert_not_called()
    def test_self_contained_install_repeat_and_live_start(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td); state=home/'.tao/genesis'; state.mkdir(parents=True)
            with socket.socket() as s: s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
            (state/'policy.json').write_text(json.dumps({'http_port':port}))
            env=dict(os.environ,HOME=td,TAO_ROOT=str(state),XDG_CONFIG_HOME=str(home/'.config')); env.pop('TAO_NO_START',None)
            run=ROOT/'dist/TAO_LINUX_0.10.7.run'
            r=subprocess.run([sys.executable,str(run),'--no-start'],env=env,capture_output=True,text=True,timeout=30)
            self.assertEqual(r.returncode,0,r.stderr)
            launcher=home/'.local/bin/tao'
            subprocess.run([str(launcher),'story','set','Mon histoire conservée'],env=env,check=True,stdout=subprocess.DEVNULL)
            r=subprocess.run([sys.executable,str(run)],env=env,capture_output=True,text=True,timeout=30)
            self.assertEqual(r.returncode,0,r.stderr)
            try:
                self.assertTrue(json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/health'))['ok'])
                story=json.loads((state/'story.json').read_text()); self.assertEqual(story['text'],'Mon histoire conservée')
                self.assertTrue((home/'tao-linux-0.10.7/.git').is_dir())
                self.assertTrue((state/'runtime.previous').is_symlink())
                self.assertTrue((state/'runtime/theory.canonical.json').is_file())
                for module in ('tao_reuse.py','tao_bridge.py','tao_connectors.py','tao_tools.py','tao_tools_ui.py','tao_centers_app.py','tao_backup.py','tao_update.py'):
                    self.assertTrue((state/'runtime'/module).is_file())
                self.assertTrue((state/'runtime/tao-center.js').is_file())
                self.assertTrue((state/'runtime/tao-center.css').is_file())
                self.assertTrue((state/'runtime/tao.webmanifest').is_file())
                self.assertTrue((state/'runtime/tao-icon-192.png').is_file())
                self.assertTrue((state/'runtime/tao-icon-512.png').is_file())
                report=subprocess.run([str(launcher),'theory'],env=env,capture_output=True,text=True,timeout=10)
                self.assertEqual(report.returncode,0,report.stderr)
                self.assertEqual(json.loads(report.stdout)['term_count'],233)
                before=json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/health'))['session']
                runtime_before=os.readlink(state/'runtime')
                bad=home/'bad-runtime.json';bad.write_text(json.dumps({'files':{},'installer':'wrong','node_version':'0.10.7'}))
                refused=subprocess.run([sys.executable,str(home/'tao-linux-0.10.7/bootstrap/install.py'),'--expected-runtime',str(bad)],env=env,capture_output=True,text=True,timeout=10)
                self.assertNotEqual(refused.returncode,0)
                self.assertEqual(os.readlink(state/'runtime'),runtime_before)
                self.assertEqual(json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/health'))['session'],before)
                self.assertEqual(json.loads((state/'source.json').read_text())['path'],str(home/'tao-linux-0.10.7'))
                # desktop autostart uses an absolute path, not unsupported %h.
                desktop=home/'.config/autostart/tao-node.desktop'
                if desktop.exists(): self.assertNotIn('%h',desktop.read_text())
            finally:
                stopped=subprocess.run([str(launcher),'stop'],env=env,capture_output=True,text=True,timeout=10)
                self.assertEqual(stopped.returncode,0,stopped.stderr)
    def test_public_gaia_serves_review_sources_without_unsigned_installer(self):
        spec=importlib.util.spec_from_file_location('distro',ROOT/'genesis_service.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        manifest=m.verify_release(); self.assertEqual(manifest['version'],'0.10.7')
        self.assertEqual(m.CONTENT_TYPES['.deb'],'application/vnd.debian.binary-package')
        from scripts.build_gaia import build
        build()
        with socket.socket() as s: s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
        env=dict(os.environ,PORT=str(port),HOST='127.0.0.1'); env.pop('TAO_GAIA_DIR',None)
        process=subprocess.Popen([sys.executable,str(ROOT/'genesis_service.py')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        base=f'http://127.0.0.1:{port}'
        try:
            for _ in range(80):
                try:
                    status=json.load(urllib.request.urlopen(base+'/health',timeout=.3)); break
                except OSError: time.sleep(.05)
            else: self.fail('No Gaïa service')
            self.assertTrue(status['integrity_verified'])
            self.assertFalse(status['signature_verified_at_build'])
            self.assertFalse(status['private_host'])
            self.assertEqual(status['download_status'],'preview')
            with urllib.request.urlopen(base+'/') as response:
                self.assertIn('Gaïa',response.read().decode())
                self.assertIn("frame-ancestors 'none'",response.headers['Content-Security-Policy'])
                self.assertEqual(response.headers['Referrer-Policy'],'no-referrer')
            data=urllib.request.urlopen(base+'/Tao_Linux_0.10.7_source.zip').read()
            import hashlib
            self.assertEqual(hashlib.sha256(data).hexdigest(),manifest['files']['Tao_Linux_0.10.7_source.zip']['sha256'])
            for path,code in [('/TAO_LINUX_0.10.7.run',404),('/Tao_Linux_0.10.7_all.deb',404),('/bootstrap.sh',410),
                              ('/../README.md',404),('/%2e%2e/README.md',404),
                              ('//README.md',404),('/.env',404),('/_headers',404),('/state.json',404)]:
                with self.subTest(path=path),self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(base+path)
                self.assertEqual(error.exception.code,code)
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(urllib.request.Request(base+'/',data=b'private data',method='POST'))
            self.assertEqual(error.exception.code,405)
            with urllib.request.urlopen(urllib.request.Request(base+'/',method='HEAD')) as response:
                self.assertEqual(response.read(),b'')
                self.assertGreater(int(response.headers['Content-Length']),100)
            catalog=json.load(urllib.request.urlopen(base+'/catalogue.json'))
            self.assertEqual(len(catalog['entries']),3)
            birth=json.load(urllib.request.urlopen(base+'/birth.json'))
            self.assertEqual(birth['schema'],'tao.gaia.birth.v1')
            self.assertEqual(birth['seed']['specialized_centers'],[])
            self.assertFalse(birth['adaptation']['automatic_ai_calls'])
            self.assertEqual(birth['permissions'],{'read':'none','execution':'not_granted'})
        finally: process.terminate(); process.wait(timeout=5); process.stderr.close()

class InstallRecoveryTests(unittest.TestCase):
    def test_mobile_readiness_is_required_only_when_requested(self):
        spec=importlib.util.spec_from_file_location('recovery_installer',ROOT/'bootstrap/install.py')
        installer=importlib.util.module_from_spec(spec);spec.loader.exec_module(installer)
        health={'ok':True,'node_version':'fixture','mobile':{'ready':False}}
        with mock.patch.object(installer,'health_snapshot',return_value=health),mock.patch.object(installer.time,'sleep'):
            self.assertEqual(installer.wait_health(ROOT,'fixture'),health)
            with self.assertRaisesRegex(RuntimeError,'accès mobile prêt'):installer.wait_health(ROOT,'fixture',require_mobile=True)
            health['mobile']['ready']=True
            self.assertEqual(installer.wait_health(ROOT,'fixture',require_mobile=True),health)

    def source(self,base,name,version,failure=None):
        repo=base/name
        shutil.copytree(ROOT/'bootstrap',repo/'bootstrap',ignore=shutil.ignore_patterns('__pycache__'))
        (repo/'docs').mkdir();shutil.copyfile(ROOT/'docs/theory.json',repo/'docs/theory.json')
        installer=repo/'bootstrap/install.py'
        import re
        installer.write_text(re.sub(r"^VERSION='[^']+'",'VERSION='+repr(version),installer.read_text(),flags=re.M))
        node=repo/'bootstrap/tao_node.py'
        source=re.sub(r'^NODE_VERSION="[^"]+"','NODE_VERSION='+json.dumps(version),node.read_text(),flags=re.M)
        if failure=='start':
            source=source.replace('def daemon():\n','def daemon():\n    raise RuntimeError("Fixture candidate cannot start")\n',1)
        elif failure=='health':
            source=source.replace('"ok":not stale and theory_ok','"ok":False',1)
        if failure:
            # This state change survives recovery: installation rolls back code,
            # never the user's state or mutations already recorded by a cycle.
            source=source.replace('def main():\n','def main():\n    if STATE.exists():\n        with LOCK:\n            s=load_raw_state(); s["fixture_attempt_seen"]="retained"; atomic_json(STATE,s,backup=True)\n',1)
        node.write_text(source)
        return installer

    def fixture(self,base):
        home=base/'home';home.mkdir();state=home/'.tao/genesis';state.mkdir(parents=True)
        with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        (state/'policy.json').write_text(json.dumps({'http_port':port}))
        env=dict(os.environ,HOME=str(home),TAO_ROOT=str(state),XDG_CONFIG_HOME=str(home/'.config'))
        env.pop('TAO_NO_START',None);env.pop('TAO_INIT_SOURCE_GIT',None)
        return home,state,port,env

    def health(self,port):
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=2) as response:return json.load(response)

    def test_failed_new_start_or_health_restores_live_previous_runtime_and_state(self):
        for failure in ('start','health'):
            with self.subTest(failure=failure),tempfile.TemporaryDirectory() as td:
                base=Path(td);home,state,port,env=self.fixture(base)
                old=self.source(base,'old','fixture-previous')
                first=subprocess.run([sys.executable,str(old)],env=env,capture_output=True,text=True,timeout=30)
                self.assertEqual(first.returncode,0,first.stderr)
                launcher=home/'.local/bin/tao'
                try:
                    subprocess.run([str(launcher),'story','set','Mon histoire à conserver'],env=env,check=True,stdout=subprocess.DEVNULL)
                    before=self.health(port);previous=os.readlink(state/'runtime');source_record=(state/'source.json').read_bytes()
                    candidate=self.source(base,'candidate','fixture-candidate',failure)
                    result=subprocess.run([sys.executable,str(candidate)],env=env,capture_output=True,text=True,timeout=40)
                    self.assertNotEqual(result.returncode,0)
                    self.assertNotIn('TAO_READY=1',result.stdout)
                    self.assertIn('TAO_READY=0',result.stderr)
                    self.assertIn('TAO_RECOVERY=healthy',result.stderr)
                    after=self.health(port)
                    self.assertTrue(after['ok']);self.assertEqual(after['node_version'],'fixture-previous')
                    self.assertNotEqual(before['session'],after['session'])
                    self.assertEqual(os.readlink(state/'runtime'),previous)
                    self.assertEqual((state/'source.json').read_bytes(),source_record)
                    self.assertEqual(json.loads((state/'story.json').read_text())['text'],'Mon histoire à conserver')
                    self.assertEqual(json.loads((state/'state.json').read_text())['fixture_attempt_seen'],'retained')
                    if failure=='start':self.assertIn('Fixture candidate cannot start',(state/'daemon.log').read_text())
                    else:self.assertIn('version et la session attendues',result.stderr)
                finally:
                    stopped=subprocess.run([str(launcher),'stop'],env=env,capture_output=True,text=True,timeout=10)
                    self.assertEqual(stopped.returncode,0,stopped.stderr)

    def test_first_install_failure_stays_failed_without_inventing_previous_runtime(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td);home,state,port,env=self.fixture(base)
            candidate=self.source(base,'candidate','fixture-candidate','start')
            result=subprocess.run([sys.executable,str(candidate)],env=env,capture_output=True,text=True,timeout=30)
            self.assertNotEqual(result.returncode,0)
            self.assertNotIn('TAO_READY=1',result.stdout)
            self.assertIn('TAO_RECOVERY=unavailable',result.stderr)
            self.assertFalse((state/'runtime.previous').exists())
            self.assertFalse((state/'runtime').exists())
            self.assertTrue((state/'state.json').exists())
            self.assertFalse((state/'source.json').exists())
            with self.assertRaises(OSError):self.health(port)
if __name__=='__main__': unittest.main()
