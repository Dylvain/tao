"""Static Gaia paths, explicit navigation, inert catalogue and release gating."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from html.parser import HTMLParser


ROOT = Path(__file__).resolve().parents[1]


class Page(HTMLParser):
    def __init__(self, source):
        super().__init__()
        self.elements = []
        self.feed(source)

    def handle_starttag(self, tag, attrs):
        self.elements.append((tag, dict(attrs)))


class GaiaUITests(unittest.TestCase):
    def run_js(self, source):
        node = os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node:
            self.skipTest('Node is needed for Gaia browser behavior checks')
        prelude = 'const assert=require("assert");const gaia=require(' + json.dumps(str(ROOT / 'gaia/app.js')) + ');\n'
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'gaia-check.cjs'
            path.write_text(prelude + source)
            result = subprocess.run([node, str(path)], capture_output=True, text=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_page_paths_labels_and_private_static_surface(self):
        source = (ROOT / 'gaia/index.html').read_text()
        page = Page(source)
        ids = [attrs['id'] for _, attrs in page.elements if attrs.get('id')]
        self.assertEqual(len(ids), len(set(ids)))
        for target in ['commencer', 'retrouver', 'contributions']:
            self.assertIn(target, ids)
            self.assertTrue(any(tag == 'a' and attrs.get('href') == '#' + target for tag, attrs in page.elements))
        labels = [attrs.get('for') for tag, attrs in page.elements if tag == 'label']
        for tag, attrs in page.elements:
            if tag in {'textarea', 'input', 'select'}:
                self.assertIn(attrs.get('id'), labels)
            if tag in {'script', 'link'} and attrs.get('src', attrs.get('href')):
                self.assertTrue(attrs.get('src', attrs.get('href')).startswith('./'))
            if tag == 'a' and attrs.get('href', '').startswith('#') and attrs['href'] != '#':
                self.assertIn(attrs['href'][1:], ids)
        self.assertIn('form-action \'none\'', source)
        self.assertIn('Version expérimentale', source)
        self.assertIn('Le contrat public de naissance', source)
        self.assertIn('Sans IA connectée ou sans résidu reproductible', source)
        self.assertIn('role="status"', source)
        self.assertIn('prefers-reduced-motion', (ROOT / 'gaia/style.css').read_text())
        script = (ROOT / 'gaia/app.js').read_text()
        for forbidden in ['localStorage', 'sessionStorage', 'document.cookie', 'innerHTML', 'eval(', 'sendBeacon', 'WebSocket']:
            self.assertNotIn(forbidden, script)

    def test_instance_origin_policy_rejects_credentials_paths_and_ambiguous_http(self):
        self.run_js(r'''
assert.equal(gaia.instanceURL(' https://tao.example:9443/ '),'https://tao.example:9443');
assert.equal(gaia.instanceURL('http://127.0.0.1:8790'),'http://127.0.0.1:8790');
assert.equal(gaia.instanceURL('http://localhost:8790/'),'http://localhost:8790');
for (const value of ['','tao.example','javascript:alert(1)','data:text/html,x','//tao.example','http://tao.example','http://192.168.1.2','http://127.1','http://2130706433','http://0x7f000001','http://127.0.0.2','http://localhost.example','http://[::1]','https://me:secret@tao.example','https://@tao.example','https://tao.example/path','https://tao.example/../','https://tao.example/%2e','https://tao.example/?token=secret','https://tao.example?','https://tao.example/#','https://tao.example\\evil','https://tao.\nexample','https://tao.example:99999']) {
  assert.throws(()=>gaia.instanceURL(value),undefined,value);
}
assert(gaia.connectionQuestion('un téléphone','').includes('ne connais pas encore'));
assert(gaia.connectionQuestion('un téléphone','https://my.example').includes('https://my.example'));
assert.throws(()=>gaia.connectionQuestion('un téléphone','http://remote.example'));
assert.throws(()=>gaia.prepareQuestion('   '));
assert.throws(()=>gaia.prepareQuestion('x'.repeat(4001)));
const first=gaia.prepareQuestion('<script>data, not code</script>');
assert(first.includes('<script>data, not code</script>'));
assert(first.includes('ne crée aucun centre spécialisé par défaut'));
assert(first.includes('résidu reproductible'));
assert(first.includes('au plus un premier centre'));
assert(first.includes('ne lis aucun secret'));
''')

    def test_birth_contract_is_inert_minimal_and_rejects_private_authority(self):
        self.run_js('const original=' + (ROOT / 'gaia/birth.json').read_text() + ';\n' + r'''
const contract=gaia.readBirthContract(original);
assert.equal(contract.schema,'tao.gaia.birth.v1');
assert.equal(contract.seed.observerModel,'C0');
assert.equal(contract.seed.specializedCenters,0);
assert.equal(contract.birth.identity,'fresh_local');
assert.equal(contract.adaptation.reasonerRequired,false);
assert.equal(contract.adaptation.automaticAICalls,false);
assert.equal(contract.permissions.read,'none');
assert.equal(contract.executable,false);
const mutations=[
  x=>x.seed.specialized_centers.push('centre-imposé'),
  x=>x.inheritance.included.push('private_memory'),
  x=>x.inheritance.excluded=x.inheritance.excluded.filter(item=>item!=='credentials'),
  x=>x.birth.identity='gaia_account',
  x=>x.adaptation.reasoner_required=true,
  x=>x.adaptation.automatic_ai_calls=true,
  x=>x.permissions.read='machine',
  x=>x.executable=true,
  x=>x.provider_endpoint='https://ai.example'
];
for (const mutate of mutations) { const bad=JSON.parse(JSON.stringify(original));mutate(bad);assert.throws(()=>gaia.readBirthContract(bad)); }
''')

    def test_unsigned_or_inconsistent_release_never_exposes_installer(self):
        self.run_js(r'''
const hash='a'.repeat(64),installer={name:'TAO_LINUX_0.10.7.run',url:'TAO_LINUX_0.10.7.run'},source_archive={name:'Tao_Linux_0.10.7_source.zip',url:'./Tao_Linux_0.10.7_source.zip'};
const manifest={version:'0.10.7',files:{[installer.name]:{sha256:hash,size:321},[source_archive.name]:{sha256:hash,size:123}}};
const signature={manifest:'release.json',signature:'release.sig',metadata:'signing.json',public_key:'release-public.pem',public_key_sha256:hash};
const config={version:'0.10.7',download_status:'preview',reason:'Signature à publier.',installer,source_archive,signature};
let view=gaia.releaseView(config,manifest);
assert.equal(view.signed,false);assert.equal(view.installer,null);assert.equal(view.source.name,source_archive.name);
view=gaia.releaseView({...config,download_status:'signed'},manifest);
assert.equal(view.signed,true);assert.equal(view.installer.href,'./TAO_LINUX_0.10.7.run');assert.equal(view.desktopInstaller,null);
for (const mutation of [{signature:null},{signature:{...signature,public_key_sha256:'bad'}},{installer:{...installer,url:'https://evil.example/TAO_LINUX_0.10.7.run'}},{installer:{...installer,url:'../TAO_LINUX_0.10.7.run'}},{installer:{...installer,url:'other.run'}},{version:'0.10.0'}]) {
  view=gaia.releaseView({...config,download_status:'signed',...mutation},manifest);assert.equal(view.signed,false);assert.equal(view.installer,null);
}
assert.equal(gaia.releaseView({...config,download_status:'signed'},{...manifest,files:{}}).signed,false);
const desktopInstaller={name:'Tao_Linux_0.10.7_all.deb',url:'Tao_Linux_0.10.7_all.deb'};
const desktopSignature={manifest:'desktop-release.json',signature:'desktop-release.sig',metadata:'desktop-signing.json',public_key:'release-public.pem',public_key_sha256:hash};
const desktopManifest={schema:'tao.desktop.release.v1',version:'0.10.7',release_manifest_sha256:hash,package:{name:desktopInstaller.name,sha256:hash,size:456,architecture:'all',supported:['debian','ubuntu'],install_mode:'graphical_or_package_manager'}};
const desktopConfig={...config,download_status:'signed',desktop_installer:desktopInstaller,desktop_signature:desktopSignature};
view=gaia.releaseView(desktopConfig,manifest,desktopManifest);
assert.equal(view.signed,true);assert.equal(view.desktopInstaller.href,'./Tao_Linux_0.10.7_all.deb');assert.equal(view.desktopSignature,'./desktop-release.sig');
for (const mutation of [{desktop_signature:null},{desktop_signature:{...desktopSignature,public_key_sha256:'b'.repeat(64)}},{desktop_installer:{...desktopInstaller,url:'../bad.deb'}}]) {
  view=gaia.releaseView({...desktopConfig,...mutation},manifest,desktopManifest);assert.equal(view.signed,true);assert.equal(view.desktopInstaller,null);
}
for (const mutate of [x=>x.schema='bad',x=>x.version='0.10.6',x=>x.package.architecture='amd64',x=>x.package.supported.push('fedora'),x=>x.package.name='bad.deb',x=>x.package.extra=true]) {
  const bad=JSON.parse(JSON.stringify(desktopManifest));mutate(bad);view=gaia.releaseView(desktopConfig,manifest,bad);assert.equal(view.desktopInstaller,null);
}
for (const value of ['https://x/a','//x/a','/a','../a','a/../b','a//b','a?x','a#x','a\\b','a%2fb','a;alert','a/./b']) assert.equal(gaia.localAsset(value),null,value);
assert.equal(gaia.localAsset('files/release.sig'),'./files/release.sig');
''')

    def test_catalogue_filters_selected_export_and_literal_rendering(self):
        self.run_js('const original=' + (ROOT / 'gaia/catalogue.json').read_text() + ';\n' + r'''
const catalogue=gaia.readCatalogue(original);
assert.equal(catalogue.entries.length,3);
assert.equal(gaia.filterEntries(catalogue.entries,'all','EVALUER').length,1);
assert.equal(gaia.filterEntries(catalogue.entries,'connection','').length,1);
assert.equal(gaia.filterEntries(catalogue.entries,'connection','résultat vécu').length,0);
const poisoned=JSON.parse(JSON.stringify(original));poisoned.entries[0].title='<img src=x onerror=alert(1)>';poisoned.entries[0].private_memory='Never export';
const clean=gaia.readCatalogue(poisoned),exported=gaia.exportEntry(clean,clean.entries[0].id);
assert.equal(exported.entry.title,poisoned.entries[0].title);assert.equal(exported.entries,undefined);assert.equal(exported.entry.private_memory,undefined);assert.equal(exported.entry.executable,false);
assert.throws(()=>gaia.exportEntry(clean,'missing'));
for (const mutate of [x=>x.entries[0].executable=true,x=>x.entries[0].permissions.execution='granted',x=>x.entries[0].category='__proto__',x=>x.entries[0].id='../secret',x=>x.entries.push(x.entries[0]),x=>x.entries[0].origin.kind='community_verified']) { const bad=JSON.parse(JSON.stringify(original));mutate(bad);assert.throws(()=>gaia.readCatalogue(bad)); }
class Element {constructor(tag){this.tagName=tag;this.children=[];this.attributes={};this.textContent='';}append(...nodes){this.children.push(...nodes);}setAttribute(k,v){this.attributes[k]=v;}addEventListener(){}get lastChild(){return this.children.at(-1);}set innerHTML(v){throw Error('HTML injection');}}
const document={createElement:tag=>new Element(tag),createDocumentFragment:()=>new Element('fragment')};
const card=gaia.renderCard(document,clean.entries[0],()=>{}),detail=gaia.renderDetail(document,clean.entries[0]);
function all(node){return [node,...node.children.flatMap(all)];}
assert(all(card).some(node=>node.textContent===poisoned.entries[0].title));assert(all(detail).some(node=>node.textContent===poisoned.entries[0].title));
assert(![...all(card),...all(detail)].some(node=>node.tagName==='img'||node.tagName==='script'));
''')

    def test_navigation_is_only_explicit_and_public_fetches_omit_credentials(self):
        ids = [attrs['id'] for _, attrs in Page((ROOT / 'gaia/index.html').read_text()).elements if attrs.get('id')]
        self.run_js('const ids=' + json.dumps(ids) + ';const data=' + (ROOT / 'gaia/catalogue.json').read_text() + ';const birth=' + (ROOT / 'gaia/birth.json').read_text() + ';\n' + r'''
class Element {
  constructor(tag='div'){this.tagName=tag;this.children=[];this.attributes={};this.events={};this.value='';this.hidden=false;this.textContent='';this.classList={toggle(){}};}
  append(...nodes){this.children.push(...nodes);}replaceChildren(...nodes){this.children=nodes;}get lastChild(){return this.children.at(-1);}
  setAttribute(k,v){this.attributes[k]=v;}removeAttribute(k){delete this.attributes[k];}
  addEventListener(type,fn){this.events[type]=fn;}focus(){}select(){}setCustomValidity(){}reportValidity(){}showModal(){this.open=true;}close(){this.open=false;}
}
const nodes=new Map(ids.map(id=>[id,new Element()]));const filters=['all','comprehension','connection','integration'].map(category=>{const e=new Element('button');e.dataset={category};return e;});
const document={getElementById:id=>nodes.get(id),createElement:tag=>new Element(tag),createDocumentFragment:()=>new Element('fragment'),querySelectorAll:()=>filters};
const requests=[],opened=[];globalThis.open=(...args)=>opened.push(args);
globalThis.fetch=async(url,options)=>{requests.push({url,options});return {ok:true,text:async()=>JSON.stringify(url==='./catalogue.json'?data:url==='./birth.json'?birth:{version:'0.10.7',files:{},download_status:'preview'})};};
gaia.init(document);
(async()=>{
await new Promise(setImmediate);
assert.deepEqual(requests.map(item=>item.url).sort(),['./birth.json','./catalogue.json','./portal.json','./release.json']);
assert(requests.every(item=>item.options.credentials==='omit'&&item.options.mode==='same-origin'&&item.options.redirect==='error'));
assert.equal(opened.length,0);assert.equal(nodes.get('installer-link').hidden,true);assert.equal(nodes.get('catalogue-list').children.length,3);
assert(nodes.get('birth-contract-state').textContent.includes('aucun centre spécialisé'));assert.equal(nodes.get('birth-contract-link').hidden,false);
nodes.get('tao-url').value='https://my-tao.example';nodes.get('tao-url').events.input();assert.equal(opened.length,0);assert.equal(requests.length,4);
nodes.get('return-form').events.submit({preventDefault(){}});assert.deepEqual(opened,[['https://my-tao.example','_blank','noopener,noreferrer']]);assert.equal(requests.length,4);
nodes.get('tao-url').value='https://secret@evil.example';nodes.get('return-form').events.submit({preventDefault(){}});assert.equal(opened.length,1);assert.equal(nodes.get('url-error').hidden,false);
nodes.get('intention').value='Une idée personnelle';nodes.get('question-form').events.submit({preventDefault(){}});assert.equal(nodes.get('draft-result').hidden,false);assert(nodes.get('draft-text').textContent.includes('Une idée personnelle'));assert.equal(requests.length,4);
filters[2].events.click();assert.equal(nodes.get('catalogue-list').children.length,1);
nodes.get('catalogue-search').value='introuvable';nodes.get('catalogue-search').events.input();assert.equal(nodes.get('catalogue-list').children.length,0);assert(nodes.get('catalogue-status').textContent.includes('Aucune méthode'));
nodes.get('platform').value='android';nodes.get('platform').events.change();assert.equal(nodes.get('linux-downloads').hidden,true);assert(nodes.get('platform-guidance').children[0].textContent.includes('Linux uniquement'));
nodes.get('platform').value='linux';nodes.get('platform').events.change();assert.equal(nodes.get('linux-downloads').hidden,false);assert.equal(nodes.get('installer-link').hidden,true);
})().catch(error=>{console.error(error);process.exitCode=1});
''')


if __name__ == '__main__':
    unittest.main()
