import concurrent.futures, hashlib, importlib.util, json, os, re, signal, socket, subprocess, sys, tempfile, threading, time, unittest, urllib.error, urllib.request
from contextlib import contextmanager
from http.server import ThreadingHTTPServer
from pathlib import Path

PROJECT=Path(__file__).resolve().parents[1]
BOOT=PROJECT/'bootstrap'; NODE=BOOT/'tao_node.py'
sys.path.insert(0,str(BOOT))
import tao_workshop as workshop

class NodeHarness(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name); self.root=self.base/'state'
        old=os.environ.get('TAO_ROOT'); os.environ['TAO_ROOT']=str(self.root)
        name='node_'+str(time.time_ns()); spec=importlib.util.spec_from_file_location(name,NODE)
        self.n=importlib.util.module_from_spec(spec); sys.modules[name]=self.n; spec.loader.exec_module(self.n)
        if old is None: os.environ.pop('TAO_ROOT',None)
        else: os.environ['TAO_ROOT']=old
        self.n.ensure_files(); self.env=dict(os.environ,TAO_ROOT=str(self.root))
    def tearDown(self): self.tmp.cleanup()
    def cli(self,*args,check=True):
        r=subprocess.run([sys.executable,str(NODE),*args],env=self.env,capture_output=True,text=True,timeout=20)
        if check: self.assertEqual(r.returncode,0,r.stderr)
        return r
class NodeTests(NodeHarness):
    def test_offline_first_cycle(self):
        s=self.n.cycle(); self.assertEqual(s['cycles'],1)
        self.assertEqual(s['resource_profile']['network_heritage_reads'],0)
        self.assertEqual(s['resource_profile']['external_ai_calls'],0)
        self.assertFalse(self.n.policy()['commons_read'])
        self.assertEqual(s['observer_model']['status'],'observer_hypothesis')
    def test_concurrent_processes_keep_every_cycle(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
            rows=list(executor.map(lambda _:self.cli('cycle'),range(12)))
        self.assertEqual(self.n.load_state()['cycles'],12)
    def test_sidecar_interruption_does_not_lose_state(self):
        self.n.cycle(); self.n.STATE_SHA.write_text('interrupted')
        self.assertEqual(self.n.load_state()['cycles'],1)
    def test_corruption_recovers_verified_previous_with_visible_buffer(self):
        self.n.cycle(); self.n.cycle(); self.n.STATE.write_text('{broken')
        s=self.n.load_state(); self.assertEqual(s['cycles'],1)
        self.assertIn('persistence.recovered',s['buffers'])
        self.assertTrue(list(self.root.glob('state.corrupt-*.json')))
    def test_double_corruption_never_silently_reinitializes(self):
        self.n.cycle(); self.n.STATE.write_text('bad'); self.n.STATE_PREV.write_text('also bad')
        with self.assertRaises(RuntimeError): self.n.load_state()
        self.assertEqual(self.n.STATE.read_text(),'bad')
    def test_migration_from_041_preserves_identity_and_story(self):
        s=self.n.initial_state(); s['cycles']=123; s['node_version']='0.4.1'
        self.n.STATE.write_text(json.dumps(s)); self.n.STATE_SHA.write_text(hashlib.sha256(self.n.STATE.read_bytes()).hexdigest())
        self.n.set_story('Garder mon histoire')
        new=self.n.cycle(); self.assertEqual(new['cycles'],124); self.assertEqual(new['id'],s['id'])
        self.assertEqual(new['node_version'],'0.10.7'); self.assertEqual(new['story']['text'],'Garder mon histoire')
    def test_upgrade_from_052_preserves_unclassified_buffer(self):
        s=self.n.load_state(); s['node_version']='0.5.2'
        old=self.n.make_buffer('old','user','Un besoin existant',authority='human')
        old['desired']='But conservé'; s['buffers'][old['id']]=old
        self.n.atomic_json(self.n.STATE,s,backup=True)
        new=self.n.cycle()
        self.assertEqual(new['node_version'],'0.10.7')
        self.assertEqual(new['buffers'][old['id']]['desired'],'But conservé')
        self.assertNotIn('origin_hypothesis',new['buffers'][old['id']])
    def test_repetition_is_not_evidence_of_resolution(self):
        s=self.n.load_state(); s['buffers']['x']=self.n.make_buffer('x','local','unknown')
        s['buffers']['x']['seen']=50
        habits,created=self.n.compile_habits(s)
        self.assertEqual(habits['habits'][0]['status'],'candidate')
        self.assertFalse(habits['habits'][0]['validated'])
        self.assertEqual(s['buffers']['x']['status'],'open')
    def test_plan_respects_risk_uncertainty_and_human_authority(self):
        s=self.n.load_state()
        danger=self.n.make_buffer('danger','resource','low disk',importance=.9,risk=.9,irreversibility=.6)
        repeated=self.n.make_buffer('repeat','local','same small issue',importance=.7,uncertainty=.2,risk=.1)
        repeated['seen']=8
        user=self.n.make_buffer('wish','user','new idea',importance=.8,uncertainty=.8,authority='human')
        for b in [danger,repeated,user]: s['buffers'][b['id']]=b
        plan={row['buffer_id']:row for row in self.n.evolution_plan(s)}
        self.assertEqual(plan['danger']['phase'],'stabilisation')
        self.assertIn('préserver',plan['danger']['next_step'])
        self.assertEqual(plan['repeat']['phase'],'conciliation')
        self.assertIn('pas une résolution',plan['repeat']['why'])
        self.assertEqual(plan['wish']['phase'],'exploration')
        self.assertTrue(plan['wish']['requires_human_decision'])
        self.assertEqual(s['buffers']['repeat']['status'],'open')
    def test_human_authority_cannot_compile_to_habit(self):
        s=self.n.load_state(); b=self.n.make_buffer('x','local','needs choice',authority='human'); b['seen']=100; s['buffers']['x']=b
        self.assertEqual(self.n.compile_habits(s)[1],[])
    def test_policy_validation(self):
        for value in [{'http_host':'0.0.0.0'},{'min_sleep_seconds':0},{'max_sleep_seconds':True},{'external_ai_auto':True}]:
            self.n.atomic_json(self.n.POLICY,value)
            with self.assertRaises(ValueError): self.n.policy()
    def test_sleep_adapts_and_respects_ceiling(self):
        s=self.n.load_state(); margins={'disk':1,'memory':1,'battery':1}
        first=self.n.adapt_scheduler(s,True,margins)
        for _ in range(50): last=self.n.adapt_scheduler(s,False,margins)
        self.assertGreater(last,first); self.assertLessEqual(last,self.n.policy()['max_sleep_seconds'])
        self.assertEqual(self.n.adapt_scheduler(s,True,margins),first)
    def test_buffer_dedup_and_residual_preservation(self):
        b=self.n.add_buffer('Un manque','Un but','Un test'); again=self.n.add_buffer('Un manque','Un but','Un test')
        self.assertEqual(b['id'],again['id']); self.assertEqual(again['seen'],2)
        self.n.cycle(); self.assertEqual(self.n.load_state()['buffers'][b['id']]['status'],'open')
        self.assertNotIn('origin_hypothesis',self.n.load_state()['buffers'][b['id']])
    def test_origin_traces_are_hypotheses_and_preserve_distinct_observations(self):
        first={'source':'contrainte','destination':'action','input':'seuil franchi',
               'output':'continuer','difference':'arrêt non transmis <script>alert(1)</script>'}
        b=self.n.add_buffer('La consigne se perd','Arrêter','La sortie respecte le seuil','translation',first)
        second=dict(first,output='ralentir',difference='seuil devenu simple priorité')
        again=self.n.add_buffer('La consigne se perd','Arrêter','La sortie respecte le seuil','translation',second)
        self.assertEqual(b['id'],again['id']); self.assertEqual(again['seen'],2)
        self.assertEqual(len(again['origin_traces']),2)
        self.assertEqual(again['origin_hypothesis']['status'],'hypothesis')
        self.assertEqual(again['origin_traces'][0]['source'],'human_report')
        plan={p['buffer_id']:p for p in self.n.evolution_plan()}
        self.assertEqual(plan[b['id']]['status'],'proposal')
        self.assertIn('traduction',plan[b['id']]['next_step'])
        self.assertEqual(self.n.load_state()['buffers'][b['id']]['status'],'open')
        snap=self.n.write_lens_snapshot(self.n.load_state())
        self.assertEqual(snap['buffers'][0]['origin_traces'][0]['trace']['input'],'seuil franchi')
        page=self.n.dashboard(self.n.load_state())
        self.assertNotIn('<script>alert(1)</script>',page)
        self.assertIn('&lt;script&gt;alert(1)&lt;/script&gt;',page)
    def test_origin_trace_requires_comparable_observation(self):
        for kind,trace in [('translation',{'input':'signal','output':'commande','difference':'perte'}),
                           ('conciliation',{'input':'agir','output':'attendre'}),
                           ('internal',{'input':'état','output':'résultat','difference':'x'*1001}),
                           ('undetermined',{'difference':'un signal'})]:
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                self.n.add_buffer('X','Y','Z',kind,trace)
        self.assertEqual(self.n.load_state()['buffers'],{})
    def test_resolution_keeps_attributed_evidence(self):
        b=self.n.add_buffer('A problem','A goal','A test')
        self.n.close_buffer(b['id'],'Verified in real use')
        row=self.n.load_state()['buffers'][b['id']]
        self.assertEqual(row['status'],'resolved')
        self.assertEqual(row['evidence'][-1]['source'],'human_report')
    def test_story_html_escaped(self):
        self.n.set_story('<script>alert(1)</script>'); self.n.cycle()
        html=self.n.dashboard(self.n.load_state()); self.assertNotIn('<script>alert(1)</script>',html)
        self.assertIn('&lt;script&gt;',html)
    def test_bounded_journal(self):
        self.n.atomic_json(self.n.POLICY,{'journal_max_bytes':1024,'journal_keep':2})
        for i in range(30): self.n.event('example',{'message':'x'*200})
        self.assertTrue((self.root/'events.jsonl.2').exists())
        self.assertFalse((self.root/'events.jsonl.3').exists())
    def test_doctor_reports_missing_daemon(self):
        self.n.cycle(); self.assertFalse(self.n.doctor(True)['ok'])
        self.assertNotEqual(self.cli('doctor','--require-running',check=False).returncode,0)
    def test_corrupt_policy_fails_visibly(self):
        self.n.POLICY.write_text('oops')
        self.assertNotEqual(self.cli('cycle',check=False).returncode,0)
    def test_bounded_process_timeout(self):
        result=workshop.run_bounded([sys.executable,'-c','import time;time.sleep(3)'],self.base,self.base/'timeout.log',.1)
        self.assertFalse(result['ok']); self.assertEqual(result['reason'],'timeout')
    def test_bounded_process_output(self):
        result=workshop.run_bounded([sys.executable,'-c','print("x"*3000000)'],self.base,self.base/'output.log',10)
        self.assertFalse(result['ok']); self.assertLessEqual((self.base/'output.log').stat().st_size,workshop.MAX_OUTPUT)

class DoctorTests(NodeHarness):
    @contextmanager
    def running_node(self, health_overrides=None):
        node=self.n
        class Handler(node.Handler):
            def send_json(self, obj, status=200):
                if self.path=='/health' and health_overrides:
                    obj=dict(obj,**health_overrides)
                return super().send_json(obj,status)
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        server.daemon_threads=True; server.session_id='doctor-fixture-session'
        node.TOKEN='doctor-fixture-private-token'
        policy=node.policy(); policy['http_port']=server.server_port
        node.atomic_json(node.POLICY,policy)
        node.atomic_json(node.ROOT/'session.json',{'id':server.session_id,'port':server.server_port,'token':node.TOKEN})
        node.cycle()
        thread=threading.Thread(target=server.serve_forever,kwargs={'poll_interval':.02},daemon=True)
        thread.start()
        try: yield server
        finally:
            server.shutdown(); server.server_close(); thread.join(timeout=3)

    def test_endpoint_change_reports_active_and_desired_without_false_ready(self):
        with self.running_node() as server, socket.socket() as unavailable:
            unavailable.bind(('127.0.0.1',0))
            desired=f'http://127.0.0.1:{unavailable.getsockname()[1]}'
            before=self.n.doctor(True)
            self.assertTrue(before['ok']); self.assertFalse(before['restart_required'])
            policy=self.n.policy(); policy['http_port']=unavailable.getsockname()[1]
            self.n.atomic_json(self.n.POLICY,policy)
            after=self.n.doctor(True)
            self.assertFalse(after['ok']); self.assertTrue(after['running'])
            self.assertTrue(after['health_ok']); self.assertTrue(after['runtime_matches'])
            self.assertFalse(after['configuration_matches']); self.assertTrue(after['restart_required'])
            self.assertEqual(after['restart_reasons'],['configured_endpoint_changed'])
            self.assertEqual(after['api'],f'http://127.0.0.1:{server.server_port}')
            self.assertEqual(after['active_api'],after['api']); self.assertEqual(after['configured_api'],desired)
            self.assertTrue(json.load(urllib.request.urlopen(after['api']+'/health',timeout=1))['ok'])
            with self.assertRaises(OSError): urllib.request.urlopen(desired+'/health',timeout=1)
            self.assertFalse(self.n.doctor()['ok'])
            cli=self.cli('doctor','--require-running',check=False)
            self.assertNotEqual(cli.returncode,0); self.assertTrue(json.loads(cli.stdout)['restart_required'])

    def test_old_runtime_is_running_but_requires_restart(self):
        with self.running_node({'node_version':'fixture-previous-version'}):
            result=self.n.doctor(True)
            self.assertTrue(result['running']); self.assertFalse(result['ok'])
            self.assertTrue(result['configuration_matches']); self.assertFalse(result['runtime_matches'])
            self.assertEqual(result['runtime_version'],'fixture-previous-version')
            self.assertEqual(result['restart_reasons'],['runtime_version_mismatch'])

    def test_unhealthy_daemon_retains_observed_endpoint_but_is_not_ready(self):
        with self.running_node() as server:
            state=self.n.load_state(); state['last_cycle_epoch']=0
            self.n.atomic_json(self.n.STATE,state)
            result=self.n.doctor(True)
            self.assertTrue(result['running']); self.assertFalse(result['ok'])
            self.assertTrue(result['stale']); self.assertFalse(result['health_ok'])
            self.assertFalse(result['restart_required'])
            self.assertEqual(result['active_api'],f'http://127.0.0.1:{server.server_port}')

    def test_foreign_session_and_false_health_cannot_qualify_service(self):
        with self.running_node({'session':'foreign-session'}):
            result=self.n.doctor(True)
            self.assertFalse(result['running']); self.assertFalse(result['ok'])
            self.assertIsNone(result['active_api']); self.assertIsNone(result['runtime_matches'])
        with self.running_node({'ok':False}):
            result=self.n.doctor(True)
            self.assertTrue(result['running']); self.assertFalse(result['health_ok'])
            self.assertFalse(result['ok'])

    def test_offline_qualification_is_explicit_and_does_not_claim_ai_ready(self):
        result=self.n.doctor()
        self.assertTrue(result['ok']); self.assertFalse(result['running'])
        self.assertIsNone(result['active_api']); self.assertIsNone(result['runtime_version'])
        self.assertIsNone(result['configuration_matches']); self.assertFalse(result['restart_required'])
        self.assertEqual(result['qualification'],'local_integrity_and_basal_service')
        self.assertIn('provider_authentication',result['not_checked'])
        self.assertIn('provider_quota',result['not_checked'])

class HTTPTests(NodeHarness):
    def test_http_health_authority_and_process_singleton(self):
        with socket.socket() as sock: sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
        self.n.atomic_json(self.n.POLICY,{'http_port':port,'min_sleep_seconds':1,'max_sleep_seconds':2})
        proc=subprocess.Popen([sys.executable,str(NODE),'daemon'],env=self.env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        base=f'http://127.0.0.1:{port}'
        try:
            for _ in range(80):
                try:
                    page=urllib.request.urlopen(base,timeout=.3).read().decode(); break
                except OSError: time.sleep(.05)
            else: self.fail('daemon did not start')
            self.assertTrue(json.load(urllib.request.urlopen(base+'/health'))['ok'])
            self.assertIn('Des mots au modèle',urllib.request.urlopen(base+'/lexicon').read().decode())
            self.assertEqual(json.load(urllib.request.urlopen(base+'/theory'))['meta']['version'],self.n.THEORY['version'])
            duplicate=self.cli('daemon',check=False); self.assertNotEqual(duplicate.returncode,0)
            bad=urllib.request.Request(base+'/state',headers={'Host':'attacker.test'})
            with self.assertRaises(urllib.error.HTTPError) as err: urllib.request.urlopen(bad)
            self.assertEqual(err.exception.code,403)
            bootstrap=json.loads(re.search(r'<script id="tao-bootstrap" type="application/json">(.*?)</script>',page,re.S).group(1))
            token=bootstrap['token']
            for headers in [{},{'X-Tao-Token':token,'Origin':'https://attacker.test'}]:
                req=urllib.request.Request(base+'/api/story',data=b'{"text":"bad"}',headers=headers)
                with self.assertRaises(urllib.error.HTTPError) as err: urllib.request.urlopen(req)
                self.assertEqual(err.exception.code,403)
            req=urllib.request.Request(base+'/api/story',data=b'{"text":"My local story"}',headers={'X-Tao-Token':token,'Content-Type':'application/json'})
            self.assertEqual(json.load(urllib.request.urlopen(req))['text'],'My local story')
            trace={'source':'contrainte','destination':'action','input':'seuil franchi','output':'continuer','difference':'signal perdu'}
            payload={'residual':'signal perdu','desired':'arrêter','acceptance':'action arrêtée','origin_type':'translation','trace':trace}
            req=urllib.request.Request(base+'/api/buffers',data=json.dumps(payload).encode(),headers={'X-Tao-Token':token,'Content-Type':'application/json'})
            recorded=json.load(urllib.request.urlopen(req))
            self.assertEqual(recorded['origin_hypothesis']['status'],'hypothesis')
            self.assertEqual(recorded['origin_traces'][0]['trace'],trace)
            page=urllib.request.urlopen(base+'/?view=dialogue').read().decode()
            self.assertIn('<select id="origin">',page)
            def post(path,payload):
                req=urllib.request.Request(base+path,data=json.dumps(payload).encode(),headers={'X-Tao-Token':token,'Content-Type':'application/json'})
                return json.load(urllib.request.urlopen(req))
            for endpoint in ['/api/work/context','/api/work/tasks','/api/work/example','/api/adaptation','/api/learning/report','/api/learning/method','/api/learning/withdraw','/api/dialogue/send','/api/dialogue/memory','/api/dialogue/prepare','/api/dialogue/remember','/api/dialogue/cancel','/api/dialogue/new','/api/worlds/create','/api/worlds/transfer','/api/worlds/presentation','/api/continuity/settings','/api/continuity/note','/api/continuity/need']:
                req=urllib.request.Request(base+endpoint,data=b'{}')
                with self.assertRaises(urllib.error.HTTPError) as err: urllib.request.urlopen(req)
                self.assertEqual(err.exception.code,403)
            profile=post('/api/work/context',{'description':'Je traite les tickets.','keep_learning':'Coder','boundaries':'Ne pas envoyer','revision':0})
            self.assertEqual(profile['authority'],'description_only')
            page=urllib.request.urlopen(base+'/?view=dialogue').read().decode(); self.assertIn('Quelle première tâche',page)
            task=post('/api/work/tasks',{'title':'Préparer les réponses'})
            page=urllib.request.urlopen(base+'/?view=dialogue').read().decode(); self.assertIn('Donne-moi un exemple',page)
            example=post('/api/work/example',{'id':task['id'],'situation':'Page vide','expected':'Demander URL et étapes','revision':1})
            self.assertEqual(example['status'],'open')
            page=urllib.request.urlopen(base+'/?view=dialogue').read().decode(); self.assertIn('Exemple enregistré',page)
            self.assertIn('Demander URL et étapes',urllib.request.urlopen(base+'/work/brief').read().decode())
            self.assertTrue(self.n.doctor(True)['ok'])
        finally:
            proc.terminate(); proc.wait(timeout=8); proc.stdout.close(); proc.stderr.close()
    def test_port_collision_fails_instead_of_headless_success(self):
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0)); sock.listen()
            self.n.atomic_json(self.n.POLICY,{'http_port':sock.getsockname()[1]})
            self.assertNotEqual(self.cli('daemon',check=False).returncode,0)

class WorkshopTests(NodeHarness):
    def prepare(self):
        repo=self.base/'repo'; repo.mkdir(); (repo/'scripts').mkdir()
        (repo/'value.txt').write_text('old\n'); (repo/'scripts/verify.sh').write_text('set -eu\ntest "$(cat value.txt)" = new\n')
        workshop.git(repo,'init'); workshop.git(repo,'add','.')
        workshop.git(repo,*workshop.identity_args(),'commit','-m','initial')
        b=self.n.add_buffer('value est old','value devient new','Le test attend new')
        w=workshop.Workshop(self.n); e=w.prepare(repo,b['id'])
        return repo,w,e
    def test_full_experiment_accept_and_history_preserving_rollback(self):
        repo,w,e=self.prepare(); d=Path(e['candidate']); (d/'value.txt').write_text('new\n')
        self.assertEqual((repo/'value.txt').read_text(),'old\n')
        with self.assertRaises(ValueError): w.verify(e['id'])
        checked=w.verify(e['id'],True); self.assertEqual(checked['status'],'verified',checked)
        w.accept(e['id']); self.assertEqual((repo/'value.txt').read_text(),'new\n')
        self.assertEqual(self.n.load_state()['buffers'][e['buffer_id']]['status'],'open')
        w.rollback(e['id']); self.assertEqual((repo/'value.txt').read_text(),'old\n')
        self.assertEqual(int(workshop.git(repo,'rev-list','--count','HEAD')),3)
    def test_failed_tests_block_acceptance(self):
        repo,w,e=self.prepare(); (Path(e['candidate'])/'value.txt').write_text('wrong')
        self.assertEqual(w.verify(e['id'],True)['status'],'test_failed')
        with self.assertRaises(ValueError): w.accept(e['id'])
        self.assertEqual((repo/'value.txt').read_text(),'old\n')
    def test_modified_candidate_invalidates_verification(self):
        repo,w,e=self.prepare(); d=Path(e['candidate']); (d/'value.txt').write_text('new\n'); w.verify(e['id'],True)
        (d/'value.txt').write_text('changed after verification')
        with self.assertRaises(ValueError): w.accept(e['id'])
    def test_new_source_commit_invalidates_acceptance(self):
        repo,w,e=self.prepare(); d=Path(e['candidate']); (d/'value.txt').write_text('new\n'); w.verify(e['id'],True)
        (repo/'other.txt').write_text('preserve'); workshop.git(repo,'add','.'); workshop.git(repo,*workshop.identity_args(),'commit','-m','user change')
        with self.assertRaises(ValueError): w.accept(e['id'])
    def test_agent_absent_does_not_fake_a_result(self):
        repo,w,e=self.prepare()
        from unittest.mock import patch
        with patch('tao_workshop.shutil.which',return_value=None):
            with self.assertRaises(ValueError): w.run(e['id'])
        self.assertEqual(w.load(e['id'])['status'],'prepared')
    def test_codex_adapter_with_fake_cli(self):
        repo,w,e=self.prepare(); exe=self.base/'codex'
        exe.write_text('#!/usr/bin/env python3\nimport sys\nfrom pathlib import Path\nassert sys.argv[1:4]==["exec","--sandbox","workspace-write"]\nassert "résidu" in sys.stdin.read()\nPath("value.txt").write_text("new\\n")\nprint("fixture only")\n'); exe.chmod(0o700)
        from unittest.mock import patch
        with patch('tao_workshop.shutil.which',return_value=str(exe)): result=w.run(e['id'])
        self.assertEqual(result['status'],'review',result)
        self.assertEqual((repo/'value.txt').read_text(),'old\n')
    def test_watch_stops_at_explicit_budget(self):
        repo,w,e=self.prepare()
        self.n.add_buffer('Second problem','Next goal','Reproducible test')
        from unittest.mock import patch
        with patch.object(w,'run',return_value={'status':'review'}) as run:
            result=w.watch(repo,max_runs=1,interval=60,hours=1)
        self.assertEqual(run.call_count,1)
        self.assertFalse(result['automatic_integration'])
    def test_watch_rejects_unbounded_parameters(self):
        w=workshop.Workshop(self.n)
        with self.assertRaises(ValueError): w.watch(self.base,max_runs=999)
    def test_workshop_ids_reject_path_traversal(self):
        with self.assertRaises(ValueError): workshop.Workshop(self.n).load('../state')

if __name__=='__main__': unittest.main()
