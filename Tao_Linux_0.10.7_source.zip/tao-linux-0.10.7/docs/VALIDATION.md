# Qualification courante — Tao 0.10.7

## Changement qualifié

Le résidu reproductible était une documentation distribuée en 38 fichiers,
parfois contradictoires, ainsi qu’un contrat machine contenant encore des
références doctrinales sans rôle dans le runtime.

Résultat souhaité : une documentation humaine courte et technique, sans ces
références, tout en conservant le modèle seed + héritage, les centres, les cas
non intégrés et les procédures d’exploitation.

Contraintes : aucune migration de mémoire privée, aucun appel IA, aucune
dépendance installée, aucun déploiement et aucun effacement silencieux d’un
pointeur canonique inconnu.

Preuve attendue :

- le `README` et `docs/TECHNICAL.md` couvrent le produit, l’architecture, les
  données, l’autorité, la sauvegarde, les mises à jour et la publication ;
- aucune référence locale ne vise un document retiré ;
- le contrat machine 4.3 est intègre et les pointeurs connus 4.1/4.2 migrent avec
  un reçu ;
- le runtime, l’installation, la release et le front-end passent le gate complet.

Contre-exemple conservé : un pointeur canonique arbitraire ne doit pas être
remplacé au prétexte du nettoyage. Il reste visible comme erreur et résidu. De
même, le mot technique « centre » reste valide ; supprimer tout le modèle parce
que certaines anciennes analogies étaient inutiles serait une perte de domaine.

Coût de complexité : un seul document technique, une migration de métadonnée
canonique et des tests de compatibilité. Aucun schéma de l’état utilisateur ne
change. Le retour arrière est le runtime précédent déjà conservé par
l’installateur ou le revert Git de ce changement.

## Résultats

Gate final exécuté sur Linux avec Python 3.12.3 :

```text
bash scripts/verify.sh
Ran 769 tests in 202.663s
OK
```

La construction locale de `tao.release.v2` a également produit une release
0.10.5 avec `minimum_runtime: 0.10.4` et `state_migrations: []`. Les tests
d’installation ont qualifié le runtime dans un état jetable, puis vérifié la
conservation de l’état et du runtime précédent.

Le contre-exemple du pointeur inconnu est couvert : il reste inchangé, `doctor`
échoue et le résidu `theory.local` reste ouvert. Les pointeurs exacts 4.1 et 4.2
produisent au contraire `theory-migration-4.3.json` avant leur remplacement.

Les comptes fournisseur, appareils réels, hébergements et réponses de modèle
restent hors de cette qualification locale. Aucun déploiement ni publication
n’a été effectué.

## Expérience qualifiée — un cockpit web et installable

Histoire et résidu reproductible : le propriétaire veut présenter le même Tao
dans un navigateur et comme application d’ordinateur, puis relier explicitement
les capacités d’une machine. Le cockpit fonctionnait déjà dans un navigateur et
le moteur Linux existait, mais l’installation comme application n’était pas
déclarée et l’accès aux appareils restait enfoui dans les détails.

Résultat souhaité : conserver une seule interface, installable en fenêtre
autonome par un navigateur compatible, avec un accès visible à **Appareils** dans
la conversation. Le manifeste ne doit ni accorder un droit système, ni prétendre
qu’une machine est reliée, ni conserver la mémoire privée hors ligne.

Contraintes : aucune migration, aucun second front-end natif, aucun service
worker, aucun appel IA ou appairage au chargement, aucune exécution implicite et
aucun accès général du navigateur aux fichiers ou processus locaux.

Preuve attendue : le manifeste et ses icônes sont livrés par le runtime exact,
le cockpit les référence, la reconstruction front-end les reproduit, le lien
**Appareils** atteint le parcours d’appairage existant et le gate complet reste
vert.

Coût de complexité : quatre actifs statiques sources, leurs quatre projections
compilées, quatre routes statiques et un lien dans le cockpit. Le moteur
d’appairage, les centres et la mémoire ne changent pas. Le retour arrière est la
suppression de ces actifs/routes et du lien, ou la réactivation du runtime
précédent conservé par l’installateur.

Résultats du 1er octobre 2026 :

```text
npm run build --prefix frontend
16 modules transformed — build OK

PYTHONPATH=tests:bootstrap python3 -m unittest -v \
  test_centers_app test_centers_http test_runtime
Ran 16 tests in 2.123s — OK

PYTHONPATH=tests:bootstrap python3 -m unittest -v test_install
Ran 6 tests in 23.299s — OK

bash scripts/verify.sh
Ran 769 tests in 233.769s — OK

tao doctor --require-running
ok=true, running=true, runtime_matches=true, external_ai_auto=false
```

Le manifeste répond en HTTP 200 avec `display: standalone`. Les icônes PNG
192×192 et 512×512 répondent en HTTP 200, et le bundle actif contient le lien
`/devices`. L’authentification fournisseur, l’exécution sur un appareil appairé
et la promotion effective de l’installation par chaque navigateur restent
explicitement hors de cette preuve.

Contre-exemple conservé : placer ces actifs uniquement dans le dossier compilé
a d’abord fait échouer deux tests, car Vite efface ce dossier avant chaque build.
Cette erreur n’a pas été requalifiée en succès. Les sources vivent désormais
dans `frontend/public` et la reconstruction les copie dans le runtime ; leur
disparition future referait échouer l’inventaire et les routes HTTP.

## Expérience — lancement graphique Debian/Ubuntu

Histoire et résidu reproductible : une personne non technique veut télécharger
Tao puis l’ouvrir depuis son menu d’applications. L’installateur `.run` est
autonome, mais le parcours exige encore un terminal et ne constitue donc pas une
installation graphique reproductible.

Résultat souhaité : un paquet Debian `all` ouvrable avec la logithèque installe
une entrée **Tao** sans créer de mémoire en tant que root. Au premier lancement,
un petit programme vérifie l’archive source, installe le runtime dans le compte
de la personne, exige un `doctor --require-running` réel, puis ouvre uniquement
l’adresse loopback confirmée. Une seconde ouverture ne réinstalle rien.

Contraintes : Debian/Ubuntu seulement pour cette expérience ; Python 3.9+ reste
un prérequis du système ; aucune dépendance ajoutée au dépôt, aucun appel IA,
aucune migration, aucune publication d’un exécutable non signé et aucune
prétention de prise en charge des autres systèmes.

Preuve ciblée exécutée le 1er octobre 2026 :

```text
PYTHONPATH=tests:bootstrap python3 -m unittest -v \
  test_desktop_package test_install test_release_safety
Ran 21 tests in 35.998s — OK
```

Le paquet est déterministe, accepté par `dpkg-deb --info`, contient quatre
éléments explicites et ouvre un vrai runtime temporaire. La deuxième ouverture
conserve la même session et ne crée pas `runtime.previous`.

Contre-exemple conservé : une archive portant une autre empreinte est refusée
avant extraction, sans modifier le marqueur privé existant. Les autres
distributions Linux, Windows et macOS restent non intégrés. Le premier test de
reproductibilité avait aussi échoué parce que son assertion dépendait du choix
de guillemets du générateur ; le paquet était correct et le test vérifie
désormais la constante dans l’arbre syntaxique, pas son formatage textuel.

Coût de complexité : un lanceur Python sans bibliothèque tierce, un constructeur
de paquet déterministe et trois tests. Aucun schéma privé ni runtime basal ne
change. Le retour arrière consiste à désinstaller `tao-local`; les sources et
la mémoire du compte restent volontairement présentes pour éviter toute perte.

## Expérience — action exacte d’un centre vers un outil existant

Histoire et résidu reproductible : dans un centre de travail, la conversation
pouvait décrire un organe mais répondait encore qu’elle ne pouvait pas utiliser
un outil déjà installé. Le propriétaire devait quitter le centre et reconstruire
manuellement la même demande. À l’inverse, donner à la réponse IA un accès direct
aurait confondu proposition, permission et exécution.

Résultat souhaité : l’IA d’un centre peut préparer un appel exact vers un outil
MCP déjà inspecté. Le milieu de l’écran montre d’abord le connecteur, l’outil,
les arguments, le résultat attendu, le risque et le retour arrière. Seul le clic
du propriétaire exécute ou écarte l’appel ; le reçu et le résultat externe
restent ensuite visibles dans ce centre.

Contraintes : aucun connecteur métier fourni par défaut, aucun secret ou commande
dans le contexte IA, aucune permission nouvelle, aucun polling, mandat récurrent,
réessai ou appel IA automatique. Un indice `readOnly` fourni par un serveur ne
vaut pas autorisation. La configuration MCP garde les droits du compte Linux et
reste séparée du centre.

Preuve attendue : sans clic, l’inspection et la proposition ne produisent aucun
`tools/call`. Une requête sans confirmation est refusée. Après revue exacte, un
seul appel part, son reçu est attribué comme donnée externe non vérifiée, et un
second clic ne peut pas le rejouer. Le front-end doit reconstruire les cartes de
revue et les reçus depuis les sources TypeScript.

Preuves ciblées exécutées le 1er octobre 2026 :

```text
npm run build --prefix frontend
16 modules transformed — build OK

PYTHONPATH=tests:bootstrap python3 -m unittest -v \
  test_centers_dialogue.CenterDialogueTests.test_malformed_action_arguments_keep_the_reply_and_create_no_action \
  test_centers_http.CenterHTTPTests.test_center_tool_call_is_exact_owner_review_and_runs_only_after_click \
  test_centers_http.CenterHTTPTests.test_changed_tool_catalog_rejects_the_frozen_action_without_a_request
Ran 3 tests in 0.757s — OK

bash scripts/verify.sh
Ran 775 tests in 222.453s — OK
```

Contre-exemples conservés : des clés JSON d’arguments dupliquées sont refusées
sans perdre la réponse conversationnelle ; un catalogue modifié pendant la
réponse rend la proposition caduque sans créer de nouvelle demande ; une
confirmation absente ne produit aucun appel. Un résultat interrompu et incertain
reste `unknown` et n’est jamais relancé.

Coût de complexité : une forme de réponse optionnelle `center_action`, une route
propriétaire, une carte de revue et une projection bornée du reçu. Le registre
MCP existant porte l’idempotence et l’exécution ; aucune dépendance ni mutation
du schéma privé n’est ajoutée. Le retour arrière consiste à retirer cette forme,
sa route et ses projections ; les reçus MCP déjà conservés restent lisibles dans
**Outils**.

## Expérience — un reçu comme entrée explicite du centre suivant

Histoire et résidu reproductible : après une action relue et terminée, son reçu
restait enfermé dans le centre source. La personne pouvait le lire, mais devait
le recopier pour demander une transformation complémentaire à un autre centre.
Faire circuler automatiquement toutes les sorties aurait au contraire confondu
liaison, traitement, permission et résolution.

Résultat souhaité : depuis un reçu terminal, **Utiliser dans…** ouvre uniquement
une destination déjà reliée et prépare ce reçu comme entrée. La personne écrit
et envoie encore sa demande. Le centre destination reçoit alors une copie bornée
du résultat externe, la provenance de l’action et la traduction du lien.

Contraintes : lien dirigé existant, reçu exact et terminal, destination courante,
résultat toujours qualifié de donnée externe non vérifiée. Le clic de préparation
ne modifie aucun registre, n’appelle aucun modèle ou outil et ne confère aucune
permission. Les reçus écartés ne deviennent pas des entrées.

Preuve attendue : une action en attente n’apparaît pas dans la destination ; après
un seul appel confirmé, son reçu y apparaît avec une référence minimale. Le même
reçu est refusé dans le centre source, avec un faux identifiant ou un mauvais lien.
L’envoi humain fige ensuite le contexte sans produire un second `tools/call`, et
la sortie proposée conserve l’entrée comme reçu externe attribué.

Preuves ciblées exécutées le 1er octobre 2026 :

```text
npm run build --prefix frontend
16 modules transformed — build OK

PYTHONPATH=bootstrap:tests python3 -m unittest \
  test_centers test_centers_app test_centers_dialogue test_centers_http
Ran 38 tests in 8.462s — OK

bash scripts/verify.sh
Ran 775 tests in 206.225s — OK
```

Contre-exemple conservé : un reçu encore `review` reste absent du centre suivant ;
une référence falsifiée ou utilisée dans le sens inverse du lien échoue au lieu
d’afficher un indicateur positif. Répéter un reçu ne prouve pas que la seconde
fonction l’a traité ni que l’histoire est résolue.

Coût de complexité : une seconde forme additive de `input_reference`, une
résolution bornée et un bouton de navigation. Aucun schéma privé, endpoint,
connecteur ou dépendance n’est ajouté, donc aucune migration n’est nécessaire.
Le retour arrière retire cette projection et ce bouton ; les messages déjà figés
restent des données attribuées dans la mémoire privée et ne sont pas effacés.

## Expérience — une hiérarchie lisible sans enfermer les centres

Histoire et résidu reproductible : la navigation savait déjà conserver un
`parent_id` et des liens entre centres, mais l’écran les présentait presque à plat
et le contexte du modèle n’expliquait pas leur différence. Une répétition, un
statut ou un domaine risquait alors de devenir un faux sous-centre ; inversement,
un échange entre deux fonctions distinctes risquait d’être pris pour une
filiation.

Résultat souhaité : une seule filiation compose le travail de C0 vers les centres
et sous-centres. Chaque centre a donc un chemin lisible et au plus un parent. Les
échanges de sortie vers entrée restent des liens dirigés qui peuvent traverser
les branches. Domaine, maturité, rythme et ordres de variation restent des vues
calculées à partir des centres et de leurs traces, pas des taxonomies à maintenir.

Contraintes : aucun nombre ou type de centres imposé, aucun dossier-centre, aucune
création automatique, aucune permission ou exécution héritée du parent. Les liens
ne changent ni la filiation, ni la mémoire privée, ni l’autorité. La projection
reste bornée et ne modifie ni le schéma privé ni le runtime basal.

Preuve attendue : le menu et le fil d’Ariane donnent le même chemin ; le tiroir
montre le parent, les enfants directs et le sens de chaque traduction. Le contexte
du modèle reçoit les mêmes `parent_id` et règles de distinction. Un parent absent,
un cycle ou un lien réflexif échoue visiblement au lieu d’inventer une catégorie.

Preuves exécutées le 1er octobre 2026 :

```text
npm test --prefix frontend
6 tests — OK

npm run build --prefix frontend
17 modules transformed — build OK

PYTHONPATH=bootstrap:tests python3 -m unittest -v \
  test_centers.CenterTests.test_hierarchy_links_and_private_worlds_are_sparse_and_scoped \
  test_centers.CenterTests.test_browser_script_is_valid_and_center_focus_stays_bounded \
  test_centers_app
Ran 6 tests in 1.056s — OK

bash scripts/verify.sh
Ran 775 tests in 200.898s — OK

~/.local/bin/tao doctor --require-running
ok=true, running=true, runtime_matches=true, external_ai_auto=false
```

Contre-exemple conservé : deux centres de branches différentes peuvent échanger
un reçu par un lien dirigé sans que l’un devienne l’enfant de l’autre. À
l’inverse, répéter un sujet ou partager le statut `candidate` ne crée aucun
parent. Les dimensions transversales et les vues globales restent non intégrées
tant qu’une histoire réelle ne justifie pas la plus petite vue utile.

Coût de complexité : un dérivateur TypeScript pur, trois tests, un fil d’Ariane
et une section de tiroir ; deux champs de contexte déjà présents dans le registre
sont désormais projetés. Aucun nouveau stockage, endpoint, appel IA ou dépendance
n’est ajouté. Le retour arrière retire ces projections et règles d’affichage ;
les centres, leurs filiations et leurs liens existants restent intacts.

## Expérience — partager le contrat visible d’un centre

Histoire et résidu reproductible : une organisation peut décrire de bonnes
pratiques, mais la personne devait les recopier dans chaque centre ou les laisser
dans un document séparé. Importer librement un document comme instruction aurait
confondu source, contrat local, autorité et permission ; créer une seconde pile
de « contrats » aurait aussi dupliqué la définition déjà portée par le centre.

Résultat souhaité : le contrat visible `x → processus → f(x)` d’un centre peut
être exporté dans une enveloppe JSON bornée. Depuis C0, son import prépare un
nouveau centre candidat ; depuis un centre, il prépare une révision candidate.
L’aperçu montre les huit champs exacts avant la confirmation du propriétaire.

Contraintes : l’enveloppe ne contient ni cas, mémoire, organe, compte, secret,
commande, mandat ou permission. La source est déclarée, jamais authentifiée par
la seule empreinte SHA-256. Un import ne lance ni IA, ni outil, ni réseau. Une
modification concurrente invalide la revue et un contrat identique reste un
no-op. Les PDF, documents juridiques et signatures d’organisation restent hors
de cette première expérience.

Preuve attendue : l’export ne modifie pas l’état et ne contient que la définition
publique. L’aperçu est lui aussi sans écriture. L’import sans confirmation, avec
une empreinte altérée, des clés JSON dupliquées ou une révision périmée est
refusé. Après confirmation exacte, le contrat précédent reste dans l’historique,
le centre redevient candidat et aucune exécution n’est activée.

Preuves ciblées exécutées le 2 octobre 2026 :

```text
npm test --prefix frontend
6 tests — OK

npm run build --prefix frontend
17 modules transformed — build OK

PYTHONPATH=bootstrap:tests python3 -m unittest -v \
  test_centers test_centers_app test_centers_dialogue test_centers_http
Ran 41 tests in 8.698s — OK

bash scripts/verify.sh
Ran 778 tests in 191.110s — OK

~/.local/bin/tao doctor --require-running
ok=true, running=true, runtime_matches=true, external_ai_auto=false
```

Contre-exemple conservé : remplacer dans le fichier une limite par « autoriser
tout sans revue » sans recalculer son identité est refusé avant tout aperçu. Une
empreinte valide ne prouverait toutefois toujours pas que « Skazy » en est
réellement l’auteur ; cette authenticité demandera plus tard une signature et
une clé obtenue séparément.

Coût de complexité : une enveloppe versionnée, trois routes propriétaires, une
section discrète dans le tiroir et trois tests de parcours. Le centre continue à
utiliser sa définition et son historique existants : aucun schéma privé, aucune
migration et aucune dépendance ne sont ajoutés. Le retour arrière retire les
routes et l’interface ; un contrat déjà importé reste une définition de centre
v1 ordinaire, lisible par le runtime précédent.

## Expérience — réunir équipement et autorité sans alourdir le centre

Histoire et résidu reproductible : le processus était visible dans la fonction,
les organes préparés dans une section distincte et la règle de revue humaine dans
une troisième. Une personne décrivant son processus de travail ne pouvait donc
pas lire d’un regard le rôle de l’IA, les moyens nécessaires et leurs effets ; le
tiroir accumulait en parallèle des explications et des contrôles de partage.

Résultat souhaité : le contrat du centre conserve `x → processus → f(x)` et ses
preuves. Une seule section compacte « Équipement et règles » résume l’IA de
conversation, le nombre d’agents ou outils préparés et l’autorité humaine. Son
détail replié montre les prérequis, effets demandés, limites et état de chaque
organe. L’import/export de la seule fonction devient une option avancée repliée.

Contraintes : l’IA reste un agent de proposition. Un agent spécialisé ou un
outil est toujours un plan d’organe inerte ; `read`, `write`, `execute`, `network`
et `interactive_ui` restent des besoins déclarés, jamais des droits accordés.
Aucun compte, secret, connecteur, permission, appel IA basal ou exécution n’est
créé. Le processus métier ne reçoit pas de configuration technique cachée.

Preuve attendue : le client compilé expose le contrat, l’équipement et la
distinction « demandé · non accordé ». Le contexte donné à l’IA sépare étapes
métier, organes et autorité. Une proposition d’organe reste soumise au même
parcours de revue et conserve `execution_enabled=false`.

Preuves ciblées exécutées le 2 octobre 2026 :

```text
npm run typecheck --prefix frontend
OK

npm test --prefix frontend
6 tests — OK

npm run build --prefix frontend
17 modules transformed — build OK

PYTHONPATH=bootstrap:tests python3 -m unittest -v \
  test_centers.CenterTests.test_hierarchy_links_and_private_worlds_are_sparse_and_scoped \
  test_centers_dialogue.CenterDialogueTests.test_center_chat_prepares_provider_neutral_organ_without_implementing_it \
  test_centers_http.CenterHTTPTests.test_page_and_empty_api_are_read_only_and_never_start_ai
Ran 3 tests in 0.641s — OK

bash scripts/verify.sh
Ran 778 tests in 181.373s — OK

~/.local/bin/tao doctor --require-running
ok=true, running=true, runtime_matches=true, external_ai_auto=false
```

Contre-exemple conservé : un plan « agent de développement » peut demander
écriture et réseau tout en n’ayant ni connecteur installé ni permission. Tao doit
alors montrer ce plan parmi les moyens prévus et afficher « demandé · non
accordé » ; il ne doit jamais le présenter comme disponible ou autonome.

Coût de complexité : un composant React de projection, des libellés et styles,
et deux règles de contexte supplémentaires. Les sections organes et autonomie
existantes sont réunies ; le partage est replié. Aucun champ persistant, endpoint,
format d’organe ou dépendance n’est ajouté, donc aucune migration n’est requise.
Le retour arrière est uniquement graphique et rédactionnel ; tous les centres,
organes, historiques et permissions existants restent identiques.

## Expérience — livrer Tao depuis une Gaia publique signée

Histoire et résidu reproductible : le propriétaire veut tester le parcours
public de bout en bout, mais Gaia ne publie actuellement qu’une archive source
de revue. L’installeur local existe sans signature, le dépôt de développement
est privé et aucune adresse publique ne relie encore une personne à une version
authentifiée.

Résultat souhaité : publier Tao 0.10.6 sur un site statique séparé, avec
l’installeur Linux, l’archive source, leur manifeste et une signature Ed25519.
La clé privée reste uniquement sur la machine du propriétaire. Le
téléchargement public doit reproduire les octets qualifiés et l’installation
doit conserver l’état privé et le runtime précédent.

Contraintes : aucun secret, historique Git privé, compte, conversation ou
mémoire privée ne quitte la machine. Gaia reste inerte, sans compte serveur,
base de données, appel IA ou écriture publique. La prise en charge publiée se
limite à Linux avec Python 3.9+ ; le paquet graphique Debian/Ubuntu reste un
aperçu non signé et n’est pas proposé au téléchargement.

Preuve attendue : le gate complet est vert sur les sources committées ; la
construction Git stricte, la signature et sa vérification réussissent ; le site
reconstruit refuse tout artefact absent, altéré ou non signé. Après publication,
les ressources HTTPS ont les mêmes tailles et SHA-256 que le manifeste local,
et une installation jetable du fichier retéléchargé passe `doctor`.

Contre-exemple conservé : un installeur valide localement mais sans signature,
ou dont un octet diffère après signature, ne doit jamais devenir le bouton de
téléchargement. Windows, macOS et les Linux sans Python 3.9 restent visibles
comme non intégrés plutôt que d’être annoncés compatibles.

Coût de complexité : un incrément de version, une paire de clés locale et un
dépôt public contenant uniquement le bundle statique construit. Aucun schéma
privé, service dynamique ou dépendance n’est ajouté. Le retour arrière consiste
à retirer la publication 0.10.6 et à conserver le runtime précédent ; une clé
compromise impose une nouvelle clé distribuée par un canal indépendant.

Qualification locale du 2 octobre 2026, avant signature et publication :

```text
PYTHONPATH=bootstrap:tests python3 -m unittest -v \
  test_update test_gaia_build test_gaia_catalogue
Ran 37 tests in 2.884s — OK

bash scripts/verify.sh
Ran 778 tests in 226.425s — OK
```

Le contre-exemple de version a été observé réellement : trois fixtures
présentaient encore 0.10.6 comme une mise à jour future. Une fois le runtime
passé en 0.10.6, Tao les a refusées comme versions non plus récentes. Les tests
ont été corrigés pour proposer 0.10.7 ; la règle de refus n’a pas été
affaiblie. Les preuves HTTPS et d’installation retéléchargée restent à ajouter
après la publication effective.

## Expérience — installer Tao graphiquement sur Debian et Ubuntu

Histoire et résidu reproductible : une personne non technique pouvait
télécharger Tao depuis Gaïa, mais l’installation publique exigeait encore
d’ouvrir un terminal et de lancer le fichier `.run`. Le paquet `.deb` local
existait seulement comme aperçu non signé et ne pouvait donc pas être proposé
honnêtement sur le site.

Résultat souhaité : sur Debian ou Ubuntu, un clic télécharge un paquet signé
qui s’ouvre avec la logithèque et ajoute Tao au menu des applications. Le
premier lancement installe le même runtime local qualifié, attend un `doctor`
positif puis ouvre son adresse loopback. Le `.run` reste disponible pour les
autres Linux et pour les mises à jour explicites.

Contraintes : le manifeste principal `tao.release.v2` conserve exactement ses
deux artefacts afin de rester lisible par Tao 0.10.6. Le paquet possède une
enveloppe additive, liée par SHA-256 à ce manifeste et signée séparément avec
la même clé Ed25519. Aucune mémoire privée, permission, connexion fournisseur,
migration ou IA automatique n’est ajoutée. Debian et Ubuntu sont les seuls
systèmes annoncés ; Windows, macOS et les autres distributions restent non
intégrés.

Preuve attendue : la construction est déterministe ; `dpkg-deb` reconnaît le
paquet ; le lanceur extrait l’archive signée, installe dans un compte jetable et
obtient un runtime sain. Gaïa ne publie jamais un candidat non signé, altéré,
lié à une autre release ou signé par une autre clé. Le site signé expose les
octets exacts du paquet et ses preuves, et l’interface masque le bouton si leur
contrat est incohérent.

Preuves ciblées exécutées le 2 octobre 2026 :

```text
PYTHONPATH=bootstrap:tests python3 -m unittest -v \
  test_release_signing test_desktop_package test_gaia_build test_gaia_ui \
  test_install test_update test_node
Ran 108 tests in 69.498s — OK

bash scripts/verify.sh
Ran 783 tests in 222.836s — OK
```

Contre-exemple conservé : la simple présence d’un `.deb` dans `dist/`, même
valide pour `dpkg-deb`, ne le rend pas publiable. Sans manifeste de bureau,
liaison exacte et signature vérifiée sous la clé externe choisie, Gaïa reste en
aperçu et n’expose pas le paquet. Une autre distribution Linux reste elle aussi
hors de la promesse graphique.

Coût de complexité : une enveloppe publique versionnée, deux petits fichiers de
preuve, un bouton conditionnel et la qualification du lanceur existant. Aucun
schéma ni état privé n’est muté, donc aucune migration n’est requise. Le retour
arrière consiste à retirer la publication 0.10.7 et à republier le tag 0.10.6 ;
les installations gardent en plus leur pointeur `runtime.previous`.
