#!/usr/bin/env python3
"""Small graphical Linux boundary for Tao's browser-based cockpit.

The Debian package installs this launcher and one verified source archive.  The
launcher itself owns no private state: it installs the regular per-user runtime,
checks its real health, then asks the desktop to open the loopback URL.
"""
from __future__ import annotations

import fcntl
import hashlib
import html
import io
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import tempfile
from urllib.parse import urlsplit
import webbrowser
import zipfile


VERSION = "@VERSION@"
SOURCE_ARCHIVE = Path("/usr/lib/tao/Tao_Linux_@VERSION@_source.zip")
SOURCE_SHA256 = "@SOURCE_SHA256@"
MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
MAX_EXPANDED_BYTES = 128 * 1024 * 1024
MAX_FILES = 512


class DesktopInstallError(RuntimeError):
    pass


def _read_regular(path: Path, expected_sha256: str) -> bytes:
    if not isinstance(expected_sha256, str) or len(expected_sha256) != 64:
        raise DesktopInstallError("Empreinte de l’archive absente ou invalide.")
    descriptor = None
    try:
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        before = os.fstat(descriptor)
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                or not 0 < before.st_size <= MAX_ARCHIVE_BYTES):
            raise DesktopInstallError("Archive Tao non régulière ou trop volumineuse.")
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            data = stream.read(MAX_ARCHIVE_BYTES + 1)
        after = os.fstat(descriptor)
    except OSError as exc:
        raise DesktopInstallError("Archive Tao absente ou inaccessible.") from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)
    identity = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    if (len(data) != before.st_size
            or any(getattr(before, field) != getattr(after, field) for field in identity)):
        raise DesktopInstallError("L’archive Tao a changé pendant sa lecture.")
    if not hashlib.sha256(data).hexdigest() == expected_sha256:
        raise DesktopInstallError("L’archive Tao ne correspond pas à la version attendue.")
    return data


def _archive_records(data: bytes, version: str) -> list[tuple[Path, bytes]]:
    prefix = "tao-linux-" + version
    records: list[tuple[Path, bytes]] = []
    seen: set[str] = set()
    expanded = 0
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            infos = archive.infolist()
            if not 1 <= len(infos) <= MAX_FILES:
                raise DesktopInstallError("Nombre de fichiers inattendu dans l’archive Tao.")
            for info in infos:
                name = PurePosixPath(info.filename)
                parts = name.parts
                mode = info.external_attr >> 16
                kind = stat.S_IFMT(mode)
                if (info.is_dir() or not parts or parts[0] != prefix
                        or len(parts) < 2 or any(part in {"", ".", ".."} for part in parts)
                        or "\\" in info.filename or info.flag_bits & 1
                        or (kind and not stat.S_ISREG(mode))):
                    raise DesktopInstallError("Chemin ou type de fichier invalide dans l’archive Tao.")
                relative = PurePosixPath(*parts[1:]).as_posix()
                if relative in seen:
                    raise DesktopInstallError("Fichier dupliqué dans l’archive Tao.")
                seen.add(relative)
                expanded += info.file_size
                if info.file_size > 8 * 1024 * 1024 or expanded > MAX_EXPANDED_BYTES:
                    raise DesktopInstallError("Contenu décompressé trop volumineux.")
                payload = archive.read(info)
                if len(payload) != info.file_size:
                    raise DesktopInstallError("Fichier incomplet dans l’archive Tao.")
                records.append((Path(*PurePosixPath(relative).parts), payload))
    except (zipfile.BadZipFile, RuntimeError, OSError) as exc:
        if isinstance(exc, DesktopInstallError):
            raise
        raise DesktopInstallError("Archive Tao illisible.") from exc
    return records


def extract_sources(data: bytes, home: Path, version: str = VERSION) -> tuple[Path, bool]:
    """Create an exact versioned source tree; never merge into changed sources."""
    records = _archive_records(data, version)
    root = home / ("tao-linux-" + version)
    if root.exists() or root.is_symlink():
        if root.is_symlink() or not root.is_dir():
            raise DesktopInstallError("Le dossier source Tao existant n’est pas un dossier sûr.")
        for relative, payload in records:
            target = root / relative
            if (target.is_symlink() or not target.is_file()
                    or target.read_bytes() != payload):
                raise DesktopInstallError(
                    "Les sources Tao existantes ont été modifiées ; elles sont conservées sans écrasement."
                )
        return root, False

    staging = Path(tempfile.mkdtemp(prefix=".tao-desktop-", dir=home))
    try:
        for relative, payload in records:
            target = staging / relative
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            descriptor = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
        if root.exists() or root.is_symlink():
            raise DesktopInstallError("Un dossier source Tao est apparu pendant l’installation.")
        staging.rename(root)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return root, True


def _validated_api(report: object, version: str) -> str | None:
    if (not isinstance(report, dict) or report.get("ok") is not True
            or report.get("running") is not True or report.get("runtime_version") != version
            or report.get("runtime_matches") is not True):
        return None
    value = report.get("active_api")
    if not isinstance(value, str):
        return None
    parsed = urlsplit(value)
    if (parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost"}
            or parsed.username or parsed.password or parsed.path not in {"", "/"}
            or parsed.query or parsed.fragment):
        return None
    return value.rstrip("/")


def _doctor(home: Path, env: dict[str, str], version: str) -> str | None:
    launcher = home / ".local" / "bin" / "tao"
    if launcher.is_symlink() or not launcher.is_file():
        return None
    try:
        result = subprocess.run(
            [str(launcher), "doctor", "--require-running"], env=env,
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            text=True, timeout=15, check=False,
        )
        if result.returncode:
            return None
        return _validated_api(json.loads(result.stdout), version)
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError, UnicodeError):
        return None


def install_and_open(source_archive: Path = SOURCE_ARCHIVE, expected_sha256: str = SOURCE_SHA256,
                     home: Path | None = None, opener=webbrowser.open,
                     env: dict[str, str] | None = None, version: str = VERSION) -> str:
    """Ensure one healthy local Tao, then open it. No model call occurs here."""
    if sys.platform != "linux":
        raise DesktopInstallError("Ce paquet graphique cible Debian et Ubuntu sous Linux.")
    if os.geteuid() == 0:
        raise DesktopInstallError("Lance Tao depuis ta session utilisateur, pas avec le compte administrateur.")
    home = (home or Path.home()).expanduser().resolve()
    if not home.is_dir():
        raise DesktopInstallError("Dossier personnel indisponible.")
    child_env = dict(os.environ if env is None else env)
    child_env["HOME"] = str(home)
    child_env.setdefault("XDG_CONFIG_HOME", str(home / ".config"))

    api = _doctor(home, child_env, version)
    if api is None:
        data = _read_regular(Path(source_archive), expected_sha256)
        lock_path = home / ".tao-desktop-install.lock"
        descriptor = os.open(lock_path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            with os.fdopen(descriptor, "a+", closefd=False) as lock:
                fcntl.flock(lock, fcntl.LOCK_EX)
                api = _doctor(home, child_env, version)
                if api is None:
                    source, created = extract_sources(data, home, version)
                    install_env = dict(child_env, TAO_INIT_SOURCE_GIT="1" if created else "0")
                    try:
                        result = subprocess.run(
                            [sys.executable, str(source / "bootstrap" / "install.py")],
                            env=install_env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True, timeout=180, check=False,
                        )
                    except subprocess.TimeoutExpired as exc:
                        raise DesktopInstallError("L’installation de Tao a dépassé trois minutes.") from exc
                    if result.returncode:
                        detail = (result.stderr or result.stdout or "échec sans détail").strip()[-3000:]
                        raise DesktopInstallError("Installation interrompue : " + detail)
                    api = _doctor(home, child_env, version)
                    if api is None:
                        raise DesktopInstallError("Tao a été installé, mais son état actif n’est pas confirmé.")
        finally:
            os.close(descriptor)
    if opener(api) is not True:
        raise DesktopInstallError("Tao fonctionne, mais aucun navigateur n’a accepté son ouverture.")
    return api


def show_error(error: Exception, opener=webbrowser.open) -> None:
    """Show a truthful local error page without requiring a GUI toolkit."""
    folder = Path(tempfile.mkdtemp(prefix="tao-desktop-error-"))
    folder.chmod(0o700)
    page = folder / "index.html"
    detail = html.escape(str(error)[:3000])
    page.write_text(
        "<!doctype html><html lang=fr><meta charset=utf-8><meta name=viewport "
        "content='width=device-width,initial-scale=1'><title>Tao — installation interrompue</title>"
        "<style>body{font:18px system-ui;max-width:720px;margin:12vh auto;padding:24px;color:#173c32}"
        "main{border:1px solid #ccd5cf;border-radius:20px;padding:32px;background:#fbfaf5}"
        "h1{font-family:Georgia,serif}pre{white-space:pre-wrap;background:#eef2ee;padding:16px;border-radius:12px}</style>"
        "<main><p>tao.</p><h1>Installation interrompue</h1>"
        "<p>Aucune réussite n’est déclarée et tes données existantes sont conservées.</p>"
        "<pre>" + detail + "</pre><p>Conserve cette page pour le diagnostic.</p></main></html>",
        encoding="utf-8",
    )
    page.chmod(0o600)
    opener(page.as_uri())


def main() -> int:
    if len(sys.argv) != 1:
        show_error(DesktopInstallError("Ce lanceur n’accepte aucun paramètre."))
        return 2
    try:
        install_and_open()
        return 0
    except (DesktopInstallError, OSError, ValueError) as exc:
        show_error(exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
