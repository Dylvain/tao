# Tao Linux 0.10.6

Tao est un logiciel local pour créer des centres de travail avec une IA. Un
centre reçoit une entrée `x`, applique un processus relu et prépare une sortie
`f(x)`. L’interface principale montre seulement les centres, le centre courant
et sa conversation.

Tao est aujourd’hui un noyau supervisé, pas un agent autonome universel. Une IA
peut proposer un centre, une sortie, un lien ou un outil, mais elle ne s’accorde
jamais elle-même un compte, une permission ou une action extérieure.

## Démarrer

Prérequis : Linux et Python 3.9 ou plus. Git est requis pour l’atelier de code.
Codex CLI est le premier fournisseur pris en charge par la conversation.

```bash
bash scripts/start.sh
~/.local/bin/tao doctor --require-running
```

Ouvrir **http://127.0.0.1:8790**. Le script indique l’adresse effective si le
port a été configuré autrement.

Le même cockpit peut rester dans un onglet ou être installé comme application
depuis un navigateur compatible. Cette installation n’ajoute aucun moteur : les
actions sur la machine passent toujours par le runtime Tao local ou par un Linux
explicitement appairé depuis **Appareils**.

Une première enveloppe graphique pour Debian et Ubuntu peut être construite par
le mainteneur :

```bash
python3 scripts/build_release.py
python3 scripts/build_linux_desktop.py
```

Le fichier `dist/Tao_Linux_0.10.6_preview_all.deb` s’ouvre avec la logithèque,
ajoute Tao au menu des applications, puis installe et démarre le runtime dans le
compte de la personne au premier lancement. Cet artefact reste un aperçu local
non signé : il ne doit pas être présenté comme téléchargement public vérifié.

L’installation sépare :

- les sources choisies par le propriétaire ;
- le runtime immuable installé sous `~/.tao/genesis/releases` ;
- l’état privé conservé sous `~/.tao/genesis`.

Elle garde le runtime précédent et n’appelle aucune IA dans la boucle basale.

## Utiliser Tao

Une installation neuve contient un seul proto-centre `C₀`. Aucun nombre fixe de
centres n’est imposé.

1. Décrire dans `C₀` une entrée réelle et la sortie attendue.
2. Relire le contrat proposé : entrée, processus, sortie, bénéfice, preuve et
   limites.
3. Créer un centre spécialisé uniquement si cette transformation mérite un état,
   une mémoire, un rythme et des résidus propres.
4. Fournir un premier cas. La réponse de l’IA reste un brouillon jusqu’à la
   décision du propriétaire.
5. Conserver aussi les échecs et contre-exemples. Une répétition ne prouve ni le
   traitement ni la résolution.

La navigation combine deux structures complémentaires. La filiation forme un
arbre de composition : un sous-centre décompose une fonction de son parent, il ne
sert pas de simple dossier. Les liens dirigés forment un graphe de traduction
entre centres, y compris entre branches différentes. Domaine, statut, maturité
et ordre de variation restent des dimensions de lecture ; ils ne créent pas une
seconde taxonomie ni une autorité supérieure.

Les histoires, tâches, missions, rôles, ressources et preuves sont des données
du travail. Elles peuvent servir d’entrées, de contraintes ou de traces sans
devenir autant de destinations dans la navigation principale.

Le contrat opérationnel affiché par Tao compose sans les confondre : la fonction
et ses étapes, l’IA de conversation qui propose, les agents ou outils préparés,
et l’autorité humaine requise avant leurs effets. Un effet demandé comme
`read`, `write` ou `network` décrit un besoin ; il n’accorde jamais la permission
correspondante. Les comptes, secrets et connexions restent séparés.

La partie fonctionnelle d’un centre — entrée, processus, sortie, bénéfice,
preuve et limites — peut être exportée comme fichier JSON puis importée ailleurs.
L’import est d’abord prévisualisé et devient seulement un centre ou une révision
candidate. La source reste déclarée mais non authentifiée : le fichier ne
transmet aucun compte, secret, outil, mandat ou droit d’exécution. Un contrat
juridique ou une procédure dans un autre format reste une source à interpréter,
pas une instruction exécutable.

Quand une transformation exige une application, un service ou une machine, le
centre peut proposer un **organe**. Un organe accepté reste un plan jusqu’à sa
construction supervisée, la revue du diff, les tests et l’installation.

Si un outil MCP a déjà été installé et inspecté par le propriétaire, l’IA du
centre peut préparer un appel exact avec ses arguments. Tao affiche cet appel
dans **À valider** ; seul un clic explicite l’exécute. Le reçu et son éventuel
résultat externe restent visibles dans le centre. Cette étape ne crée ni mandat
récurrent, ni relance automatique, ni permission nouvelle.

Si ce centre possède un lien sortant, un reçu terminal peut être préparé comme
entrée du centre suivant avec **Utiliser dans…**. Ce clic ne transmet rien : il
ouvre seulement la destination avec le reçu attribué en pièce jointe. La personne
écrit encore sa consigne et l’envoie explicitement ; Tao vérifie alors le reçu,
le sens du lien et la destination avant de figer ce contexte.

## IA, imports et sauvegarde

- `/connect` vérifie la connexion Codex locale ; aucun fournisseur n’est
  installé automatiquement.
- `/onboarding` prépare l’import relu d’exports ChatGPT ou Claude reconnus ; il
  ne se connecte pas aux comptes et ne récupère pas les pièces jointes.
- La sauvegarde depuis `C₀` chiffre le cœur local dans le navigateur avant le
  téléchargement. La phrase secrète n’est pas envoyée au runtime.

Le texte d’une réponse arrive progressivement. Un envoi interrompu reste visible
et reprenable. Authentification, quota, réseau, modèle et capacité d’exécution
sont des diagnostics distincts.

## Architecture du dépôt

```text
bootstrap/                 runtime Python local
  tao_runtime.py           inventaire unique du runtime
  tao_node.py              persistance, service HTTP et CLI
  tao_centers.py           centres, cas, liens et organes
  tao_dialogue.py          dialogue explicitement déclenché
  tao_workshop.py          expériences de code supervisées
  tao_backup.py            sauvegarde et restauration du cœur
  tao_update.py            mises à jour signées et retour arrière
frontend/                  source React/TypeScript du cockpit
bootstrap/tao_frontend/    actifs compilés livrés sans Node
docs/theory.json           contrat machine versionné
gaia/                      portail public statique
tests/                     preuves automatisées et contre-exemples
```

Le client React est une projection. Les invariants, les contrôles d’autorité et
les écritures restent dans le runtime Python. L’usage normal ne nécessite ni
Node ni `node_modules`. Pour reconstruire le client avec les dépendances déjà
présentes :

```bash
npm run build --prefix frontend
```

## Vérifier et construire

Avant de retenir une évolution :

```bash
bash scripts/verify.sh
```

Construire les artefacts locaux :

```bash
python3 scripts/build_release.py
python3 scripts/build_linux_desktop.py
python3 scripts/build_gaia.py
```

Ces commandes ne publient rien. Une distribution exécutable exige ensuite une
signature Ed25519 vérifiée avec une clé publique obtenue séparément.

## Documentation

- [Architecture, données et exploitation](docs/TECHNICAL.md)
- [Qualification courante](docs/VALIDATION.md)
- [Contrat machine](docs/theory.json)

Les anciennes notes de conception restent récupérables dans l’historique Git,
mais ne font plus partie de la distribution courante.
