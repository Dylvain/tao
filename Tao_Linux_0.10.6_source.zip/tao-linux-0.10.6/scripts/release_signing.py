#!/usr/bin/env python3
"""Opt-in Ed25519 signatures for the two-artifact Tao release manifest.

Only an explicitly supplied PEM key is read. Private keys are never generated,
copied into a release, or written to a temporary file. OpenSSL >= 3 performs all
key parsing and cryptography; no extra Python package is required.

Authenticate the trusted public key independently, outside this release. A key
fingerprint in signing.json is descriptive, never a trust anchor. A successful
verification authenticates the exact manifest bytes and artifact contents under
that key; it does not establish code safety, publisher identity independently of
the key, freshness, anti-rollback protection, or a complete TUF update system.
Repeated verification of an older, correctly signed release remains possible.

OpenSSL reference: https://docs.openssl.org/3.0/man1/openssl-pkeyutl/
"""

import argparse
import contextlib
import functools
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import stat
import subprocess
import tempfile


MAX_MANIFEST_BYTES = 16 * 1024
MAX_METADATA_BYTES = 4 * 1024
MAX_KEY_BYTES = 16 * 1024
MAX_ARTIFACT_BYTES = 128 * 1024 * 1024
MANIFEST_NAME = "release.json"
SIGNATURE_NAME = "release.sig"
METADATA_NAME = "signing.json"
_VERSION = re.compile(r"(?:0|[1-9][0-9]{0,4})\.(?:0|[1-9][0-9]{0,4})\.(?:0|[1-9][0-9]{0,4})\Z")
_HASH = re.compile(r"[0-9a-f]{64}\Z")
RELEASE_SCHEMA = "tao.release.v2"
# RFC 8410 SubjectPublicKeyInfo prefix; OpenSSL produces and parses the DER.
_ED25519_SPKI_PREFIX = bytes.fromhex("302a300506032b6570032100")


class ReleaseSigningError(ValueError):
    """The release, explicit key, or detached signature could not be verified."""


def _errors(function):
    @functools.wraps(function)
    def checked(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except ReleaseSigningError:
            raise
        except (OSError, ValueError, TypeError, RecursionError) as error:
            raise ReleaseSigningError("Invalid or inaccessible release/key input.") from error
    return checked


def _absolute(path):
    if path is None or not os.fspath(path):
        raise ReleaseSigningError("An explicit file or directory path is required.")
    if ".." in Path(path).parts:
        raise ReleaseSigningError("Parent traversal is not permitted in release or key paths.")
    return Path(os.path.abspath(os.fspath(path)))


@contextlib.contextmanager
def _directory(path):
    """Open every directory component without following symbolic links."""
    path = _absolute(path)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    descriptor = os.open(path.anchor, flags)
    try:
        for part in path.parts[1:]:
            child = os.open(part, flags, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
        yield descriptor
    finally:
        os.close(descriptor)


def _snapshot(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


@contextlib.contextmanager
def _file(directory_fd, name, maximum):
    descriptor = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory_fd)
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
            raise ReleaseSigningError("Release and key inputs must be regular files without hard links.")
        if before.st_size <= 0 or before.st_size > maximum:
            raise ReleaseSigningError("File size is outside the permitted bounds.")
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            yield stream, before.st_size
        if _snapshot(before) != _snapshot(os.fstat(descriptor)):
            raise ReleaseSigningError("Input changed while being read.")
    finally:
        os.close(descriptor)


def _read(directory_fd, name, maximum):
    with _file(directory_fd, name, maximum) as (stream, size):
        data = stream.read(maximum + 1)
        if len(data) != size:
            raise ReleaseSigningError("Input changed while being read.")
        return data


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ReleaseSigningError("Duplicate JSON properties are not permitted.")
        result[key] = value
    return result


def _reject_constant(value):
    raise ReleaseSigningError("Non-finite JSON values are not permitted.")


def _json(data):
    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=_unique_object,
                          parse_constant=_reject_constant)
    except (UnicodeError, json.JSONDecodeError) as error:
        raise ReleaseSigningError("Invalid UTF-8 JSON input.") from error


@_errors
def parse_manifest(raw, version=None):
    """Validate bounded manifest bytes and their strict schema, without I/O.

    This does not inspect artifacts, verify hashes against files, or establish
    authenticity. Call inspect_release() or verify() for those operations.
    """
    if type(raw) is not bytes or not 0 < len(raw) <= MAX_MANIFEST_BYTES:
        raise ReleaseSigningError("Manifest bytes are outside the permitted bounds.")
    manifest = _json(raw)
    if type(manifest) is not dict:
        raise ReleaseSigningError("Invalid release manifest schema.")
    legacy = set(manifest) == {"version", "files"}
    if not legacy and set(manifest) != {"schema", "version", "update", "files"}:
        raise ReleaseSigningError("Invalid release manifest schema.")
    actual_version = manifest["version"]
    if type(actual_version) is not str or not _VERSION.fullmatch(actual_version):
        raise ReleaseSigningError("Release version must be a bounded numeric x.y.z version.")
    if version is not None and version != actual_version:
        raise ReleaseSigningError("Release version differs from the requested version.")
    if not legacy:
        update = manifest["update"]
        if (manifest["schema"] != RELEASE_SCHEMA or type(update) is not dict or
                set(update) != {"minimum_runtime", "install_mode", "changes", "state_migrations"}):
            raise ReleaseSigningError("Invalid signed update contract.")
        if type(update["minimum_runtime"]) is not str or not _VERSION.fullmatch(update["minimum_runtime"]):
            raise ReleaseSigningError("Invalid minimum runtime version.")
        changes, migrations = update["changes"], update["state_migrations"]
        if update["install_mode"] != "explicit" or type(changes) is not list or not 1 <= len(changes) <= 12:
            raise ReleaseSigningError("Invalid signed release changes.")
        for change in changes:
            if (type(change) is not dict or set(change) != {"fr", "en"} or
                    any(type(change.get(locale)) is not str or not 1 <= len(change[locale]) <= 300
                        for locale in ("fr", "en"))):
                raise ReleaseSigningError("Invalid bilingual release change.")
        if (type(migrations) is not list or len(migrations) > 12 or
                any(type(item) is not str or not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,79}", item)
                    for item in migrations)):
            raise ReleaseSigningError("Invalid private-state migration list.")
    expected = {f"TAO_LINUX_{actual_version}.run", f"Tao_Linux_{actual_version}_source.zip"}
    files = manifest["files"]
    if type(files) is not dict or set(files) != expected:
        raise ReleaseSigningError("Manifest must name exactly the versioned installer and source ZIP.")
    for name, record in files.items():
        if type(record) is not dict or set(record) != {"sha256", "size"}:
            raise ReleaseSigningError("Invalid artifact record schema.")
        if type(record["sha256"]) is not str or not _HASH.fullmatch(record["sha256"]):
            raise ReleaseSigningError("Invalid artifact SHA-256.")
        if type(record["size"]) is not int or not 0 < record["size"] <= MAX_ARTIFACT_BYTES:
            raise ReleaseSigningError("Artifact size is outside the permitted bounds.")
    return manifest


def _manifest(directory_fd, version=None):
    raw = _read(directory_fd, MANIFEST_NAME, MAX_MANIFEST_BYTES)
    manifest = parse_manifest(raw, version)
    for name, record in manifest["files"].items():
        digest = hashlib.sha256()
        count = 0
        with _file(directory_fd, name, MAX_ARTIFACT_BYTES) as (stream, size):
            if size != record["size"]:
                raise ReleaseSigningError("Artifact size does not match the manifest.")
            while True:
                chunk = stream.read(min(1024 * 1024, MAX_ARTIFACT_BYTES + 1 - count))
                if not chunk:
                    break
                count += len(chunk)
                if count > MAX_ARTIFACT_BYTES:
                    raise ReleaseSigningError("Artifact exceeds the permitted size.")
                digest.update(chunk)
        if count != record["size"] or digest.hexdigest() != record["sha256"]:
            raise ReleaseSigningError("Artifact digest does not match the manifest.")
    return manifest, raw


@_errors
def inspect_release(release_dir, version=None):
    """Validate the strict manifest, artifact names, bounds, sizes and SHA-256s.

    This returns the validated legacy or v2 manifest, makes no
    signature/authenticity claim, and does not require OpenSSL. Unrelated files
    in release_dir are ignored.
    """
    with _directory(release_dir) as directory_fd:
        return _manifest(directory_fd, version)[0]


def _key_bytes(path, release_dir, private=False):
    key_path, root_path = _absolute(path), _absolute(release_dir)
    if key_path == root_path or root_path in key_path.parents:
        raise ReleaseSigningError("Keys must be explicit files outside the release directory.")
    with _directory(key_path.parent) as key_directory_fd:
        data = _read(key_directory_fd, key_path.name, MAX_KEY_BYTES)
    label = b"PRIVATE KEY" if private else b"PUBLIC KEY"
    pattern = (b"-----BEGIN " + label + b"-----\r?\n[A-Za-z0-9+/=\r\n]+"
               b"-----END " + label + b"-----[\r\n]*")
    if not re.fullmatch(pattern, data):
        raise ReleaseSigningError("An unencrypted PKCS#8 private key or SPKI public PEM key is required.")
    return data


def _run(openssl, arguments, data=None):
    # Do not inherit credential/provider/configuration environment variables.
    environment = {"PATH": os.defpath, "LANG": "C", "LC_ALL": "C", "OPENSSL_CONF": os.devnull}
    try:
        result = subprocess.run([openssl, *arguments], input=data, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=15, env=environment, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise ReleaseSigningError("OpenSSL is unavailable or did not complete.") from error
    if result.returncode:
        # Never echo private input or command diagnostics into public output.
        raise ReleaseSigningError("OpenSSL rejected the key or signature.")
    return result.stdout


def _openssl():
    executable = shutil.which("openssl")
    if not executable:
        raise ReleaseSigningError("OpenSSL >= 3 is required for Ed25519 signatures.")
    report = _run(executable, ["version"])
    match = re.match(rb"OpenSSL ([0-9]+)\.", report)
    if not match or int(match[1]) < 3:
        raise ReleaseSigningError("OpenSSL >= 3 is required for Ed25519 signatures.")
    return executable


def _public_der(openssl, key, private=False):
    arguments = ["pkey", "-pubout", "-outform", "DER", "-passin", "pass:"]
    if not private:
        arguments.append("-pubin")
    der = _run(openssl, arguments, key)
    if len(der) != 44 or not der.startswith(_ED25519_SPKI_PREFIX):
        raise ReleaseSigningError("Only Ed25519 keys are accepted.")
    return der


def _metadata(raw_manifest, public_der):
    return {"schema": 1, "algorithm": "ed25519", "manifest": MANIFEST_NAME,
            "signature": SIGNATURE_NAME,
            "manifest_sha256": hashlib.sha256(raw_manifest).hexdigest(),
            "public_key_sha256": hashlib.sha256(public_der).hexdigest()}


def _verify_signature(openssl, raw_manifest, signature, public_der):
    if len(signature) != 64:
        raise ReleaseSigningError("Ed25519 signatures must contain exactly 64 bytes.")
    # Ed25519 pkeyutl requires a seekable input with a known length. Only public
    # data is staged here, and the signature covers these exact manifest bytes.
    with tempfile.TemporaryDirectory(prefix="tao-release-verify-") as temporary:
        base = Path(temporary)
        (base / MANIFEST_NAME).write_bytes(raw_manifest)
        (base / SIGNATURE_NAME).write_bytes(signature)
        _run(openssl, ["pkeyutl", "-verify", "-rawin", "-pubin", "-keyform", "DER",
                       "-inkey", "/dev/stdin", "-in", str(base / MANIFEST_NAME),
                       "-sigfile", str(base / SIGNATURE_NAME)], public_der)


def _report(manifest, metadata):
    return {**manifest,
            "algorithm": "ed25519", "manifest_sha256": metadata["manifest_sha256"],
            "public_key_sha256": metadata["public_key_sha256"],
            "signature_verified": True, "integrity_verified": True}


@_errors
def verify(release_dir, trusted_public_key_path, version=None):
    """Verify a release against an explicitly named, independently trusted key.

    Never trust a key because it arrived beside the release. The key must be
    outside release_dir. Metadata is strictly checked against derived values;
    an attacker cannot claim another algorithm, digest, or public key identity.
    """
    openssl = _openssl()
    public_key = _key_bytes(trusted_public_key_path, release_dir)
    public_der = _public_der(openssl, public_key)
    with _directory(release_dir) as directory_fd:
        manifest, raw = _manifest(directory_fd, version)
        signature = _read(directory_fd, SIGNATURE_NAME, 64)
        metadata = _json(_read(directory_fd, METADATA_NAME, MAX_METADATA_BYTES))
        expected_metadata = _metadata(raw, public_der)
        if (type(metadata) is not dict or metadata != expected_metadata
                or type(metadata.get("schema")) is not int):
            raise ReleaseSigningError("Signing metadata does not match the manifest and trusted key.")
        _verify_signature(openssl, raw, signature, public_der)
        return _report(manifest, expected_metadata)


def _check_output(directory_fd, name):
    try:
        info = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
    except FileNotFoundError:
        return
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ReleaseSigningError("Signature outputs must not be links or special files.")


def _atomic_write(directory_fd, name, data):
    _check_output(directory_fd, name)
    temporary = ".tao-signature-" + secrets.token_hex(12)
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o644, dir_fd=directory_fd)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        _check_output(directory_fd, name)
        os.replace(temporary, name, src_dir_fd=directory_fd, dst_dir_fd=directory_fd)
    finally:
        try:
            os.unlink(temporary, dir_fd=directory_fd)
        except FileNotFoundError:
            pass


@_errors
def sign(release_dir, private_key_path, public_key_path, version=None):
    """Sign only a qualified release using two explicit, matching Ed25519 keys.

    Writes release.sig and signing.json after full validation. No key is copied
    or published. Returns the same report as verify(), only after verification.
    An interrupted write is not a verified release and must be verified again.
    """
    openssl = _openssl()
    # Qualify the release before reading the explicitly authorized private key.
    with _directory(release_dir) as directory_fd:
        manifest, raw = _manifest(directory_fd, version)
        _check_output(directory_fd, SIGNATURE_NAME)
        _check_output(directory_fd, METADATA_NAME)
        public_key = _key_bytes(public_key_path, release_dir)
        public_der = _public_der(openssl, public_key)
        private_key = _key_bytes(private_key_path, release_dir, private=True)
        if _public_der(openssl, private_key, private=True) != public_der:
            raise ReleaseSigningError("The explicit private and public keys do not match.")
        with tempfile.TemporaryDirectory(prefix="tao-release-sign-") as temporary:
            snapshot = Path(temporary) / MANIFEST_NAME
            snapshot.write_bytes(raw)
            signature = _run(openssl, ["pkeyutl", "-sign", "-rawin", "-inkey", "/dev/stdin",
                                       "-passin", "pass:", "-in", str(snapshot)], private_key)
        _verify_signature(openssl, raw, signature, public_der)
        metadata = _metadata(raw, public_der)
        _atomic_write(directory_fd, SIGNATURE_NAME, signature)
        _atomic_write(directory_fd, METADATA_NAME, (json.dumps(metadata, sort_keys=True, indent=2) + "\n").encode())
    return verify(release_dir, public_key_path, version=version)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    signing = commands.add_parser("sign", help="Sign a validated release with explicitly supplied PEM keys.")
    signing.add_argument("--release-dir", required=True)
    signing.add_argument("--private-key", required=True, help="Unencrypted Ed25519 PKCS#8 PEM outside the release directory.")
    signing.add_argument("--public-key", required=True, help="Matching Ed25519 SPKI public PEM outside the release directory.")
    signing.add_argument("--version", help="Require this exact release version; does not provide anti-rollback protection.")
    verification = commands.add_parser("verify", help="Verify against a public key authenticated independently.")
    verification.add_argument("--release-dir", required=True)
    verification.add_argument("--trusted-key", required=True)
    verification.add_argument("--version")
    arguments = parser.parse_args(argv)
    try:
        if arguments.command == "sign":
            report = sign(arguments.release_dir, arguments.private_key, arguments.public_key, arguments.version)
        else:
            report = verify(arguments.release_dir, arguments.trusted_key, arguments.version)
    except ReleaseSigningError as error:
        parser.exit(1, "Release verification failed: " + str(error) + "\n")
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
