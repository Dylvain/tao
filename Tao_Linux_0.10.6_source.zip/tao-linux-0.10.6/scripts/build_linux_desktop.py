#!/usr/bin/env python3
"""Build a deterministic, unsigned Debian/Ubuntu desktop preview for Tao.

The resulting package is intentionally outside the signed release manifest. It
is suitable for local qualification only until the owner extends and signs the
public distribution contract.
"""
from __future__ import annotations

import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile
import uuid


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.release_signing import inspect_release

MAX_INPUT_BYTES = 128 * 1024 * 1024


def _regular(path: Path, maximum: int = MAX_INPUT_BYTES) -> bytes:
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(descriptor)
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                or not 0 < before.st_size <= maximum):
            raise ValueError("Entrée du paquet absente, liée ou trop volumineuse.")
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            data = stream.read(maximum + 1)
        after = os.fstat(descriptor)
    finally:
        os.close(descriptor)
    identity = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    if (len(data) != before.st_size
            or any(getattr(before, field) != getattr(after, field) for field in identity)):
        raise ValueError("Entrée du paquet modifiée pendant sa lecture.")
    return data


def _tar_gzip(entries: list[tuple[str, bytes, int]]) -> bytes:
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            for name, payload, mode in entries:
                info = tarfile.TarInfo(name)
                info.size = len(payload)
                info.mode = mode
                info.uid = info.gid = 0
                info.uname = info.gname = "root"
                info.mtime = 0
                archive.addfile(info, io.BytesIO(payload))
    return output.getvalue()


def _ar_member(name: str, payload: bytes, mode: int = 0o100644) -> bytes:
    encoded = (name + "/").encode("ascii")
    if len(encoded) > 16:
        raise ValueError("Nom de membre ar trop long.")
    fields = (
        encoded.ljust(16), b"0".ljust(12), b"0".ljust(6), b"0".ljust(6),
        format(mode, "o").encode("ascii").ljust(8), str(len(payload)).encode("ascii").ljust(10), b"`\n",
    )
    result = b"".join(fields) + payload
    return result + (b"\n" if len(payload) % 2 else b"")


def _desktop_file() -> bytes:
    return b"""[Desktop Entry]
Type=Application
Name=Tao
GenericName=Centres de travail
Comment=Ouvrir mon Tao local
Exec=/usr/bin/tao-desktop
TryExec=/usr/bin/tao-desktop
Icon=tao
Terminal=false
Categories=Office;Utility;
StartupNotify=true
"""


def _write(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_symlink():
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ValueError("Destination du paquet non régulière.")
    temporary = path.parent / (".desktop-build-" + uuid.uuid4().hex)
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        temporary.unlink(missing_ok=True)


def build(release_dir: Path | None = None, output_dir: Path | None = None) -> dict[str, object]:
    release_dir = (release_dir or ROOT / "dist").absolute()
    output_dir = (output_dir or ROOT / "dist").absolute()
    manifest = inspect_release(release_dir)
    version = manifest["version"]
    archive_name = f"Tao_Linux_{version}_source.zip"
    archive = _regular(release_dir / archive_name)
    expected = manifest["files"][archive_name]
    if len(archive) != expected["size"] or hashlib.sha256(archive).hexdigest() != expected["sha256"]:
        raise ValueError("L’archive source ne correspond pas à la release vérifiée.")

    template = _regular(ROOT / "desktop" / "tao_desktop.py", 256 * 1024).decode("utf-8")
    if template.count("@VERSION@") != 2 or template.count("@SOURCE_SHA256@") != 1:
        raise ValueError("Gabarit du lanceur inattendu.")
    launcher = template.replace("@VERSION@", version).replace("@SOURCE_SHA256@", expected["sha256"]).encode("utf-8")
    compile(launcher, "tao-desktop", "exec")
    icon = _regular(ROOT / "bootstrap" / "tao_frontend" / "tao-icon.svg", 256 * 1024)
    installed_size = (len(launcher) + len(archive) + len(icon) + len(_desktop_file()) + 1023) // 1024
    control = (f"""Package: tao-local
Version: {version}
Section: utils
Priority: optional
Architecture: all
Depends: python3 (>= 3.9)
Recommends: git
Installed-Size: {installed_size}
Maintainer: Tao Commons <tao@localhost>
Description: Tao local — centres de travail avec une IA
 Installe un petit lanceur graphique. Le runtime et la mémoire restent dans le
 compte de la personne ; aucune IA n’est appelée pendant l’installation.
""").encode("utf-8")
    control_tar = _tar_gzip([("./control", control, 0o644)])
    data_tar = _tar_gzip([
        ("./usr/bin/tao-desktop", launcher, 0o755),
        ("./usr/lib/tao/" + archive_name, archive, 0o644),
        ("./usr/share/applications/tao.desktop", _desktop_file(), 0o644),
        ("./usr/share/icons/hicolor/scalable/apps/tao.svg", icon, 0o644),
    ])
    package = (b"!<arch>\n" + _ar_member("debian-binary", b"2.0\n")
               + _ar_member("control.tar.gz", control_tar) + _ar_member("data.tar.gz", data_tar))
    name = f"Tao_Linux_{version}_preview_all.deb"
    target = output_dir / name
    _write(target, package)
    result = {
        "schema": "tao.desktop.preview.v1",
        "status": "unsigned_preview",
        "version": version,
        "artifact": name,
        "sha256": hashlib.sha256(package).hexdigest(),
        "size": len(package),
        "supported": ["debian", "ubuntu"],
        "proof_expected": "double_click_install_then_launch_without_terminal",
        "counterexample": "other_linux_distributions_remain_unsupported",
    }
    print(json.dumps(result, ensure_ascii=False))
    return result


if __name__ == "__main__":
    build()
