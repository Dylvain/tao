#!/usr/bin/env python3
"""Serve only the generated Gaïa snapshot; no private runtime or code in env."""
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import socket
import threading
from urllib.parse import urlsplit

from scripts.build_gaia import SECURITY_HEADERS, load_site
from scripts.release_signing import inspect_release

ROOT = Path(__file__).resolve().parent
DIST = ROOT / 'dist'
CONTENT_TYPES = {
    '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
    '.zip': 'application/zip', '.pem': 'application/x-pem-file',
}


def verify_release():
    """Local packaging check, not a statement about signature or source safety."""
    return inspect_release(DIST)


class GaiaServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address, site_dir):
        # Validate once, then serve these bytes throughout this process lifetime.
        # No request can read private files, shell out or change the site.
        self.site_manifest, self.payloads = load_site(site_dir)
        self.slots = threading.BoundedSemaphore(16)
        super().__init__(address, H)

    def get_request(self):
        connection, address = super().get_request()
        connection.settimeout(10)
        return connection, address

    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self.slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()

    def handle_error(self, request, client_address):
        # Broken pipes/timeouts are normal when mobile users leave a page.
        pass


class H(BaseHTTPRequestHandler):
    server_version = 'Gaia'
    sys_version = ''

    def log_message(self, *args):
        pass

    def send(self, status, data, ctype='application/json; charset=utf-8', attachment=None):
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        for name, value in SECURITY_HEADERS.items():
            self.send_header(name, value)
        if attachment:
            self.send_header('Content-Disposition', 'attachment; filename="' + attachment + '"')
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(data)

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        # An exact whitelist intentionally rejects encoded/slashed aliases.
        # Query strings carry no behaviour and are never logged or reflected.
        try:
            parsed = urlsplit(self.path)
        except ValueError:
            return self.send(400, b'{"error":"invalid_path"}')
        if parsed.scheme or parsed.netloc or len(self.path) > 2048:
            return self.send(400, b'{"error":"invalid_path"}')
        path = parsed.path
        manifest = self.server.site_manifest
        if path == '/health':
            state = {'ok': True, 'version': manifest['version'],
                     'integrity_verified': True, 'download_status': manifest['mode'],
                     'signature_verified_at_build': manifest['mode'] == 'signed',
                     'private_host': False}
            return self.send(200, json.dumps(state).encode())
        if path == '/bootstrap.sh':
            return self.send(410, b'{"error":"automatic_bootstrap_retired"}')
        name = 'index.html' if path == '/' else ('release.json' if path == '/manifest' else path[1:])
        if not path.startswith('/') or name not in self.server.payloads or name == '_headers':
            return self.send(404, b'{"error":"not_found"}')
        ctype = CONTENT_TYPES.get(Path(name).suffix, 'application/octet-stream')
        attachment = name if name.endswith(('.run', '.zip', '.sig', '.pem')) else None
        return self.send(200, self.server.payloads[name], ctype, attachment)

    def do_POST(self):
        self.send(405, b'{"error":"read_only_portal"}')

    do_PUT = do_DELETE = do_PATCH = do_OPTIONS = do_POST


if __name__ == '__main__':
    folder = Path(os.environ.get('TAO_GAIA_DIR', str(DIST / 'gaia')))
    server = GaiaServer((os.environ.get('HOST', '0.0.0.0'), int(os.environ.get('PORT', '8080'))), folder)
    server.serve_forever()
