import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("release_signing", ROOT / "scripts/release_signing.py")
signing = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(signing)


@unittest.skipUnless(shutil.which("openssl"), "OpenSSL is needed for ephemeral signing fixtures")
class ReleaseSigningTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.keys_temporary = tempfile.TemporaryDirectory(prefix="tao-test-ephemeral-keys-")
        cls.keys = Path(cls.keys_temporary.name)
        for name in ("first", "other"):
            subprocess.run(["openssl", "genpkey", "-algorithm", "ED25519", "-out", str(cls.keys / (name + ".pem"))],
                           check=True, capture_output=True, timeout=15)
            subprocess.run(["openssl", "pkey", "-in", str(cls.keys / (name + ".pem")), "-pubout",
                            "-out", str(cls.keys / (name + ".pub"))], check=True, capture_output=True, timeout=15)

    @classmethod
    def tearDownClass(cls):
        cls.keys_temporary.cleanup()

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="tao-test-release-")
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.release = self.base / "release"
        self.release.mkdir()
        self.private = self.keys / "first.pem"
        self.public = self.keys / "first.pub"
        self.manifest = {"version": "0.8.0", "files": {}}
        for name, data in (("TAO_LINUX_0.8.0.run", b"installer fixture\n"),
                           ("Tao_Linux_0.8.0_source.zip", b"source fixture\n")):
            (self.release / name).write_bytes(data)
            self.manifest["files"][name] = {"sha256": hashlib.sha256(data).hexdigest(), "size": len(data)}
        self.write_manifest()

    def write_manifest(self):
        (self.release / "release.json").write_text(json.dumps(self.manifest, indent=2) + "\n", encoding="utf-8")

    def sign(self):
        return signing.sign(self.release, self.private, self.public, version="0.8.0")

    def metadata(self):
        return json.loads((self.release / "signing.json").read_text())

    def write_metadata(self, metadata):
        (self.release / "signing.json").write_text(json.dumps(metadata), encoding="utf-8")

    def refresh_metadata_manifest_hash(self):
        metadata = self.metadata()
        metadata["manifest_sha256"] = hashlib.sha256((self.release / "release.json").read_bytes()).hexdigest()
        self.write_metadata(metadata)

    def test_unsigned_inspection_makes_no_authenticity_claim(self):
        with mock.patch.object(signing.shutil, "which", return_value=None):
            self.assertEqual(signing.inspect_release(self.release, version="0.8.0"), self.manifest)
            with self.assertRaisesRegex(signing.ReleaseSigningError, "OpenSSL"):
                self.sign()
        self.assertFalse((self.release / "release.sig").exists())

    def test_parse_manifest_is_bounded_schema_only_and_performs_no_io(self):
        raw = (self.release / "release.json").read_bytes()
        (self.release / "TAO_LINUX_0.8.0.run").unlink()
        with mock.patch.object(signing.os, "open") as open_file:
            self.assertEqual(signing.parse_manifest(raw, version="0.8.0"), self.manifest)
            open_file.assert_not_called()
        for invalid in (raw.decode(), b"", b" " * (signing.MAX_MANIFEST_BYTES + 1)):
            with self.assertRaises(signing.ReleaseSigningError):
                signing.parse_manifest(invalid)

    def test_v2_update_contract_is_signed_and_legacy_remains_readable(self):
        modern = {
            'schema': signing.RELEASE_SCHEMA,
            'version': self.manifest['version'],
            'update': {
                'minimum_runtime': '0.8.0',
                'install_mode': 'explicit',
                'changes': [{'fr': 'Changement borné.', 'en': 'Bounded change.'}],
                'state_migrations': [],
            },
            'files': self.manifest['files'],
        }
        self.manifest = modern
        self.write_manifest()
        report = self.sign()
        self.assertEqual(report['schema'], signing.RELEASE_SCHEMA)
        self.assertEqual(report['update']['state_migrations'], [])
        self.assertEqual(signing.inspect_release(self.release), modern)

        for mutation in (
                {**modern, 'update': {**modern['update'], 'install_mode': 'automatic'}},
                {**modern, 'update': {**modern['update'], 'state_migrations': ['../state']}},
                {**modern, 'update': {**modern['update'], 'changes': []}},
                {**modern, 'schema': 'tao.release.v3'}):
            (self.release / 'release.json').write_text(json.dumps(mutation))
            with self.assertRaises(signing.ReleaseSigningError):
                signing.inspect_release(self.release)

    def test_sign_verify_exact_manifest_and_no_private_key_published(self):
        before = (self.release / "release.json").read_bytes()
        report = self.sign()
        self.assertEqual(report, signing.verify(self.release, self.public, version="0.8.0"))
        self.assertEqual(report["files"], self.manifest["files"])
        self.assertTrue(report["signature_verified"])
        self.assertTrue(report["integrity_verified"])
        self.assertEqual(report["algorithm"], "ed25519")
        self.assertEqual((self.release / "release.json").read_bytes(), before)
        self.assertEqual(len((self.release / "release.sig").read_bytes()), 64)
        self.assertEqual(set(p.name for p in self.release.iterdir()),
                         set(self.manifest["files"]) | {"release.json", "release.sig", "signing.json"})
        public_der = subprocess.run(["openssl", "pkey", "-pubin", "-in", str(self.public), "-outform", "DER"],
                                    check=True, capture_output=True, timeout=15).stdout
        self.assertEqual(report["public_key_sha256"], hashlib.sha256(public_der).hexdigest())

    def test_signature_verifiable_with_standard_openssl_cli(self):
        self.sign()
        result = subprocess.run(["openssl", "pkeyutl", "-verify", "-rawin", "-pubin", "-inkey", str(self.public),
                                 "-in", str(self.release / "release.json"),
                                 "-sigfile", str(self.release / "release.sig")], capture_output=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_modified_payload_without_manifest_change_is_rejected(self):
        self.sign()
        installer = self.release / "TAO_LINUX_0.8.0.run"
        installer.write_bytes(b"x" * installer.stat().st_size)
        with self.assertRaisesRegex(signing.ReleaseSigningError, "digest"):
            signing.verify(self.release, self.public)

    def test_modified_payload_and_all_untrusted_hashes_with_old_signature_are_rejected(self):
        self.sign()
        name = "TAO_LINUX_0.8.0.run"
        malicious = b"malicious replacement with matching untrusted checksums\n"
        (self.release / name).write_bytes(malicious)
        self.manifest["files"][name] = {"size": len(malicious), "sha256": hashlib.sha256(malicious).hexdigest()}
        self.write_manifest()
        self.refresh_metadata_manifest_hash()
        self.assertEqual(signing.inspect_release(self.release), self.manifest)
        with self.assertRaisesRegex(signing.ReleaseSigningError, "signature"):
            signing.verify(self.release, self.public)

    def test_even_json_whitespace_is_covered_by_signature(self):
        self.sign()
        (self.release / "release.json").write_text(json.dumps(self.manifest, separators=(",", ":")))
        self.refresh_metadata_manifest_hash()
        with self.assertRaisesRegex(signing.ReleaseSigningError, "signature"):
            signing.verify(self.release, self.public)

    def test_other_trusted_key_is_rejected_even_with_matching_fingerprint_claim(self):
        self.sign()
        other = self.keys / "other.pub"
        metadata = self.metadata()
        metadata["public_key_sha256"] = hashlib.sha256(
            signing._public_der(signing._openssl(), other.read_bytes())).hexdigest()
        self.write_metadata(metadata)
        with self.assertRaisesRegex(signing.ReleaseSigningError, "signature"):
            signing.verify(self.release, other)

    def test_false_or_extended_metadata_is_rejected(self):
        self.sign()
        original = self.metadata()
        mutations = [{**original, "algorithm": "sha256"}, {**original, "schema": True},
                     {**original, "manifest": "elsewhere.json"}, {**original, "signature": "../other.sig"},
                     {**original, "manifest_sha256": "0" * 64}, {**original, "public_key_sha256": "0" * 64},
                     {**original, "publisher_verified": True}, {k: v for k, v in original.items() if k != "schema"}]
        for metadata in mutations:
            with self.subTest(metadata=metadata):
                self.write_metadata(metadata)
                with self.assertRaisesRegex(signing.ReleaseSigningError, "metadata"):
                    signing.verify(self.release, self.public)

    def test_mismatched_private_key_never_writes_signature(self):
        with self.assertRaisesRegex(signing.ReleaseSigningError, "do not match"):
            signing.sign(self.release, self.keys / "other.pem", self.public)
        self.assertFalse((self.release / "release.sig").exists())
        self.assertFalse((self.release / "signing.json").exists())

    def test_unqualified_manifest_is_rejected_before_private_key_read(self):
        (self.release / "release.json").write_text('{"arbitrary": "message"}')
        with mock.patch.object(signing, "_key_bytes") as read_key:
            with self.assertRaises(signing.ReleaseSigningError):
                self.sign()
            read_key.assert_not_called()

    def test_manifest_schema_paths_types_and_bounds_are_strict(self):
        original = json.loads(json.dumps(self.manifest))
        name = "TAO_LINUX_0.8.0.run"
        mutations = [{**original, "extra": True}, {**original, "version": "../0.8.0"},
                     {**original, "version": "00.8.0"}, {**original, "files": []},
                     {**original, "files": {"../" + name: original["files"][name]}},
                     {**original, "files": {**original["files"], "unexpected": original["files"][name]}}]
        for record in ({"sha256": "0" * 64, "size": True}, {"sha256": "g" * 64, "size": 10},
                       {"sha256": "0" * 64, "size": signing.MAX_ARTIFACT_BYTES + 1},
                       {"sha256": "0" * 64, "size": -1}, {"sha256": "0" * 64, "size": 1, "extra": False}):
            mutations.append({**original, "files": {**original["files"], name: record}})
        for manifest in mutations:
            with self.subTest(manifest=manifest):
                (self.release / "release.json").write_text(json.dumps(manifest))
                with self.assertRaises(signing.ReleaseSigningError):
                    signing.inspect_release(self.release)

    def test_duplicate_json_keys_and_oversized_manifest_are_rejected(self):
        valid = (self.release / "release.json").read_text()
        (self.release / "release.json").write_text(valid.replace('"version":', '"version":"0.8.0","version":'))
        with self.assertRaisesRegex(signing.ReleaseSigningError, "Duplicate"):
            signing.inspect_release(self.release)
        (self.release / "release.json").write_bytes(b" " * (signing.MAX_MANIFEST_BYTES + 1))
        with self.assertRaisesRegex(signing.ReleaseSigningError, "size"):
            signing.inspect_release(self.release)

    def test_symlink_release_root_or_parent_is_rejected(self):
        link = self.base / "release-link"
        link.symlink_to(self.release, target_is_directory=True)
        with self.assertRaises(signing.ReleaseSigningError):
            signing.inspect_release(link)
        ancestor = self.base / "parent-link"
        ancestor.symlink_to(self.base, target_is_directory=True)
        with self.assertRaises(signing.ReleaseSigningError):
            signing.inspect_release(ancestor / "release")
        # Do not normalize away a symlink before walking the supplied path.
        with self.assertRaises(signing.ReleaseSigningError):
            signing.inspect_release(ancestor / ".." / "release")

    def test_symlink_manifest_artifact_signature_or_metadata_is_rejected(self):
        self.sign()
        for name in ("release.json", "TAO_LINUX_0.8.0.run", "release.sig", "signing.json"):
            with self.subTest(name=name):
                target = self.base / (name + ".real")
                path = self.release / name
                path.rename(target)
                path.symlink_to(target)
                try:
                    with self.assertRaises(signing.ReleaseSigningError):
                        signing.verify(self.release, self.public)
                finally:
                    path.unlink()
                    target.rename(path)

    def test_key_symlinks_hardlinks_and_release_internal_keys_are_rejected(self):
        private_link = self.base / "private-link"
        private_link.symlink_to(self.private)
        with self.assertRaises(signing.ReleaseSigningError):
            signing.sign(self.release, private_link, self.public)
        public_link = self.base / "public-link"
        public_link.symlink_to(self.public)
        with self.assertRaises(signing.ReleaseSigningError):
            signing.sign(self.release, self.private, public_link)
        internal = self.release / "private.pem"
        shutil.copyfile(self.private, internal)
        with self.assertRaisesRegex(signing.ReleaseSigningError, "outside"):
            signing.sign(self.release, internal, self.public)
        internal.unlink()
        self.sign()
        internal_public = self.release / "trusted.pub"
        shutil.copyfile(self.public, internal_public)
        with self.assertRaisesRegex(signing.ReleaseSigningError, "outside"):
            signing.verify(self.release, internal_public)
        copied = self.base / "private-copy"
        shutil.copyfile(self.private, copied)
        hardlink = self.base / "hardlink"
        os.link(copied, hardlink)
        with self.assertRaises(signing.ReleaseSigningError):
            signing.sign(self.release, hardlink, self.public)

    def test_symlink_signature_output_does_not_overwrite_external_file(self):
        target = self.base / "preserved"
        target.write_bytes(b"untouched")
        (self.release / "release.sig").symlink_to(target)
        with self.assertRaises(signing.ReleaseSigningError):
            self.sign()
        self.assertEqual(target.read_bytes(), b"untouched")

    def test_non_ed25519_keys_are_rejected(self):
        private = self.base / "ed448.pem"
        public = self.base / "ed448.pub"
        subprocess.run(["openssl", "genpkey", "-algorithm", "ED448", "-out", str(private)],
                       check=True, capture_output=True, timeout=15)
        subprocess.run(["openssl", "pkey", "-in", str(private), "-pubout", "-out", str(public)],
                       check=True, capture_output=True, timeout=15)
        with self.assertRaisesRegex(signing.ReleaseSigningError, "Only Ed25519"):
            signing.sign(self.release, private, public)

    def test_truncated_signature_and_missing_signature_are_rejected(self):
        self.sign()
        (self.release / "release.sig").write_bytes(b"x" * 63)
        with self.assertRaises(signing.ReleaseSigningError):
            signing.verify(self.release, self.public)
        (self.release / "release.sig").unlink()
        with self.assertRaises(signing.ReleaseSigningError):
            signing.verify(self.release, self.public)

    def test_explicit_version_pin_and_replay_scope(self):
        self.sign()
        self.assertEqual(signing.verify(self.release, self.public)["version"], "0.8.0")
        self.assertEqual(signing.verify(self.release, self.public, version="0.8.0")["version"], "0.8.0")
        with self.assertRaisesRegex(signing.ReleaseSigningError, "version"):
            signing.verify(self.release, self.public, version="0.8.1")

    def test_cli_explicit_sign_verify_and_nonzero_failure(self):
        script = str(ROOT / "scripts/release_signing.py")
        command = [sys.executable, script, "sign", "--release-dir", str(self.release),
                   "--private-key", str(self.private), "--public-key", str(self.public), "--version", "0.8.0"]
        result = subprocess.run(command, capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(json.loads(result.stdout)["signature_verified"])
        command = [sys.executable, script, "verify", "--release-dir", str(self.release), "--trusted-key", str(self.public)]
        result = subprocess.run(command, capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(json.loads(result.stdout)["signature_verified"])
        (self.release / "release.sig").write_bytes(b"x" * 64)
        result = subprocess.run(command, capture_output=True, text=True, timeout=15)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertIn("failed", result.stderr)


if __name__ == "__main__":
    unittest.main()
