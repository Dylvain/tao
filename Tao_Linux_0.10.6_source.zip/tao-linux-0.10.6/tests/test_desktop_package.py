"""The desktop preview stays thin, deterministic and honest about its scope."""
import ast
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tarfile
import tempfile
import unittest
import urllib.request


ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


builder = load("desktop_package_builder", ROOT / "scripts" / "build_linux_desktop.py")
desktop = load("desktop_launcher", ROOT / "desktop" / "tao_desktop.py")


def ar_members(payload):
    if not payload.startswith(b"!<arch>\n"):
        raise AssertionError("not an ar archive")
    result = {}
    offset = 8
    while offset < len(payload):
        header = payload[offset:offset + 60]
        if len(header) != 60 or header[58:] != b"`\n":
            raise AssertionError("invalid ar member")
        name = header[:16].decode("ascii").strip().rstrip("/")
        size = int(header[48:58].decode("ascii").strip())
        start = offset + 60
        result[name] = payload[start:start + size]
        offset = start + size + (size % 2)
    if offset != len(payload):
        raise AssertionError("trailing ar bytes")
    return result


def tar_members(payload):
    with tarfile.open(fileobj=io.BytesIO(payload), mode="r:gz") as archive:
        return {item.name: archive.extractfile(item).read() for item in archive.getmembers()}


class DesktopPackageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run([sys.executable, str(ROOT / "scripts" / "build_release.py")],
                       check=True, stdout=subprocess.DEVNULL)
        cls.description = builder.build()
        cls.package = ROOT / "dist" / cls.description["artifact"]

    def test_package_is_deterministic_minimal_and_opens_without_terminal(self):
        before = self.package.read_bytes()
        again = builder.build()
        self.assertEqual(self.package.read_bytes(), before)
        self.assertEqual(again, self.description)
        self.assertEqual(hashlib.sha256(before).hexdigest(), self.description["sha256"])
        self.assertEqual(self.description["status"], "unsigned_preview")
        self.assertEqual(self.description["supported"], ["debian", "ubuntu"])

        outer = ar_members(before)
        self.assertEqual(set(outer), {"debian-binary", "control.tar.gz", "data.tar.gz"})
        self.assertEqual(outer["debian-binary"], b"2.0\n")
        control = tar_members(outer["control.tar.gz"])["./control"].decode()
        self.assertIn("Package: tao-local\n", control)
        self.assertIn("Architecture: all\n", control)
        data = tar_members(outer["data.tar.gz"])
        version = self.description["version"]
        archive_name = f"Tao_Linux_{version}_source.zip"
        self.assertEqual(set(data), {
            "./usr/bin/tao-desktop",
            "./usr/lib/tao/" + archive_name,
            "./usr/share/applications/tao.desktop",
            "./usr/share/icons/hicolor/scalable/apps/tao.svg",
        })
        self.assertEqual(data["./usr/lib/tao/" + archive_name],
                         (ROOT / "dist" / archive_name).read_bytes())
        entry = data["./usr/share/applications/tao.desktop"].decode()
        self.assertIn("Exec=/usr/bin/tao-desktop", entry)
        self.assertIn("Terminal=false", entry)
        tree = ast.parse(data["./usr/bin/tao-desktop"], "tao-desktop")
        source_digest = hashlib.sha256(data["./usr/lib/tao/" + archive_name]).hexdigest()
        constants = {
            node.targets[0].id: ast.literal_eval(node.value)
            for node in tree.body
            if isinstance(node, ast.Assign) and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id in {"VERSION", "SOURCE_SHA256"}
        }
        self.assertEqual(constants, {"VERSION": version, "SOURCE_SHA256": source_digest})
        if shutil.which("dpkg-deb"):
            result = subprocess.run(["dpkg-deb", "--info", str(self.package)],
                                    capture_output=True, text=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_launcher_installs_opens_and_second_launch_does_not_reinstall(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            state = home / ".tao" / "genesis"
            state.mkdir(parents=True)
            with socket.socket() as listener:
                listener.bind(("127.0.0.1", 0))
                port = listener.getsockname()[1]
            (state / "policy.json").write_text(json.dumps({"http_port": port}))
            env = dict(os.environ, HOME=str(home), TAO_ROOT=str(state),
                       XDG_CONFIG_HOME=str(home / ".config"))
            env.pop("TAO_NO_START", None)
            archive = ROOT / "dist" / f"Tao_Linux_{builder.inspect_release(ROOT / 'dist')['version']}_source.zip"
            digest = hashlib.sha256(archive.read_bytes()).hexdigest()
            opened = []
            try:
                first = desktop.install_and_open(
                    archive, digest, home, lambda url: opened.append(url) or True,
                    env=env, version=self.description["version"],
                )
                with urllib.request.urlopen(first + "/health", timeout=2) as response:
                    first_health = json.load(response)
                self.assertTrue(first_health["ok"])
                self.assertFalse((state / "runtime.previous").exists())
                second = desktop.install_and_open(
                    archive, digest, home, lambda url: opened.append(url) or True,
                    env=env, version=self.description["version"],
                )
                with urllib.request.urlopen(second + "/health", timeout=2) as response:
                    second_health = json.load(response)
                self.assertEqual(first, second)
                self.assertEqual(first_health["session"], second_health["session"])
                self.assertFalse((state / "runtime.previous").exists())
                self.assertEqual(opened, [first, second])
            finally:
                launcher = home / ".local" / "bin" / "tao"
                if launcher.exists():
                    subprocess.run([str(launcher), "stop"], env=env,
                                   capture_output=True, timeout=10)

    def test_wrong_archive_digest_preserves_existing_state_and_reports_failure(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            marker = home / "private-state"
            marker.write_text("preserved")
            archive = home / "candidate.zip"
            archive.write_bytes(b"not the reviewed archive")
            with self.assertRaisesRegex(desktop.DesktopInstallError, "ne correspond pas"):
                desktop.install_and_open(
                    archive, "0" * 64, home, lambda _url: True,
                    env=dict(os.environ, HOME=str(home)), version="0.10.6",
                )
            self.assertEqual(marker.read_text(), "preserved")
            self.assertFalse((home / "tao-linux-0.10.6").exists())


if __name__ == "__main__":
    unittest.main()
