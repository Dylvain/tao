import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
import zipfile

from scripts import build_gaia
from scripts import release_signing


@unittest.skipUnless(shutil.which("openssl"), "OpenSSL is needed for ephemeral signing fixtures")
class GaiaBuildTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.key_directory = tempfile.TemporaryDirectory(prefix="gaia-test-ephemeral-keys-")
        cls.keys = Path(cls.key_directory.name)
        for label in ("trusted", "other"):
            private, public = cls.keys / (label + ".pem"), cls.keys / (label + ".pub")
            subprocess.run(["openssl", "genpkey", "-algorithm", "ED25519", "-out", str(private)],
                           check=True, capture_output=True, timeout=15)
            subprocess.run(["openssl", "pkey", "-in", str(private), "-pubout", "-out", str(public)],
                           check=True, capture_output=True, timeout=15)

    @classmethod
    def tearDownClass(cls):
        cls.key_directory.cleanup()

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="gaia-test-build-")
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.release = self.base / "release"
        self.release.mkdir()
        self.output = self.base / "public"
        self.private = self.keys / "trusted.pem"
        self.public = self.keys / "trusted.pub"
        self.installer = "TAO_LINUX_0.8.0.run"
        self.source = "Tao_Linux_0.8.0_source.zip"
        archive = io.BytesIO()
        with zipfile.ZipFile(archive, "w") as bundle:
            bundle.writestr("tao-linux-0.8.0/README.md", "Public fixture for review only.\n")
        (self.release / self.source).write_bytes(archive.getvalue())
        (self.release / self.installer).write_bytes(b"#!/usr/bin/env python3\nraise SystemExit('fixture only')\n")
        self.release_manifest = {"version": "0.8.0", "files": {
            name: self.metadata((self.release / name).read_bytes()) for name in (self.installer, self.source)}}
        (self.release / "release.json").write_bytes(build_gaia.json_bytes(self.release_manifest))

    @staticmethod
    def metadata(data):
        return {"sha256": hashlib.sha256(data).hexdigest(), "size": len(data)}

    def sign(self):
        release_signing.sign(self.release, self.private, self.public, version="0.8.0")

    def build_signed(self):
        self.sign()
        return build_gaia.build(self.release, self.output, trusted_key=self.public)

    def portal(self):
        return json.loads((self.output / "portal.json").read_text())

    def replace_site_file_with_matching_outer_hash(self, name, data):
        """Model tampering with the untrusted outer checksum catalogue too."""
        (self.output / name).write_bytes(data)
        manifest = json.loads((self.output / "site-manifest.json").read_text())
        manifest["files"][name] = self.metadata(data)
        (self.output / "site-manifest.json").write_bytes(build_gaia.json_bytes(manifest))

    def test_preview_has_only_source_and_no_installer_or_signature_claim(self):
        report = build_gaia.build(self.release, self.output)
        self.assertEqual(report["version"], "0.8.0")
        self.assertEqual(report["mode"], "preview")
        self.assertFalse(report["installer_published"])
        portal = self.portal()
        self.assertEqual(portal["download_status"], "preview")
        self.assertIsNone(portal["installer"])
        self.assertIsNone(portal["signature"])
        self.assertTrue((self.output / self.source).is_file())
        for name in (self.installer, "release.sig", "signing.json", "release-public.pem"):
            self.assertFalse((self.output / name).exists(), name)
        self.assertNotIn(self.installer, (self.output / "SHA256SUMS").read_text())
        manifest, payloads = build_gaia.load_site(self.output)
        self.assertEqual(manifest["mode"], "preview")
        self.assertEqual(set(payloads), build_gaia.allowed_names("0.8.0", "preview"))
        birth = json.loads(payloads["birth.json"])
        self.assertEqual(build_gaia.validate_birth_contract(birth), birth)
        self.assertEqual(birth["seed"]["specialized_centers"], [])
        self.assertFalse(birth["adaptation"]["automatic_ai_calls"])
        self.assertEqual(birth["permissions"], {"read": "none", "execution": "not_granted"})

    def test_signature_files_alone_never_promote_preview(self):
        self.sign()
        # A bundled public key and a genuine signature still confer no trust.
        shutil.copyfile(self.public, self.release / "release-public.pem")
        report = build_gaia.build(self.release, self.output)
        self.assertEqual(report["mode"], "preview")
        self.assertFalse(report["installer_published"])
        self.assertIsNone(self.portal()["signature"])
        self.assertFalse((self.output / self.installer).exists())
        self.assertFalse((self.output / "release-public.pem").exists())

    def test_signed_build_requires_explicit_matching_external_key(self):
        report = self.build_signed()
        self.assertEqual(report["mode"], "signed")
        self.assertTrue(report["installer_published"])
        manifest, payloads = build_gaia.load_site(self.output)
        self.assertEqual(manifest["mode"], "signed")
        self.assertEqual(payloads["release.json"], (self.release / "release.json").read_bytes())
        self.assertEqual(payloads["release.sig"], (self.release / "release.sig").read_bytes())
        self.assertEqual(payloads["release-public.pem"], self.public.read_bytes())
        self.assertEqual(release_signing.verify(self.output, self.public)["version"], "0.8.0")
        self.assertEqual(self.portal()["installer"], {"name": self.installer, "url": self.installer})

    def test_wrong_external_key_or_missing_signature_never_publishes(self):
        with self.assertRaises((ValueError, OSError)):
            build_gaia.build(self.release, self.output, trusted_key=self.public)
        self.assertFalse(self.output.exists())
        self.sign()
        with self.assertRaises((ValueError, OSError)):
            build_gaia.build(self.release, self.output, trusted_key=self.keys / "other.pub")
        self.assertFalse(self.output.exists())

    def test_key_within_release_cannot_be_reclassified_as_external_trust(self):
        self.sign()
        bundled = self.release / "release-public.pem"
        shutil.copyfile(self.public, bundled)
        with self.assertRaises((ValueError, OSError)):
            build_gaia.build(self.release, self.output, trusted_key=bundled)
        self.assertFalse(self.output.exists())

    def test_existing_output_cannot_supply_its_own_trust_key(self):
        self.build_signed()
        before = (self.output / "site-manifest.json").read_bytes()
        with self.assertRaises((ValueError, OSError)):
            build_gaia.build(self.release, self.output, trusted_key=self.output / "release-public.pem")
        self.assertEqual((self.output / "site-manifest.json").read_bytes(), before)

    def test_tampered_artifact_blocks_preview_and_signed_build(self):
        self.sign()
        (self.release / self.installer).write_bytes(b"tampered fixture\n")
        for key in (None, self.public):
            with self.subTest(key=key):
                with self.assertRaises((ValueError, OSError)):
                    build_gaia.build(self.release, self.output, trusted_key=key)
                self.assertFalse(self.output.exists())

    def test_private_and_unlisted_release_files_are_never_copied(self):
        private_sentinel = b"private sentinel: this must not be published\n"
        for name in ("auth.json", ".env", "memory.json", "personal-notes.txt", "old-release.run"):
            (self.release / name).write_bytes(private_sentinel)
        (self.release / "state").mkdir()
        (self.release / "state" / "private.json").write_bytes(private_sentinel)
        # Even an unrelated key present in input is outside the output allowlist.
        shutil.copyfile(self.private, self.release / "unpublished-private.pem")
        self.build_signed()
        manifest, payloads = build_gaia.load_site(self.output)
        self.assertEqual(set(payloads), build_gaia.allowed_names("0.8.0", "signed"))
        self.assertEqual(set(p.name for p in self.output.iterdir()), set(manifest["files"]) | {"site-manifest.json"})
        for data in payloads.values():
            self.assertNotIn(private_sentinel, data)
            self.assertNotIn(self.private.read_bytes(), data)

    def test_plain_payload_tampering_is_rejected(self):
        build_gaia.build(self.release, self.output)
        (self.output / "index.html").write_bytes(b"changed")
        with self.assertRaises((ValueError, OSError)):
            build_gaia.load_site(self.output)

    def test_birth_contract_cannot_smuggle_ai_authority_even_with_outer_hash(self):
        build_gaia.build(self.release, self.output)
        birth = json.loads((self.output / "birth.json").read_bytes())
        birth["adaptation"]["automatic_ai_calls"] = True
        birth["inheritance"]["included"].append("private_memory")
        self.replace_site_file_with_matching_outer_hash("birth.json", build_gaia.json_bytes(birth))
        with self.assertRaisesRegex(ValueError, "Héritage public invalide|adaptation invalide"):
            build_gaia.load_site(self.output)

    def test_preview_source_must_match_inner_release_manifest(self):
        build_gaia.build(self.release, self.output)
        self.replace_site_file_with_matching_outer_hash(self.source, b"different source bytes")
        with self.assertRaises((ValueError, OSError)):
            build_gaia.load_site(self.output)

    def test_signed_tampering_with_all_unsigned_hashes_still_fails(self):
        self.build_signed()
        malicious = b"changed installer with attacker-controlled checksums\n"
        release = json.loads((self.output / "release.json").read_bytes())
        release["files"][self.installer] = self.metadata(malicious)
        raw_release = build_gaia.json_bytes(release)
        metadata = json.loads((self.output / "signing.json").read_bytes())
        metadata["manifest_sha256"] = hashlib.sha256(raw_release).hexdigest()
        self.replace_site_file_with_matching_outer_hash(self.installer, malicious)
        self.replace_site_file_with_matching_outer_hash("release.json", raw_release)
        self.replace_site_file_with_matching_outer_hash("signing.json", build_gaia.json_bytes(metadata))
        self.replace_site_file_with_matching_outer_hash("SHA256SUMS", "".join(
            record["sha256"] + "  " + name + "\n" for name, record in release["files"].items()).encode())
        with self.assertRaises((ValueError, OSError)):
            build_gaia.load_site(self.output)

    def test_portal_must_not_add_preview_installation_or_change_download_paths(self):
        build_gaia.build(self.release, self.output)
        original = self.portal()
        mutations = [
            {**original, "installer": {"name": self.installer, "url": self.installer}},
            {**original, "signature": {"manifest": "release.json"}},
            {**original, "source_archive": {"name": self.source, "url": "../private.zip"}},
            {**original, "source_archive": {"name": self.source, "url": "https://invalid.example/download"}},
        ]
        for portal in mutations:
            with self.subTest(portal=portal):
                self.replace_site_file_with_matching_outer_hash("portal.json", build_gaia.json_bytes(portal))
                with self.assertRaises((ValueError, OSError)):
                    build_gaia.load_site(self.output)

    def test_manifest_paths_sizes_and_modes_are_strict(self):
        build_gaia.build(self.release, self.output)
        path = self.output / "site-manifest.json"
        original = json.loads(path.read_bytes())
        changed_size = json.loads(json.dumps(original))
        changed_size["files"]["index.html"]["size"] = True
        changed_path = json.loads(json.dumps(original))
        changed_path["files"]["../index.html"] = changed_path["files"].pop("index.html")
        for manifest in ({**original, "mode": "verified"}, {**original, "version": "../0.8.0"},
                         {**original, "extra": True}, changed_size, changed_path):
            with self.subTest(manifest=manifest):
                path.write_bytes(build_gaia.json_bytes(manifest))
                with self.assertRaises((ValueError, OSError)):
                    build_gaia.load_site(self.output)

    def test_unowned_destination_is_preserved(self):
        self.output.mkdir()
        sentinel = self.output / "personal.txt"
        sentinel.write_text("preserve this directory")
        with self.assertRaises((ValueError, OSError)):
            build_gaia.build(self.release, self.output)
        self.assertEqual(sentinel.read_text(), "preserve this directory")
        self.assertEqual(set(p.name for p in self.output.iterdir()), {"personal.txt"})

    def test_managed_destination_with_unlisted_file_is_preserved(self):
        build_gaia.build(self.release, self.output)
        sentinel = self.output / "personal.txt"
        sentinel.write_text("preserve this file")
        original = (self.output / "site-manifest.json").read_bytes()
        with self.assertRaises((ValueError, OSError)):
            build_gaia.build(self.release, self.output)
        self.assertEqual(sentinel.read_text(), "preserve this file")
        self.assertEqual((self.output / "site-manifest.json").read_bytes(), original)

    def test_owned_output_can_be_rebuilt_and_downgraded_to_preview(self):
        self.build_signed()
        report = build_gaia.build(self.release, self.output)
        self.assertEqual(report["mode"], "preview")
        self.assertFalse((self.output / self.installer).exists())
        self.assertFalse((self.output / "release-public.pem").exists())
        build_gaia.load_site(self.output)
        self.assertFalse(any(p.name.startswith((".gaia-build-", ".gaia-previous-")) for p in self.base.iterdir()))

    def test_exact_previous_bundle_is_migrated_atomically_to_birth_contract(self):
        build_gaia.build(self.release, self.output)
        manifest_path = self.output / "site-manifest.json"
        manifest = json.loads(manifest_path.read_bytes())
        (self.output / "birth.json").unlink()
        manifest["files"].pop("birth.json")
        manifest_path.write_bytes(build_gaia.json_bytes(manifest))
        with self.assertRaisesRegex(ValueError, "Liste de fichiers publics invalide"):
            build_gaia.load_site(self.output)
        build_gaia.load_site(self.output, allow_legacy=True)
        report = build_gaia.build(self.release, self.output)
        self.assertEqual(report["mode"], "preview")
        _, payloads = build_gaia.load_site(self.output)
        self.assertIn("birth.json", payloads)
        self.assertFalse(any(p.name.startswith((".gaia-build-", ".gaia-previous-")) for p in self.base.iterdir()))

    def test_symlink_destination_or_parent_does_not_change_target(self):
        target = self.base / "preserved"
        target.mkdir()
        (target / "sentinel").write_text("unchanged")
        self.output.symlink_to(target, target_is_directory=True)
        with self.assertRaises((ValueError, OSError)):
            build_gaia.build(self.release, self.output)
        with self.assertRaises((ValueError, OSError)):
            build_gaia.build(self.release, self.output / "nested")
        self.assertEqual((target / "sentinel").read_text(), "unchanged")
        self.assertEqual(set(p.name for p in target.iterdir()), {"sentinel"})

    def test_symlink_or_hardlinked_release_artifact_is_rejected(self):
        source = self.release / self.source
        external = self.base / "source.zip"
        source.rename(external)
        source.symlink_to(external)
        with self.assertRaises((ValueError, OSError)):
            build_gaia.build(self.release, self.output)
        source.unlink()
        os.link(external, source)
        with self.assertRaises((ValueError, OSError)):
            build_gaia.build(self.release, self.output)
        self.assertFalse(self.output.exists())

    def test_symlink_public_payload_is_rejected_by_snapshot_loader(self):
        build_gaia.build(self.release, self.output)
        source = self.output / self.source
        external = self.base / "source.zip"
        source.rename(external)
        source.symlink_to(external)
        with self.assertRaises((ValueError, OSError)):
            build_gaia.load_site(self.output)


if __name__ == "__main__":
    unittest.main()
