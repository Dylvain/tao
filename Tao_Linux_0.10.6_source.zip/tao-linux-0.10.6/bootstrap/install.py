#!/usr/bin/env python3
"""Install a verified runtime while preserving state and a previous runtime pointer."""
from __future__ import annotations
import argparse, ast, fcntl, hashlib, importlib.util, json, os, pwd, py_compile, shutil, signal, subprocess, sys, tempfile, time, urllib.request
from pathlib import Path

try:
    from tao_runtime import RUNTIME_ASSETS, RUNTIME_FILES
except ModuleNotFoundError as exc:
    # Tests and embedders may load this script directly without adding its
    # directory to sys.path. Resolve only our sibling inventory explicitly.
    if exc.name != 'tao_runtime': raise
    spec=importlib.util.spec_from_file_location('tao_runtime',Path(__file__).with_name('tao_runtime.py'))
    if spec is None or spec.loader is None: raise
    runtime_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(runtime_module)
    RUNTIME_ASSETS=runtime_module.RUNTIME_ASSETS;RUNTIME_FILES=runtime_module.RUNTIME_FILES

VERSION='0.10.6'

def runtime_version(script):
    """Read the previous release identifier without importing or running its code."""
    try:
        for node in ast.parse(script.read_bytes()).body:
            if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NODE_VERSION' for t in node.targets):
                value=ast.literal_eval(node.value)
                return value if isinstance(value,str) and value else None
    except (OSError,SyntaxError,ValueError,TypeError): pass
    return None

def manager(action):
    subprocess.run(['systemctl','--user',action,'tao-node.service'],check=True,timeout=15)

def launch_background(root,runtime,env):
    log=root/'daemon.log'
    if log.exists() and log.stat().st_size>2097152: log.replace(root/'daemon.log.previous')
    with log.open('ab') as stream:
        proc=subprocess.Popen(runtime+['daemon'],env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=stream,start_new_session=True)
    log.chmod(0o600)
    return proc

def health_snapshot(root):
    port=json.loads((root/'policy.json').read_text()).get('http_port',8790)
    session=json.loads((root/'session.json').read_text())
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(f'http://127.0.0.1:{port}/health',timeout=.3) as response: health=json.load(response)
    return health if session.get('id') and health.get('session')==session['id'] else {}

def wait_health(root,version,proc=None,require_mobile=False):
    """A healthy unrelated listener must never qualify this installation."""
    if not version: raise RuntimeError('Version précédente impossible à vérifier')
    for _ in range(80):
        if proc is not None and proc.poll() is not None:
            raise RuntimeError('Le processus du service s’est arrêté avant sa confirmation de santé')
        try:
            health=health_snapshot(root)
            mobile_ready=isinstance(health.get('mobile'),dict) and health['mobile'].get('ready') is True
            if health.get('ok') and health.get('node_version')==version and (not require_mobile or mobile_ready):
                return health
        except (OSError,ValueError): pass
        time.sleep(.1)
    raise RuntimeError('La santé du service ne répond pas pour la version et la session attendues'+(' avec accès mobile prêt' if require_mobile else '')+' ; consulter daemon.log ou journalctl --user -u tao-node')

def stop_candidate(systemd,proc):
    if systemd: manager('stop')
    elif proc is not None:
        if proc.poll() is None:
            proc.terminate()
            try: proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill(); proc.wait(timeout=5)
        else: proc.wait()

def user_systemd_available(root):
    # A live user manager belongs to the login home, not a temporary HOME used
    # by a test or an isolated installation. Never install into that other session.
    home=Path.home().resolve()
    if home!=Path(pwd.getpwuid(os.getuid()).pw_dir).resolve(): return False
    if root!=(home/'.tao/genesis').resolve(): return False
    manager_socket=Path(os.environ.get('XDG_RUNTIME_DIR',f'/run/user/{os.getuid()}'))/'systemd/private'
    return bool(manager_socket.is_socket() and shutil.which('systemctl') and subprocess.run(
        ['systemctl','--user','show-environment'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0)

def main():
    # A runtime installation and its basal daemon belong to the whole node.
    os.environ['TAO_WORLD']='main'
    ap=argparse.ArgumentParser(); ap.add_argument('--no-start',action='store_true'); ap.add_argument('--expected-runtime'); args=ap.parse_args()
    if sys.version_info<(3,9): raise SystemExit('Python 3.9 minimum requis')
    if sys.platform!='linux': raise SystemExit('Cet installateur cible Linux')
    src=Path(__file__).resolve().parent
    root=Path(os.environ.get('TAO_ROOT',str(Path.home()/'.tao'/'genesis'))).expanduser().resolve()
    root.mkdir(parents=True,exist_ok=True,mode=0o700); root.chmod(0o700)
    with open(root/'install.lock','a+') as install_lock:
        fcntl.flock(install_lock,fcntl.LOCK_EX)
        no_start=args.no_start or os.environ.get('TAO_NO_START')=='1'
        files={name:src/name for name in RUNTIME_FILES}
        for name in RUNTIME_ASSETS:
            files[name]=src/'tao_frontend'/name
        files['theory.canonical.json']=src.parent/'docs/theory.json'
        payloads={name:path.read_bytes() for name,path in files.items()}
        if args.expected_runtime:
            expected=json.loads(Path(args.expected_runtime).read_text())
            actual={name:hashlib.sha256(data).hexdigest() for name,data in payloads.items()}
            if expected.get('files')!=actual or expected.get('installer')!=hashlib.sha256(Path(__file__).read_bytes()).hexdigest() or expected.get('node_version')!=VERSION:
                raise SystemExit('Les sources diffèrent du commit vérifié ; runtime actif conservé')
        release_hash=hashlib.sha256(b''.join(payloads.values())).hexdigest()[:12]
        release=root/'releases'/f'{VERSION}-{release_hash}'
        release.mkdir(parents=True,exist_ok=True,mode=0o700)
        for name,data in payloads.items():
            if name.endswith('.py'): compile(data,name,'exec')
            target=release/name
            target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
            if target.exists() and target.read_bytes()!=data: raise SystemExit('Version installée différente; fichiers préservés')
            if not target.exists(): target.write_bytes(data); target.chmod(0o600)
        # Qualify the exact runtime in disposable state before touching the active runtime.
        with tempfile.TemporaryDirectory(prefix='tao-install-check-') as td:
            test_env=dict(os.environ,TAO_ROOT=td)
            for command in ['cycle','doctor']:
                subprocess.run([sys.executable,str(release/'tao_node.py'),command],env=test_env,check=True,stdout=subprocess.DEVNULL,timeout=30)
        # Source lives separately from runtime/data; create a local history only when none exists.
        if shutil.which('git') and os.environ.get('TAO_INIT_SOURCE_GIT')=='1':
            repository=src.parent
            inside=subprocess.run(['git','-C',str(repository),'rev-parse','--show-toplevel'],capture_output=True).returncode==0
            if not inside:
                subprocess.run(['git','-C',str(repository),'init','-b','main'],check=True,stdout=subprocess.DEVNULL)
                subprocess.run(['git','-C',str(repository),'add','--','.'],check=True)
                subprocess.run(['git','-c','core.hooksPath=/dev/null','-C',str(repository),'-c','user.name=Tao Local',
                    '-c','user.email=tao@localhost','commit','-m','Tao Linux 0.10.6 — initial local source'],check=True,stdout=subprocess.DEVNULL)
        default_root=(Path.home()/'.tao'/'genesis').resolve()
        systemd=user_systemd_available(root)
        source_file=root/'source.json'
        previous_source=source_file.read_bytes() if source_file.exists() else None
        current=root/'runtime'; previous=os.readlink(current) if current.is_symlink() else None
        previous_version=runtime_version(current/'tao_node.py') if previous else None
        previous_mobile_ready=False
        if previous:
            try:
                health=health_snapshot(root)
                previous_mobile_ready=health.get('node_version')==previous_version and isinstance(health.get('mobile'),dict) and health['mobile'].get('ready') is True
            except (OSError,ValueError): pass
        if current.exists() and not current.is_symlink(): raise SystemExit('runtime doit être un lien symbolique; données préservées')
        config_home=Path(os.environ.get('XDG_CONFIG_HOME',str(Path.home()/'.config')))
        old_unit=config_home/'systemd/user/tao-node.service'
        previous_unit=old_unit.read_bytes() if systemd and old_unit.exists() else None
        if systemd and old_unit.exists():
            manager('stop')
        if (root/'session.json').exists() and (current/'tao_node.py').exists():
            subprocess.run([sys.executable,str(current/'tao_node.py'),'stop'],
                env=dict(os.environ,TAO_ROOT=str(root)),check=True,stdout=subprocess.DEVNULL,timeout=15)
        # Handle previous nohup installs, including 0.4.1, using exact script paths owned by this user.
        allowed={str(root/'tao_node.py'),str(current/'tao_node.py')}
        if previous: allowed.add(str((root/previous/'tao_node.py').resolve()))
        pids=[]
        for item in Path('/proc').iterdir():
            if not item.name.isdigit(): continue
            try:
                if item.stat().st_uid!=os.getuid(): continue
                cmd=(item/'cmdline').read_bytes().split(b'\0')
                if b'daemon' in cmd and any(p.encode() in cmd for p in allowed):
                    os.kill(int(item.name),signal.SIGTERM); pids.append(int(item.name))
            except (OSError,ValueError): continue
        for _ in range(100):
            if all(not Path(f'/proc/{pid}').exists() for pid in pids): break
            time.sleep(.05)
        else: raise SystemExit('Ancien processus encore actif; aucun basculement effectué')
        if previous:
            prev=root/'runtime.previous'; prev.unlink(missing_ok=True); prev.symlink_to(previous)
        temporary=root/'runtime.next'; temporary.unlink(missing_ok=True); temporary.symlink_to(release.relative_to(root)); os.replace(temporary,current)
        bin_dir=Path.home()/'.local/bin'; bin_dir.mkdir(parents=True,exist_ok=True)
        wrapper=bin_dir/'tao'
        if wrapper.exists() and not (root/'tao-launcher.previous').exists(): shutil.copy2(wrapper,root/'tao-launcher.previous')
        wrapper.write_text('#!/usr/bin/env bash\nset -euo pipefail\nROOT="${TAO_ROOT:-$HOME/.tao/genesis}"\nexec python3 "$ROOT/runtime/tao_node.py" "$@"\n')
        wrapper.chmod(0o700)
        env=dict(os.environ,TAO_ROOT=str(root))
        runtime=[sys.executable,str(current/'tao_node.py')]
        proc=None; started=False
        try:
            source_record={'schema':'tao.source.v1','path':str(src.parent),'systemd_user':systemd,
                           'executables':{name:shutil.which(name) for name in ['codex','git']},
                           'path_env':os.environ.get('PATH','')}
            next_source=root/'source.next.json'
            next_source.write_text(json.dumps(source_record,ensure_ascii=False,indent=2))
            next_source.chmod(0o600); os.replace(next_source,source_file)
            subprocess.run(runtime+['cycle'],env=env,check=True,stdout=subprocess.DEVNULL,timeout=30)
            mode='manual'
            if not no_start:
                if systemd:
                    old_unit.parent.mkdir(parents=True,exist_ok=True)
                    old_unit.write_text('''[Unit]
Description=Tao local adaptive node
After=network-online.target
[Service]
Type=simple
ExecStart=/usr/bin/env python3 "%h/.tao/genesis/runtime/tao_node.py" daemon
Restart=on-failure
RestartSec=5
Nice=10
UMask=0077
NoNewPrivileges=yes
[Install]
WantedBy=default.target
''')
                    subprocess.run(['systemctl','--user','daemon-reload'],check=True,timeout=15)
                    manager('enable')
                    started=True; manager('restart')
                    mode='systemd-user'
                else:
                    proc=launch_background(root,runtime,env); started=True
                    if root==default_root:
                        desktop=config_home/'autostart/tao-node.desktop'; desktop.parent.mkdir(parents=True,exist_ok=True)
                        quoted=str(current/'tao_node.py').replace('\\','\\\\').replace('"','\\"').replace('`','\\`').replace('$','\\$').replace('%','%%')
                        desktop.write_text('[Desktop Entry]\nType=Application\nName=Tao\nExec=python3 "'+quoted+'" daemon\nTerminal=false\nX-GNOME-Autostart-enabled=true\n')
                    mode='session-autostart'
                mobile_file=root/'mobile.json'
                require_mobile=mobile_file.exists() and json.loads(mobile_file.read_text()).get('enabled') is True
                wait_health(root,VERSION,proc,require_mobile)
            print(f'TAO_READY=1\nTAO_VERSION={VERSION}\nTAO_RUNTIME={mode}\nTAO_STATE={root}/state.json')
            print('Ouvre http://127.0.0.1:'+str(json.loads((root/'policy.json').read_text()).get('http_port',8790)))
        except Exception:
            # Report recovery separately and re-raise the original failure: restoring
            # service availability must never count as installing the new candidate.
            print('TAO_READY=0',file=sys.stderr)
            try:
                stop_error=None
                if started:
                    try: stop_candidate(systemd,proc)
                    except Exception as exc: stop_error=exc
                if previous_source is not None:
                    next_source=root/'source.next.json'; next_source.write_bytes(previous_source)
                    next_source.chmod(0o600); os.replace(next_source,source_file)
                else: source_file.unlink(missing_ok=True)
                if previous:
                    temporary.unlink(missing_ok=True); temporary.symlink_to(previous); os.replace(temporary,current)
                    if previous_unit is not None:
                        old_unit.write_bytes(previous_unit)
                        subprocess.run(['systemctl','--user','daemon-reload'],check=True,timeout=15)
                    if stop_error is not None: raise RuntimeError('Runtime précédent restauré, mais arrêt du candidat non confirmé : '+str(stop_error))
                    if no_start:
                        print('TAO_RECOVERY=restored_stopped\nAncien runtime restauré. Données conservées ; démarrage non demandé.',file=sys.stderr)
                    else:
                        if systemd: manager('restart'); recovery_proc=None
                        else: recovery_proc=launch_background(root,runtime,env)
                        wait_health(root,previous_version,recovery_proc,previous_mobile_ready)
                        print('TAO_RECOVERY=healthy\nAncien runtime restauré et redémarré ; santé vérifiée. Données conservées. Nouvelle installation refusée.',file=sys.stderr)
                else:
                    current.unlink(missing_ok=True)
                    if stop_error is not None: raise stop_error
                    print('TAO_RECOVERY=unavailable\nAucun runtime précédent à redémarrer. Données conservées ; service indisponible.',file=sys.stderr)
            except Exception as recovery_error:
                print('TAO_RECOVERY=failed\nLa récupération automatique n’a pas été confirmée : '+str(recovery_error),file=sys.stderr)
            raise

if __name__=='__main__': main()
