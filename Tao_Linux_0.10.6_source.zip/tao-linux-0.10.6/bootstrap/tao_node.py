#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, math, os, platform, shutil, socket, sys, threading, time, urllib.parse, urllib.request
import contextlib, fcntl, functools, html, re, secrets, signal, subprocess, tempfile
from collections import Counter, defaultdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import tao_ecology as ecology
import tao_theory as theory
import tao_work as work
import tao_adaptation as adaptation
import tao_learning as learning
import tao_dialogue as dialogue
import tao_continuity as continuity
import tao_worlds as worlds
import tao_mobile as mobile
import tao_handoff as handoff
import tao_devices as devices
import tao_device_worker as device_worker
import tao_tools as durable_tools
import tao_centers_routes as center_routes
import tao_backup as backup
import tao_update as update
import tao_onboarding_routes as onboarding_routes
import tao_foundations as foundations
import tao_workspace_routes as workspace_routes

NODE_VERSION="0.10.6"
THEORY={"id":"tao.origin.v4.unified","version":"4.3.0","sha256":"504cee4d51a4ceca4921313c8309b0b5a6d5cb635d0636571a5f6814a6e24c1e"}
COMMONS="https://tao-commons-production.up.railway.app"

ROOT=Path(os.environ.get("TAO_ROOT", str(Path.home()/".tao"/"genesis"))).expanduser().resolve()
STATE=ROOT/"state.json"
STATE_PREV=ROOT/"state.prev.json"
STATE_SHA=ROOT/"state.sha256"
EVENTS=ROOT/"events.jsonl"
EVIDENCE=ROOT/"evidence.jsonl"
THEORY_PTR=ROOT/"theory.json"
GENOME=ROOT/"genome.json"
REFLEXES=ROOT/"reflexes.json"
DEVELOPMENT=ROOT/"development.json"
POLICY=ROOT/"policy.json"
STORY=ROOT/"story.json"
HERITAGE=ROOT/"heritage.json"
HABITS=ROOT/"habits.json"
LENS_STATE=ROOT/"lens-snapshot.json"
class ProcessLock:
    """Serialize full transactions across HTTP threads and CLI processes."""
    def __init__(self):
        self.mutex=threading.RLock(); self.local=threading.local()
    def __enter__(self):
        self.mutex.acquire()
        try:
            if not getattr(self.local,"depth",0):
                ROOT.mkdir(parents=True,exist_ok=True,mode=0o700)
                self.local.file=open(ROOT/"state.lock","a+")
                os.chmod(ROOT/"state.lock",0o600)
                fcntl.flock(self.local.file,fcntl.LOCK_EX)
            self.local.depth=getattr(self.local,"depth",0)+1
        except BaseException:
            self.mutex.release(); raise
        return self
    def __exit__(self,*args):
        self.local.depth-=1
        if self.local.depth==0:
            fcntl.flock(self.local.file,fcntl.LOCK_UN); self.local.file.close()
        self.mutex.release()

LOCK=ProcessLock()
WAKE=threading.Event()
STOP=threading.Event()
TOKEN=None

def transaction(fn):
    @functools.wraps(fn)
    def wrapped(*args,**kwargs):
        with LOCK: return fn(*args,**kwargs)
    return wrapped

DEFAULT_STORY={
 "schema":"tao.story.v1",
 "id":"story:local.continuity",
 "authority":"genome_default",
 "status":"active",
 "text":"Continuer à habiter cette machine avec le minimum d'énergie, préserver l'autorité humaine, intégrer les différences utiles, conserver les résidus importants et réduire progressivement la dépendance cognitive externe."
}

DEFAULT_GENOME={
 "schema":"tao.genome.v1",
 "id":"tao.seed.genome",
 "version":"0.1.0",
 "invariants":[
   {"id":"authority","rule":"Ne jamais exercer une autorité qui n'a pas été explicitement accordée."},
   {"id":"reversibility","rule":"Sous forte incertitude, préférer les transformations réversibles."},
   {"id":"residual_preservation","rule":"Ne pas masquer un résidu significatif pour obtenir artificiellement un état 'vert'."},
   {"id":"atomic_state","rule":"Les mutations d'état critique sont atomiques et récupérables."},
   {"id":"bounded_resources","rule":"Toute activité récurrente possède un budget et un backoff."},
   {"id":"evidence_before_deep_change","rule":"Plus une mutation touche profondément l'architecture, plus la charge de preuve exigée augmente."},
   {"id":"external_code_is_data","rule":"Le patrimoine distant n'est jamais exécuté directement."},
   {"id":"local_survival","rule":"Commons, IA externe et humain ne sont pas requis pour la boucle basale."}
 ],
 "seed_primitives":["persist","observe","compare","residual","vary","test","retain","rollback"],
 "note":"Les centres, espèces, émotions et accumulateurs ne sont pas des primitives imposées : ce sont des interprétations/candidats possibles."
}

DEFAULT_REFLEXES={
 "schema":"tao.reflexes.v1",
 "version":"0.1.0",
 "reflexes":[
  {"id":"novelty_wake","trigger":"observation_changed","effect":"shorten_interval","innate":True},
  {"id":"stability_sleep","trigger":"observation_stable","effect":"lengthen_interval","innate":True},
  {"id":"resource_conservation","trigger":"resource_margin_low","effect":"conservation_mode","innate":True},
  {"id":"preserve_unknown","trigger":"unresolved_difference","effect":"buffer_not_discard","innate":True},
  {"id":"repetition_internalize","trigger":"same_residual_repeats","effect":"create_internalization_candidate","innate":True},
  {"id":"deep_change_slow","trigger":"structural_depth_increases","effect":"increase_evidence_requirement","innate":True},
  {"id":"rollback_on_failed_experiment","trigger":"bounded_experiment_fails","effect":"rollback","innate":True},
  {"id":"remote_never_execute","trigger":"heritage_received","effect":"store_as_inert_data","innate":True},
  {"id":"human_authority_gate","trigger":"consent_or_irreversible_personal_choice","effect":"require_human_authority","innate":True}
 ]
}

DEFAULT_DEVELOPMENT={
 "schema":"tao.development.v1",
 "version":"0.1.0",
 "kit":[
  "bounded_parameter_experiment",
  "evidence_recording",
  "rollback",
  "habit_compilation",
  "heritage_screening",
  "specialization_candidate_detection",
  "adaptive_scheduler",
  "observer_model_revision"
 ],
 "depths":{
   "state":1,
   "habit":2,
   "recipe":3,
   "organ":4,
   "center":5,
   "architecture":6,
   "genome":7
 },
 "min_evidence_by_depth":{"1":1,"2":3,"3":5,"4":12,"5":30,"6":80,"7":200},
 "auto_apply_max_depth":2,
 "note":"Seules les adaptations locales et réversibles de profondeur <=2 peuvent être auto-appliquées."
}

DEFAULT_HERITAGE={
 "schema":"tao.heritage.cache.v1",
 "builtin":[
  {"id":"heritage:atomic-write","kind":"recipe","capability":"persistence","content":"écrire dans un fichier temporaire, fsync si nécessaire, puis remplacer atomiquement","source":"builtin"},
  {"id":"heritage:exponential-backoff","kind":"recipe","capability":"scheduler","content":"augmenter l'intervalle quand le milieu reste stable et le réduire lorsqu'une nouveauté apparaît","source":"builtin"},
  {"id":"heritage:authority-gate","kind":"knowledge","capability":"authority","content":"une capacité technique ne vaut pas autorité","source":"builtin"},
  {"id":"heritage:rollback-first","kind":"recipe","capability":"mutation","content":"conserver un état antérieur avant toute mutation auto-appliquée","source":"builtin"},
  {"id":"heritage:remote-is-data","kind":"knowledge","capability":"heritage","content":"ne jamais exécuter directement un artefact reçu du réseau","source":"builtin"}
 ],
 "remote":[],
 "last_sync_at":None,
 "last_sync_status":"never",
 "next_sync_after":0
}

DEFAULT_POLICY={
 "schema":"tao.node.policy.v2",
 "local_first":True,
 "commons_read":False,
 "commons_write":False,
 "external_ai_auto":False,
 "human_interrupt_auto":False,
 "self_modify_code":False,
 "auto_apply_max_depth":2,
 "http_host":"127.0.0.1",
 "http_port":8790,
 "min_sleep_seconds":15,
 "max_sleep_seconds":1800,
 "conservation_min_sleep_seconds":120,
 "heritage_sync_seconds":43200,
 "buffer_internalize_seen":4,
 "habit_promote_seen":8,
 "resolved_retention":100,
 "journal_max_bytes":2097152,
 "journal_keep":4,
 "adaptation_runs_per_day":3,
 "adaptation_seconds_per_day":1800,
 "dialogue_runs_per_day":20,
 "dialogue_seconds_per_day":1800
}

def now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def epoch():
    return int(time.time())

def clamp(x,a=0.0,b=1.0):
    return max(a,min(b,float(x)))

def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()

def json_bytes(obj):
    return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()

def load_json(path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default
    except (ValueError, OSError) as exc:
        raise RuntimeError(f"Fichier illisible conservé : {path.name}: {exc}") from exc

def durable_bytes(path, data):
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    fd,tmp=tempfile.mkstemp(prefix="."+path.name+"-",dir=path.parent)
    try:
        with os.fdopen(fd,"wb") as out:
            out.write(data); out.flush(); os.fsync(out.fileno())
        os.chmod(tmp,0o600); os.replace(tmp,path)
        dfd=os.open(path.parent,os.O_RDONLY)
        try: os.fsync(dfd)
        finally: os.close(dfd)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def checked_state(path):
    raw=path.read_bytes(); value=json.loads(raw)
    if not isinstance(value,dict) or not isinstance(value.get("buffers"),dict):
        raise ValueError("invalid state schema")
    claimed=value.pop("_integrity",None)
    if claimed is not None:
        if claimed!=digest_bytes(json_bytes(value)): raise ValueError("state checksum mismatch")
    elif path==STATE and STATE_SHA.exists():
        if digest_bytes(raw)!=STATE_SHA.read_text().strip(): raise ValueError("legacy state checksum mismatch")
    elif path==STATE_PREV:
        raise ValueError("unverified legacy backup; manual recovery required")
    return value

@transaction
def atomic_json(path,obj,backup=False):
    obj=dict(obj)
    if path==STATE:
        if '_world_view' in obj:
            raw=checked_state(STATE) if STATE.exists() else initial_state()
            obj=worlds.merge(raw,obj)
        obj.pop("_integrity",None)
        obj["_integrity"]=digest_bytes(json_bytes(obj))
    data=json.dumps(obj,ensure_ascii=False,indent=2).encode()
    if backup and path.exists():
        # Preserve only a state already verified, never replace a valid backup with corruption.
        previous=checked_state(path)
        previous["_integrity"]=digest_bytes(json_bytes(previous))
        durable_bytes(STATE_PREV,json.dumps(previous,ensure_ascii=False,indent=2).encode())
    durable_bytes(path,data)
    if path==STATE: durable_bytes(STATE_SHA,(digest_bytes(data)+"\n").encode())

@transaction
def append_jsonl(path,row):
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    p=policy(); limit=p["journal_max_bytes"]; keep=p["journal_keep"]
    if path.exists() and path.stat().st_size>=limit:
        last=path.with_name(path.name+f".{keep}")
        if last.exists(): last.unlink()
        for index in range(keep-1,0,-1):
            older=path.with_name(path.name+f".{index}")
            if older.exists(): older.replace(path.with_name(path.name+f".{index+1}"))
        path.replace(path.with_name(path.name+".1"))
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
    with os.fdopen(fd,"a",encoding="utf-8") as f:
        f.write(json.dumps(row,ensure_ascii=False,separators=(",",":"))+"\n")
        f.flush()
    os.chmod(path,0o600)

def event(kind,data):
    append_jsonl(EVENTS,{"at":now(),"kind":kind,"data":data})

def machine_id():
    return hashlib.sha256((socket.gethostname()+"|"+str(ROOT)).encode()).hexdigest()[:24]

def policy():
    p=load_json(POLICY,{}) or {}
    if not isinstance(p,dict): raise ValueError("policy.json doit être un objet")
    q=dict(DEFAULT_POLICY); q.update(p)
    for k,v in DEFAULT_POLICY.items():
        if isinstance(v,bool) and not isinstance(q[k],bool): raise ValueError(f"Politique booléenne invalide: {k}")
    for k,lo,hi in [("http_port",1024,65535),("min_sleep_seconds",1,3600),
          ("max_sleep_seconds",1,86400),("conservation_min_sleep_seconds",1,86400),
          ("heritage_sync_seconds",60,604800),("habit_promote_seen",3,10000),
          ("buffer_internalize_seen",2,10000),("resolved_retention",1,10000),
          ("auto_apply_max_depth",0,2),("journal_max_bytes",1024,16777216),("journal_keep",1,10),
          ("adaptation_runs_per_day",0,20),("adaptation_seconds_per_day",0,14400),
          ("dialogue_runs_per_day",0,100),("dialogue_seconds_per_day",0,14400)]:
        if type(q[k]) is not int or not lo<=q[k]<=hi: raise ValueError(f"Politique invalide: {k}")
    if q["min_sleep_seconds"]>q["max_sleep_seconds"]: raise ValueError("Intervalle min > max")
    if q["http_host"]!="127.0.0.1": raise ValueError("Le nœud local écoute uniquement sur 127.0.0.1")
    if q["self_modify_code"] or q["external_ai_auto"] or q["commons_write"]:
        raise ValueError("Cette politique exige un pilote absent; utiliser l'atelier explicite")
    return q

def genome():
    return load_json(GENOME,DEFAULT_GENOME) or DEFAULT_GENOME

def reflexes():
    return load_json(REFLEXES,DEFAULT_REFLEXES) or DEFAULT_REFLEXES

def development():
    return load_json(DEVELOPMENT,DEFAULT_DEVELOPMENT) or DEFAULT_DEVELOPMENT

def heritage():
    return load_json(HERITAGE,DEFAULT_HERITAGE) or DEFAULT_HERITAGE

def story():
    if worlds.current()!='main':
        s=load_state();meta=worlds.describe(sys.modules[__name__],s)['current']
        if not s.get('story') and meta.get('template_key'):
            return {'schema':'tao.story.v1','id':'story:'+worlds.current(),
                    'authority':'template_context','source':'software_template',
                    'status':'empty','text':''}
        return s.get('story') or {'schema':'tao.story.v1','id':'story:'+worlds.current(),
            'authority':'human_description','status':'active','text':meta.get('description') or meta['title']}
    return load_json(STORY,DEFAULT_STORY) or DEFAULT_STORY

def initial_state():
    return foundations.seed({
      "schema":"tao.node.state.v4",
      "id":"node:"+machine_id(),
      "class":"tao.sovereign.adaptive.seed",
      "maturity":"seedling",
      "node_version":NODE_VERSION,
      "born_at":now(),
      "theory":THEORY,
      "seed":{"primitives":DEFAULT_GENOME["seed_primitives"],"transition_count":0},
      "observer_model":{
        "status":"observer_hypothesis",
        "interpretation":"C0",
        "description":"La boucle entière peut être décrite de l'extérieur comme un proto-centre; C0 n'est pas une primitive imposée.",
        "specialization_candidates":[]
      },
      "mode":"normal",
      "buffers":{},
      "memory":{"environment_fingerprints":[],"residual_counts":{}},
      "development":{"internalization_candidates":[],"experiments":[],"adaptations":[]},
      "resource_profile":{
        "external_ai_calls":0,
        "human_interruptions":0,
        "network_heritage_reads":0,
        "cycles":0,
        "estimated_work_units":0.0
      },
      "scheduler":{"sleep_seconds":30,"novelty_ewma":1.0,"stable_cycles":0},
      "heritage":{"builtin_count":len(DEFAULT_HERITAGE["builtin"]),"remote_count":0,"last_sync_status":"never"},
      "cycles":0
    })

@transaction
def ensure_files():
    theory.load(THEORY)
    ROOT.mkdir(parents=True,exist_ok=True,mode=0o700)
    os.chmod(ROOT,0o700)
    for path,obj in [
        (GENOME,DEFAULT_GENOME),(REFLEXES,DEFAULT_REFLEXES),(DEVELOPMENT,DEFAULT_DEVELOPMENT),
        (POLICY,DEFAULT_POLICY),(STORY,DEFAULT_STORY),(HERITAGE,DEFAULT_HERITAGE),(THEORY_PTR,THEORY),
        (HABITS,{"schema":"tao.habits.v1","habits":[]})
    ]:
        if not path.exists(): atomic_json(path,obj)
    previous_theory=theory.known_legacy(load_json(THEORY_PTR))
    if previous_theory:
        atomic_json(ROOT/'theory-migration-4.3.json',{'at':now(),'previous':previous_theory,'current':THEORY,
            'reason':'Contrat technique consolidé ; aucune donnée privée convertie'})
        atomic_json(THEORY_PTR,THEORY)
    if not STATE.exists() and not STATE_PREV.exists(): atomic_json(STATE,initial_state(),backup=False)

@transaction
def load_raw_state():
    ensure_files()
    try:
        s=checked_state(STATE)
    except (OSError,ValueError) as exc:
        try: s=checked_state(STATE_PREV)
        except (OSError,ValueError) as backup_exc:
            raise RuntimeError("État et sauvegarde invalides; fichiers préservés. Restaurer une sauvegarde vérifiée.") from backup_exc
        if STATE.exists():
            durable_bytes(ROOT/("state.corrupt-"+str(time.time_ns())+".json"),STATE.read_bytes())
        touch_buffer(s["buffers"],"persistence.recovered","integrity",
                     "État précédent restauré après corruption; examiner les données mises en quarantaine.",0.95,0.1,0.5)
        atomic_json(STATE,s)
        event("state_recovered",{"reason":str(exc),"source":"state.prev.json"})
    s["node_version"]=NODE_VERSION
    if theory.known_legacy(s.get('theory')): s['theory']=dict(THEORY)
    ecology.ensure(s)
    return s

@transaction
def load_state():
    s=worlds.project(load_raw_state())
    if s.get('continuity'): continuity.ensure(s)
    return s

def proc_mem():
    out={}
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            k,v=line.split(":",1); out[k]=int(v.strip().split()[0])*1024
    except Exception: pass
    return out

def battery():
    root=Path("/sys/class/power_supply")
    if not root.exists(): return None
    rows=[]
    for p in root.iterdir():
        try:
            typ=(p/"type").read_text().strip()
            if typ!="Battery": continue
            cap=int((p/"capacity").read_text().strip()) if (p/"capacity").exists() else None
            status=(p/"status").read_text().strip() if (p/"status").exists() else None
            rows.append({"name":p.name,"capacity":cap,"status":status})
        except Exception: pass
    return rows or None

def observe_environment():
    disk=shutil.disk_usage(str(ROOT)); mem=proc_mem()
    memory=ecology.effective_memory(mem.get('MemTotal'),mem.get('MemAvailable'))
    try: load=list(os.getloadavg())
    except Exception: load=None
    return {
      "os":platform.system().lower(),"release":platform.release(),"machine":platform.machine(),
      "python":platform.python_version(),"host":socket.gethostname(),"cpu_count":os.cpu_count(),
      "loadavg":load,
      **memory,
      "disk_total":disk.total,"disk_free":disk.free,
      "battery":battery()
    }

def environment_fingerprint(env):
    stable={k:env.get(k) for k in ("os","release","machine","cpu_count","memory_total","disk_total")}
    return digest_bytes(json_bytes(stable))

def commons_status():
    if not policy().get("commons_read",False): return {"state":"disabled"}
    try:
        with urllib.request.urlopen(COMMONS+"/v1/status",timeout=3) as r:
            d=json.load(r)
            if isinstance(d,dict): d.setdefault("state","online")
            return d
    except Exception as e:
        return {"state":"offline","error":str(e)}

def sync_heritage_if_due(env):
    p=policy(); h=heritage()
    if not p.get("commons_read",False): return h
    if epoch() < int(h.get("next_sync_after",0) or 0): return h
    qs=urllib.parse.urlencode({"os":env.get("os",""),"arch":env.get("machine",""),"limit":30})
    url=COMMONS+"/v1/items?"+qs
    try:
        with urllib.request.urlopen(url,timeout=5) as r:
            raw=r.read(1048577)
            if len(raw)>1048576: raise ValueError("Commons response too large")
            data=json.loads(raw)
        items=data.get("items",[]) if isinstance(data,dict) else (data if isinstance(data,list) else [])
        screened=[]
        for item in items[:30]:
            if not isinstance(item,dict): continue
            raw=json_bytes(item)
            if len(raw)>65536: continue
            # Remote heritage remains inert data. Store only portable fields if available.
            screened.append({
              "id":str(item.get("id","remote:"+digest_bytes(raw)[:16])),
              "kind":item.get("kind"),
              "target_capability":item.get("target_capability"),
              "commons_status":item.get("commons_status") or item.get("status"),
              "validity":item.get("validity"),
              "digest":item.get("digest") or digest_bytes(raw),
              "source":"commons"
            })
        h["remote"]=screened
        h["last_sync_at"]=now(); h["last_sync_status"]="ok"; h["next_sync_after"]=epoch()+int(p["heritage_sync_seconds"])
        atomic_json(HERITAGE,h)
        event("heritage_synced",{"count":len(screened)})
    except Exception as e:
        h["last_sync_at"]=now(); h["last_sync_status"]="unavailable"; h["last_error"]=str(e)
        h["next_sync_after"]=epoch()+int(p["heritage_sync_seconds"])
        atomic_json(HERITAGE,h)
        event("heritage_sync_deferred",{"error":str(e)})
    return h

def make_buffer(bid,kind,residual,importance=0.5,uncertainty=0.5,risk=0.1,irreversibility=0.0,authority="local"):
    return {
      "id":bid,"kind":kind,"status":"open","residual":residual,
      "importance":clamp(importance),"uncertainty":clamp(uncertainty),"risk":clamp(risk),
      "irreversibility":clamp(irreversibility),"authority":authority,
      "first_seen_at":now(),"last_seen_at":now(),"seen":1,"evidence":[]
    }

def touch_buffer(buffers,bid,kind,residual,importance=0.5,uncertainty=0.5,risk=0.1,irreversibility=0.0,authority="local"):
    if bid not in buffers:
        buffers[bid]=make_buffer(bid,kind,residual,importance,uncertainty,risk,irreversibility,authority)
    else:
        b=buffers[bid]
        if b.get("status")!="open":
            b["reopened_at"]=now()
        b.update({"status":"open","residual":residual,"importance":clamp(importance),
                  "uncertainty":clamp(uncertainty),"risk":clamp(risk),
                  "irreversibility":clamp(irreversibility),"authority":authority,
                  "last_seen_at":now(),"seen":int(b.get("seen",0))+1})
    return buffers[bid]

def resolve_buffer(buffers,bid,reason):
    b=buffers.get(bid)
    if b and b.get("status")=="open":
        b["status"]="resolved"; b["resolved_at"]=now(); b["resolution"]=reason

def open_buffers(s):
    return [b for b in s.get("buffers",{}).values() if b.get("status")=="open"]

def cognitive_demand(b):
    recurrence=clamp(math.log1p(max(1,int(b.get("seen",1))))/math.log(12))
    novelty=1.0-recurrence*0.65
    return {
      "novelty":round(novelty,3),
      "uncertainty":round(float(b.get("uncertainty",0.5)),3),
      "recurrence":round(recurrence,3),
      "risk":round(float(b.get("risk",0.1)),3),
      "irreversibility":round(float(b.get("irreversibility",0.0)),3),
      "importance":round(float(b.get("importance",0.5)),3)
    }

def route_cognition(b, habits, heritage_cache):
    d=cognitive_demand(b)
    if b.get("authority")=="human" or d["irreversibility"]>=0.8:
        return "sovereign_human"
    if any(h.get("trigger_buffer")==b["id"] and h.get("status")=="active" and h.get("validated") is True for h in habits.get("habits",[])):
        return "deterministic_local"
    if d["recurrence"]>=0.45 and d["risk"]<0.5:
        return "local_internalization"
    if heritage_cache.get("remote") or heritage_cache.get("builtin"):
        if d["uncertainty"]<0.65 and d["risk"]<0.65:
            return "compatible_heritage"
    if d["novelty"]+d["uncertainty"]+d["importance"] >= 2.1:
        return "powerful_external_ai"
    if d["novelty"]+d["uncertainty"] >= 1.0:
        return "small_local_model"
    return "deterministic_local"

def resource_margins(env):
    disk=(env["disk_free"]/env["disk_total"]) if env.get("disk_total") else 1.0
    mem=(env["memory_available"]/env["memory_total"]) if env.get("memory_total") and env.get("memory_available") is not None else 1.0
    batt=1.0
    rows=env.get("battery") or []
    if rows:
        vals=[x["capacity"]/100 for x in rows if x.get("capacity") is not None]
        if vals: batt=min(vals)
    return {"disk":clamp(disk),"memory":clamp(mem),"battery":clamp(batt)}

def compile_habits(s):
    p=policy(); habits=load_json(HABITS,{"schema":"tao.habits.v1","habits":[]}) or {"schema":"tao.habits.v1","habits":[]}
    existing={x.get("trigger_buffer") for x in habits.get("habits",[])}
    created=[]
    for h in habits.get('habits',[]):
        if h.get('status')=='active' and h.get('validated') is not True:
            h['status']='candidate'; h['reason']='Ancienne habitude sans preuve de résolution; requalification requise.'
            atomic_json(HABITS,habits)
    for b in s.get("buffers",{}).values():
        if int(b.get("seen",0)) < int(p["habit_promote_seen"]): continue
        if b.get("status")!="open" or b.get("authority")!="local": continue
        if float(b.get("risk",1))>=0.4 or float(b.get("irreversibility",1))>=0.2: continue
        if b["id"] in existing: continue
        response="backoff_and_observe"
        if b["id"]=="commons.link": response="accept_offline_and_backoff"
        habits["habits"].append({
          "id":"habit:"+digest_bytes(b["id"].encode())[:16],
          "trigger_buffer":b["id"],
          "response":response,
          "status":"candidate",
          "validated":False,
          "reason":"Répétition observée; aucune réduction du résidu démontrée.",
          "depth":2,
          "created_at":now(),
          "source":"repeated_residual",
          "evidence_seen":int(b.get("seen",0)),
          "external_action":False
        })
        created.append(b["id"])
    if created:
        atomic_json(HABITS,habits); event("habits_compiled",{"buffers":created})
    return habits,created

def internalization_candidates(s):
    p=policy(); out=[]
    for b in open_buffers(s):
        if int(b.get("seen",1))>=int(p["buffer_internalize_seen"]):
            out.append({
              "id":"internalize:"+digest_bytes(b["id"].encode())[:16],
              "source_buffer":b["id"],
              "status":"candidate",
              "depth":2 if float(b.get("risk",0))<0.4 else 3,
              "reason":"repeated residual",
              "seen":int(b.get("seen",1)),
              "created_or_observed_at":now()
            })
    # stable unique
    seen=set(); unique=[]
    for x in sorted(out,key=lambda y:-y["seen"]):
        if x["source_buffer"] not in seen:
            seen.add(x["source_buffer"]); unique.append(x)
    return unique

def specialization_candidates(s):
    # Observer-side hypothesis only. The runtime does not create a center automatically.
    groups=defaultdict(list)
    for b in open_buffers(s):
        groups[b.get("kind","unknown")].append(b)
    out=[]
    for kind,items in groups.items():
        recurrence=sum(int(x.get("seen",1)) for x in items)
        if recurrence>=12 and len(items)>=2:
            out.append({
              "id":"specialization:"+kind,
              "kind":kind,
              "status":"observer_candidate",
              "recurrence":recurrence,
              "buffer_count":len(items),
              "note":"May justify a specialized representation later; not auto-applied."
            })
    return out

def adapt_scheduler(s, changed, margins):
    p=policy(); sch=s.setdefault("scheduler",{})
    prev=float(sch.get("novelty_ewma",1.0))
    novelty=1.0 if changed else 0.0
    ewma=0.25*novelty+0.75*prev
    sch["novelty_ewma"]=round(ewma,4)
    if changed:
        sch["stable_cycles"]=0
        interval=int(p["min_sleep_seconds"])
    else:
        sch["stable_cycles"]=int(sch.get("stable_cycles",0))+1
        old=int(sch.get("sleep_seconds",30))
        interval=min(int(p["max_sleep_seconds"]),max(int(p["min_sleep_seconds"]),int(old*1.6)))
    conserve=min(margins.values())<0.10
    if conserve:
        interval=max(interval,int(p["conservation_min_sleep_seconds"]))
        s["mode"]="conserve"
    else:
        s["mode"]="normal"
    interval=min(int(p["max_sleep_seconds"]),interval)
    sch["sleep_seconds"]=interval
    return interval

def prune_resolved(s):
    limit=int(policy()["resolved_retention"])
    resolved=[b for b in s.get("buffers",{}).values() if b.get("status")=="resolved" and not b.get('dialogue_need')]
    if len(resolved)<=limit:return
    resolved.sort(key=lambda b:b.get("resolved_at",""))
    remove={b["id"] for b in resolved[:-limit]}
    for bid in remove:s["buffers"].pop(bid,None)

def cycle():
    with LOCK:
        ensure_files()
        s=load_state()
        started=time.monotonic(); cpu_started=time.process_time()
        env=observe_environment()
        fp=environment_fingerprint(env)
        previous_fp=s.get("memory",{}).get("last_environment_fingerprint")
        changed=(fp!=previous_fp)
        s.setdefault("memory",{})["last_environment_fingerprint"]=fp
        fps=s["memory"].setdefault("environment_fingerprints",[])
        if not fps or fps[-1]!=fp:
            fps.append(fp)
            del fps[:-20]

        h_before=heritage()
        h=sync_heritage_if_due(env)
        heritage_synced_this_cycle=(h_before.get("last_sync_at")!=h.get("last_sync_at"))
        commons={"state":"online" if h.get("last_sync_status")=="ok" else ("unknown" if h.get("last_sync_status")=="never" else "offline"),
                 "source":"heritage_backoff","last_sync_at":h.get("last_sync_at"),"last_sync_status":h.get("last_sync_status")}
        habits=load_json(HABITS,{"schema":"tao.habits.v1","habits":[]}) or {"schema":"tao.habits.v1","habits":[]}
        b=s.setdefault("buffers",{})

        ptr=load_json(THEORY_PTR,{}) or {}
        if ptr!=THEORY:
            touch_buffer(b,"theory.local","theory","Canonical theory pointer missing or mismatched",0.90,0.05,0.15,0.0)
        else: resolve_buffer(b,"theory.local","theory pointer matches")

        if commons.get("state")=="offline":
            touch_buffer(b,"commons.link","environment","Commons unavailable; basal local operation continues",0.18,0.10,0.05,0.0)
        elif commons.get("state")=="online": resolve_buffer(b,"commons.link","Commons reachable")

        margins=resource_margins(env)
        if margins["disk"]<0.05:
            touch_buffer(b,"viability.disk","resource","State filesystem free space below 5%",0.98,0.05,0.8,0.4)
        else: resolve_buffer(b,"viability.disk","disk margin acceptable")
        if margins["memory"]<0.05:
            touch_buffer(b,"viability.memory","resource","Available memory below 5%",0.98,0.10,0.7,0.2)
        else: resolve_buffer(b,"viability.memory","memory margin acceptable")
        batt=env.get("battery") or []
        low_batt=any((x.get("capacity") is not None and x["capacity"]<12 and str(x.get("status","")).lower()!="charging") for x in batt)
        if low_batt:
            touch_buffer(b,"viability.battery","resource","Battery below 12% and not charging",0.92,0.05,0.35,0.1)
        else: resolve_buffer(b,"viability.battery","battery margin acceptable or not applicable")

        if changed and previous_fp:
            touch_buffer(b,"environment.shift","novelty","The machine environment fingerprint changed",0.55,0.45,0.15,0.0)
        elif not changed:
            resolve_buffer(b,"environment.shift","new environment fingerprint stabilized")

        for x in open_buffers(s):
            x["cognitive_demand"]=cognitive_demand(x)
            x["recommended_level"]=route_cognition(x,habits,h)

        habits,created=compile_habits(s)
        s.setdefault("development",{})["internalization_candidates"]=internalization_candidates(s)
        s["observer_model"]["specialization_candidates"]=specialization_candidates(s)
        s["heritage"]={
          "builtin_count":len(h.get("builtin",[])),
          "remote_count":len(h.get("remote",[])),
          "last_sync_status":h.get("last_sync_status"),
          "last_sync_at":h.get("last_sync_at")
        }

        buffer_signature=digest_bytes(json_bytes(sorted(
            [(x.get("id"),x.get("status"),x.get("residual")) for x in s.get("buffers",{}).values()]
        )))
        previous_buffer_signature=s.setdefault("memory",{}).get("last_buffer_signature")
        buffer_changed=(buffer_signature!=previous_buffer_signature)
        s["memory"]["last_buffer_signature"]=buffer_signature
        changed_any=changed or buffer_changed
        interval=adapt_scheduler(s,changed_any,margins)
        s["last_cycle_epoch"]=epoch()
        s["cycles"]=int(s.get("cycles",0))+1
        s["seed"]["transition_count"]=int(s["seed"].get("transition_count",0))+1
        s["resource_profile"]["cycles"]=s["cycles"]
        s["resource_profile"]["network_heritage_reads"]=int(s["resource_profile"].get("network_heritage_reads",0)) + (1 if heritage_synced_this_cycle else 0)
        work=0.002 + 0.002*len(open_buffers(s)) + (0.01 if changed else 0.0)
        s["resource_profile"]["estimated_work_units"]=round(float(s["resource_profile"].get("estimated_work_units",0))+work,6)
        s["observation"]={"at":now(),"environment":env,"environment_fingerprint":fp,"commons":commons,"resource_margins":margins}
        s["story"]=story()
        s["habits"]={"active":len([x for x in habits.get("habits",[]) if x.get("status")=="active"]),"new_this_cycle":len(created)}
        s["last_evidence"]={
          "cycle":s["cycles"],"at":now(),"open_buffers":len(open_buffers(s)),
          "environment_changed":changed,"buffer_changed":buffer_changed,"mode":s["mode"],"sleep_seconds":interval,
          "duration_ms":round((time.monotonic()-started)*1000,2),
          "external_ai_calls":s["resource_profile"]["external_ai_calls"],
          "human_interruptions":s["resource_profile"]["human_interruptions"]
        }
        append_jsonl(EVIDENCE,s["last_evidence"])
        prune_resolved(s)
        ecology.measure_cycle(s,time.process_time()-cpu_started,time.monotonic()-started)
        atomic_json(STATE,s,backup=True)
        event("cycle",s["last_evidence"])
        write_lens_snapshot(s)
        return s

def write_lens_snapshot(s):
    rows=[]
    for b in open_buffers(s):
        rows.append({
          "schema":"tao.buffer.v1","id":b["id"],"status":"open","kind":b.get("kind"),
          "capability":"seed","importance":b.get("importance"),"desired_state":"integrated_or_bounded",
          "current_state":b.get("residual"),"residual_difference":b.get("residual"),
          "evidence":b.get("evidence",[]),"attempts":[],
          "origin_hypothesis":b.get("origin_hypothesis"),
          "origin_traces":b.get("origin_traces",[]),
          "first_seen_at":b.get("first_seen_at"),"last_seen_at":b.get("last_seen_at"),
          "trace_context":{"observer_model":"C0","recommended_level":b.get("recommended_level"),
                           "cognitive_demand":b.get("cognitive_demand")},
          "privacy":{"scope":"local_private","shareable_projection":False}
        })
    snap={
      "schema":"tao.lens.snapshot.v2","captured_at":now(),
      "tao":{"version":NODE_VERSION,"class":s.get("class"),"maturity":s.get("maturity"),"theory":THEORY},
      "environment":s.get("observation",{}).get("environment",{}),
      "summary":{"open_buffers":len(rows),"mode":s.get("mode"),"sleep_seconds":s.get("scheduler",{}).get("sleep_seconds"),
                 "heritage_remote":s.get("heritage",{}).get("remote_count",0)},
      "buffers":rows,
      "development":s.get("development",{}),
      "observer_model":s.get("observer_model",{}),
      "ecology":ecology.snapshot(sys.modules[__name__],s),
      "recent_evidence":[s.get("last_evidence",{})]
    }
    snap['world_id']=worlds.current()
    target=LENS_STATE if worlds.current()=='main' else ROOT/'world-snapshots'/worlds.current()/'lens.json'
    try: atomic_json(target,snap)
    except OSError as exc: event("lens_write_failed",{"error":str(exc)})
    return snap

@transaction
def public_state(s=None):
    s=s or load_state()
    return {
      "id":s.get("id"),"class":s.get("class"),"maturity":s.get("maturity"),
      "node_version":s.get("node_version"),"theory":s.get("theory"),
      "seed":s.get("seed"),"genome":{"id":genome().get("id"),"version":genome().get("version"),
      "invariant_count":len(genome().get("invariants",[]))},
      "story":story(),"mode":s.get("mode"),"work_context":s.get('work_context'),
      "learning":s.get('learning',{}),
      "dialogue":s.get('dialogue',{}),
      "continuity":s.get('continuity',{}),
      "presentation":s.get('presentation',{'view':'needs','revision':0}),
      "world":worlds.describe(sys.modules[__name__],s),
      "cycles":s.get("cycles"),"scheduler":s.get("scheduler"),
      "resource_profile":s.get("resource_profile"),
      "ecology":ecology.snapshot(sys.modules[__name__],s),
      "heritage":s.get("heritage"),"habits":s.get("habits"),
      "buffers":open_buffers(s),"development":s.get("development"),
      "observer_model":s.get("observer_model"),"observation":s.get("observation")
    }

def dashboard(s):
    from tao_ui import render
    return scoped_links(render(sys.modules[__name__],s,TOKEN))

def scoped_links(page):
    def scoped_link(match):
        url=match.group(1)
        if 'world=' in url or url.startswith('/host/'): return match.group(0)
        return 'href="'+url+('&amp;' if '?' in url else '?')+'world='+worlds.current()+'"'
    return re.sub(r'href="(/[^"#]*)"',scoped_link,page)

ORIGIN_TYPES={'undetermined','internal','translation','conciliation'}
TRACE_FIELDS={'source','destination','input','output','difference'}

def validate_origin_trace(origin_type,trace):
    if origin_type not in ORIGIN_TYPES: raise ValueError('Origine du résidu inconnue')
    if trace is None: trace={}
    if not isinstance(trace,dict) or set(trace)-TRACE_FIELDS: raise ValueError('Champs de trace inconnus')
    clean={}
    for key,value in trace.items():
        if not isinstance(value,str) or len(value)>1000: raise ValueError('Trace textuelle requise, 1000 caractères maximum par champ')
        if value.strip(): clean[key]=value.strip()
    if origin_type=='undetermined':
        if clean: raise ValueError('Choisir une hypothèse avant de joindre une trace')
        return None
    if any(not clean.get(key) for key in ('input','output','difference')):
        raise ValueError('Décrire l’entrée, la sortie et la différence observée')
    if origin_type=='translation' and any(not clean.get(key) for key in ('source','destination')):
        raise ValueError('Nommer les deux représentations de la traduction')
    return clean

@transaction
def add_buffer(residual,desired,acceptance,origin_type='undetermined',trace=None):
    for text,limit in [(residual,4000),(desired,2000),(acceptance,2000)]:
        if not isinstance(text,str) or not text.strip() or len(text)>limit: raise ValueError("Champs requis ou trop longs")
    observed=validate_origin_trace(origin_type,trace)
    s=load_state()
    if len(open_buffers(s))>=200: raise ValueError("200 tampons ouverts; résoudre ou regrouper avant d'ajouter")
    identity=[residual.strip(),desired.strip(),acceptance.strip()]
    if observed is not None: identity.append(origin_type)
    bid="user:"+digest_bytes(json_bytes(identity))[:12]
    b=touch_buffer(s['buffers'],bid,"user",residual.strip(),0.7,0.6,0.2,0.0,"human")
    b.update({'desired':desired.strip(),'acceptance':acceptance.strip(),'story_id':story()['id']})
    if observed is not None:
        rows=b.setdefault('origin_traces',[])
        row={'at':now(),'source':'human_report','kind':origin_type,'status':'hypothesis','trace':observed}
        if not rows or rows[-1]['kind']!=origin_type or rows[-1]['trace']!=observed:
            rows.append(row)
        b['origin_traces']=rows[-20:]
        b['origin_hypothesis']={'kind':origin_type,'status':'hypothesis','source':'human_report'}
    atomic_json(STATE,s,backup=True); event("buffer_recorded",{'id':bid}); WAKE.set()
    return b

@transaction
def close_buffer(bid,evidence):
    if not isinstance(evidence,str) or not evidence.strip() or len(evidence)>4000: raise ValueError('Preuve requise, maximum 4000 caractères')
    s=load_state(); b=s['buffers'].get(bid)
    if not b or b.get('kind') not in ('user','work','code_projection'): raise ValueError('Seuls les besoins utilisateur se résolvent manuellement; les capteurs revérifient les autres')
    b.setdefault('evidence',[]).append({'at':now(),'source':'human_report','text':evidence.strip()})
    resolve_buffer(s['buffers'],bid,'Résolution déclarée par le propriétaire avec preuve jointe')
    atomic_json(STATE,s,backup=True); event('buffer_resolved',{'id':bid,'source':'human_report'}); WAKE.set()
    return b

def evolution_plan(s=None):
    s=s or load_state(); result=[]
    for b in sorted(open_buffers(s),key=lambda x:(-x.get('importance',0),-x.get('risk',0),x.get('first_seen_at','')))[:8]:
        risk=float(b.get('risk',0)); irreversible=float(b.get('irreversibility',0))
        uncertain=float(b.get('uncertainty',0.5)); seen=int(b.get('seen',1))
        if risk>=0.6 or irreversible>=0.5:
            phase='stabilisation'
            next_step='Décrire le danger et la marge de sécurité; préserver l’état avant un essai réversible.'
            why='Le risque ou l’irréversibilité exigent une preuve plus forte avant de changer le système.'
        elif seen>=int(policy()['buffer_internalize_seen']):
            phase='conciliation'
            next_step='Comparer les occurrences et un contre-exemple; proposer une règle locale si elle réduit réellement le résidu.'
            why='La répétition fournit un candidat d’apprentissage, pas une résolution ni une permission d’automatiser.'
        elif uncertain>=0.55:
            phase='exploration'
            next_step='Observer un exemple concret et un contre-exemple; préparer la plus petite expérience locale.'
            why='Le résultat reste incertain : clarifier la différence avant d’investir davantage d’énergie.'
        else:
            phase='conciliation'
            next_step='Tester une action locale et réversible, puis comparer le résultat au but exprimé.'
            why='Le besoin est assez précis pour essayer une petite contribution mesurable.'
        origin=b.get('origin_hypothesis') or {}
        cause=origin.get('kind')
        if phase!='stabilisation' and cause=='internal':
            next_step='Reproduire le signal et la sortie dans le même sous-système, puis chercher un contre-exemple.'
            why='Cause interne déclarée par une personne ; le lien causal reste à tester.'
        elif phase!='stabilisation' and cause=='translation':
            next_step='Comparer les deux représentations et la différence perdue ; tester une traduction candidate sur un autre cas.'
            why='Perte de traduction déclarée par une personne ; aucune fidélité n’a encore été mesurée.'
        elif phase!='stabilisation' and cause=='conciliation':
            next_step='Mettre les deux propositions et leurs contraintes côte à côte ; chercher une action compatible ou garder le conflit ouvert.'
            why='Conflit déclaré par une personne ; une proposition commune ne doit pas effacer les désaccords.'
        if b.get('work_task'):
            phase='exploration'
            next_step=('Décrire une situation de départ et le résultat attendu dans l’accueil.'
                       if b['work_task']['phase']=='needs_example' else
                       'Utiliser la fiche pour concevoir une aide, puis vérifier son résultat sur des cas réels. Cette exécution reste à implémenter.')
            why='Une description prépare l’apprentissage ; elle ne démontre aucune capacité et ne donne aucune permission.'
            observed=learning.assessment(s,b['id'])
            if observed['status']!='unobserved':
                phase='conciliation'
                next_step=('Conserver le cas qui bloque et tester une amélioration ciblée à partir des retours.'
                           if observed['status']=='needs_work' else
                           'Essayer un autre cas, puis un contre-exemple avant de généraliser la méthode.')
                why='Retours d’usage déclarés par une personne ; aucun droit d’exécution ni généralisation automatique.'
        if b.get('dialogue_need'):
            need=b['dialogue_need']
            phase='stabilisation' if need.get('phase')=='paused' else 'exploration'
            next_step=('Conserver ce besoin en pause jusqu’à ta décision de le reprendre.'
                       if need.get('phase')=='paused' else need.get('next_step','Clarifier le résultat souhaité.'))
            why='Besoin interprété à partir d’un message conservé ; aucune action extérieure ni résolution automatique.'
        result.append({'buffer_id':b['id'],'residual':b['residual'],
            'phase':phase,'next_step':next_step,'why':why,
            'origin_hypothesis':origin or None,
            'expected_evidence':b.get('acceptance','Mesure avant/après et vérification des contraintes'),
            'desired':b.get('desired'),'authority':b.get('authority'),
            'requires_human_decision':b.get('authority')=='human' or irreversible>=0.8,
            'status':'proposal'})
    return result

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def send_bytes(self,status,data,ctype):
        self.send_response(status); self.send_header("Content-Type",ctype)
        self.send_header("Content-Length",str(len(data))); self.send_header("Cache-Control","no-store")
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Referrer-Policy","no-referrer")
        self.send_header("Content-Security-Policy","default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        self.end_headers(); self.wfile.write(data)
    def send_json(self,obj,status=200):
        self.send_bytes(status,json.dumps(obj,ensure_ascii=False,separators=(",",":")).encode(),"application/json; charset=utf-8")
    def valid_host(self):
        return self.headers.get('Host') in {f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}
    def with_world(self,operation):
        original=self.path
        try:
            parsed=urllib.parse.urlsplit(original);params=urllib.parse.parse_qs(parsed.query,keep_blank_values=True)
            selected=params.pop('world',['main'])
            if len(selected)!=1: raise ValueError('Choisir un seul espace.')
            query=urllib.parse.urlencode(params,doseq=True)
            self.path=parsed.path+('?' + query if query else '')
            with worlds.using(selected[0]): return operation()
        except ValueError as exc: return self.send_json({'error':str(exc)},400)
        finally: self.path=original
    def do_GET(self): return self.with_world(self.scoped_GET)
    def do_POST(self):
        # Device credentials select their own space; browser owner credentials
        # and query parameters must never widen this narrow worker protocol.
        if urllib.parse.urlsplit(self.path).path in {'/api/devices/enrol','/api/devices/worker'}:
            return self.device_POST()
        return self.with_world(self.scoped_POST)
    def device_POST(self):
        if not self.valid_host(): return self.send_json({'error':'Hôte refusé'},403)
        if self.path not in {'/api/devices/enrol','/api/devices/worker'}:
            return self.send_json({'error':'Adresse de travailleur invalide'},400)
        if self.headers.get_all('Origin') is not None:
            return self.send_json({'error':'Origine navigateur refusée'},403)
        try:
            lengths=self.headers.get_all('Content-Length',[])
            if len(lengths)!=1 or self.headers.get_all('Transfer-Encoding'):
                raise ValueError('Longueur de requête unique requise')
            length=int(lengths[0]); maximum=1048576 if self.path.endswith('/worker') else 32768
            if not 1<=length<=maximum: return self.send_json({'error':'Requête trop grande ou vide'},413)
            self.connection.settimeout(5)
            obj=json.loads(self.rfile.read(length))
            if not isinstance(obj,dict): raise ValueError('Objet JSON requis')
            auth=self.headers.get_all('Authorization',[])
            token=None
            if self.path.endswith('/enrol'):
                if auth: raise PermissionError('Identifiants ambigus')
                action='enrol'
            else:
                if len(auth)!=1 or not re.fullmatch(r'Bearer [A-Za-z0-9_-]{32,256}',auth[0]):
                    raise PermissionError('Identifiant de travailleur requis')
                token=auth[0][7:]; action=obj.pop('action',None)
                if action not in {'poll','report'}: raise ValueError('Action de travailleur invalide')
            return self.send_json(devices.worker(sys.modules[__name__],action,obj,token))
        except PermissionError: return self.send_json({'error':'Travailleur non autorisé'},403)
        except (ValueError,TypeError,RuntimeError,OSError) as exc: return self.send_json({'error':str(exc)},400)
    def scoped_GET(self):
        if not self.valid_host(): return self.send_json({'error':'Hôte refusé'},403)
        try:
            with LOCK:
                s=load_state()
                parsed=urllib.parse.urlsplit(self.path)
                params=urllib.parse.parse_qs(parsed.query,keep_blank_values=True)
                assets={
                    '/assets/tao-center.js':('tao-center.js','text/javascript; charset=utf-8'),
                    '/assets/tao-center.css':('tao-center.css','text/css; charset=utf-8'),
                    '/app.webmanifest':('tao.webmanifest','application/manifest+json; charset=utf-8'),
                    '/assets/tao-icon.svg':('tao-icon.svg','image/svg+xml'),
                    '/assets/tao-icon-192.png':('tao-icon-192.png','image/png'),
                    '/assets/tao-icon-512.png':('tao-icon-512.png','image/png'),
                }
                if parsed.path in assets:
                    if params: raise ValueError('Cet élément statique ne prend aucun paramètre.')
                    filename,ctype=assets[parsed.path]
                    base=Path(__file__).resolve().parent
                    path=next((candidate for candidate in
                               (base/filename,base/'tao_frontend'/filename)
                               if candidate.is_file() and not candidate.is_symlink()),None)
                    if path is None:
                        raise OSError('Interface compilée absente du runtime.')
                    data=path.read_bytes()
                    if len(data)>2097152: raise OSError('Interface compilée trop volumineuse.')
                    return self.send_bytes(200,data,ctype)
                if parsed.path in {'/','/explore','/connect','/trends','/guide'}:
                    allowed=({'lang','view'} if parsed.path=='/' else
                             {'lang','type','arrival'} if parsed.path=='/explore' else {'lang'})
                    if set(params)-allowed or any(len(v)!=1 for v in params.values()):
                        raise ValueError('Paramètres de page inconnus ou répétés.')
                    locale=params.get('lang',['fr'])[0]
                    if locale not in ('fr','en'): raise ValueError('Langue disponible : fr ou en.')
                    selected_type=params.get('type',[None])[0]
                    if selected_type is not None and selected_type not in foundations.CONCEPTS:
                        raise ValueError('Type de repère inconnu.')
                    arrival=params.get('arrival',[None])[0]
                    if arrival not in (None,'1') or (arrival and selected_type):
                        raise ValueError('Vue d’arrivée invalide.')
                    if parsed.path=='/' and params.get('view')==['dialogue']:
                        return self.send_bytes(200,dashboard(s).encode(),'text/html; charset=utf-8')
                    if 'view' in params: raise ValueError('Vue inconnue.')
                    if parsed.path=='/':
                        import tao_centers_app
                        page=tao_centers_app.render(sys.modules[__name__],s,locale)
                    elif parsed.path=='/explore':
                        import tao_home_ui
                        # ``arrival=1`` is a compatibility alias for old
                        # bookmarks; C₀ is now the sole working entrance.
                        page=tao_home_ui.render(sys.modules[__name__],s,locale,
                                                selected_type=selected_type)
                    elif parsed.path=='/connect':
                        import tao_connection_ui
                        page=tao_connection_ui.render(sys.modules[__name__],locale)
                    elif parsed.path=='/guide':
                        import tao_guide_ui
                        page=tao_guide_ui.render(sys.modules[__name__],s,locale)
                    else:
                        import tao_trends_ui
                        page=tao_trends_ui.render(sys.modules[__name__],locale)
                    return self.send_bytes(200,page.encode(),'text/html; charset=utf-8')
                if center_routes.owns_get(self.path):
                    kind,value=center_routes.get(sys.modules[__name__],s,self.path)
                    if kind=='json': return self.send_json(value)
                    return self.send_bytes(200,value.encode(),'text/html; charset=utf-8')
                if workspace_routes.owns(self.path):
                    return self.send_json(workspace_routes.get(sys.modules[__name__],self.path))
                if self.path=='/api/connection/status':
                    import tao_connection_ui
                    return self.send_json(tao_connection_ui.status(sys.modules[__name__],self.server))
                if self.path=='/onboarding':
                    import tao_onboarding_ui
                    return self.send_bytes(200,tao_onboarding_ui.render(sys.modules[__name__],s).encode(),'text/html; charset=utf-8')
                if self.path=='/history':
                    import tao_onboarding_ui
                    return self.send_bytes(200,tao_onboarding_ui.render_archives(sys.modules[__name__],s).encode(),'text/html; charset=utf-8')
                if onboarding_routes.owns(self.path):
                    return self.send_json(onboarding_routes.get(sys.modules[__name__],self.path))
                if self.path=='/tools':
                    import tao_tools_ui
                    return self.send_bytes(200,tao_tools_ui.render(sys.modules[__name__],s).encode(),'text/html; charset=utf-8')
                if self.path=='/api/tools' or self.path.startswith(('/api/reuse/template?','/api/reuse/suggest?')):
                    return self.send_json(durable_tools.get(sys.modules[__name__],self.path))
                if self.path=='/devices':
                    import tao_devices_ui
                    return self.send_bytes(200,scoped_links(tao_devices_ui.page(sys.modules[__name__],s)).encode(),'text/html; charset=utf-8')
                if self.path=='/api/devices': return self.send_json(devices.owner_view(sys.modules[__name__]))
                if self.path.startswith('/api/devices/job?'):
                    params=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query,keep_blank_values=True)
                    if set(params)!={'id'} or len(params['id'])!=1: raise ValueError('Identifiant de travail unique requis')
                    return self.send_json(devices.job_view(sys.modules[__name__],params['id'][0]))
                if self.path=="/lexicon":
                    from tao_ui import render_lexicon
                    return self.send_bytes(200,scoped_links(render_lexicon(theory.load(THEORY))).encode(),"text/html; charset=utf-8")
                if self.path=='/work/brief':
                    return self.send_bytes(200,work.brief(s).encode(),'text/plain; charset=utf-8')
                if self.path=='/dialogue/export':
                    return self.send_bytes(200,dialogue.export(s).encode(),'text/plain; charset=utf-8')
                if self.path=='/dialogue/handoff':
                    return self.send_json(handoff.export(sys.modules[__name__]))
                if self.path=='/continuity/export':
                    return self.send_bytes(200,continuity.exports(sys.modules[__name__],s).encode(),'text/plain; charset=utf-8')
                if self.path.startswith('/dialogue/context?'):
                    ident=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get('id',[''])[0]
                    dialogue.load(sys.modules[__name__],ident)
                    payload=load_json(dialogue.file(sys.modules[__name__],ident).parent/'context.json')
                    if not payload: raise ValueError('Contexte introuvable')
                    return self.send_bytes(200,json.dumps(payload,ensure_ascii=False,indent=2).encode(),'text/plain; charset=utf-8')
                if self.path.startswith('/dialogue/archive?'):
                    ident=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get('id',[''])[0]
                    return self.send_bytes(200,dialogue.export(dialogue.read_archive(sys.modules[__name__],ident)).encode(),'text/plain; charset=utf-8')
                if self.path.startswith('/api/dialogue?'):
                    ident=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get('id',[''])[0]
                    return self.send_json(dialogue.view(sys.modules[__name__],ident))
                if self.path.startswith('/api/adaptation?'):
                    ident=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get('id',[''])[0]
                    return self.send_json(adaptation.view(sys.modules[__name__],ident))
                if self.path=="/health":
                    stale=epoch()-s.get('last_cycle_epoch',0)>max(60,s.get('scheduler',{}).get('sleep_seconds',30)+30)
                    theory_ok=load_json(THEORY_PTR)==THEORY
                    return self.send_json({"ok":not stale and theory_ok,"theory_ok":theory_ok,"node_version":NODE_VERSION,"cycles":s.get("cycles"),"stale":stale,"session":getattr(self.server,"session_id",None),"mobile":mobile_health()},503 if stale or not theory_ok else 200)
                routes={"/state":lambda:public_state(s),"/buffers":lambda:{"buffers":open_buffers(s)},
                    "/genome":genome,"/reflexes":reflexes,"/heritage":heritage,
                    "/habits":lambda:load_json(HABITS,{"habits":[]}),
                    "/theory":lambda:theory.load(THEORY),"/api/lexicon":lambda:theory.lookup(THEORY),
                    "/lens/snapshot":lambda:write_lens_snapshot(s),"/plan":lambda:evolution_plan(s)}
                if self.path in routes: return self.send_json(routes[self.path]())
                return self.send_json({"error":"not_found"},404)
        except (ValueError,RuntimeError,OSError) as exc: return self.send_json({'error':str(exc)},503)
    def scoped_POST(self):
        if not self.valid_host(): return self.send_json({'error':'Hôte refusé'},403)
        origin=self.headers.get('Origin')
        if origin and origin!='http://'+self.headers.get('Host',''): return self.send_json({'error':'Origine refusée'},403)
        if not TOKEN or not secrets.compare_digest(self.headers.get('X-Tao-Token',''),TOKEN):
            return self.send_json({'error':'Session locale invalide; recharger la page'},403)
        try:
            length=int(self.headers.get('Content-Length','0'))
            maximum=(backup.MAX_BODY if self.path.startswith('/api/backup/') else
                     onboarding_routes.MAX_BODY if onboarding_routes.owns(self.path) else
                     65536 if self.path.startswith('/api/centers/contract/') else
                     262144 if self.path=='/api/dialogue/handoff' or durable_tools.owns(self.path) else
                     32768)
            if length<1 or length>maximum: return self.send_json({'error':'Requête trop grande ou vide'},413)
            self.connection.settimeout(5)
            raw=self.rfile.read(length)
            obj=(backup.request_json(raw) if self.path.startswith('/api/backup/') else
                 json.loads(raw,object_pairs_hook=onboarding_routes.unique_object if onboarding_routes.owns(self.path) or workspace_routes.owns(self.path) or self.path.startswith('/api/connection/') or self.path.startswith('/api/centers/') or self.path.startswith('/api/update/') else dict))
            if not isinstance(obj,dict): raise ValueError('Objet JSON requis')
            if self.path.startswith('/api/backup/'):
                routes={
                    '/api/backup/export':(
                        {'scope'},lambda:backup.export(sys.modules[__name__])),
                    '/api/backup/inspect':(
                        {'bundle'},lambda:backup.inspect(sys.modules[__name__],obj.get('bundle'))),
                    '/api/backup/restore':(
                        {'bundle','review_digest','expected_current_digest','confirmed'},
                        lambda:backup.restore(sys.modules[__name__],obj.get('bundle'),
                            obj.get('review_digest'),obj.get('expected_current_digest'),
                            obj.get('confirmed',False))),
                    '/api/backup/rollback':(
                        {'after_digest','confirmed'},lambda:backup.rollback(
                            sys.modules[__name__],obj.get('after_digest'),obj.get('confirmed',False))),
                }
                if self.path not in routes: return self.send_json({'error':'not_found'},404)
                fields,operation=routes[self.path]
                if set(obj)!=fields or (self.path=='/api/backup/export' and obj.get('scope')!='core'):
                    raise ValueError('Champs de sauvegarde incomplets ou inconnus.')
                return self.send_json(operation())
            if workspace_routes.owns(self.path):
                return self.send_json(workspace_routes.post(sys.modules[__name__],self.path,obj))
            if self.path.startswith('/api/connection/'):
                import tao_connection_ui
                load_state()  # Validate the selected space before an owner action.
                return self.send_json(tao_connection_ui.post(sys.modules[__name__],self.server,self.path,obj))
            if onboarding_routes.owns(self.path):
                return self.send_json(onboarding_routes.post(sys.modules[__name__],self.path,obj))
            if durable_tools.owns(self.path):
                return self.send_json(durable_tools.post(sys.modules[__name__],self.path,obj))
            if center_routes.owns_post(self.path):
                result=center_routes.post(sys.modules[__name__],self.path,obj)
                return self.send_json(result) if result is not None else self.send_json({'error':'not_found'},404)
            device_routes={
                '/api/devices/pair':({'label','revision'},lambda:devices.create_pairing(sys.modules[__name__],obj.get('label'),obj.get('revision'))),
                '/api/devices/device':({'id','action','revision'},lambda:devices.owner_device(sys.modules[__name__],obj.get('id'),obj.get('action'),obj.get('revision'))),
                '/api/devices/project-need':({'need_id','need_revision','expected_snapshot'},lambda:devices.project_need(sys.modules[__name__],obj.get('need_id'),obj.get('need_revision'),obj.get('expected_snapshot'))),
                '/api/devices/jobs':({'device_id','buffer_id','revision','expected_snapshot'},lambda:devices.enqueue(sys.modules[__name__],obj.get('device_id'),obj.get('buffer_id'),obj.get('revision'),obj.get('expected_snapshot'))),
                '/api/devices/job':({'id','action','revision','review_digest','confirmed'},lambda:devices.owner_job(sys.modules[__name__],obj.get('id'),obj.get('action'),obj.get('revision'),obj.get('review_digest'),obj.get('confirmed',False)))
            }
            if self.path in device_routes:
                allowed,operation=device_routes[self.path]
                if self.path in ('/api/devices/jobs','/api/devices/project-need') and not isinstance(obj.get('expected_snapshot'),dict):
                    raise ValueError('Relire les trois champs du besoin ou du tampon avant de poursuivre')
                if set(obj)-allowed: raise ValueError('Champs d’appareil inconnus')
                return self.send_json(operation())
            if self.path=='/api/worlds/create':
                return self.send_json(worlds.create(sys.modules[__name__],obj.get('title'),obj.get('parent_id'),obj.get('description',''),obj.get('revision',0)))
            if self.path=='/api/worlds/presentation':
                return self.send_json(worlds.save_presentation(sys.modules[__name__],obj.get('view'),obj.get('revision',0)))
            if self.path=='/api/worlds/transfer':
                return self.send_json(worlds.transfer(sys.modules[__name__],obj.get('target_id'),obj.get('text'),obj.get('source_quote'),obj.get('source_message_id'),obj.get('revision',0)))
            if self.path=='/api/story': return self.send_json(set_story(obj.get('text','')))
            if self.path=='/api/dialogue/send':
                return self.send_json(dialogue.send(sys.modules[__name__],obj.get('text'),obj.get('revision',0),obj.get('nonce'),obj.get('focus'),obj.get('intent','auto'),obj.get('model'),obj.get('input_reference')))
            if self.path=='/api/dialogue/retry':
                return self.send_json(dialogue.retry(sys.modules[__name__],obj.get('id'),obj.get('revision',0)))
            if self.path=='/api/dialogue/memory':
                return self.send_json(dialogue.save_memory(sys.modules[__name__],obj.get('text',''),obj.get('revision',0),obj.get('include_archives')))
            if self.path=='/api/dialogue/handoff':
                if set(obj)-{'document','revision'}: raise ValueError('Champs de transfert inconnus')
                return self.send_json(handoff.import_memory(sys.modules[__name__],obj.get('document'),obj.get('revision',0)))
            if self.path=='/api/dialogue/prepare':
                return self.send_json(dialogue.prepare(sys.modules[__name__],obj.get('id'),obj.get('need_id')))
            if self.path=='/api/continuity/settings':
                return self.send_json(continuity.save_settings(sys.modules[__name__],obj.get('enabled'),obj.get('revision',0)))
            if self.path=='/api/continuity/note':
                return self.send_json(continuity.edit_note(sys.modules[__name__],obj.get('id'),obj.get('text'),obj.get('status'),obj.get('revision',0)))
            if self.path=='/api/continuity/need':
                return self.send_json(continuity.need_action(sys.modules[__name__],obj.get('id'),obj.get('action'),obj.get('revision',0),obj.get('values'),obj.get('evidence','')))
            if self.path=='/api/dialogue/remember':
                return self.send_json(dialogue.remember(sys.modules[__name__],obj.get('id')))
            if self.path=='/api/dialogue/cancel':
                return self.send_json(dialogue.cancel(sys.modules[__name__],obj.get('id')))
            if self.path=='/api/dialogue/new':
                return self.send_json(dialogue.new_discussion(sys.modules[__name__],obj.get('revision',0)))
            if self.path=='/api/work/context':
                return self.send_json(work.save_context(sys.modules[__name__],obj.get('description'),obj.get('keep_learning',''),obj.get('boundaries',''),obj.get('revision',0)))
            if self.path=='/api/work/tasks':
                return self.send_json(work.add_task(sys.modules[__name__],obj.get('title')))
            if self.path=='/api/work/example':
                return self.send_json(work.save_example(sys.modules[__name__],obj.get('id'),obj.get('situation'),obj.get('expected'),obj.get('boundaries',''),obj.get('revision',1)))
            if self.path=='/api/adaptation':
                return self.send_json(adaptation.request(sys.modules[__name__],obj.get('task_id'),obj.get('action'),obj.get('id'),obj.get('review_digest'),obj.get('confirmed',False),obj.get('method_ids')))
            if self.path=='/api/learning/report':
                return self.send_json(learning.report(sys.modules[__name__],obj.get('task_id'),obj.get('adaptation_id'),obj.get('outcome'),obj.get('case'),obj.get('observed'),obj.get('remaining',''),obj.get('revision',0)))
            if self.path=='/api/learning/method':
                return self.send_json(learning.create_method(sys.modules[__name__],obj.get('report_id'),obj.get('values'),obj.get('confirmed',False),obj.get('revision',0)))
            if self.path=='/api/learning/withdraw':
                return self.send_json(learning.suspend_method(sys.modules[__name__],obj.get('id'),obj.get('revision',0)))
            if self.path=='/api/buffers': return self.send_json(add_buffer(obj.get('residual'),obj.get('desired'),obj.get('acceptance'),obj.get('origin_type','undetermined'),obj.get('trace')))
            if self.path=='/api/resolve': return self.send_json(close_buffer(obj.get('id'),obj.get('evidence')))
            if self.path=='/api/stop': STOP.set(); WAKE.set(); return self.send_json({'ok':True})
            if self.path=='/api/wake': WAKE.set(); return self.send_json({'ok':True,'scheduled':True})
            return self.send_json({'error':'not_found'},404)
        except (ValueError,TypeError,RuntimeError,OSError) as exc: return self.send_json({'error':str(exc)},400)

def proc_start(pid):
    try:
        fields=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
        return fields[19] if fields[0]!='Z' else None
    except (OSError,IndexError): return None

def local_request(port,path,data=None,token=None):
    if type(port) is not int or not 1024<=port<=65535: raise ValueError('Port local invalide')
    headers={'Content-Type':'application/json'}
    if token: headers['X-Tao-Token']=token
    req=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=data,headers=headers)
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=2) as response:
        return json.loads(response.read(32768))

def stop_daemon():
    row=load_json(ROOT/'session.json',{}) or {}
    if not row: return {'stopped':False,'reason':'not_running'}
    try: health=local_request(row['port'],'/health')
    except OSError: return {'stopped':False,'reason':'not_running'}
    if health.get('session')!=row.get('id'): raise ValueError('Session locale différente; arrêt refusé')
    local_request(row['port'],'/api/stop',b'{}',row['token'])
    for _ in range(100):
        try:
            health=local_request(row['port'],'/health')
            if health.get('session')!=row['id']: return {'stopped':True}
        except OSError: return {'stopped':True}
        time.sleep(.05)
    raise RuntimeError('Arrêt en cours')

def mobile_health():
    try:
        state=mobile.status(sys.modules[__name__])
        return {'enabled':state['enabled'],'ready':state['running'] and not state['restart_required']}
    except (ValueError,TypeError,OSError,KeyError):
        return {'enabled':True,'ready':False,'error':'Configuration mobile à vérifier sur cet ordinateur.'}

def setup_mobile(port=8792,https_port=8443):
    """Read local Tailscale metadata; configure only Tao, never the network."""
    exe=shutil.which('tailscale')
    if not exe: raise ValueError('Installer et connecter Tailscale sur cet ordinateur et le téléphone, puis reprendre tao mobile setup.')
    def read_status(arguments):
        try: result=subprocess.run([exe,*arguments],capture_output=True,text=True,timeout=10)
        except (OSError,subprocess.SubprocessError): raise ValueError('Tailscale ne répond pas ; vérifier sa connexion sur cet ordinateur.') from None
        if result.returncode or len(result.stdout)>2*1024*1024: raise ValueError('État Tailscale indisponible ; vérifier sa connexion sur cet ordinateur.')
        try: return json.loads(result.stdout)
        except ValueError: raise ValueError('État Tailscale illisible ; utiliser la configuration manuelle documentée.') from None
    state=read_status(['status','--json'])
    if not isinstance(state,dict) or state.get('BackendState')!='Running': raise ValueError('Connecter Tailscale sur cet ordinateur avant de continuer.')
    own=state.get('Self',{});users=state.get('User',{})
    if not isinstance(own,dict) or not isinstance(users,dict): raise ValueError('Identité Tailscale introuvable ; utiliser la configuration manuelle.')
    profile=users.get(str(own.get('UserID')),{});dns=own.get('DNSName')
    if not isinstance(profile,dict) or not isinstance(dns,str) or not dns: raise ValueError('Identité personnelle Tailscale requise ; les appareils tagués ne sont pas pris en charge.')
    origin='https://'+dns.rstrip('.')+(':'+str(https_port) if https_port!=443 else '')
    # Refuse to instruct replacement of an existing Serve/Funnel listener.
    serve=read_status(['serve','status','--json'])
    if serve is None: serve={}
    if not isinstance(serve,dict): raise ValueError('Configuration Serve illisible ; ne pas remplacer les services existants.')
    occupied=bool(serve.get('TCP',{}).get(str(https_port))) if isinstance(serve.get('TCP',{}),dict) else bool(serve.get('TCP'))
    if occupied:
        web=serve.get('Web',{});authority=urllib.parse.urlsplit(origin).netloc
        entry=web.get(authority,web.get(dns.rstrip('.')+':'+str(https_port),{})) if isinstance(web,dict) else {}
        expected={'/':{'Proxy':'http://127.0.0.1:'+str(port)}}
        funnels=serve.get('AllowFunnel',{})
        if not isinstance(entry,dict) or entry.get('Handlers')!=expected or not isinstance(funnels,dict) or any(funnels.values()):
            raise ValueError('Ce port Tailscale sert déjà un autre accès. Sa configuration est conservée ; consulter tao mobile configure et le guide.')
    result=mobile.configure(sys.modules[__name__],origin,profile.get('LoginName'),port)
    result['next_steps']=['Relancer bash bootstrap/install.sh depuis les sources pour activer le point d’accès local.',result['serve_command'],'tao mobile pair --name "Mon téléphone"']
    result['network_changed']=False
    return result

def daemon():
    global TOKEN
    ensure_files(); p=policy(); STOP.clear(); WAKE.clear()
    singleton=open(ROOT/'daemon.lock','a+')
    try:
        try: fcntl.flock(singleton,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError('Tao tourne déjà pour cet état')
        # Bind synchronously: an occupied port must make startup fail visibly.
        srv=ThreadingHTTPServer((p['http_host'],p['http_port']),Handler)
        srv.daemon_threads=True; TOKEN=secrets.token_urlsafe(32); srv.session_id=secrets.token_hex(16)
        atomic_json(ROOT/'session.json',{'id':srv.session_id,'port':p['http_port'],'token':TOKEN})
        def stopping(*args): STOP.set(); WAKE.set()
        old={sig:signal.signal(sig,stopping) for sig in [signal.SIGINT,signal.SIGTERM]}
        atomic_json(ROOT/'pid.json',{'pid':os.getpid(),'start':proc_start(os.getpid()),'script':str(Path(__file__).resolve())})
        mobile_listener=None
        try:
            cycle()
            try:
                mobile_listener=mobile.start(sys.modules[__name__])
                if mobile_listener is not None:
                    with LOCK:
                        s=load_state()
                        resolve_buffer(s['buffers'],'interface.mobile','Le point d’accès local mobile est démarré ; la liaison au téléphone reste à vérifier.')
                        atomic_json(STATE,s,backup=True)
            except (OSError,ValueError,RuntimeError,TypeError):
                with LOCK:
                    s=load_state()
                    touch_buffer(s['buffers'],'interface.mobile','environment','Accès mobile indisponible ; Tao reste accessible sur cet ordinateur. Consulter tao mobile status.',.8,.3,.4)
                    atomic_json(STATE,s,backup=True)
                event('mobile_unavailable',{'local_node_preserved':True})
            thread=threading.Thread(target=srv.serve_forever,kwargs={'poll_interval':.25},daemon=True); thread.start()
            event('daemon_started',{'pid':os.getpid(),'node_version':NODE_VERSION})
            while not STOP.is_set():
                wait=load_state()['scheduler']['sleep_seconds']; WAKE.wait(wait); WAKE.clear()
                if not STOP.is_set(): cycle()
        finally:
            STOP.set()
            if hasattr(srv,'tao_connection'): srv.tao_connection.close()
            if mobile_listener is not None: mobile.stop(mobile_listener)
            if 'thread' in locals(): srv.shutdown(); thread.join(timeout=3)
            srv.server_close(); (ROOT/'pid.json').unlink(missing_ok=True); (ROOT/'session.json').unlink(missing_ok=True)
            for sig,handler in old.items(): signal.signal(sig,handler)
    finally: singleton.close()

@transaction
def set_story(text):
    if not text.strip() or len(text)>8000: raise ValueError("Histoire requise, 8000 caractères maximum")
    row={"schema":"tao.story.v1","id":"story:local.primary","authority":"human","status":"active","text":text.strip(),"updated_at":now()}
    if worlds.current()=='main': atomic_json(STORY,row)
    else:
        row['id']='story:'+worlds.current();s=load_state();s['story']=row;atomic_json(STATE,s,backup=True)
    event("story_set",{"authority":"human","world_id":worlds.current()}); WAKE.set(); return row

@transaction
def consolidate():
    s=load_state(); habits,created=compile_habits(s)
    s["development"]["internalization_candidates"]=internalization_candidates(s)
    s["observer_model"]["specialization_candidates"]=specialization_candidates(s)
    s["last_consolidation_at"]=now()
    atomic_json(STATE,s,backup=True)
    event("consolidated",{"new_habits":created,"candidates":len(s["development"]["internalization_candidates"])})
    return {"new_habits":created,"habits":habits,"development":s["development"],"observer_model":s["observer_model"]}

def doctor(require_running=False):
    with LOCK:
        s=load_state(); p=policy(); checked_state(STATE)
        row=load_json(ROOT/'session.json',{}) or {}
    running=False; stale=True; health_ok=False; runtime_version=None; active_api=None
    configured_api=f"http://127.0.0.1:{p['http_port']}"
    if isinstance(row,dict) and row.get('id'):
        try:
            try:
                health=local_request(row['port'],'/health')
            except urllib.error.HTTPError as exc:
                # An unhealthy but identified daemon is still running. Preserve
                # its actual endpoint instead of advertising an unbound new port.
                if exc.code!=503: raise
                with exc: health=json.loads(exc.read(32768))
            if isinstance(health,dict) and health.get('session')==row['id']:
                running=True; active_api=f"http://127.0.0.1:{row['port']}"
                stale=health.get('stale') is not False
                runtime_version=health.get('node_version') if isinstance(health.get('node_version'),str) else None
                health_ok=health.get('ok') is True and health.get('theory_ok') is True and not stale
        except (OSError,ValueError,KeyError,TypeError): pass
    runtime_matches=runtime_version==NODE_VERSION if running else None
    configuration_matches=active_api==configured_api if running else None
    restart_reasons=[]
    if running and not runtime_matches: restart_reasons.append('runtime_version_mismatch')
    if running and not configuration_matches: restart_reasons.append('configured_endpoint_changed')
    service_ok=running and health_ok and runtime_matches and configuration_matches
    theory_status=theory.summary(THEORY); theory_ok=load_json(THEORY_PTR)==THEORY
    return {'ok':theory_ok and (service_ok if running or require_running else True),'node_version':NODE_VERSION,
       'theory':theory_status,'theory_pointer_ok':theory_ok,
       'python':sys.version.split()[0],'state_checksum_ok':True,'running':running,'stale':stale,
       'state_path':str(STATE),'api':active_api or configured_api,
       'active_api':active_api,'configured_api':configured_api,
       'health_ok':health_ok,'runtime_version':runtime_version,'runtime_matches':runtime_matches,
       'configuration_matches':configuration_matches,'configuration_scope':'http_endpoint',
       'restart_required':bool(restart_reasons),
       'restart_reasons':restart_reasons,'qualification':'local_integrity_and_basal_service',
       'not_checked':['provider_authentication','provider_quota','external_network','device_execution'],
       'commons':'opt_in_enabled' if p['commons_read'] else 'disabled',
       'codex_available':adaptation.executable(sys.modules[__name__],'codex') is not None,'git_available':shutil.which('git') is not None,
       'external_ai_auto':False,'self_modify_code':False,'cycles':s.get('cycles'),'mobile':mobile_health()}

def main():
    ap=argparse.ArgumentParser(prog='tao',description='Tao — observer, conserver, expérimenter')
    ap.add_argument('--world',help='Identifiant de l’espace ; principal par défaut')
    sub=ap.add_subparsers(dest='cmd')
    device_worker.add_parser(sub)
    durable_tools.add_parser(sub)
    onboarding_routes.add_parser(sub)
    update.add_parser(sub)
    for name in ['status','cycle','buffers','consolidate','daemon','heritage','habits','plan','stop','ecology']:
        sub.add_parser(name)
    birth=sub.add_parser('birth',help='Créer un descendant local dormant, sans mémoire ni permissions privées')
    birth.add_argument('destination'); birth.add_argument('--purpose',required=True); birth.add_argument('--port',type=int,required=True)
    birth.add_argument('--method',action='append',default=[],help='Méthode généralisée explicitement choisie ; répétable, dix maximum')
    sub.add_parser('doctor').add_argument('--require-running',action='store_true')
    hp=sub.add_parser('handoff',help='Transférer explicitement la mémoire choisie vers un autre Tao')
    hs=hp.add_subparsers(dest='action',required=True)
    hs.add_parser('export')
    hi=hs.add_parser('import'); hi.add_argument('file'); hi.add_argument('--revision',type=int,required=True)
    mp=sub.add_parser('mobile',help='Relier un navigateur mobile au même Tao via Tailscale Serve privé')
    ms=mp.add_subparsers(dest='action',required=True)
    setup=ms.add_parser('setup',help='Préparer Tao depuis le compte Tailscale local ; réseau inchangé')
    setup.add_argument('--port',type=int,default=8792);setup.add_argument('--https-port',type=int,choices=[443,8443],default=8443)
    configure=ms.add_parser('configure',help='Configurer manuellement le point d’accès mobile privé')
    configure.add_argument('--origin',required=True);configure.add_argument('--owner',required=True)
    configure.add_argument('--port',type=int,default=8792)
    pair=ms.add_parser('pair');pair.add_argument('--name',default='Mon téléphone')
    ms.add_parser('status');ms.add_parser('disable')
    ms.add_parser('revoke').add_argument('id',help='Identifiant de l’appareil, ou all')
    aw=sub.add_parser('adapt-worker',help=argparse.SUPPRESS)
    aw.add_argument('id'); aw.add_argument('operation',choices=['generate','verify','apply'])
    dw=sub.add_parser('dialogue-worker',help=argparse.SUPPRESS); dw.add_argument('id')
    lx=sub.add_parser('lexicon'); lx.add_argument('term',nargs='?')
    th=sub.add_parser('theory'); ths=th.add_subparsers(dest='action')
    ths.add_parser('show'); ths.add_parser('proposals')
    proposal=ths.add_parser('propose'); proposal.add_argument('term'); proposal.add_argument('--buffer',required=True)
    for field in ['definition','reason','evidence','counterexample','migration','rollback']:
        proposal.add_argument('--'+field,required=True)
    sp=sub.add_parser('story'); sp.add_argument('action',choices=['show','set']); sp.add_argument('text',nargs='*')
    bp=sub.add_parser('buffer'); bp.add_argument('residual'); bp.add_argument('--desired',required=True); bp.add_argument('--acceptance',required=True)
    bp.add_argument('--origin',choices=sorted(ORIGIN_TYPES),default='undetermined')
    for name in sorted(TRACE_FIELDS): bp.add_argument('--'+name)
    resolve=sub.add_parser('resolve'); resolve.add_argument('id'); resolve.add_argument('--evidence',required=True)
    at=sub.add_parser('atelier'); ats=at.add_subparsers(dest='action',required=True)
    atp=ats.add_parser('prepare'); atp.add_argument('repo'); atp.add_argument('--buffer',required=True)
    for name in ['run','show','diff','verify','accept','rollback','archive','restore']:
        c=ats.add_parser(name); c.add_argument('id')
        if name=='verify': c.add_argument('--trust-candidate',action='store_true')
    ats.add_parser('list').add_argument('--archived',action='store_true',help='Inclure les expériences archivées, conservées en lecture')
    watch=ats.add_parser('watch'); watch.add_argument('repo'); watch.add_argument('--max-runs',type=int,default=2); watch.add_argument('--interval',type=int,default=900); watch.add_argument('--hours',type=int,default=2)
    args=ap.parse_args()
    try:
        if args.world: os.environ['TAO_WORLD']=args.world
        ensure_files()
        if args.cmd=='daemon':
            if worlds.current()!='main': raise ValueError('Le service basal se lance dans l’espace principal ; les espaces se choisissent dans l’interface.')
            daemon(); return 0
        if args.cmd=='atelier':
            import tao_workshop
            # Dedicated lock; long AI runs do not block the basal state loop.
            with open(ROOT/'workshop.lock','a+') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX)
                result=tao_workshop.command(sys.modules[__name__],args)
        elif args.cmd in {'reuse','bridge','tools'}:
            result=durable_tools.command(sys.modules[__name__],args)
            if args.cmd=='bridge' and args.action=='serve': return result
        elif args.cmd=='onboarding': result=onboarding_routes.command(sys.modules[__name__],args)
        elif args.cmd=='update': result=update.command(sys.modules[__name__],args)
        elif args.cmd=='device': result=device_worker.command(sys.modules[__name__],args)
        elif args.cmd=='story': result=set_story(' '.join(args.text)) if args.action=='set' else story()
        elif args.cmd=='buffer': result=add_buffer(args.residual,args.desired,args.acceptance,args.origin,
            {name:getattr(args,name) for name in TRACE_FIELDS if getattr(args,name) is not None})
        elif args.cmd=='resolve': result=close_buffer(args.id,args.evidence)
        elif args.cmd=='doctor': result=doctor(args.require_running)
        elif args.cmd=='handoff':
            if args.action=='export': result=handoff.export(sys.modules[__name__])
            else:
                with open(args.file,'rb') as stream: document=stream.read(262145)
                result=handoff.import_memory(sys.modules[__name__],document,args.revision)
        elif args.cmd=='mobile':
            if args.action=='setup': result=setup_mobile(args.port,args.https_port)
            elif args.action=='configure': result=mobile.configure(sys.modules[__name__],args.origin,args.owner,args.port)
            elif args.action=='pair': result=mobile.pair(sys.modules[__name__],args.name)
            elif args.action=='revoke': result=mobile.revoke(sys.modules[__name__],args.id)
            elif args.action=='disable': result=mobile.disable(sys.modules[__name__])
            else: result=mobile.status(sys.modules[__name__])
        elif args.cmd=='adapt-worker': result=adaptation.worker(sys.modules[__name__],args.id,args.operation)
        elif args.cmd=='dialogue-worker': result=dialogue.worker(sys.modules[__name__],args.id)
        elif args.cmd=='lexicon': result=theory.lookup(THEORY,args.term)
        elif args.cmd=='theory':
            if args.action=='show': result=theory.load(THEORY)
            elif args.action=='proposals': result=theory.proposals(sys.modules[__name__])
            elif args.action=='propose': result=theory.propose(sys.modules[__name__],args.term,args.buffer,
                args.definition,args.reason,args.evidence,args.counterexample,args.migration,args.rollback)
            else: result=theory.summary(THEORY)
        elif args.cmd=='ecology': result=ecology.snapshot(sys.modules[__name__])
        elif args.cmd=='birth': result=ecology.birth(sys.modules[__name__],args.destination,args.purpose,args.port,args.method)
        else:
            actions={'status':public_state,'cycle':lambda:public_state(cycle()),'buffers':lambda:{'buffers':open_buffers(load_state())},
              'consolidate':consolidate,'heritage':heritage,'habits':lambda:load_json(HABITS,{}),'plan':evolution_plan,'stop':stop_daemon}
            result=actions.get(args.cmd,public_state)()
        print(json.dumps(result,ensure_ascii=False,indent=2))
        if args.cmd=='reuse' and args.action=='qualify' and not result.get('qualification',{}).get('ok'):
            return 1
        if args.cmd=='tools' and args.action=='execute' and result.get('status')!='succeeded':
            return 1
        return 1 if isinstance(result,dict) and (result.get('ok') is False or result.get('status') in {'agent_failed','test_failed'}) else 0
    except KeyboardInterrupt:
        print('Atelier interrompu; candidats conservés.',file=sys.stderr); return 130
    except (ValueError,RuntimeError,OSError) as exc:
        print(json.dumps({'ok':False,'error':str(exc)},ensure_ascii=False),file=sys.stderr); return 1

if __name__=='__main__':
    raise SystemExit(main())
